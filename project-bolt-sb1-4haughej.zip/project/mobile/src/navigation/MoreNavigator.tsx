import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { MoreStackParamList } from '../types/navigation';
import MoreMainScreen from '../screens/more/MoreMainScreen';

const Stack = createStackNavigator<MoreStackParamList>();

export default function MoreNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MoreMain" component={MoreMainScreen} />
    </Stack.Navigator>
  );
}
