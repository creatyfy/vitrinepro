import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { TrainingStackParamList } from '../types/navigation';
import MyTrainingsScreen from '../screens/training/MyTrainingsScreen';

const Stack = createStackNavigator<TrainingStackParamList>();

export default function TrainingNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MyTrainings" component={MyTrainingsScreen} />
    </Stack.Navigator>
  );
}
