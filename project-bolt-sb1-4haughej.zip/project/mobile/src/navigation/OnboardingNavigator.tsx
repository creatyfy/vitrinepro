import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { OnboardingStackParamList } from '../types/navigation';
import WelcomeScreen from '../screens/onboarding/WelcomeScreen';
import UserTypeSelectionScreen from '../screens/onboarding/UserTypeSelectionScreen';
import GenderSelectionScreen from '../screens/onboarding/GenderSelectionScreen';
import TrainingFrequencyScreen from '../screens/onboarding/TrainingFrequencyScreen';
import PlayerPositionSelectionScreen from '../screens/onboarding/PlayerPositionSelectionScreen';
import CongratulationsScreen from '../screens/onboarding/CongratulationsScreen';

const Stack = createStackNavigator<OnboardingStackParamList>();

export default function OnboardingNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="UserTypeSelection" component={UserTypeSelectionScreen} />
      <Stack.Screen name="GenderSelection" component={GenderSelectionScreen} />
      <Stack.Screen name="TrainingFrequency" component={TrainingFrequencyScreen} />
      <Stack.Screen name="PlayerPositionSelection" component={PlayerPositionSelectionScreen} />
      <Stack.Screen name="Congratulations" component={CongratulationsScreen} />
    </Stack.Navigator>
  );
}
