import { supabase } from '../config/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface SignUpData {
  email: string;
  password: string;
  userData: {
    full_name?: string;
    phone?: string;
    birth_date?: string;
    gender?: string;
    height?: number;
    weight?: number;
    user_type?: 'athlete' | 'club' | 'agent';
    player_position?: string;
    goals?: string[];
    objective?: string;
    obstacles?: string[];
    training_frequency?: string;
    referral_source?: string;
    referral_code?: string;
  };
}

export interface SignInData {
  email: string;
  password: string;
}

export const authService = {
  async signUp(data: SignUpData) {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: data.userData,
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        const birthDate = data.userData.birth_date
          ? this.convertBirthDateToISO(data.userData.birth_date)
          : null;

        const { error: profileError } = await supabase
          .from('profiles')
          .update({
            full_name: data.userData.full_name,
            phone: data.userData.phone,
            birth_date: birthDate,
            gender: data.userData.gender,
            height: data.userData.height,
            weight: data.userData.weight,
            user_type: data.userData.user_type,
            player_position: data.userData.player_position,
            goals: data.userData.goals,
            objective: data.userData.objective,
            obstacles: data.userData.obstacles,
            training_frequency: data.userData.training_frequency,
            referral_source: data.userData.referral_source,
            referral_code: data.userData.referral_code,
          })
          .eq('id', authData.user.id);

        if (profileError) throw profileError;

        await AsyncStorage.setItem('user_id', authData.user.id);
      }

      return { user: authData.user, session: authData.session };
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  },

  async signIn(data: SignInData) {
    try {
      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (error) throw error;

      if (authData.user) {
        await AsyncStorage.setItem('user_id', authData.user.id);
      }

      return { user: authData.user, session: authData.session };
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  },

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      await AsyncStorage.removeItem('user_id');
    } catch (error) {
      console.error('Sign out error:', error);
      throw error;
    }
  },

  async getCurrentUser() {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) throw error;
      return user;
    } catch (error) {
      console.error('Get current user error:', error);
      return null;
    }
  },

  async getProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Get profile error:', error);
      return null;
    }
  },

  convertBirthDateToISO(birthDate: string): string {
    const parts = birthDate.split('/');
    if (parts.length === 3) {
      const [day, month, year] = parts;
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    return birthDate;
  },

  async checkSession() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      return session;
    } catch (error) {
      console.error('Check session error:', error);
      return null;
    }
  },
};
