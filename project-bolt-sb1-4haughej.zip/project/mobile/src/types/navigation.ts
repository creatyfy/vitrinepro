export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Login: undefined;
  ForgotPassword: undefined;
  MainApp: undefined;
};

export type OnboardingStackParamList = {
  Welcome: undefined;
  UserTypeSelection: undefined;
  GenderSelection: undefined;
  TrainingFrequency: undefined;
  VitrineProVisibility: undefined;
  HeightWeight: undefined;
  BirthDate: undefined;
  ReferralSource: undefined;
  ObjectiveSelection: undefined;
  ObstacleSelection: undefined;
  GoalsSelection: undefined;
  Results: undefined;
  VitrineKnowledge: undefined;
  SuccessStories: undefined;
  AthleteNameCollection: undefined;
  EmailCollection: undefined;
  PhoneCollection: undefined;
  ReferralCodeCollection: undefined;
  PlayerPositionSelection: undefined;
  LoadingScreen: undefined;
  Congratulations: undefined;
};

export type MainTabParamList = {
  Home: undefined;
  Trainings: undefined;
  Profile: undefined;
  More: undefined;
};

export type HomeStackParamList = {
  MainHub: undefined;
  TreinoDoDia: undefined;
  Challenge28: undefined;
  Challenge28DayDetail: { challengeId: string; day: number };
  DailyProgress: undefined;
  ProofHistory: undefined;
};

export type TrainingStackParamList = {
  MyTrainings: undefined;
  TrainingCategory: { categoryId: string };
  TrainingPreRoll: { categoryId: string; categoryName: string; videoUrl: string };
  TrainingExecution: { trainingId: string };
  ExerciseExecution: { exerciseId: string };
  TrainingProof: { sessionId: string };
  WeeklyProgram: undefined;
};

export type ProfileStackParamList = {
  ProfileMain: undefined;
  PlayerProfile: { userId: string };
  EditProfile: undefined;
  CareerOverview: undefined;
  VideoGallery: undefined;
  MedalsDetail: undefined;
};

export type MoreStackParamList = {
  MoreMain: undefined;
  Settings: undefined;
  Privacy: undefined;
  Support: undefined;
  Peneiras: undefined;
  Peladas: undefined;
  PeladaDetail: { peladaId: string };
  CreatePelada: undefined;
  Nutrition: undefined;
  DailyNutritionChallenge: undefined;
  NutritionHistory: undefined;
  Mindset: undefined;
  Ranking: undefined;
  Marketplace: undefined;
  ProductDetail: { productId: string };
  Checkout: undefined;
};
