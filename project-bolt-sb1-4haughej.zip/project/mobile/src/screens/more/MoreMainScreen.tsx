import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { authService } from '../../services/authService';

export default function MoreMainScreen() {
  const navigation = useNavigation();

  const menuItems = [
    { title: 'Configurações', icon: '⚙️', screen: 'Settings' },
    { title: 'Privacidade', icon: '🔒', screen: 'Privacy' },
    { title: 'Suporte', icon: '💬', screen: 'Support' },
    { title: 'Peneiras', icon: '⚽', screen: 'Peneiras' },
    { title: 'Peladas', icon: '🏃', screen: 'Peladas' },
    { title: 'Nutrição', icon: '🥗', screen: 'Nutrition' },
    { title: 'Mindset', icon: '🧠', screen: 'Mindset' },
    { title: 'Ranking', icon: '🏆', screen: 'Ranking' },
    { title: 'Loja', icon: '🛍️', screen: 'Marketplace' },
  ];

  const handleLogout = async () => {
    await authService.signOut();
    navigation.reset({ index: 0, routes: [{ name: 'Onboarding' as any }] });
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <Text style={styles.title}>Mais</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {menuItems.map((item) => (
          <TouchableOpacity
            key={item.title}
            style={styles.menuItem}
            onPress={() => navigation.navigate(item.screen as any)}
          >
            <View style={styles.menuLeft}>
              <Text style={styles.menuIcon}>{item.icon}</Text>
              <Text style={styles.menuTitle}>{item.title}</Text>
            </View>
            <Text style={styles.menuArrow}>→</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>Sair</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#f9fafb'},
  header: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {fontSize: 28, fontWeight: 'bold', color: '#111827'},
  content: {padding: 20, gap: 8},
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
  },
  menuLeft: {flexDirection: 'row', alignItems: 'center'},
  menuIcon: {fontSize: 24, marginRight: 12},
  menuTitle: {fontSize: 16, fontWeight: '500', color: '#111827'},
  menuArrow: {fontSize: 20, color: '#9ca3af'},
  logoutButton: {
    backgroundColor: '#ef4444',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  logoutText: {fontSize: 16, fontWeight: '600', color: '#fff'},
});
