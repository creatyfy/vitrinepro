import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';

export default function TrainingFrequencyScreen() {
  const navigation = useNavigation();
  const [frequency, setFrequency] = useState('');

  const frequencies = [
    '1-2 vezes por semana',
    '3-4 vezes por semana',
    '5-6 vezes por semana',
    'Todos os dias',
  ];

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>← Voltar</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Com que frequência você treina?</Text>
        {frequencies.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.option, frequency === f && styles.optionSelected]}
            onPress={() => setFrequency(f)}
          >
            <Text style={styles.optionText}>{f}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('PlayerPositionSelection' as any)}
        >
          <Text style={styles.buttonText}>Continuar</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, paddingTop: 60 },
  back: { color: '#22c55e', marginBottom: 20, fontSize: 16, fontWeight: '600' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 24, color: '#111827' },
  option: {
    padding: 20,
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 12,
    marginBottom: 12,
  },
  optionSelected: { borderColor: '#22c55e', backgroundColor: '#f0fdf4' },
  optionText: { fontSize: 16, color: '#111827' },
  button: {
    backgroundColor: '#111827',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: '600' },
});
