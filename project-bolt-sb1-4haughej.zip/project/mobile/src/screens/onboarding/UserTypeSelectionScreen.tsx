import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { OnboardingStackParamList } from '../../types/navigation';

type UserTypeSelectionNavigationProp = StackNavigationProp<
  OnboardingStackParamList,
  'UserTypeSelection'
>;

const userTypes = [
  {
    id: 'atleta',
    title: 'Atleta',
    subtitle: 'Busco me destacar e ser visto por clubes',
  },
  {
    id: 'clube',
    title: 'Clube',
    subtitle: 'Quero encontrar talentos para meu clube',
  },
  {
    id: 'empresario',
    title: 'Empresário',
    subtitle: 'Agencio atletas e busco oportunidades',
  },
];

export default function UserTypeSelectionScreen() {
  const navigation = useNavigation<UserTypeSelectionNavigationProp>();
  const [selectedType, setSelectedType] = useState('');

  const handleNext = () => {
    if (selectedType) {
      navigation.navigate('GenderSelection');
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Voltar</Text>
        </TouchableOpacity>

        <View style={styles.header}>
          <Text style={styles.title}>Qual é o seu perfil?</Text>
          <Text style={styles.subtitle}>
            Selecione a opção que melhor descreve você
          </Text>
        </View>

        <View style={styles.optionsContainer}>
          {userTypes.map((type) => (
            <TouchableOpacity
              key={type.id}
              style={[
                styles.option,
                selectedType === type.id && styles.optionSelected,
              ]}
              onPress={() => setSelectedType(type.id)}
            >
              <Text
                style={[
                  styles.optionTitle,
                  selectedType === type.id && styles.optionTitleSelected,
                ]}
              >
                {type.title}
              </Text>
              <Text
                style={[
                  styles.optionSubtitle,
                  selectedType === type.id && styles.optionSubtitleSelected,
                ]}
              >
                {type.subtitle}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[
            styles.nextButton,
            !selectedType && styles.nextButtonDisabled,
          ]}
          onPress={handleNext}
          disabled={!selectedType}
        >
          <Text style={styles.nextButtonText}>Continuar</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 60,
  },
  backButton: {
    marginBottom: 20,
  },
  backButtonText: {
    fontSize: 16,
    color: '#22c55e',
    fontWeight: '600',
  },
  header: {
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  optionsContainer: {
    gap: 16,
    marginBottom: 32,
  },
  option: {
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 16,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  optionSelected: {
    borderColor: '#22c55e',
    backgroundColor: '#f0fdf4',
  },
  optionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  optionTitleSelected: {
    color: '#15803d',
  },
  optionSubtitle: {
    fontSize: 14,
    color: '#6b7280',
  },
  optionSubtitleSelected: {
    color: '#16a34a',
  },
  nextButton: {
    backgroundColor: '#111827',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 'auto',
  },
  nextButtonDisabled: {
    opacity: 0.4,
  },
  nextButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
});
