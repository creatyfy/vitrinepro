import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';

const genders = [
  { id: 'masculino', title: 'Masculino' },
  { id: 'feminino', title: 'Feminino' },
  { id: 'outro', title: 'Outro' },
];

export default function GenderSelectionScreen() {
  const navigation = useNavigation();
  const [selectedGender, setSelectedGender] = useState('');

  const handleNext = () => {
    if (selectedGender) {
      navigation.navigate('TrainingFrequency' as any);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Voltar</Text>
        </TouchableOpacity>

        <View style={styles.header}>
          <Text style={styles.title}>Qual é o seu gênero?</Text>
        </View>

        <View style={styles.optionsContainer}>
          {genders.map((gender) => (
            <TouchableOpacity
              key={gender.id}
              style={[
                styles.option,
                selectedGender === gender.id && styles.optionSelected,
              ]}
              onPress={() => setSelectedGender(gender.id)}
            >
              <Text
                style={[
                  styles.optionTitle,
                  selectedGender === gender.id && styles.optionTitleSelected,
                ]}
              >
                {gender.title}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[
            styles.nextButton,
            !selectedGender && styles.nextButtonDisabled,
          ]}
          onPress={handleNext}
          disabled={!selectedGender}
        >
          <Text style={styles.nextButtonText}>Continuar</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 60,
  },
  backButton: {
    marginBottom: 20,
  },
  backButtonText: {
    fontSize: 16,
    color: '#22c55e',
    fontWeight: '600',
  },
  header: {
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
  },
  optionsContainer: {
    gap: 16,
    marginBottom: 32,
  },
  option: {
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 16,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  optionSelected: {
    borderColor: '#22c55e',
    backgroundColor: '#f0fdf4',
  },
  optionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
  },
  optionTitleSelected: {
    color: '#15803d',
  },
  nextButton: {
    backgroundColor: '#111827',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 'auto',
  },
  nextButtonDisabled: {
    opacity: 0.4,
  },
  nextButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
});
