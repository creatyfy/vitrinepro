import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';

export default function PlayerPositionSelectionScreen() {
  const navigation = useNavigation();
  const [position, setPosition] = useState('');

  const positions = [
    'Goleiro',
    'Zagueiro',
    'Lateral',
    'Volante',
    'Meia',
    'Atacante',
  ];

  const handleFinish = () => {
    if (position) {
      navigation.navigate('Congratulations' as any);
    } else {
      Alert.alert('Atenção', 'Por favor, selecione uma posição');
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>← Voltar</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Qual é a sua posição?</Text>
        <View style={styles.grid}>
          {positions.map((pos) => (
            <TouchableOpacity
              key={pos}
              style={[styles.option, position === pos && styles.optionSelected]}
              onPress={() => setPosition(pos)}
            >
              <Text style={[styles.optionText, position === pos && styles.optionTextSelected]}>
                {pos}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={styles.button} onPress={handleFinish}>
          <Text style={styles.buttonText}>Finalizar</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, paddingTop: 60 },
  back: { color: '#22c55e', marginBottom: 20, fontSize: 16, fontWeight: '600' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 24, color: '#111827' },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  option: {
    width: '48%',
    padding: 20,
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 12,
    alignItems: 'center',
  },
  optionSelected: { borderColor: '#22c55e', backgroundColor: '#f0fdf4' },
  optionText: { fontSize: 16, color: '#111827', fontWeight: '600' },
  optionTextSelected: { color: '#15803d' },
  button: {
    backgroundColor: '#111827',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: '600' },
});
