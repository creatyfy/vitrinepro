import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function ProfileMainScreen() {
  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <ScrollView>
        <View style={styles.header}>
          <View style={styles.profileImage}>
            <Text style={styles.profileInitial}>A</Text>
          </View>
          <Text style={styles.name}>Atleta Pro</Text>
          <Text style={styles.position}>Atacante</Text>
        </View>
        <View style={styles.stats}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>28</Text>
            <Text style={styles.statLabel}>Treinos</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>1.2K</Text>
            <Text style={styles.statLabel}>Pontos</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>15</Text>
            <Text style={styles.statLabel}>Medalhas</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#f9fafb'},
  header: {alignItems: 'center', padding: 40, paddingTop: 60, backgroundColor: '#fff'},
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#22c55e',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  profileInitial: {fontSize: 40, fontWeight: 'bold', color: '#fff'},
  name: {fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4},
  position: {fontSize: 16, color: '#6b7280'},
  stats: {flexDirection: 'row', padding: 24, backgroundColor: '#fff', marginTop: 8},
  statItem: {flex: 1, alignItems: 'center'},
  statValue: {fontSize: 24, fontWeight: 'bold', color: '#22c55e', marginBottom: 4},
  statLabel: {fontSize: 14, color: '#6b7280'},
});
