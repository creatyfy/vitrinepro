# Vitrine Pro - Mobile App

Aplicativo mobile nativo do Vitrine Pro, desenvolvido com React Native e Expo.

## 🚀 Tecnologias

- **React Native** - Framework para desenvolvimento mobile
- **Expo** - Plataforma para desenvolvimento React Native
- **TypeScript** - Tipagem estática
- **React Navigation** - Navegação entre telas
- **Supabase** - Backend, autenticação e banco de dados
- **AsyncStorage** - Armazenamento local
- **Expo Camera** - Acesso à câmera
- **Expo Sensors** - Sensores de movimento
- **Expo Location** - Geolocalização
- **Expo Notifications** - Notificações push

## 📁 Estrutura do Projeto

```
mobile/
├── src/
│   ├── components/       # Componentes reutilizáveis
│   ├── screens/          # Telas do aplicativo
│   │   ├── onboarding/   # Fluxo de onboarding
│   │   ├── auth/         # Autenticação
│   │   ├── home/         # Hub principal
│   │   ├── training/     # Treinos
│   │   ├── profile/      # Perfil
│   │   └── more/         # Menu "Mais"
│   ├── navigation/       # Configuração de navegação
│   ├── services/         # Serviços (API, Auth, etc)
│   ├── contexts/         # Contextos React
│   ├── hooks/            # Hooks customizados
│   ├── utils/            # Utilitários
│   ├── types/            # Tipos TypeScript
│   └── config/           # Configurações (Supabase, etc)
├── assets/               # Imagens, fontes, etc
├── App.tsx              # Componente principal
├── app.json             # Configurações do Expo
└── package.json         # Dependências
```

## 🏗️ Setup do Projeto

### Pré-requisitos

- Node.js 18+
- npm ou yarn
- Expo CLI: `npm install -g expo-cli`
- Expo Go app no seu dispositivo móvel (iOS ou Android)

### Instalação

1. Navegue até a pasta mobile:
```bash
cd mobile
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
   - O arquivo `.env` já está configurado com as credenciais do Supabase
   - Verifique se as variáveis estão corretas

4. Inicie o servidor de desenvolvimento:
```bash
npm start
```

5. Escaneie o QR code com o Expo Go:
   - **Android**: Use o Expo Go app
   - **iOS**: Use a câmera nativa do iPhone

## 📱 Funcionalidades Implementadas

### ✅ Core Features

- [x] **Autenticação completa**
  - Login com email/senha
  - Cadastro de novos usuários
  - Recuperação de senha
  - Persistência de sessão
  - Logout

- [x] **Onboarding**
  - Fluxo de boas-vindas
  - Seleção de tipo de usuário (Atleta, Clube, Empresário)
  - Seleção de gênero
  - Frequência de treino
  - Posição do jogador
  - Tela de congratulações

- [x] **Navegação**
  - Bottom Tab Navigator (Home, Treinos, Perfil, Mais)
  - Stack Navigators para cada seção
  - Navegação fluida entre telas

- [x] **Hub Principal**
  - Estatísticas do usuário
  - Menu de funcionalidades
  - Card de treino do dia
  - Perfil rápido

- [x] **Treinos**
  - Lista de categorias de treino
  - Interface otimizada com FlatList

- [x] **Perfil**
  - Visualização de perfil
  - Estatísticas do atleta
  - Medalhas e conquistas

- [x] **Menu Mais**
  - Acesso a todas funcionalidades
  - Configurações
  - Logout

### 🚧 Funcionalidades a Implementar

As seguintes funcionalidades já estão estruturadas na navegação e precisam apenas de implementação das telas:

#### Treinos Avançados
- [ ] Execução de treino com timer
- [ ] Sistema de contagem de repetições com sensores
- [ ] Verificação anti-cheat com câmera
- [ ] Upload de comprovantes
- [ ] Histórico de treinos
- [ ] Programa semanal
- [ ] Desafio 28 dias

#### Peneiras e Peladas
- [ ] Lista de peneiras com filtros
- [ ] Mapa de peneiras/peladas próximas
- [ ] Detalhes de peneira
- [ ] Criar pelada
- [ ] Busca por localização
- [ ] Sistema de inscrição

#### Nutrição
- [ ] Planos de refeição
- [ ] Desafio nutricional diário
- [ ] Desafio semanal
- [ ] Upload de fotos de refeições
- [ ] Histórico nutricional

#### Ranking e Social
- [ ] Ranking global e por categoria
- [ ] Perfil de outros atletas
- [ ] Sistema de seguir/seguidores
- [ ] Feed de atividades

#### Marketplace
- [ ] Lista de produtos
- [ ] Detalhes do produto
- [ ] Carrinho de compras
- [ ] Checkout
- [ ] Integração com pagamento

#### Mindset
- [ ] Conteúdos motivacionais
- [ ] Vídeos de mindset
- [ ] Artigos

#### Configurações e Suporte
- [ ] Edição de perfil
- [ ] Configurações de notificações
- [ ] Configurações de privacidade
- [ ] Chat de suporte
- [ ] FAQ

## 🔧 Próximos Passos de Desenvolvimento

### 1. Implementar Câmera e Sensores
```bash
# Código já preparado para:
- expo-camera: Captura de fotos/vídeos
- expo-sensors: Acelerômetro e giroscópio
- expo-image-picker: Seleção de mídia
```

### 2. Adicionar Notificações Push
```bash
# Configurar expo-notifications:
- Permissões
- Token de dispositivo
- Handlers de notificação
```

### 3. Implementar Geolocalização
```bash
# Usar expo-location para:
- Encontrar peladas próximas
- Mostrar peneiras na região
- Integrar com mapas
```

### 4. Adicionar Analytics
```bash
npm install expo-firebase-analytics
```

### 5. Otimizar Performance
- Implementar código splitting
- Adicionar cache de imagens
- Otimizar FlatLists
- Implementar lazy loading

## 🎨 Design System

### Cores Principais
- **Primary**: `#22c55e` (Verde)
- **Secondary**: `#111827` (Preto)
- **Background**: `#f9fafb` (Cinza claro)
- **Surface**: `#ffffff` (Branco)
- **Error**: `#ef4444` (Vermelho)
- **Text Primary**: `#111827`
- **Text Secondary**: `#6b7280`

### Espaçamentos
- Base: 4px
- Padrão: 8px, 12px, 16px, 20px, 24px

### Border Radius
- Small: 8px
- Medium: 12px
- Large: 16px
- XLarge: 24px

## 📦 Build para Produção

### Android (APK)
```bash
expo build:android -t apk
```

### iOS (IPA)
```bash
expo build:ios
```

### Usando EAS Build (Recomendado)
```bash
# Instalar EAS CLI
npm install -g eas-cli

# Login
eas login

# Configurar projeto
eas build:configure

# Build Android
eas build --platform android

# Build iOS
eas build --platform ios
```

## 🧪 Testes

```bash
# Adicionar Jest e React Native Testing Library
npm install --save-dev jest @testing-library/react-native

# Rodar testes
npm test
```

## 📝 Migração do Web para Mobile

### ✅ Já Migrado
- Estrutura de navegação
- Autenticação (signUp, signIn, signOut)
- Serviço do Supabase
- Contextos básicos
- Telas de onboarding
- Hub principal
- Telas base de treinos, perfil e mais

### 🔄 Em Progresso
- Componentes de UI customizados
- Hooks do web app
- Serviços adicionais (ranking, exercícios, etc)
- Sistema de anti-cheat
- Upload de mídia

### ⏳ Próximas Migrações
- Todas as 90+ telas do web app
- Sistema completo de treinos
- Sistema de medalhas e conquistas
- Marketplace completo
- Sistema de peneiras e peladas
- Sistema nutricional completo
- Features de clube e empresário

## 🔐 Segurança

- ✅ Credenciais em variáveis de ambiente
- ✅ AsyncStorage para dados sensíveis
- ✅ Autenticação com Supabase Auth
- ✅ Row Level Security no banco
- [ ] Implementar biometria (Face ID/Touch ID)
- [ ] Implementar criptografia adicional
- [ ] Adicionar rate limiting

## 📱 Compatibilidade

- **iOS**: 13.0+
- **Android**: API 21+ (Android 5.0+)

## 📄 Licença

Propriedade da Vitrine Pro - Todos os direitos reservados

## 👥 Time

Desenvolvido pela equipe Vitrine Pro

## 🆘 Suporte

Para dúvidas ou problemas, entre em contato através do app ou email.

---

**Status do Projeto**: 🚧 Em Desenvolvimento Ativo

**Versão Atual**: 1.0.0 (MVP)

**Última Atualização**: Novembro 2025
