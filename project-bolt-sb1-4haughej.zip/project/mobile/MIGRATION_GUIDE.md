# Guia de Migração: Web → Mobile

Este guia documenta o processo de migração do Vitrine Pro de React Web para React Native.

## 📊 Status da Migração

### Estrutura Base ✅ COMPLETO
- [x] Configuração do projeto Expo
- [x] TypeScript configurado
- [x] Estrutura de pastas organizada
- [x] Configuração do Supabase
- [x] Sistema de navegação (React Navigation)
- [x] Variáveis de ambiente

### Autenticação ✅ COMPLETO
- [x] authService.ts migrado
- [x] Supabase client configurado com AsyncStorage
- [x] LoginScreen
- [x] ForgotPasswordScreen
- [x] Persistência de sessão
- [x] Check de autenticação no splash

### Onboarding ✅ PARCIAL
- [x] WelcomeScreen (slides iniciais)
- [x] UserTypeSelectionScreen
- [x] GenderSelectionScreen
- [x] TrainingFrequencyScreen
- [x] PlayerPositionSelectionScreen
- [x] CongratulationsScreen
- [ ] VitrineProVisibility
- [ ] HeightWeight
- [ ] BirthDate (com DatePicker nativo)
- [ ] ReferralSource
- [ ] ObjectiveSelection
- [ ] ObstacleSelection
- [ ] GoalsSelection
- [ ] ResultsScreen
- [ ] VitrineKnowledge
- [ ] SuccessStories
- [ ] AthleteNameCollection
- [ ] EmailCollection (formulário completo)
- [ ] PhoneCollection
- [ ] ReferralCodeCollection
- [ ] LoadingScreen

### Hub Principal ✅ PARCIAL
- [x] MainHubScreen (estrutura básica)
- [x] Bottom Tab Navigation
- [ ] Integração com dados reais do Supabase
- [ ] Stats dinâmicas
- [ ] Notificações em tempo real
- [ ] Pull-to-refresh

### Treinos 🚧 EM PROGRESSO
- [x] MyTrainingsScreen (lista básica)
- [ ] TrainingCategoryScreen
- [ ] TrainingPreRollScreen (player de vídeo)
- [ ] ExerciseExecutionScreen
- [ ] ModernTrainingExecutionScreen
- [ ] UniversalTrainingExecutionScreen
- [ ] Timer e contador de repetições
- [ ] Integração com sensores
- [ ] Sistema de pausa/retomada
- [ ] TreinoDoDiaScreen
- [ ] WeeklyTrainingProgram
- [ ] Challenge28Screen
- [ ] Challenge28ExecutionScreen

### Anti-Cheat e Verificação ⏳ PENDENTE
- [ ] UniversalAntiCheatVerification
- [ ] Camera access com expo-camera
- [ ] Captura de foto/vídeo
- [ ] Upload para Supabase Storage
- [ ] ProofHistoryScreen
- [ ] Sistema de pontuação

### Perfil ✅ PARCIAL
- [x] ProfileMainScreen (estrutura básica)
- [ ] PlayerProfileScreen completo
- [ ] EditProfileScreen
- [ ] CareerOverviewScreen
- [ ] VideoGalleryScreen
- [ ] MedalsDetailScreen
- [ ] DailyProgressScreen
- [ ] Integração com dados reais

### Menu Mais ✅ PARCIAL
- [x] MoreMainScreen (lista de opções)
- [ ] SettingsScreen completo
- [ ] AgentSettingsScreen
- [ ] ClubSettingsScreen
- [ ] PrivacyScreen
- [ ] SupportScreen
- [ ] MyAccountScreen

### Peneiras e Peladas ⏳ PENDENTE
- [ ] PeneirasScreen
- [ ] PeneirasScreenRealtime
- [ ] Filtros e busca
- [ ] PeladasScreen
- [ ] PeladaDetailScreen
- [ ] CreatePeladaScreen
- [ ] BoostPeladaScreen
- [ ] Mapas (react-native-maps)
- [ ] Geolocalização

### Nutrição ⏳ PENDENTE
- [ ] NutritionScreen
- [ ] DailyNutritionChallenge
- [ ] NutritionMealPlansScreen
- [ ] NutritionHistoryScreen
- [ ] NutritionChallengeScreen
- [ ] NutritionWeeklyChallengeV2
- [ ] Upload de fotos de refeições

### Ranking e Social ⏳ PENDENTE
- [ ] RankingScreen
- [ ] Sistema de seguir/seguidores
- [ ] Feed de atividades
- [ ] Notificações em tempo real

### Marketplace ⏳ PENDENTE
- [ ] MarketplaceScreen
- [ ] ProductDetailScreen
- [ ] CheckoutScreen
- [ ] CardPaymentForm
- [ ] Carrinho de compras
- [ ] Integração com pagamento

### Mindset ⏳ PENDENTE
- [ ] MindsetScreen
- [ ] Player de vídeo otimizado
- [ ] Lista de conteúdos

### Hubs Específicos ⏳ PENDENTE

#### Club Hub
- [ ] ClubHub
- [ ] ClubNameCollection
- [ ] ClubAddressCollection
- [ ] ClubLogoUpload
- [ ] ClubResponsibleCollection
- [ ] ClubPositionSelection
- [ ] ClubDocumentUpload
- [ ] ClubAgreementScreen
- [ ] ClubCategorySelection

#### Agent Hub
- [ ] AgentHub
- [ ] AgentNameCollection
- [ ] AgentCompanyCollection
- [ ] AgentAddressCollection
- [ ] AgentCredentialsCollection
- [ ] AgentSocialLinksCollection
- [ ] AgentExperienceSelection
- [ ] AgentLicenseUpload

### Serviços e Utils ⏳ PENDENTE
- [x] authService (completo)
- [ ] rankingService
- [ ] dailyTrainingService
- [ ] exerciseService
- [ ] trainingPersistenceService
- [ ] realtimeService
- [ ] antiCheat utils
- [ ] performance utils
- [ ] videoUtils
- [ ] trainingProgress utils

### Contextos ⏳ PENDENTE
- [ ] ThemeContext (com AsyncStorage)
- [ ] LanguageContext
- [ ] Outros contextos necessários

### Hooks ⏳ PENDENTE
- [ ] useProfile
- [ ] useExercises
- [ ] useMotionSensor
- [ ] Outros hooks customizados

### Features Nativas 🎯 PRÓXIMO
- [ ] Camera (expo-camera)
- [ ] Image Picker (expo-image-picker)
- [ ] Sensors (expo-sensors)
  - Acelerômetro
  - Giroscópio
- [ ] Location (expo-location)
- [ ] Notifications (expo-notifications)
- [ ] Video Player (expo-av)
- [ ] Maps (react-native-maps)
- [ ] Secure Storage (expo-secure-store)
- [ ] Biometrics (expo-local-authentication)

## 🔄 Diferenças Principais Web vs Mobile

### Navegação
**Web**: Estados com `currentStep` e renderização condicional
```tsx
if (currentStep === 'login') return <LoginScreen />
```

**Mobile**: React Navigation com Stack/Tab Navigators
```tsx
<Stack.Screen name="Login" component={LoginScreen} />
```

### Estilização
**Web**: Tailwind CSS classes
```tsx
<div className="bg-white p-4 rounded-lg">
```

**Mobile**: StyleSheet do React Native
```tsx
<View style={styles.container}>
const styles = StyleSheet.create({ container: { ... }})
```

### Storage
**Web**: localStorage
```tsx
localStorage.setItem('key', 'value')
```

**Mobile**: AsyncStorage
```tsx
await AsyncStorage.setItem('key', 'value')
```

### Componentes
| Web | Mobile |
|-----|--------|
| `<div>` | `<View>` |
| `<span>`, `<p>` | `<Text>` |
| `<button>` | `<TouchableOpacity>` |
| `<input>` | `<TextInput>` |
| `<img>` | `<Image>` |
| `<video>` | `<Video>` (expo-av) |
| `<a>` | `<TouchableOpacity>` + navigation |

### Scroll
**Web**: Scroll automático em divs
**Mobile**: Requer `<ScrollView>` ou `<FlatList>`

### Listas
**Web**: `.map()` direto
**Mobile**: `<FlatList>` para performance

## 📝 Checklist de Migração de Tela

Para cada tela web, siga este processo:

1. **Criar arquivo da tela**
```bash
mobile/src/screens/[categoria]/[NomeDaTela].tsx
```

2. **Estrutura base**
```tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function NomeDaTela() {
  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      {/* Conteúdo */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
});
```

3. **Converter HTML para React Native**
- `div` → `View`
- `button` → `TouchableOpacity`
- Remover classes do Tailwind
- Criar StyleSheet

4. **Adicionar navegação**
```tsx
import { useNavigation } from '@react-navigation/native';
const navigation = useNavigation();
// Usar navigation.navigate(), goBack(), etc
```

5. **Migrar lógica**
- Estados (useState, useEffect)
- Chamadas API
- Validações
- Event handlers

6. **Testar**
- Funcionalidade
- Layout em diferentes tamanhos
- Performance
- Erros

## 🎯 Prioridades de Migração

### Fase 1: MVP (1-2 semanas) ✅ COMPLETO
- [x] Setup e configuração
- [x] Autenticação
- [x] Onboarding básico
- [x] Navegação principal
- [x] Telas principais (Home, Treinos, Perfil, Mais)

### Fase 2: Core Features (2-3 semanas) 🚧 ATUAL
- [ ] Sistema completo de treinos
- [ ] Execução de exercícios
- [ ] Timer e contador
- [ ] Sistema de pontos

### Fase 3: Anti-Cheat e Mídia (1-2 semanas)
- [ ] Camera integration
- [ ] Upload de fotos/vídeos
- [ ] Verificação anti-cheat
- [ ] Histórico de provas

### Fase 4: Social e Peneiras (2 semanas)
- [ ] Peneiras completo
- [ ] Peladas completo
- [ ] Mapas e geolocalização
- [ ] Sistema de inscrição

### Fase 5: Nutrição e Extras (1-2 semanas)
- [ ] Sistema nutricional
- [ ] Desafios
- [ ] Upload de refeições

### Fase 6: Marketplace (1 semana)
- [ ] Listagem de produtos
- [ ] Carrinho
- [ ] Checkout
- [ ] Pagamentos

### Fase 7: Features Avançadas (2 semanas)
- [ ] Notificações push
- [ ] Realtime updates
- [ ] Analytics
- [ ] Crash reporting

### Fase 8: Polimento (1 semana)
- [ ] Animações
- [ ] Micro-interações
- [ ] Performance optimization
- [ ] Testes finais

### Fase 9: Hubs Especiais (1-2 semanas)
- [ ] Club Hub completo
- [ ] Agent Hub completo
- [ ] Features específicas

### Fase 10: Launch (1 semana)
- [ ] Build de produção
- [ ] App Store submission
- [ ] Google Play submission
- [ ] Documentação final

## 📚 Recursos Úteis

- [React Native Docs](https://reactnative.dev/)
- [Expo Docs](https://docs.expo.dev/)
- [React Navigation](https://reactnavigation.org/)
- [Supabase React Native](https://supabase.com/docs/guides/getting-started/tutorials/with-expo-react-native)

## 🐛 Problemas Comuns

### AsyncStorage Warnings
Certifique-se de importar de `@react-native-async-storage/async-storage`

### Navigation Type Errors
Use os tipos corretos do `@types/navigation`

### Supabase URL Polyfill
Sempre importe no início: `import 'react-native-url-polyfill/auto'`

### Image não carrega
Use `require()` para assets locais ou URL completa para remotos

### Scroll não funciona
Sempre envolva conteúdo scrollável em `<ScrollView>`

## ✅ Próximos Passos Imediatos

1. **Completar onboarding**
   - Implementar telas faltantes
   - Adicionar validações
   - Salvar dados no Supabase

2. **Integrar dados reais**
   - Conectar MainHub com Supabase
   - Buscar estatísticas reais
   - Mostrar treinos do usuário

3. **Implementar execução de treino**
   - Player de vídeo
   - Timer
   - Contador de repetições

4. **Adicionar camera**
   - Permissões
   - Captura de fotos
   - Upload

---

**Tempo estimado total**: 10-14 semanas para migração completa

**Status atual**: Semana 1-2 completa (MVP Base)
