# 🚀 Getting Started - Vitrine Pro Mobile

Guia rápido para começar a desenvolver no Vitrine Pro Mobile.

## 📱 Instalação Inicial

### 1. Instale as Dependências

```bash
cd mobile
npm install
```

### 2. Verifique as Variáveis de Ambiente

O arquivo `.env` já está configurado com:
```env
EXPO_PUBLIC_SUPABASE_URL=https://melqsylrxevhxcumpfut.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 3. Inicie o Servidor de Desenvolvimento

```bash
npm start
```

Isso abrirá o Expo DevTools no seu navegador.

## 📲 Testando no Dispositivo

### Android

1. Instale o **Expo Go** da Play Store
2. Escaneie o QR code na tela do Expo DevTools
3. O app abrirá automaticamente

### iOS

1. Instale o **Expo Go** da App Store
2. Use a câmera nativa do iPhone para escanear o QR code
3. Toque na notificação para abrir no Expo Go

### Emulador Android (opcional)

```bash
npm run android
```

Requer Android Studio instalado.

### Simulador iOS (opcional, apenas macOS)

```bash
npm run ios
```

Requer Xcode instalado.

## 🎯 Fluxo de Desenvolvimento

### Estrutura de Arquivos

```
mobile/
├── App.tsx                    # Entrada principal
├── src/
│   ├── navigation/
│   │   ├── RootNavigator.tsx  # Navegação raiz
│   │   ├── MainNavigator.tsx  # Tabs principais
│   │   └── ...Navigators      # Outros navegadores
│   ├── screens/
│   │   ├── onboarding/        # Telas de cadastro
│   │   ├── auth/              # Login/Senha
│   │   ├── home/              # Hub principal
│   │   ├── training/          # Treinos
│   │   ├── profile/           # Perfil
│   │   └── more/              # Menu extras
│   ├── services/
│   │   └── authService.ts     # Serviços de auth
│   └── config/
│       └── supabase.ts        # Config Supabase
```

### Criando uma Nova Tela

1. **Crie o arquivo da tela:**
```bash
touch src/screens/[categoria]/MinhaNovaScreen.tsx
```

2. **Use o template base:**
```tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function MinhaNovaScreen() {
  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <Text style={styles.title}>Minha Nova Tela</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
  },
});
```

3. **Adicione à navegação:**
```tsx
// Em src/navigation/[Apropriado]Navigator.tsx
<Stack.Screen name="MinhaNovaScreen" component={MinhaNovaScreen} />
```

4. **Navegue para ela:**
```tsx
navigation.navigate('MinhaNovaScreen');
```

## 🔄 Hot Reload

O Expo suporta hot reload automático:
- Salve qualquer arquivo
- O app recarrega automaticamente
- Pressione `r` no terminal para reload manual
- Pressione `m` para abrir o menu de desenvolvimento

## 🛠️ Comandos Úteis

```bash
# Iniciar desenvolvimento
npm start

# Limpar cache
npm start -- --clear

# Rodar no Android
npm run android

# Rodar no iOS (macOS only)
npm run ios

# Rodar no web (para debug)
npm run web
```

## 🐛 Debug

### Acessar DevTools

No dispositivo:
- **iOS**: Shake o dispositivo
- **Android**: Shake o dispositivo ou `Cmd+M` / `Ctrl+M`

Opções do menu:
- **Reload**: Recarregar app
- **Debug JS Remotely**: Abrir Chrome DevTools
- **Toggle Element Inspector**: Inspecionar elementos
- **Show Perf Monitor**: Mostrar FPS

### Console.log

Logs aparecem no terminal do Metro bundler e no browser se usar Remote JS Debugging.

```tsx
console.log('Debug:', variavel);
console.error('Erro:', erro);
console.warn('Aviso:', aviso);
```

### React DevTools

```bash
npm install -g react-devtools
react-devtools
```

## 📊 Testando Funcionalidades

### 1. Autenticação

**Criar nova conta:**
1. Abra o app
2. Toque em "Iniciar Quiz"
3. Complete o onboarding
4. Observe: dados são salvos no Supabase

**Login:**
1. Tela inicial → "Entre aqui"
2. Use um email/senha existente
3. Observe: sessão é persistida

**Logout:**
1. Tab "Mais" → "Sair"
2. Observe: volta para onboarding

### 2. Navegação

**Bottom Tabs:**
- Home: Hub principal
- Treinos: Lista de treinos
- Perfil: Perfil do atleta
- Mais: Menu de opções

**Stack Navigation:**
- Use o botão de voltar
- Swipe da esquerda para direita (iOS)

### 3. Verificar Dados do Supabase

**No Supabase Dashboard:**
1. Vá para Table Editor
2. Tabela `profiles`
3. Veja os dados criados

## 🎨 Personalizando Estilos

### Cores do App

Edite em cada StyleSheet:
```tsx
const styles = StyleSheet.create({
  primary: '#22c55e',     // Verde
  secondary: '#111827',    // Preto
  background: '#f9fafb',   // Cinza claro
  surface: '#ffffff',      // Branco
  error: '#ef4444',        // Vermelho
});
```

### Tipografia

```tsx
const styles = StyleSheet.create({
  heading: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  body: {
    fontSize: 16,
    fontWeight: 'normal',
  },
  small: {
    fontSize: 14,
  },
});
```

## 🔒 Testando com Supabase

### Verificar Conexão

```tsx
// Em qualquer tela
import { supabase } from '../config/supabase';

useEffect(() => {
  const testConnection = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .limit(1);

    console.log('Supabase test:', data, error);
  };
  testConnection();
}, []);
```

### Ver Logs do Supabase

No terminal, você verá:
```
[Supabase] POST https://melqsylrxevhxcumpfut.supabase.co/auth/v1/signup
```

## 🚨 Problemas Comuns

### Erro: "Unable to resolve module"
```bash
npm start -- --clear
```

### Erro: "Invariant Violation"
```bash
npm install
npm start -- --clear
```

### App não conecta no Supabase
1. Verifique `.env`
2. Certifique-se que as variáveis começam com `EXPO_PUBLIC_`
3. Reinicie o Metro bundler

### Tela branca/crash
1. Verifique console por erros
2. Verifique se todos imports estão corretos
3. Verifique se componentes retornam JSX válido

### Navigation não funciona
1. Certifique-se que tela está no Navigator
2. Use o nome correto da tela
3. Verifique tipos do navigation

## 📦 Próximos Passos

1. **Explore o código:**
   - Veja `src/screens/` para todas telas
   - Veja `src/navigation/` para entender fluxo
   - Veja `src/services/` para integrações

2. **Implemente uma feature:**
   - Escolha uma tela do MIGRATION_GUIDE.md
   - Siga o processo de migração
   - Teste no dispositivo

3. **Aprenda mais:**
   - [React Native Tutorial](https://reactnative.dev/docs/tutorial)
   - [Expo Guides](https://docs.expo.dev/guides/)
   - [React Navigation](https://reactnavigation.org/docs/getting-started)

## 🎯 Checklist de Desenvolvimento

- [ ] App roda no dispositivo
- [ ] Consigo fazer login
- [ ] Consigo criar conta
- [ ] Navegação funciona entre telas
- [ ] Dados aparecem do Supabase
- [ ] Hot reload funciona
- [ ] Sem erros no console
- [ ] Entendo a estrutura de pastas

## 💡 Dicas

1. **Use componentes do React Native**, não do web
2. **Sempre teste no dispositivo real**, não só no browser
3. **Use FlatList para listas longas**, não .map()
4. **Envolva conteúdo em ScrollView** se precisar scroll
5. **Use navigation.navigate()** ao invés de links
6. **AsyncStorage é assíncrono**, sempre use await
7. **StyleSheet.create()** para melhor performance
8. **StatusBar** controla a barra de status do sistema

## 🆘 Precisa de Ajuda?

- Veja [README.md](./README.md) para overview completo
- Veja [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) para detalhes de migração
- Consulte a documentação oficial do [Expo](https://docs.expo.dev)
- Confira [React Native docs](https://reactnative.dev/docs/getting-started)

---

**Pronto para começar!** 🚀

Execute `npm start` e comece a desenvolver!
