export interface Medal {
  id: string;
  name: string;
  description: string;
  category: 'iniciante' | 'consistencia' | 'visibilidade' | 'performance' | 'progressao' | 'carreira' | 'social' | 'lendaria';
  rarity: 'comum' | 'raro' | 'epico' | 'lendario';
  icon: string;
  requirement: {
    type: 'training_count' | 'streak' | 'video_count' | 'likes' | 'views' | 'ranking' | 'followers' | 'special';
    target: number;
    condition?: string;
  };
  points: number;
}

const MEDAL_PLACEHOLDER = '/ChatGPT Image 3 de out. de 2025, 01_36_03.png';

export const MEDALS: Medal[] = [
  {
    id: 'chute_inicial',
    name: 'Chute Inicial',
    description: 'Primeiro treino concluído',
    category: 'iniciante',
    rarity: 'comum',
    icon: '/image copy copy copy.png',
    requirement: { type: 'training_count', target: 1 },
    points: 10
  },
  {
    id: 'primeira_estrela',
    name: 'Primeira Estrela',
    description: 'Primeiro vídeo enviado',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'video_count', target: 1 },
    points: 15
  },
  {
    id: 'foco_total',
    name: 'Foco Total',
    description: 'Primeiro treino em vídeo concluído',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'first_video_training' },
    points: 20
  },
  {
    id: 'em_campo',
    name: 'Em Campo',
    description: '3 dias de treino seguidos',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 3 },
    points: 25
  },
  {
    id: 'pegando_ritmo',
    name: 'Pegando Ritmo',
    description: '5 treinos concluídos',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 5 },
    points: 30
  },
  {
    id: 'constancia_rei',
    name: 'Constância é Rei',
    description: '7 dias de treinos seguidos',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 7 },
    points: 40
  },
  {
    id: 'sem_migue',
    name: 'Sem Migué',
    description: '14 dias seguidos de treino',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 14 },
    points: 80
  },
  {
    id: 'primeira_vitoria',
    name: 'Primeira Vitória',
    description: 'Primeiro treino completo com nota máxima',
    category: 'iniciante',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'first_perfect_training' },
    points: 50
  },
  {
    id: 'motozinho',
    name: 'Motozinho',
    description: '30 treinos concluídos',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 30 },
    points: 100
  },
  {
    id: 'faro_de_gol',
    name: 'Faro de Gol',
    description: '50 treinos concluídos',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 50 },
    points: 150
  },
  {
    id: 'raca_coracao',
    name: 'Raça e Coração',
    description: '20 dias de treinos seguidos',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 20 },
    points: 120
  },
  {
    id: 'treino_jogo',
    name: 'Treino é Jogo',
    description: '25 vídeos publicados na plataforma',
    category: 'visibilidade',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'video_count', target: 25 },
    points: 130
  },
  {
    id: 'orgulho_quebrada',
    name: 'Orgulho da Quebrada',
    description: '30 dias seguidos de treino',
    category: 'consistencia',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 30 },
    points: 200
  },
  {
    id: 'ta_voando',
    name: 'Tá Voando',
    description: '75 treinos concluídos',
    category: 'consistencia',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 75 },
    points: 220
  },
  {
    id: 'artilheiro_treino',
    name: 'Artilheiro de Treino',
    description: '100 treinos concluídos',
    category: 'consistencia',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 100 },
    points: 300
  },
  {
    id: 'nunca_desista',
    name: 'Nunca Desista',
    description: '30 dias parado, mas voltou a treinar',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'comeback_30days' },
    points: 100
  },
  {
    id: 'disciplina_tudo',
    name: 'Disciplina é Tudo',
    description: '60 dias seguidos de treino',
    category: 'consistencia',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 60 },
    points: 400
  },
  {
    id: 'tanque_cheio',
    name: 'Tanque Cheio',
    description: '150 treinos concluídos',
    category: 'consistencia',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 150 },
    points: 450
  },
  {
    id: 'top_semana',
    name: 'Top da Semana',
    description: 'Apareceu no ranking semanal',
    category: 'visibilidade',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 10, condition: 'weekly' },
    points: 120
  },
  {
    id: 'craque_bairro',
    name: 'Craque do Bairro',
    description: 'Destaque no ranking regional',
    category: 'visibilidade',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 5, condition: 'regional' },
    points: 150
  },
  {
    id: 'idolo_local',
    name: 'Ídolo Local',
    description: '50 curtidas nos treinos',
    category: 'social',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'likes', target: 50 },
    points: 100
  },
  {
    id: 'camisa_10',
    name: 'Camisa 10',
    description: 'Avaliação positiva de empresário',
    category: 'carreira',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'agent_review' },
    points: 250
  },
  {
    id: 'olho_olheiro',
    name: 'Olho do Olheiro',
    description: 'Vídeo avaliado por olheiro',
    category: 'carreira',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'scout_review' },
    points: 280
  },
  {
    id: 'inspirando_base',
    name: 'Inspirando a Base',
    description: '100 curtidas nos treinos',
    category: 'social',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'likes', target: 100 },
    points: 200
  },
  {
    id: 'fazendo_historia',
    name: 'Fazendo História',
    description: 'Vídeo com 500 visualizações',
    category: 'visibilidade',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'views', target: 500 },
    points: 300
  },
  {
    id: 'fenomeno_internet',
    name: 'Fenômeno da Internet',
    description: 'Vídeo com 1.000 visualizações',
    category: 'visibilidade',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'views', target: 1000 },
    points: 400
  },
  {
    id: 'ta_estourado',
    name: 'Tá Estourado',
    description: 'Vídeo com 5.000 visualizações',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'views', target: 5000 },
    points: 800
  },
  {
    id: 'vitrine_nacional',
    name: 'Vitrine Nacional',
    description: 'Vídeo compartilhado por clube',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'club_share' },
    points: 700
  },
  {
    id: 'desafio_semanal_cumprido',
    name: 'Desafio Semanal Cumprido',
    description: 'Cumpriu todos os treinos de uma semana',
    category: 'performance',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'weekly_challenge_complete' },
    points: 150
  },
  {
    id: 'showman',
    name: 'Showman',
    description: 'Vídeo em destaque na aba Top da Semana',
    category: 'visibilidade',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'top_weekly_video' },
    points: 250
  },
  {
    id: 'desafio_ferro',
    name: 'Desafio de Ferro',
    description: 'Concluiu 10 desafios oficiais seguidos',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'consecutive_challenges' },
    points: 300
  },
  {
    id: 'craque_mundial',
    name: 'Craque Mundial',
    description: 'Vídeo atingiu 10.000 visualizações',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'views', target: 10000 },
    points: 1200
  },
  {
    id: 'lenda_viva',
    name: 'Lenda Viva',
    description: 'Concluiu 365 treinos no total',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 365 },
    points: 2000
  },
  {
    id: 'hall_fama',
    name: 'Hall da Fama',
    description: 'Atingiu 100% das medalhas até Ouro',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'all_gold_medals' },
    points: 3000
  },
  {
    id: 'elite_vitrine',
    name: 'Elite Vitrine',
    description: 'Entrou no Top 10 geral do app',
    category: 'progressao',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 10, condition: 'global' },
    points: 1500
  },
  {
    id: 'mentor_pro',
    name: 'Mentor Pro',
    description: 'Avaliou positivamente 10 atletas diferentes',
    category: 'social',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'athlete_evaluations' },
    points: 400
  },
  {
    id: 'treino_supremo',
    name: 'Treino Supremo',
    description: '500 treinos completos com vídeo publicado',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 500, condition: 'video_trainings' },
    points: 5000
  },
  {
    id: 'relampago_humano',
    name: 'Relâmpago Humano',
    description: 'Média de velocidade acima de 30 km/h registrada',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'speed_30kmh' },
    points: 350
  },
  {
    id: 'maestro_bola',
    name: 'Maestro da Bola',
    description: 'Fez 20 vídeos técnicos com nota máxima',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 20, condition: 'perfect_technical_videos' },
    points: 400
  },
  {
    id: 'retorno_triunfal',
    name: 'Retorno Triunfal',
    description: 'Voltou de lesão e completou 7 treinos seguidos',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'injury_comeback' },
    points: 180
  },
  {
    id: 'tanque_guerra',
    name: 'Tanque de Guerra',
    description: 'Treinou 200 dias consecutivos',
    category: 'consistencia',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 200 },
    points: 2500
  },
  {
    id: 'frieza_artilheiro',
    name: 'Frieza de Artilheiro',
    description: 'Marcou 10 gols em vídeos de treino',
    category: 'performance',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'training_goals' },
    points: 200
  },
  {
    id: 'destaque_oficial_vitrine',
    name: 'Destaque Oficial Vitrine',
    description: 'Vídeo repostado pela página oficial',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'official_repost' },
    points: 1000
  },
  {
    id: 'fenomeno_local',
    name: 'Fenômeno Local',
    description: 'Entrou no Top 3 da região',
    category: 'progressao',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 3, condition: 'regional' },
    points: 500
  },
  {
    id: 'desafio_semanal_nota_maxima',
    name: 'Desafio Semanal Cumprido',
    description: 'Cumpriu todos os treinos da semana com nota máxima',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'weekly_perfect' },
    points: 350
  },
  {
    id: 'showman_destaque',
    name: 'Showman',
    description: 'Vídeo em destaque na aba Top da Semana',
    category: 'visibilidade',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'featured_weekly' },
    points: 300
  },
  {
    id: 'desafio_ferro_10',
    name: 'Desafio de Ferro',
    description: 'Concluiu 10 desafios oficiais seguidos',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'iron_challenges' },
    points: 400
  },
  {
    id: 'craque_mundial_10k',
    name: 'Craque Mundial',
    description: 'Vídeo atingiu 10.000 visualizações',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'views', target: 10000 },
    points: 1300
  },
  {
    id: 'lenda_viva_365',
    name: 'Lenda Viva',
    description: 'Concluiu 365 treinos no total',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'training_count', target: 365 },
    points: 2200
  },
  {
    id: 'hall_fama_ouro',
    name: 'Hall da Fama',
    description: 'Atingiu 100% das medalhas até Ouro',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'gold_complete' },
    points: 3500
  },
  {
    id: 'elite_vitrine_top10',
    name: 'Elite Vitrine',
    description: 'Entrou no Top 10 geral do app',
    category: 'progressao',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 10, condition: 'app_global' },
    points: 1800
  },
  {
    id: 'mentor_pro_avaliador',
    name: 'Mentor Pro',
    description: 'Avaliou positivamente 10 atletas diferentes',
    category: 'social',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'positive_reviews' },
    points: 450
  },
  {
    id: 'treino_supremo_500',
    name: 'Treino Supremo',
    description: '500 treinos completos com vídeo publicado',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 500, condition: 'supreme_videos' },
    points: 5500
  },
  {
    id: 'relampago_humano_velocidade',
    name: 'Relâmpago Humano',
    description: 'Média de velocidade acima de 30 km/h registrada',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'lightning_speed' },
    points: 380
  },
  {
    id: 'maestro_bola_tecnico',
    name: 'Maestro da Bola',
    description: 'Fez 20 vídeos técnicos com nota máxima',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 20, condition: 'maestro_tech' },
    points: 420
  },
  {
    id: 'retorno_triunfal_lesao',
    name: 'Retorno Triunfal',
    description: 'Voltou de lesão e completou 7 treinos seguidos',
    category: 'consistencia',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'comeback_injury' },
    points: 200
  },
  {
    id: 'tanque_guerra_200',
    name: 'Tanque de Guerra',
    description: 'Treinou 200 dias consecutivos',
    category: 'consistencia',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'streak', target: 200 },
    points: 2800
  },
  {
    id: 'frieza_artilheiro_gols',
    name: 'Frieza de Artilheiro',
    description: 'Marcou 10 gols em vídeos de treino',
    category: 'performance',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'goal_scorer' },
    points: 220
  },
  {
    id: 'destaque_oficial',
    name: 'Destaque Oficial Vitrine',
    description: 'Vídeo repostado pela página oficial',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'vitrine_repost' },
    points: 1100
  },
  {
    id: 'top_1_semana',
    name: 'Top 1 da Semana',
    description: 'Líder absoluto do ranking semanal',
    category: 'progressao',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 1, condition: 'weekly_leader' },
    points: 1000
  },
  {
    id: 'top_1_regiao',
    name: 'Top 1 da Região',
    description: 'Líder do ranking regional',
    category: 'progressao',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 1, condition: 'regional_leader' },
    points: 1500
  },
  {
    id: 'top_10_nacional',
    name: 'Top 10 Nacional',
    description: 'Entrou entre os 10 melhores do país',
    category: 'progressao',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'ranking', target: 10, condition: 'national' },
    points: 2000
  },
  {
    id: 'top_1_posicao',
    name: 'Top 1 da Posição',
    description: 'Melhor atleta da sua posição',
    category: 'progressao',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'position_leader' },
    points: 800
  },
  {
    id: 'subiu_divisao',
    name: 'Subiu de Divisão',
    description: 'Passou de categoria (Bronze → Prata, etc.)',
    category: 'progressao',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'division_promotion' },
    points: 300
  },
  {
    id: 'desafio_1000',
    name: 'Desafio dos 1000',
    description: 'Realizou 1.000 repetições em treino',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1000, condition: 'repetitions' },
    points: 600
  },
  {
    id: 'desafio_vitrine',
    name: 'Desafio do Vitrine',
    description: 'Cumpriu desafio oficial mensal',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'monthly_challenge' },
    points: 500
  },
  {
    id: 'evolucao_confirmada',
    name: 'Evolução Confirmada',
    description: 'IA detectou melhora física/estatística',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'ai_improvement' },
    points: 400
  },
  {
    id: 'feedback_profissional',
    name: 'Feedback Profissional',
    description: 'Recebeu avaliação positiva de olheiro',
    category: 'carreira',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'scout_feedback' },
    points: 350
  },
  {
    id: 'olheiro_confirmado',
    name: 'Olheiro Confirmado',
    description: 'Adicionado à lista de observação de um empresário',
    category: 'carreira',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'scout_watchlist' },
    points: 450
  },
  {
    id: 'contrato_assinado',
    name: 'Contrato Assinado',
    description: 'Firmou contrato com clube ou empresa pelo app',
    category: 'carreira',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'contract_signed' },
    points: 3000
  },
  {
    id: 'primeiro_patrocinio',
    name: 'Primeiro Patrocínio',
    description: 'Recebeu patrocínio validado',
    category: 'carreira',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'sponsorship' },
    points: 2500
  },
  {
    id: 'treino_verificado',
    name: 'Treino Verificado',
    description: 'Treino autenticado por IA com vídeo legítimo',
    category: 'performance',
    rarity: 'comum',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'ai_verified' },
    points: 50
  },
  {
    id: 'perfil_oficial',
    name: 'Perfil Oficial',
    description: 'Conta verificada com documento e vídeo facial',
    category: 'social',
    rarity: 'raro',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'verified_profile' },
    points: 200
  },
  {
    id: 'desafio_relampago',
    name: 'Desafio Relâmpago',
    description: 'Venceu desafio de 24 horas',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'flash_challenge' },
    points: 400
  },
  {
    id: 'top_video_semana',
    name: 'Top Vídeo da Semana',
    description: 'Vídeo mais curtido da semana',
    category: 'visibilidade',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'top_video_week' },
    points: 500
  },
  {
    id: 'top_video_mes',
    name: 'Top Vídeo do Mês',
    description: 'Vídeo mais visualizado do mês',
    category: 'visibilidade',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'top_video_month' },
    points: 1000
  },
  {
    id: 'treino_nota_10',
    name: 'Treino Nota 10',
    description: '10 treinos consecutivos com nota máxima',
    category: 'performance',
    rarity: 'epico',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 10, condition: 'perfect_streak' },
    points: 600
  },
  {
    id: 'atleta_5_estrelas',
    name: 'Atleta 5 Estrelas',
    description: '5 avaliações máximas de empresários',
    category: 'carreira',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 5, condition: 'max_evaluations' },
    points: 2000
  },
  {
    id: 'camisa_assinada',
    name: 'Camisa Assinada',
    description: 'Reconhecimento oficial de um clube profissional',
    category: 'carreira',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'club_recognition' },
    points: 5000
  },
  {
    id: 'imortal_vitrine',
    name: 'Imortal do Vitrine',
    description: 'Conquistou todas as medalhas e reconhecimento global',
    category: 'lendaria',
    rarity: 'lendario',
    icon: MEDAL_PLACEHOLDER,
    requirement: { type: 'special', target: 1, condition: 'all_medals' },
    points: 25000
  }
];

export function getMedalById(id: string): Medal | undefined {
  return MEDALS.find(medal => medal.id === id);
}

export function getMedalsByCategory(category: Medal['category']): Medal[] {
  return MEDALS.filter(medal => medal.category === category);
}

export function getMedalsByRarity(rarity: Medal['rarity']): Medal[] {
  return MEDALS.filter(medal => medal.rarity === rarity);
}

export const MEDAL_CATEGORIES = [
  { id: 'iniciante', name: 'Iniciante', description: 'Primeiros passos na plataforma' },
  { id: 'consistencia', name: 'Consistência e Evolução', description: 'Treinos regulares e dedicação' },
  { id: 'visibilidade', name: 'Visibilidade & Engajamento', description: 'Destaque na comunidade' },
  { id: 'performance', name: 'Performance Esportiva', description: 'Excelência nos treinos' },
  { id: 'progressao', name: 'Progressão de Nível', description: 'Evolução no ranking' },
  { id: 'carreira', name: 'Conquistas de Carreira', description: 'Marcos profissionais' },
  { id: 'social', name: 'Social & Comunidade', description: 'Conexões e networking' },
  { id: 'lendaria', name: 'Medalhas Lendárias', description: 'Conquistas raríssimas' }
] as const;
