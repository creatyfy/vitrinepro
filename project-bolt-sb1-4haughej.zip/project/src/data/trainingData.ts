export interface Training {
  id: string;
  title: string;
  description: string;
  duration: string;
  difficulty: 'Iniciante' | 'Amador' | 'Intermediário' | 'Avançado';
  environment: 'Academia' | 'Ar Livre' | 'Equipamentos Simples';
  videoUrl: string;
  instructions: {
    series: string;
    repetitions: string;
    rest: string;
    tips: string[];
  };
  equipment: string[];
  targetMuscles: string[];
  points: number;
}

export interface TrainingTopic {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  trainings: {
    academia: Training[];
    arLivre: Training[];
    equipamentosSimples: Training[];
  };
}

export const trainingTopics: TrainingTopic[] = [
  {
    id: 'explosao',
    name: 'Explosão',
    description: 'Desenvolva potência e força explosiva',
    icon: '💥',
    color: 'bg-red-500',
    trainings: {
      academia: [
        {
          id: 'exp-acad-001',
          title: 'Abdominal com Triângulo',
          description: 'Exercício abdominal utilizando triângulo para apoio',
          duration: '12 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1UW-Eqf6lbz9sNmCUhg0RWC7J0Q0YwwLU/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Mantenha o core contraído', 'Movimento controlado', 'Respiração ritmada']
          },
          equipment: ['Triângulo', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'exp-acad-002',
          title: 'Abdominal no Step',
          description: 'Abdominal com amplitude aumentada usando step',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1fduymqfnI1S3_8dJrHPHxNn1L_-TT7Bn/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '30 segundos entre séries',
            tips: ['Use step para apoio', 'Amplitude completa', 'Lombar protegida']
          },
          equipment: ['Step', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Flexores do quadril'],
          points: 10
        },
        {
          id: 'exp-acad-003',
          title: 'Abdominal no Step Unilateral',
          description: 'Variação unilateral do abdominal no step',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1-4ReUWBBdz7Mlc_yy3ujgFL6oqxk0jWK/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Trabalhe um lado por vez', 'Mantenha equilíbrio', 'Core ativado']
          },
          equipment: ['Step', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Oblíquos'],
          points: 10
        },
        {
          id: 'exp-acad-004',
          title: 'Abdução com Explosão Equilibrando',
          description: 'Abdução lateral com movimento explosivo em equilíbrio',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1bOTYadxRKpYnIKkaSSZv0z-s9jelfNR0/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: ['Movimento explosivo', 'Mantenha equilíbrio', 'Core estável']
          },
          equipment: ['Superfície instável'],
          targetMuscles: ['Glúteo médio', 'Abdutores', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-acad-005',
          title: 'Afundo com Pé Atrás no Step',
          description: 'Afundo búlgaro com pé elevado no step',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1yobVVFY5gLrPHIzehjGSE2E5ffOorubw/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: ['Joelho não ultrapassa ponta do pé', 'Descida controlada', 'Subida explosiva']
          },
          equipment: ['Step'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'exp-acad-006',
          title: 'Afundo pra Trás com Toque no Chão',
          description: 'Afundo reverso com toque no solo',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1nZsG2DH9pMJjwtYOry2eqiH_fPLPMlIX/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Toque leve no chão', 'Movimento controlado', 'Mantenha tronco ereto']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos'],
          points: 10
        },
        {
          id: 'exp-acad-007',
          title: 'Agachamento com Saída em Explosão',
          description: 'Agachamento seguido de movimento explosivo lateral',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/132_f1gbs34jn3XJ2m4vO0ziwgl0hIkUG/preview',
          instructions: {
            series: '5 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Explosão máxima na saída', 'Agachamento profundo', 'Aterrissagem controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-acad-008',
          title: 'Agachamento com Salto + Peso',
          description: 'Agachamento pliométrico com peso adicional',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1b9umEfNe7FPOBfX3RnUdw9YZEQymmius/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '2 minutos entre séries',
            tips: ['Peso controlado', 'Salto explosivo', 'Aterrissagem suave']
          },
          equipment: ['Halter', 'Kettlebell'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-acad-009',
          title: 'Agachamento com Salto em Agilidade',
          description: 'Combinação de agachamento com salto e mudança de direção',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1tattfbP6vsB8qjSTRK7Ae6QKRagArJgU/preview',
          instructions: {
            series: '5 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Mudança rápida de direção', 'Explosão no salto', 'Coordenação']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-acad-010',
          title: 'Agachamento com Toque no Cone mais Saída em Agilidade',
          description: 'Agachamento com toque em cone e saída explosiva',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1oIiErQxBhry_kUO-9IPDWu22jb4ffGEN/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Toque preciso no cone', 'Saída explosiva', 'Coordenação e agilidade']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-acad-011',
          title: 'Elevação de Joelho no Step',
          description: 'Elevação alternada de joelhos sobre step',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/16X4XS5pJ_9Spy6GvS1mqkWOsVVB5ZcPX/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições cada lado',
            rest: '30 segundos entre séries',
            tips: ['Movimento rápido', 'Mantenha equilíbrio', 'Core ativado']
          },
          equipment: ['Step'],
          targetMuscles: ['Flexores do quadril', 'Core', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-acad-012',
          title: 'Elevação de Perna com Elástico',
          description: 'Elevação de perna com resistência de elástico',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Resistência controlada', 'Movimento completo', 'Core estável']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Flexores do quadril', 'Abdômen'],
          points: 10
        },
        {
          id: 'exp-acad-013',
          title: 'Elevação de Pernas na Parede',
          description: 'Elevação de pernas apoiado na parede',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1btnsmrhi4CL7kPPOjw9hmRYg5v75_IUt/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '45 segundos entre séries',
            tips: ['Apoio firme na parede', 'Movimento controlado', 'Lombar protegida']
          },
          equipment: ['Parede'],
          targetMuscles: ['Abdômen', 'Flexores do quadril'],
          points: 10
        },
        {
          id: 'exp-acad-014',
          title: 'Elevação de Pernas Segurando',
          description: 'Elevação isométrica de pernas',
          duration: '10 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1F5ho2btThO1lk9M7KTEf1RH55O1nIDYq/preview',
          instructions: {
            series: '4 séries',
            repetitions: '30 segundos de hold',
            rest: '60 segundos entre séries',
            tips: ['Pernas elevadas', 'Core máximo', 'Respiração controlada']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Flexores do quadril'],
          points: 10
        },
        {
          id: 'exp-acad-015',
          title: 'Prancha Dinâmica',
          description: 'Prancha com movimentos dinâmicos',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1S_6L1ugfMyyAnOGvI1xDgP9HJSYArtz3/preview',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos',
            rest: '60 segundos entre séries',
            tips: ['Movimento controlado', 'Core sempre ativado', 'Quadril estável']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Abdômen'],
          points: 10
        },
        {
          id: 'exp-acad-016',
          title: 'Salto com Pé Atrás do Step',
          description: 'Salto pliométrico com pé elevado',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/10zrBWY-6Vg-LA--Nfo0xq2wLOZPSRW0z/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada lado',
            rest: '90 segundos entre séries',
            tips: ['Explosão máxima', 'Aterrissagem controlada', 'Equilíbrio']
          },
          equipment: ['Step'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-acad-017',
          title: 'Saltos Rápidos',
          description: 'Sequência de saltos rápidos e explosivos',
          duration: '12 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1Z5OVTKQ36AeQliAN3E7qoSiPOgi_VucN/preview',
          instructions: {
            series: '5 séries',
            repetitions: '20 saltos',
            rest: '60 segundos entre séries',
            tips: ['Velocidade máxima', 'Toques rápidos no chão', 'Ritmo constante']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Panturrilha', 'Quadríceps', 'Core'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'exp-livre-001',
          title: 'Corrida Ida e Volta em T com Cones',
          description: 'Corrida em formato T com mudanças de direção',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1b3qQDvVp1_6evVsnQLa7l00P-Uc01UWX/preview',
          instructions: {
            series: '5 séries',
            repetitions: '6 percursos',
            rest: '90 segundos entre séries',
            tips: ['Mudanças rápidas de direção', 'Velocidade máxima', 'Postura baixa nas curvas']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-livre-002',
          title: 'Abdominal Dinâmico com Salto',
          description: 'Combinação de abdominal com salto explosivo',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1--k_B7emloaCuGfRv8bMA61HZ_awxcXl/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Transição fluida', 'Explosão no salto', 'Coordenação']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Quadríceps', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-003',
          title: 'Burpe com Agilidade',
          description: 'Burpee com componente de agilidade',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/15zgD9AdMIxk_jln4hHQDUZMC-gm0xTUa/preview',
          instructions: {
            series: '5 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Movimento completo', 'Saída explosiva', 'Coordenação motora']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-004',
          title: 'Corrida com Elevação dos Joelhos',
          description: 'Corrida com elevação alta dos joelhos',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1JQQ5Pdk89AaH8j_2b9MtD2Pjh_JoSGB_/preview',
          instructions: {
            series: '6 séries',
            repetitions: '30 segundos',
            rest: '45 segundos entre séries',
            tips: ['Joelhos até altura do quadril', 'Ritmo acelerado', 'Braços sincronizados']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Flexores do quadril', 'Panturrilha', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-005',
          title: 'Corrida com Giro e Saída',
          description: 'Corrida com giro de 180° e sprint',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1wsQRkJ9Ir8_j0F5Q6DvxeANgJZA8czVp/preview',
          instructions: {
            series: '5 séries',
            repetitions: '8 repetições',
            rest: '60 segundos entre séries',
            tips: ['Giro rápido', 'Aceleração imediata', 'Equilíbrio na virada']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-006',
          title: 'Corrida com Giro entre os Triângulos',
          description: 'Percurso com giros entre marcadores',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/11E_BFcfNowZ4Z5xNRxhT05HU5nXYGIyv/preview',
          instructions: {
            series: '5 séries',
            repetitions: '10 percursos',
            rest: '90 segundos entre séries',
            tips: ['Giros controlados', 'Velocidade mantida', 'Postura baixa']
          },
          equipment: ['Triângulos', 'Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-livre-007',
          title: 'Corrida com Saída Explosiva e Volta Devagar',
          description: 'Sprint explosivo com retorno em trote',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1mjf6xylJtbsfWbxc_t-fghYN4-_r8UTR/preview',
          instructions: {
            series: '6 séries',
            repetitions: '20 metros',
            rest: '90 segundos entre séries',
            tips: ['Explosão na saída', 'Velocidade máxima', 'Recuperação ativa']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-livre-008',
          title: 'Corrida Controlada com Elástico',
          description: 'Corrida com resistência de elástico',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1mOWUa9qyXDJPXlSPaODrUvckXsghFWA_/preview',
          instructions: {
            series: '5 séries',
            repetitions: '15 metros',
            rest: '2 minutos entre séries',
            tips: ['Resistência constante', 'Postura inclinada', 'Força máxima']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-009',
          title: 'Corrida de Costas com Giro',
          description: 'Corrida de costas seguida de giro e sprint',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1A6GCRprAlwFiJC81bkejE88qMg9-o5-C/preview',
          instructions: {
            series: '5 séries',
            repetitions: '10 repetições',
            rest: '60 segundos entre séries',
            tips: ['Olhar por cima do ombro', 'Giro rápido', 'Transição suave']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-livre-010',
          title: 'Corrida com Abdominal com Rolo',
          description: 'Corrida intercalada com abdominais',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1xTcsWBAcsw1he7Uwyi7fKKl0_jXfM9bN/preview',
          instructions: {
            series: '4 séries',
            repetitions: '6 ciclos',
            rest: '90 segundos entre séries',
            tips: ['Alternância rápida', 'Recuperação controlada', 'Core sempre ativado']
          },
          equipment: ['Rolo', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Quadríceps', 'Core'],
          points: 10
        },
        {
          id: 'exp-livre-011',
          title: 'Corrida Ida e Volta com Explosão',
          description: 'Sprint com mudança de direção explosiva',
          duration: '13 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1I9HiUmoyt4YpM0ZAvOSLYzqVseneaXeC/preview',
          instructions: {
            series: '5 séries',
            repetitions: '8 repetições',
            rest: '2 minutos entre séries',
            tips: ['Freada brusca', 'Mudança explosiva', 'Aceleração máxima']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-livre-012',
          title: 'Salto Ida e Volta com Uma Perna',
          description: 'Saltos unilaterais em sequência',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1bheIVDQXvMK9Z_qHsaDb5p1sOC0VJCv3/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '90 segundos entre séries',
            tips: ['Equilíbrio constante', 'Explosão máxima', 'Aterrissagem controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-livre-013',
          title: 'Saltos com Parada com uma Perna só',
          description: 'Salto unilateral com hold isométrico',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1kozT84GtG_6tFkZXxA2Hxioui3cvHRUG/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições + 5s hold',
            rest: '90 segundos entre séries',
            tips: ['Aterrissagem estável', 'Equilíbrio perfeito', 'Core ativado']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'exp-equip-001',
          title: 'Corrida com Parada em Superfície Instável',
          description: 'Corrida com paradas em bosu ou superfície instável',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1edCPtkEm1OlVpIFUkPY5A__SXfs4JQfk/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Equilíbrio na parada', 'Transição controlada', 'Core estável']
          },
          equipment: ['Bosu', 'Superfície instável'],
          targetMuscles: ['Quadríceps', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-002',
          title: 'Corrida com Peso',
          description: 'Corrida com peso adicional nos braços',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1Qjxa1Vuk2n-sdd4fW4pQ7y58JZlMdCei/preview',
          instructions: {
            series: '5 séries',
            repetitions: '30 segundos',
            rest: '60 segundos entre séries',
            tips: ['Peso controlado', 'Postura ereta', 'Ritmo mantido']
          },
          equipment: ['Halteres'],
          targetMuscles: ['Quadríceps', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-003',
          title: 'Corrida com Salto sobre Superfície Instável',
          description: 'Corrida com saltos sobre bosu',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1AwQAVouFEXEcY61GizRXIAqnGWAhCvmS/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 saltos',
            rest: '90 segundos entre séries',
            tips: ['Aterrissagem precisa', 'Equilíbrio dinâmico', 'Explosão controlada']
          },
          equipment: ['Bosu', 'Superfície instável'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-004',
          title: 'Corrida com Toques nas Mãos',
          description: 'Corrida com toques alternados nas mãos',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '20 toques',
            rest: '45 segundos entre séries',
            tips: ['Coordenação mão-pé', 'Ritmo constante', 'Core ativado']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Core', 'Coordenação'],
          points: 10
        },
        {
          id: 'exp-equip-005',
          title: 'Corrida com Toques no Step',
          description: 'Corrida com toques alternados no step',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1ogKgeEsPAdaMGoGTdRT_y3jmut7t7P5v/preview',
          instructions: {
            series: '5 séries',
            repetitions: '30 segundos',
            rest: '45 segundos entre séries',
            tips: ['Toques rápidos', 'Ritmo acelerado', 'Equilíbrio']
          },
          equipment: ['Step'],
          targetMuscles: ['Panturrilha', 'Quadríceps', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-006',
          title: 'Corrida com Toques Unilaterais no Step',
          description: 'Toques unilaterais alternados no step',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/17bWwthjPQyRHe-AnqzPDznYRsRONiKZT/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 toques cada lado',
            rest: '60 segundos entre séries',
            tips: ['Uma perna por vez', 'Velocidade máxima', 'Equilíbrio']
          },
          equipment: ['Step'],
          targetMuscles: ['Panturrilha', 'Quadríceps', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-007',
          title: 'Corrida Ida e Volta com Subida em Superfície Instável',
          description: 'Sprint com subida em bosu',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1ev7hdHI97zLjVCnlaFpccl_ltSSPR9HH/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '2 minutos entre séries',
            tips: ['Transição rápida', 'Equilíbrio na subida', 'Explosão mantida']
          },
          equipment: ['Bosu', 'Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-008',
          title: 'Dentro e Fora com Duas Pernas',
          description: 'Saltos laterais com duas pernas',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1btlewEnSTAjLktoao1SDFBvO7bYBShb_/preview',
          instructions: {
            series: '5 séries',
            repetitions: '20 saltos',
            rest: '45 segundos entre séries',
            tips: ['Saltos laterais rápidos', 'Aterrissagem suave', 'Ritmo constante']
          },
          equipment: ['Linha no chão'],
          targetMuscles: ['Abdutores', 'Adutores', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-equip-009',
          title: 'Dentro e Fora com Duas Pernas com Elásticos',
          description: 'Saltos laterais com resistência de elástico',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1q33ZntzWtc5pljZU0n2QE5IJTqoWc-Ak/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 saltos',
            rest: '60 segundos entre séries',
            tips: ['Resistência constante', 'Controle do movimento', 'Explosão lateral']
          },
          equipment: ['Elástico', 'Linha no chão'],
          targetMuscles: ['Abdutores', 'Adutores', 'Glúteos'],
          points: 10
        },
        {
          id: 'exp-equip-010',
          title: 'Ida e Volta com Bastão',
          description: 'Sprint com bastão elevado',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1YmFhJTOSHqSa8jGFu5uFrlACOIwaLJGV/preview',
          instructions: {
            series: '5 séries',
            repetitions: '8 repetições',
            rest: '60 segundos entre séries',
            tips: ['Bastão acima da cabeça', 'Postura ereta', 'Core ativado']
          },
          equipment: ['Bastão'],
          targetMuscles: ['Quadríceps', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'exp-equip-011',
          title: 'Ida e Volta com Uma Perna com Elástico',
          description: 'Saltos unilaterais com resistência',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1ShANzf6hwkcAwesl6j4ChumbvDW4g5Kw/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '90 segundos entre séries',
            tips: ['Equilíbrio com resistência', 'Explosão controlada', 'Core estável']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-012',
          title: 'Saída de Joelho',
          description: 'Sprint partindo da posição de joelhos',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1ec0E1qymS93eE1g63i2axqMq85d0GzB3/preview',
          instructions: {
            series: '5 séries',
            repetitions: '8 saídas',
            rest: '90 segundos entre séries',
            tips: ['Explosão inicial máxima', 'Transição rápida', 'Aceleração progressiva']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-013',
          title: 'Stiff Unilateral com Bastão',
          description: 'Stiff em uma perna com bastão',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1WEat2Iw0zxQJoGQTuem84CRQ1h9zRdLH/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Equilíbrio perfeito', 'Movimento controlado', 'Alongamento posterior']
          },
          equipment: ['Bastão'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'exp-equip-014',
          title: 'Stiff com Explosão',
          description: 'Stiff com movimento explosivo na subida',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1u3WyhFREmw5b6DEm6uDQgvrUN9LzCaNv/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Descida controlada', 'Subida explosiva', 'Quadril em foco']
          },
          equipment: ['Peso corporal ou halter'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Lombar'],
          points: 10
        },
        {
          id: 'exp-equip-015',
          title: 'Stiff Unilateral com Bastão + Elevação de Bastão',
          description: 'Stiff combinado com elevação overhead',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1mNMkvP-2keuWggOiY5dXDEiUSeMMZLR4/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '90 segundos entre séries',
            tips: ['Movimento sincronizado', 'Core ativado', 'Amplitude completa']
          },
          equipment: ['Bastão'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-016',
          title: 'Toques com os Pés sobre Superfície Instável',
          description: 'Toques rápidos em superfície instável',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1UY65CwjwD248MttN-iFQhZqTxBRCYZzf/preview',
          instructions: {
            series: '5 séries',
            repetitions: '30 segundos',
            rest: '60 segundos entre séries',
            tips: ['Toques rápidos', 'Equilíbrio dinâmico', 'Core estável']
          },
          equipment: ['Bosu', 'Superfície instável'],
          targetMuscles: ['Panturrilha', 'Estabilizadores', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-017',
          title: 'Abdominal no Step - Variação 2',
          description: 'Segunda variação de abdominal no step com foco em diferentes ângulos',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '18 repetições',
            rest: '45 segundos entre séries',
            tips: ['Variação de ângulo', 'Core contraído', 'Movimento fluido']
          },
          equipment: ['Step', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-018',
          title: 'Agachamento com Saída em Explosão - Variação 2',
          description: 'Variação avançada do agachamento explosivo',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1hy4HePLKlOcqysvZKAG4-xCsmtxm0XK6/preview',
          instructions: {
            series: '5 séries',
            repetitions: '10 repetições',
            rest: '2 minutos entre séries',
            tips: ['Explosão máxima', 'Variação de direção', 'Aterrissagem segura']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-equip-019',
          title: 'Agachamento com Toque no Cone - Variação 2',
          description: 'Segunda variação com padrões diferentes de toque',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1D_55IR2YYMzIm67DHsxB3WJ0TvqFwO0s/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '90 segundos entre séries',
            tips: ['Padrão variado', 'Agilidade aprimorada', 'Precisão nos toques']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-020',
          title: 'Corrida Ida e Volta em T - Variação 2',
          description: 'Variação do percurso em T com maior complexidade',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '8 percursos',
            rest: '2 minutos entre séries',
            tips: ['Mudanças rápidas', 'Padrão complexo', 'Velocidade mantida']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Agilidade'],
          points: 10
        },
        {
          id: 'exp-equip-021',
          title: 'Abdominal Dinâmico com Salto - Variação 2',
          description: 'Variação dinâmica com foco em explosão',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Transição explosiva', 'Coordenação', 'Core máximo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Quadríceps', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-022',
          title: 'Burpe com Agilidade - Variação 2',
          description: 'Burpee com componentes adicionais de agilidade',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '12 repetições',
            rest: '2 minutos entre séries',
            tips: ['Movimento completo', 'Agilidade aumentada', 'Ritmo constante']
          },
          equipment: ['Peso corporal', 'Cones'],
          targetMuscles: ['Corpo inteiro', 'Core', 'Agilidade'],
          points: 10
        },
        {
          id: 'exp-equip-023',
          title: 'Corrida com Elevação dos Joelhos - Variação 2',
          description: 'Variação com intensidade aumentada',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '6 séries',
            repetitions: '40 segundos',
            rest: '60 segundos entre séries',
            tips: ['Joelhos mais altos', 'Velocidade aumentada', 'Coordenação']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Flexores do quadril', 'Panturrilha', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-024',
          title: 'Corrida com Giro e Saída - Variação 2',
          description: 'Variação com múltiplos giros e direções',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Giros múltiplos', 'Equilíbrio dinâmico', 'Aceleração rápida']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-025',
          title: 'Corrida com Giro entre Triângulos - Variação 2',
          description: 'Percurso mais complexo com triângulos',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '8 percursos',
            rest: '2 minutos entre séries',
            tips: ['Padrão complexo', 'Giros precisos', 'Velocidade mantida']
          },
          equipment: ['Triângulos', 'Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Agilidade'],
          points: 10
        },
        {
          id: 'exp-equip-026',
          title: 'Corrida Explosiva e Volta Devagar - Variação 2',
          description: 'Variação com distâncias diferentes',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '6 séries',
            repetitions: '30 metros',
            rest: '2 minutos entre séries',
            tips: ['Explosão máxima', 'Recuperação controlada', 'Variação de ritmo']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha'],
          points: 10
        },
        {
          id: 'exp-equip-027',
          title: 'Corrida Controlada com Elástico - Variação 2',
          description: 'Variação com resistência aumentada',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '20 metros',
            rest: '2 minutos entre séries',
            tips: ['Resistência alta', 'Força máxima', 'Postura perfeita']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'exp-equip-028',
          title: 'Corrida de Costas com Giro - Variação 2',
          description: 'Variação com múltiplas mudanças de direção',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '12 repetições',
            rest: '90 segundos entre séries',
            tips: ['Atenção redobrada', 'Giros rápidos', 'Coordenação avançada']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'forca',
    name: 'Força',
    description: 'Construa força funcional para o futebol',
    icon: '💪',
    color: 'bg-blue-600',
    trainings: {
      academia: [
        {
          id: 'for-001',
          title: 'Abdominal bicicleta',
          description: 'Movimento alternado de pernas simulando pedalada com rotação de tronco',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1kcOHOoGwPrtDpVO7dPjebKcdmRhkkiMp/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Cotovelo toca joelho oposto', 'Lombar no chão', 'Movimento controlado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Oblíquos'],
          points: 10
        },
        {
          id: 'for-002',
          title: 'Abdominal com carga',
          description: 'Abdominal tradicional com peso adicional no peito',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1IQbyBfnc83FG5hgrgkCoT8pEHWxB3nMe/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Segure o peso no peito', 'Suba até escápulas saírem do chão', 'Respiração controlada']
          },
          equipment: ['Colchonete', 'Anilha ou halter'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'for-003',
          title: 'Abdominal com rolo',
          description: 'Abdominal com auxílio de rolo para amplitude aumentada',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1NnHLbMEEv-MgVIkXgk4CLMxXihoIifkE/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Rolo sob lombar', 'Amplitude completa', 'Controle na descida']
          },
          equipment: ['Colchonete', 'Rolo de espuma'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'for-004',
          title: 'Abdominal curto',
          description: 'Movimento curto e controlado focado na parte superior do abdômen',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1yA3LddBqtiugETSmXoC2tE2q5T3dPXk9/preview',
          instructions: {
            series: '4 séries',
            repetitions: '25 repetições',
            rest: '30 segundos entre séries',
            tips: ['Movimento curto', 'Tensão constante', 'Não force o pescoço']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen superior'],
          points: 10
        },
        {
          id: 'for-005',
          title: 'Abdominal remador',
          description: 'Combina movimento de remada com crunch abdominal',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1AalB08fafvybaYvz2z_SrYsEmRPXsTVP/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Movimento sincronizado', 'Core sempre ativo', 'Equilíbrio mantido']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'for-006',
          title: 'Afundo com pausa',
          description: 'Afundo com pausa isométrica na posição inferior',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1ImEi2JLOUY9b0H4_744W8SMjz90DnOIK/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Pausa de 2 segundos embaixo', 'Joelho não ultrapassa ponta do pé', 'Costas retas']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos'],
          points: 10
        },
        {
          id: 'for-007',
          title: 'Afundo com rotação de tronco com carga',
          description: 'Afundo combinado com rotação de tronco segurando peso',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1rrldqPL5vGz25Sz6bT46nOI-JfRTvcmP/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições cada lado',
            rest: '75 segundos entre séries',
            tips: ['Rotação para lado da perna da frente', 'Peso na altura do peito', 'Movimento controlado']
          },
          equipment: ['Halter ou bola medicinal'],
          targetMuscles: ['Pernas', 'Core', 'Oblíquos'],
          points: 10
        },
        {
          id: 'for-008',
          title: 'Afundo com salto DIREITO',
          description: 'Afundo alternado com troca explosiva no ar',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1JAn9fAPgHqXDtzRMDMb2AXtiNzHxO82V/preview',
          instructions: {
            series: '4 séries',
            repetitions: '16 repetições (8 cada perna)',
            rest: '90 segundos entre séries',
            tips: ['Explosão máxima', 'Troca de perna no ar', 'Aterrissagem controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'for-009',
          title: 'Afundo com salto ESQUERDO',
          description: 'Variação de afundo com salto e pausa',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1CLPdns8pagCoKkomZWu_9SmkNDqhm2gq/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '90 segundos entre séries',
            tips: ['Salto vertical máximo', 'Mesma perna 3x depois troca', 'Recuperação adequada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Explosão'],
          points: 10
        },
        {
          id: 'for-010',
          title: 'Afundo pra trás',
          description: 'Afundo com passo para trás',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1qQa3CURDr9zJi261EqHicmkE6v0YygjU/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '45 segundos entre séries',
            tips: ['Passo amplo para trás', 'Tronco ereto', 'Joelho da frente a 90 graus']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'for-011',
          title: 'Agachamento com afundo',
          description: 'Combinação de agachamento seguido de afundo',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1CnW0zEXGAMVwvyor5HlRx2QZozj-ZSHV/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '75 segundos entre séries',
            tips: ['Agachamento completo primeiro', 'Depois afundo', 'Movimento fluido']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas completas', 'Core'],
          points: 10
        },
        {
          id: 'for-012',
          title: 'Agachamento com chute frontal',
          description: 'Agachamento seguido de chute frontal',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1l4QHyYOt__7ezZgZJ6xnc3cNQYoy7GuT/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Agachamento profundo', 'Chute na subida', 'Equilíbrio e controle']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Coordenação'],
          points: 10
        },
        {
          id: 'for-013',
          title: 'Agachamento com deslocamento lateral',
          description: 'Agachamento com passo lateral alternado',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1xWV3o4Y1ToTvhrWSwOKCOzmUVDm91tG8/preview',
          instructions: {
            series: '4 séries',
            repetitions: '14 repetições',
            rest: '60 segundos entre séries',
            tips: ['Desloca lateral e agacha', 'Postura baixa', 'Passos controlados']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Adutores', 'Glúteos'],
          points: 10
        },
        {
          id: 'for-014',
          title: 'Agachamento com elástico',
          description: 'Agachamento com resistência de elástico',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1N_wzzNaZ4CA54cHF0Avl-9HSsssH8vkz/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Elástico preso embaixo dos pés', 'Tensão constante', 'Controle total']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Quadríceps', 'Glúteos'],
          points: 10
        },
        {
          id: 'for-015',
          title: 'Agachamento com elástico 2',
          description: 'Variação de agachamento com elástico em diferentes ângulos',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Elástico ao redor das coxas', 'Força abdução', 'Joelhos abertos']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Glúteos', 'Abdutores', 'Quadríceps'],
          points: 10
        },
        {
          id: 'for-016',
          title: 'Agachamento com elevação de carga',
          description: 'Agachamento com elevação de peso acima da cabeça',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1BZmC2X-gXLLkXwf6nzPwTTAozHICM54q/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Eleva peso na subida', 'Core sempre ativo', 'Movimento sincronizado']
          },
          equipment: ['Halter ou barra'],
          targetMuscles: ['Pernas', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'for-017',
          title: 'Agachamento com equilíbrio na bola',
          description: 'Agachamento em superfície instável',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições',
            rest: '90 segundos entre séries',
            tips: ['Meia bola (bosu)', 'Equilíbrio constante', 'Movimento lento']
          },
          equipment: ['Bosu ou bola de equilíbrio'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'for-018',
          title: 'Agachamento com salto',
          description: 'Agachamento explosivo com salto vertical',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '90 segundos entre séries',
            tips: ['Agachamento profundo', 'Explosão máxima', 'Aterrissagem suave']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'for-019',
          title: 'Agachamento com salto 2',
          description: 'Variação de agachamento com salto e giro',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Giro de 180 graus no ar', 'Aterrissagem controlada', 'Coordenação']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Coordenação'],
          points: 10
        },
        {
          id: 'for-020',
          title: 'Agachamento com salto 3',
          description: 'Agachamento com salto frontal',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '2 minutos entre séries',
            tips: ['Salto para frente', 'Distância máxima', 'Agachamento na aterrissagem']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão horizontal'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'for-021',
          title: 'Agachamento com salto no step',
          description: 'Agachamento seguido de salto em caixa ou step',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Agachamento antes do salto', 'Salto explosivo na caixa', 'Descida controlada']
          },
          equipment: ['Caixa ou banco'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'for-022',
          title: 'Agachamento isométrico',
          description: 'Manutenção da posição de agachamento por tempo',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada',
            rest: '60 segundos entre séries',
            tips: ['Joelhos a 90 graus', 'Costas retas', 'Respiração constante']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Resistência'],
          points: 10
        },
        {
          id: 'for-023',
          title: 'Agachamento isométrico na parede com carga',
          description: 'Agachamento isométrico com as costas apoiadas na parede e peso',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada',
            rest: '75 segundos entre séries',
            tips: ['Costas na parede', 'Peso no colo', '90 graus nos joelhos']
          },
          equipment: ['Parede', 'Objeto pesado'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Força isométrica'],
          points: 10
        },
        {
          id: 'for-024',
          title: 'Agachamento isométrico na parede com carga 2',
          description: 'Variação com peso elevado acima da cabeça',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '35 segundos cada',
            rest: '90 segundos entre séries',
            tips: ['Peso acima da cabeça', 'Core super ativado', 'Estabilidade total']
          },
          equipment: ['Parede', 'Objeto pesado'],
          targetMuscles: ['Pernas', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'for-025',
          title: 'Agachamento lateral',
          description: 'Agachamento com deslocamento lateral amplo',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: ['Passo lateral amplo', 'Agachamento profundo', 'Alternância fluida']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Adutores', 'Glúteos'],
          points: 10
        },
        {
          id: 'for-026',
          title: 'Agachamento sumô com carga',
          description: 'Agachamento com pés afastados e peso',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Pés bem afastados', 'Pontas dos pés para fora', 'Peso entre as pernas']
          },
          equipment: ['Objeto pesado'],
          targetMuscles: ['Adutores', 'Glúteos', 'Quadríceps'],
          points: 10
        },
        {
          id: 'for-027',
          title: 'Burpe',
          description: 'Exercício completo de corpo inteiro',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Movimento fluido', 'Flexão completa', 'Salto no final']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Cardio'],
          points: 10
        },
        {
          id: 'for-028',
          title: 'Burpe com salto',
          description: 'Burpe com salto vertical explosivo',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '75 segundos entre séries',
            tips: ['Burpe completo', 'Salto máximo', 'Mãos acima da cabeça']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Explosão'],
          points: 10
        },
        {
          id: 'for-029',
          title: 'Burpe com salto duplo',
          description: 'Burpe com dois saltos consecutivos',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Dois saltos no final', 'Máxima explosão', 'Recuperação adequada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'for-030',
          title: 'Corrida',
          description: 'Corrida contínua em ritmo moderado',
          duration: '25 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '1 série',
            repetitions: '20 minutos contínuos',
            rest: 'N/A',
            tips: ['Ritmo constante', 'Respiração controlada', 'Postura ereta']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Cardio', 'Resistência', 'Pernas'],
          points: 10
        },
        {
          id: 'for-031',
          title: 'Corrida com cabeçada',
          description: 'Corrida com simulação de cabeçadas',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 metros corrida + cabeçada (repetir 6x)',
            rest: '75 segundos entre séries',
            tips: ['Salto vertical', 'Simulação de cabeçada', 'Sprint entre repetições']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Coordenação'],
          points: 10
        },
        {
          id: 'for-032',
          title: 'Corrida com carga',
          description: 'Corrida carregando peso',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '50 metros',
            rest: '90 segundos entre séries',
            tips: ['Peso nos ombros ou nas mãos', 'Postura mantida', 'Velocidade controlada']
          },
          equipment: ['Objeto pesado'],
          targetMuscles: ['Pernas', 'Core', 'Resistência'],
          points: 10
        },
        {
          id: 'for-033',
          title: 'Corrida com salto unilateral em equilíbrio',
          description: 'Corrida alternada com saltos unilaterais',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '90 segundos entre séries',
            tips: ['Saltos em uma perna', 'Equilíbrio mantido', 'Sprint entre saltos']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'for-034',
          title: 'Corrida controlada com elástico',
          description: 'Corrida com resistência de elástico',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '20 metros',
            rest: '90 segundos entre séries',
            tips: ['Elástico preso atrás', 'Força contra resistência', 'Inclinação para frente']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Potência', 'Velocidade'],
          points: 10
        },
        {
          id: 'for-035',
          title: 'Corrida ida e volta',
          description: 'Sprints com mudança rápida de direção',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '10 idas e voltas de 10 metros',
            rest: '90 segundos entre séries',
            tips: ['Mudança rápida de direção', 'Toque no cone', 'Máxima velocidade']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Agilidade', 'Velocidade'],
          points: 10
        },
        {
          id: 'for-036',
          title: 'Corrida ida e volta com agachamento',
          description: 'Sprint com agachamento antes de voltar',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '75 segundos entre séries',
            tips: ['Sprint até o cone', 'Agachamento profundo', 'Sprint de volta']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Cardio', 'Força'],
          points: 10
        },
        {
          id: 'for-037',
          title: 'Corrida mais salto',
          description: 'Corrida intercalada com saltos verticais',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 metros corrida + salto (repetir 8x)',
            rest: '75 segundos entre séries',
            tips: ['Sprint de 10m', 'Salto máximo', 'Repetir imediatamente']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Potência', 'Cardio'],
          points: 10
        },
        {
          id: 'for-038',
          title: 'Flexão com apoio estável',
          description: 'Flexão de braço tradicional com boa base',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Corpo alinhado', 'Cotovelos próximos ao corpo', 'Amplitude completa']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Core'],
          points: 10
        },
        {
          id: 'for-039',
          title: 'Flexão com elevação de perna',
          description: 'Flexão alternando elevação de pernas',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Flexão + eleva perna', 'Core sempre ativo', 'Alternância']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Core', 'Glúteos'],
          points: 10
        },
        {
          id: 'for-040',
          title: 'Flexão com explosão',
          description: 'Flexão pliométrica com mãos saindo do chão',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Explosão na subida', 'Mãos saem do chão', 'Aterrissagem controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Potência'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'for-041',
          title: 'Flexão com parada',
          description: 'Flexão com pausa isométrica no meio do movimento',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Pausa de 2 segundos no meio', 'Corpo alinhado', 'Força isométrica']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Core'],
          points: 10
        },
        {
          id: 'for-042',
          title: 'Flexão dinâmica',
          description: 'Flexão com movimento rápido e contínuo',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Ritmo acelerado', 'Movimento fluido', 'Respiração constante']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Resistência'],
          points: 10
        },
        {
          id: 'for-043',
          title: 'Passada com carga',
          description: 'Passadas longas carregando peso',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 passadas',
            rest: '60 segundos entre séries',
            tips: ['Passos longos', 'Peso nas mãos ou ombros', 'Postura ereta']
          },
          equipment: ['Halteres ou mochila'],
          targetMuscles: ['Pernas', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'for-044',
          title: 'Ponte dinâmica',
          description: 'Elevação de quadril com movimento dinâmico',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Eleva quadril totalmente', 'Contrai glúteos no topo', 'Movimento controlado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Lombar'],
          points: 10
        },
        {
          id: 'for-045',
          title: 'Ponte unilateral',
          description: 'Elevação de quadril com uma perna só',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Uma perna estendida', 'Quadril alinhado', 'Força unilateral']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'for-046',
          title: 'Prancha com bola',
          description: 'Prancha com instabilidade da bola',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada',
            rest: '60 segundos entre séries',
            tips: ['Antebraços na bola', 'Core super ativado', 'Estabilidade total']
          },
          equipment: ['Bola suíça'],
          targetMuscles: ['Core', 'Ombros', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'for-047',
          title: 'Prancha com flexão de perna',
          description: 'Prancha alternando flexão de pernas',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições (10 cada perna)',
            rest: '45 segundos entre séries',
            tips: ['Prancha + joelho ao peito', 'Alternância', 'Core sempre ativo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Quadríceps', 'Ombros'],
          points: 10
        },
        {
          id: 'for-048',
          title: 'Prancha dinâmica',
          description: 'Prancha com movimento de antebraços para mãos',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Sobe de antebraços para mãos', 'Alternância', 'Quadril estável']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Tríceps', 'Ombros'],
          points: 10
        },
        {
          id: 'for-049',
          title: 'Prancha isométrica',
          description: 'Manutenção da posição de prancha',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada',
            rest: '45 segundos entre séries',
            tips: ['Corpo alinhado', 'Quadril não cai', 'Respiração constante']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Resistência'],
          points: 10
        },
        {
          id: 'for-050',
          title: 'Saída de joelho',
          description: 'Explosão partindo da posição ajoelhada',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '75 segundos entre séries',
            tips: ['Explosão máxima', 'De joelhos para em pé', 'Equilíbrio na saída']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Pernas', 'Core', 'Explosão'],
          points: 10
        },
        {
          id: 'for-051',
          title: 'Saída de joelho com carga',
          description: 'Explosão de joelhos carregando peso',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '90 segundos entre séries',
            tips: ['Peso no peito', 'Explosão controlada', 'Equilíbrio na chegada']
          },
          equipment: ['Colchonete', 'Objeto pesado'],
          targetMuscles: ['Pernas', 'Core', 'Potência'],
          points: 10
        },
        {
          id: 'for-052',
          title: 'Saída de joelho com carga 2',
          description: 'Variação com peso acima da cabeça',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '6 repetições',
            rest: '2 minutos entre séries',
            tips: ['Peso elevado acima da cabeça', 'Explosão máxima', 'Estabilidade total']
          },
          equipment: ['Colchonete', 'Objeto pesado'],
          targetMuscles: ['Pernas', 'Ombros', 'Core', 'Potência'],
          points: 10
        },
        {
          id: 'for-053',
          title: 'Salto com carga',
          description: 'Salto vertical carregando peso',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Peso nas mãos ou ombros', 'Salto máximo', 'Aterrissagem controlada']
          },
          equipment: ['Halteres ou mochila'],
          targetMuscles: ['Pernas', 'Ombros', 'Potência'],
          points: 10
        },
        {
          id: 'for-054',
          title: 'Salto com equilíbrio',
          description: 'Salto seguido de manutenção de equilíbrio',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Salto + pausa em uma perna', 'Estabilização de 3 segundos', 'Equilíbrio total']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'for-055',
          title: 'Salto unilateral',
          description: 'Saltos consecutivos em uma perna só',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '75 segundos entre séries',
            tips: ['Saltos contínuos', 'Equilíbrio unilateral', 'Força em uma perna']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Potência'],
          points: 10
        },
        {
          id: 'for-056',
          title: 'Salto vertical máximo',
          description: 'Salto com máxima altura possível',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '8 repetições',
            rest: '2 minutos entre séries',
            tips: ['Explosão máxima', 'Braços para cima', 'Recuperação completa']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Potência vertical', 'Explosão'],
          points: 10
        },
        {
          id: 'for-057',
          title: 'Subida no step com carga',
          description: 'Subida em step ou banco carregando peso',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Peso nas mãos ou ombros', 'Suba completamente', 'Controle na descida']
          },
          equipment: ['Step ou banco', 'Halteres ou mochila'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'for-058',
          title: 'Subida no step com elevação de joelho',
          description: 'Subida no step com elevação do joelho livre',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Sobe e eleva joelho', 'Equilíbrio no topo', 'Movimento fluido']
          },
          equipment: ['Step ou banco'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'for-059',
          title: 'Superman',
          description: 'Exercício de extensão lombar e posterior',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Eleva braços e pernas simultaneamente', 'Contrai lombar e glúteos', 'Pausa no topo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Lombar', 'Glúteos', 'Posterior'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'equilibrio',
    name: 'Equilíbrio',
    description: 'Desenvolva estabilidade e controle corporal',
    icon: '⚖️',
    color: 'bg-teal-500',
    trainings: {
      academia: [
        {
          id: 'equ-acad-001',
          title: 'Abdominal Dinâmico sobre Superfície Instável com Equilíbrio',
          description: 'Exercício abdominal sobre bola suíça ou bosu para trabalhar core e equilíbrio',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: [
              'Mantenha equilíbrio constante na bola',
              'Core sempre contraído',
              'Movimento controlado e preciso'
            ]
          },
          equipment: ['Bola suíça', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-002',
          title: 'Abdução Unilateral com Elástico em Equilíbrio',
          description: 'Afastamento lateral de perna equilibrado em uma perna só',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Mantenha equilíbrio na perna de apoio',
              'Abdução completa da perna livre',
              'Controle a resistência do elástico'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Glúteo médio', 'Abdutores', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-003',
          title: 'Afundo com Equilíbrio',
          description: 'Afundo seguido de equilíbrio em uma perna só',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Afundo completo antes do equilíbrio',
              'Pausa de 3 segundos em equilíbrio',
              'Joelho alinhado com ponta do pé'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-004',
          title: 'Afundo com Salto em Equilíbrio',
          description: 'Afundo explosivo finalizando com equilíbrio unilateral',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Explosão máxima no salto',
              'Aterrissagem em uma perna',
              'Estabilização completa'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Explosão', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-005',
          title: 'Afundo Dinâmico em Equilíbrio com Mãos sobre a Cabeça',
          description: 'Afundo alternado com mãos na cabeça e equilíbrio',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '75 segundos entre séries',
            tips: [
              'Mãos atrás da cabeça durante todo exercício',
              'Tronco ereto e alinhado',
              'Equilíbrio entre repetições'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-006',
          title: 'Agachamento com Braços à Frente em Equilíbrio',
          description: 'Agachamento unilateral com braços estendidos à frente',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Braços estendidos para equilíbrio',
              'Agachamento profundo em uma perna',
              'Controle total do movimento'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-007',
          title: 'Agachamento com Equilíbrio de Bastão',
          description: 'Agachamento segurando bastão horizontalmente para equilíbrio',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: [
              'Bastão horizontal acima da cabeça',
              'Equilíbrio constante durante agachamento',
              'Postura ereta mantida'
            ]
          },
          equipment: ['Bastão ou cabo de vassoura'],
          targetMuscles: ['Pernas', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'equ-acad-008',
          title: 'Agachamento em Superfície Instável',
          description: 'Agachamento sobre bosu ou almofada de equilíbrio',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '75 segundos entre séries',
            tips: [
              'Pés firmes na superfície instável',
              'Movimento lento e controlado',
              'Core sempre ativado'
            ]
          },
          equipment: ['Bosu ou almofada de equilíbrio'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-009',
          title: 'Agachamento Isométrico com Rotação de Tronco',
          description: 'Posição de agachamento mantida com rotações de tronco',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada',
            rest: '60 segundos entre séries',
            tips: [
              'Agachamento a 90 graus mantido',
              'Rotações controladas do tronco',
              'Equilíbrio constante'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Core', 'Oblíquos'],
          points: 10
        },
        {
          id: 'equ-acad-010',
          title: 'Agachamento Isométrico na Parede Unilateral',
          description: 'Agachamento isométrico na parede com uma perna elevada',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '3 séries',
            repetitions: '30 segundos cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Costas apoiadas na parede',
              'Uma perna sustenta todo peso',
              'Joelho a 90 graus'
            ]
          },
          equipment: ['Parede'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Força unilateral'],
          points: 10
        },
        {
          id: 'equ-acad-011',
          title: 'Agachamento Lateral com Braços pra Cima',
          description: 'Agachamento lateral alternado com braços elevados',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: [
              'Braços estendidos acima da cabeça',
              'Agachamento lateral profundo',
              'Equilíbrio durante transição'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Adutores', 'Core'],
          points: 10
        },
        {
          id: 'equ-acad-012',
          title: 'Agachamento sobre Superfície Instável Unilateral',
          description: 'Agachamento em uma perna sobre superfície instável',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '3 séries',
            repetitions: '8 repetições cada perna',
            rest: '2 minutos entre séries',
            tips: [
              'Máximo controle e estabilidade',
              'Movimento muito lento',
              'Core extremamente ativo'
            ]
          },
          equipment: ['Bosu ou almofada'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-013',
          title: 'Equilíbrio com Carga',
          description: 'Manutenção de equilíbrio em uma perna segurando peso',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Peso nas mãos ou ombros',
              'Olhar fixo em um ponto',
              'Respiração constante'
            ]
          },
          equipment: ['Halter ou anilha'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-014',
          title: 'Equilíbrio com Carga acima da Cabeça',
          description: 'Equilíbrio unilateral com peso elevado acima da cabeça',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '3 séries',
            repetitions: '40 segundos cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Peso totalmente elevado',
              'Braço estendido e travado',
              'Core super ativado'
            ]
          },
          equipment: ['Halter ou kettlebell'],
          targetMuscles: ['Pernas', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'equ-acad-015',
          title: 'Equilíbrio com Carga sobre Superfície Instável',
          description: 'Equilíbrio com peso sobre bosu ou almofada',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '3 séries',
            repetitions: '35 segundos cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Combinação de instabilidade e carga',
              'Máxima concentração',
              'Progressão gradual de peso'
            ]
          },
          equipment: ['Bosu', 'Halter'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-016',
          title: 'Equilíbrio com Elástico + Elevação de Perna',
          description: 'Equilíbrio com elevações laterais de perna contra resistência',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elástico no tornozelo',
              'Elevação lateral controlada',
              'Equilíbrio constante na perna de apoio'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Glúteo médio', 'Abdutores', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-017',
          title: 'Equilíbrio com Elástico nos Pés',
          description: 'Manutenção de equilíbrio com elástico entre os pés',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Elástico cria tensão constante',
              'Mantenha postura ereta',
              'Core ativado durante todo exercício'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-018',
          title: 'Equilíbrio com Elevação à Frente com Elástico',
          description: 'Equilíbrio com elevação frontal de perna contra resistência',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elevação frontal controlada',
              'Elástico preso atrás',
              'Tronco ereto mantido'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Quadríceps', 'Flexores de quadril', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-acad-019',
          title: 'Equilíbrio na Bola com Contração Abdominal',
          description: 'Equilíbrio sentado na bola suíça com contrações abdominais',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 contrações',
            rest: '45 segundos entre séries',
            tips: [
              'Sentado no centro da bola',
              'Pés podem sair do chão',
              'Core sempre contraído'
            ]
          },
          equipment: ['Bola suíça'],
          targetMuscles: ['Core', 'Abdômen', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-020',
          title: 'Flexão com Equilíbrio Unilateral',
          description: 'Flexão de braço com uma perna elevada',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '75 segundos entre séries',
            tips: [
              'Uma perna elevada durante toda série',
              'Flexão completa',
              'Core estabiliza corpo'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Core'],
          points: 10
        },
        {
          id: 'equ-acad-021',
          title: 'Flexão de Perna com Bola',
          description: 'Flexão de isquiotibiais rolando bola suíça',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: [
              'Pés sobre a bola',
              'Quadril elevado durante exercício',
              'Controle o movimento da bola'
            ]
          },
          equipment: ['Bola suíça'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'equ-acad-022',
          title: 'Equilíbrio lombar com elástico',
          description: 'Inclinação frontal em uma perna com resistência de elástico',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elástico preso à frente',
              'Inclinação controlada do tronco',
              'Perna de trás estendida'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Lombar', 'Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'equ-acad-023',
          title: 'Ponte de Glúteo sobre Superfície Instável Unilateral',
          description: 'Elevação de quadril em uma perna sobre bosu',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '75 segundos entre séries',
            tips: [
              'Pé sobre superfície instável',
              'Quadril completamente elevado',
              'Contração máxima no topo'
            ]
          },
          equipment: ['Bosu', 'Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'equ-acad-024',
          title: 'Prancha com Equilíbrio sobre Superfície Instável',
          description: 'Prancha com antebraços sobre bola ou bosu',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada',
            rest: '60 segundos entre séries',
            tips: [
              'Antebraços na superfície instável',
              'Corpo completamente alinhado',
              'Core extremamente ativo'
            ]
          },
          equipment: ['Bola suíça ou bosu'],
          targetMuscles: ['Core', 'Ombros', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-acad-025',
          title: 'Prancha Lateral em Equilíbrio',
          description: 'Prancha lateral com perna superior elevada',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '35 segundos cada lado',
            rest: '60 segundos entre séries',
            tips: [
              'Perna de cima elevada',
              'Corpo alinhado lateralmente',
              'Oblíquos sempre ativos'
            ]
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Oblíquos', 'Core', 'Ombros'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'equ-livre-001',
          title: 'Caminhada com Equilíbrio de Carga nos Pés',
          description: 'Caminhada carregando peso nos pés alternadamente',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '20 metros',
            rest: '60 segundos entre séries',
            tips: [
              'Peso amarrado no tornozelo',
              'Passos controlados',
              'Equilíbrio mantido'
            ]
          },
          equipment: ['Caneleiras ou peso improvisado'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-002',
          title: 'Caminhada com Equilíbrio de Peso',
          description: 'Caminhada com peso acima da cabeça ou nos ombros',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '25 metros',
            rest: '75 segundos entre séries',
            tips: [
              'Peso estável acima da cabeça',
              'Postura ereta durante caminhada',
              'Olhar à frente'
            ]
          },
          equipment: ['Objeto pesado'],
          targetMuscles: ['Pernas', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'equ-livre-003',
          title: 'Caminhada sobre Superfície Instável',
          description: 'Caminhada sobre linha ou superfície estreita',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '5 séries',
            repetitions: '15 metros',
            rest: '45 segundos entre séries',
            tips: [
              'Um pé na frente do outro',
              'Braços abertos para equilíbrio',
              'Concentração máxima'
            ]
          },
          equipment: ['Linha marcada no chão'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'equ-livre-004',
          title: 'Circuito com Equilíbrio Trocando de Perna',
          description: 'Circuito de equilíbrio com trocas alternadas de perna',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '8 estações de 20 segundos',
            rest: '90 segundos entre séries',
            tips: [
              'Troca rápida entre pernas',
              'Equilíbrio mantido em cada estação',
              'Sem tocar o chão com perna livre'
            ]
          },
          equipment: ['Cones marcadores'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Resistência'],
          points: 10
        },
        {
          id: 'equ-livre-005',
          title: 'Corrida com Salto sobre Superfície Instável',
          description: 'Sprint com saltos sobre marcações',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '30 metros com 5 saltos',
            rest: '90 segundos entre séries',
            tips: [
              'Aterrissagem em uma perna',
              'Estabilização rápida antes do próximo',
              'Velocidade mantida'
            ]
          },
          equipment: ['Cones ou marcadores'],
          targetMuscles: ['Pernas', 'Explosão', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-006',
          title: 'Equilíbrio com Perna à Frente e Mãos sobre a Cabeça',
          description: 'Equilíbrio estático com perna estendida à frente',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Perna livre estendida à frente',
              'Mãos atrás da cabeça',
              'Olhar fixo em um ponto'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Flexores de quadril'],
          points: 10
        },
        {
          id: 'equ-livre-007',
          title: 'Equilíbrio com um Pé só com Rotação de Tronco',
          description: 'Equilíbrio com rotações laterais do tronco',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 rotações cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Rotação ampla do tronco',
              'Equilíbrio mantido durante rotação',
              'Braços estendidos lateralmente'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Oblíquos'],
          points: 10
        },
        {
          id: 'equ-livre-008',
          title: 'Equilíbrio com um Pé só com Toque à Frente',
          description: 'Equilíbrio com inclinação e toque no chão à frente',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Toque com mão oposta no chão',
              'Perna livre estendida atrás',
              'Retorno ao equilíbrio'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Isquiotibiais', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-009',
          title: 'Equilíbrio com um Pé só com Toque ao Lado',
          description: 'Equilíbrio com toque lateral no chão',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: [
              'Toque lateral controlado',
              'Equilíbrio na perna de apoio',
              'Movimento fluido'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Adutores', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-010',
          title: 'Equilíbrio de Peso com uma Perna em Equilíbrio',
          description: 'Manutenção de equilíbrio segurando objeto pesado',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Peso em diferentes posições',
              'Concentração total',
              'Respiração controlada'
            ]
          },
          equipment: ['Objeto pesado'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-livre-011',
          title: 'Equilíbrio de um Pé só',
          description: 'Equilíbrio estático básico em uma perna',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '5 séries',
            repetitions: '60 segundos cada perna',
            rest: '30 segundos entre séries',
            tips: [
              'Olhar fixo à frente',
              'Braços abertos para ajudar',
              'Progressivamente feche os olhos'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'equ-livre-012',
          title: 'Equilíbrio Dinâmico com Elástico nos Pés',
          description: 'Equilíbrio com movimentos de perna contra resistência',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 movimentos cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elástico entre tornozelos',
              'Movimentos em todas direções',
              'Equilíbrio constante'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-013',
          title: 'Equilíbrio Dinâmico com Mãos na Cabeça',
          description: 'Movimentos dinâmicos em equilíbrio com mãos na cabeça',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Mãos atrás da cabeça',
              'Movimentos variados da perna livre',
              'Tronco sempre ereto'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-014',
          title: 'Equilíbrio Dinâmico com Troca de Perna',
          description: 'Equilíbrio alternado com trocas explosivas',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '20 trocas',
            rest: '60 segundos entre séries',
            tips: [
              'Troca rápida entre pernas',
              'Pequeno salto na troca',
              'Estabilização imediata'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Agilidade'],
          points: 10
        },
        {
          id: 'equ-livre-015',
          title: 'Equilíbrio Unilateral pegando Bastão no Solo',
          description: 'Equilíbrio com inclinação para pegar bastão',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Inclinação completa até o bastão',
              'Perna de trás estendida',
              'Movimento controlado'
            ]
          },
          equipment: ['Bastão ou cabo de vassoura'],
          targetMuscles: ['Pernas', 'Isquiotibiais', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-016',
          title: 'Equilíbrio Unilateral pegando Objeto do Solo',
          description: 'Equilíbrio unilateral com agachamento para pegar objeto',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Agachamento em uma perna',
              'Pega objeto no chão',
              'Retorna ao equilíbrio'
            ]
          },
          equipment: ['Objeto leve (bola, cone)'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-017',
          title: 'Equilíbrio Unilateral com Elástico',
          description: 'Equilíbrio com resistência de elástico em várias direções',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 movimentos cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elástico preso em ponto fixo',
              'Resistência em diferentes ângulos',
              'Equilíbrio constante'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-livre-018',
          title: 'Peso Morto sem Carga com Salto',
          description: 'Movimento de peso morto unilateral com salto',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '75 segundos entre séries',
            tips: [
              'Inclinação até posição de peso morto',
              'Explosão com salto unilateral',
              'Aterrissagem e equilíbrio'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Glúteos', 'Explosão'],
          points: 10
        },
        {
          id: 'equ-livre-019',
          title: 'Polichinelo com uma Perna só',
          description: 'Movimento de polichinelo equilibrado em uma perna',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Saltos pequenos em uma perna',
              'Braços fazem movimento de polichinelo',
              'Equilíbrio mantido'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Cardio', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-livre-020',
          title: 'Ponte de Glúteo Unilateral sobre Superfície Instável',
          description: 'Elevação de quadril em uma perna sobre superfície irregular',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Pé sobre almofada ou superfície macia',
              'Elevação completa do quadril',
              'Contração máxima dos glúteos'
            ]
          },
          equipment: ['Almofada ou toalha dobrada'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'equ-livre-021',
          title: 'Rotação de Tronco com Equilíbrio',
          description: 'Rotações de tronco amplas em equilíbrio unilateral',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 rotações cada perna',
            rest: '45 segundos entre séries',
            tips: [
              'Rotação completa do tronco',
              'Quadril estável',
              'Equilíbrio constante'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Core', 'Oblíquos', 'Equilíbrio'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'equ-equip-001',
          title: 'Prancha com Perna Elevada em Equilíbrio',
          description: 'Prancha com alternância de pernas elevadas',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos cada',
            rest: '60 segundos entre séries',
            tips: [
              'Eleva uma perna por vez',
              'Quadril alinhado',
              'Core sempre ativo'
            ]
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Glúteos', 'Ombros'],
          points: 10
        },
        {
          id: 'equ-equip-002',
          title: 'Prancha com Toque nos Cotovelos em Equilíbrio',
          description: 'Prancha com toques alternados nos cotovelos',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '20 toques',
            rest: '60 segundos entre séries',
            tips: [
              'Toca ombro com mão oposta',
              'Minimiza rotação do quadril',
              'Equilíbrio durante movimento'
            ]
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-equip-003',
          title: 'Prancha de Joelhos Dinâmica',
          description: 'Prancha de joelhos com movimentos alternados',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada',
            rest: '45 segundos entre séries',
            tips: [
              'Joelhos apoiados',
              'Movimentos controlados',
              'Progressão para prancha completa'
            ]
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros'],
          points: 10
        },
        {
          id: 'equ-equip-004',
          title: 'Salto 360 Unilateral',
          description: 'Salto com giro de 360 graus em uma perna',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '6 repetições cada perna',
            rest: '2 minutos entre séries',
            tips: [
              'Giro completo no ar',
              'Aterrissagem na mesma perna',
              'Equilíbrio após aterrissagem'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Explosão', 'Coordenação'],
          points: 10
        },
        {
          id: 'equ-equip-005',
          title: 'Salto com Agachamento em Equilíbrio',
          description: 'Salto seguido de agachamento em uma perna',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Salto vertical primeiro',
              'Aterrissagem em uma perna',
              'Agachamento profundo em equilíbrio'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Força'],
          points: 10
        },
        {
          id: 'equ-equip-006',
          title: 'Salto com Estabilização',
          description: 'Salto com pausa de estabilização ao aterrissar',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: [
              'Aterrissagem controlada',
              'Pausa de 3 segundos',
              'Equilíbrio perfeito antes do próximo'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Controle'],
          points: 10
        },
        {
          id: 'equ-equip-007',
          title: 'Salto com uma Perna só em Equilíbrio',
          description: 'Saltos consecutivos na mesma perna',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 saltos cada perna',
            rest: '90 segundos entre séries',
            tips: [
              'Saltos contínuos',
              'Equilíbrio entre cada salto',
              'Altura consistente'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Panturrilha', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-008',
          title: 'Salto Dinâmico em Equilíbrio',
          description: 'Saltos variados com equilíbrio entre repetições',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos variados',
            rest: '75 segundos entre séries',
            tips: [
              'Varie direção e altura',
              'Equilíbrio após cada salto',
              'Movimentos imprevisíveis'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Agilidade'],
          points: 10
        },
        {
          id: 'equ-equip-009',
          title: 'Salto em Superfície Instável',
          description: 'Saltos sobre almofada ou superfície macia',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '75 segundos entre séries',
            tips: [
              'Aterrissagem em superfície instável',
              'Estabilização rápida',
              'Core super ativado'
            ]
          },
          equipment: ['Almofada ou toalha dobrada'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'equ-equip-010',
          title: 'Salto Lateral com Cone em Equilíbrio',
          description: 'Saltos laterais sobre cone com equilíbrio',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '16 saltos (8 cada lado)',
            rest: '60 segundos entre séries',
            tips: [
              'Salto lateral sobre cone',
              'Aterrissagem em uma perna',
              'Equilíbrio antes de voltar'
            ]
          },
          equipment: ['Cone ou objeto baixo'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Agilidade'],
          points: 10
        },
        {
          id: 'equ-equip-011',
          title: 'Salto Lateral em Equilíbrio',
          description: 'Saltos laterais alternados com equilíbrio',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '20 saltos',
            rest: '60 segundos entre séries',
            tips: [
              'Salto lateral em uma perna',
              'Aterrissagem na mesma perna',
              'Equilíbrio entre repetições'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Agilidade lateral'],
          points: 10
        },
        {
          id: 'equ-equip-012',
          title: 'Subida com Equilíbrio em Superfície Instável',
          description: 'Subida em step ou degrau instável',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Step com almofada por cima',
              'Subida controlada',
              'Equilíbrio no topo'
            ]
          },
          equipment: ['Step', 'Almofada'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-013',
          title: 'Toque à Frente com Elástico sobre as Pernas',
          description: 'Toque frontal em equilíbrio com resistência de elástico',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Elástico ao redor das coxas',
              'Toque no chão à frente',
              'Equilíbrio mantido'
            ]
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-014',
          title: 'Toque à Frente com Elevação de Perna com Carga',
          description: 'Toque frontal seguido de elevação posterior com peso',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '75 segundos entre séries',
            tips: [
              'Peso nas mãos',
              'Toque no chão e elevação de perna',
              'Equilíbrio durante todo movimento'
            ]
          },
          equipment: ['Halteres ou objeto pesado'],
          targetMuscles: ['Pernas', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-015',
          title: 'Toque à Frente com Elevação de Pernas Dinâmico',
          description: 'Movimento contínuo de toque e elevação em equilíbrio',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Movimento fluido e contínuo',
              'Sem pausas entre repetições',
              'Equilíbrio constante'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-016',
          title: 'Toque Lateral no Cone Equilibrando a Perna',
          description: 'Toque lateral em cone mantendo equilíbrio',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 toques cada lado',
            rest: '60 segundos entre séries',
            tips: [
              'Toque lateral no cone',
              'Equilíbrio em uma perna',
              'Retorno controlado'
            ]
          },
          equipment: ['Cone ou objeto'],
          targetMuscles: ['Pernas', 'Adutores', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-017',
          title: 'Toque no Cone com Elevação de Perna',
          description: 'Toque em cone seguido de elevação de perna',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Toque no cone com mão',
              'Elevação da perna livre',
              'Equilíbrio mantido'
            ]
          },
          equipment: ['Cone ou objeto'],
          targetMuscles: ['Pernas', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'equ-equip-018',
          title: 'Toque no Cone Equilibrando uma Perna',
          description: 'Toques variados em cone mantendo equilíbrio unilateral',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: '/Equilibrio/image.png',
          instructions: {
            series: '4 séries',
            repetitions: '15 toques cada perna',
            rest: '60 segundos entre séries',
            tips: [
              'Toques em diferentes direções',
              'Equilíbrio constante',
              'Movimento controlado'
            ]
          },
          equipment: ['Cone ou objeto'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'fortalecimento',
    name: 'Fortalecimento',
    description: 'Fortalecimento muscular completo e progressivo',
    icon: '🏋️',
    color: 'bg-indigo-600',
    trainings: {
      academia: [
        {
          id: 'fort-001',
          title: 'Abdominal curto com carga',
          description: 'Movimento curto de abdômen com peso adicional',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1WjfAOSiSex-KRihg7bco0tCBlGvFpcOG/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Peso no peito', 'Movimento curto', 'Tensão constante']
          },
          equipment: ['Colchonete', 'Anilha ou halter'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'fort-002',
          title: 'Abdução de quadril com elástico',
          description: 'Afastamento lateral da perna com resistência elástica',
          duration: '16 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/178K3b0tXp-9NMgJTfBDUc__bis0rSbEI/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '30 segundos entre séries',
            tips: ['Elástico acima dos joelhos', 'Movimento controlado', 'Glúteos ativos']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Glúteo médio', 'Abdutores'],
          points: 10
        },
        {
          id: 'fort-003',
          title: 'Abdução de quadril sentado',
          description: 'Afastamento das pernas na posição sentada',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1YBmNUmes9MgdHUzpxCuY7SzblIiqC51H/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 repetições',
            rest: '40 segundos entre séries',
            tips: ['Costas retas', 'Elástico acima dos joelhos', 'Movimento amplo']
          },
          equipment: ['Banco', 'Elástico'],
          targetMuscles: ['Glúteo médio', 'Quadril'],
          points: 10
        },
        {
          id: 'fort-004',
          title: 'Afundo com chute à frente',
          description: 'Afundo seguido de chute frontal',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1hWaj5LoZ3lnfuEnhCuXMUARPbnRw1C0o/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições cada perna',
            rest: '50 segundos entre séries',
            tips: ['Equilíbrio na transição', 'Chute controlado', 'Joelho alinhado']
          },
          equipment: [],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-005',
          title: 'Afundo pra trás',
          description: 'Afundo com passo para trás',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1D8dxfMA7gIZTvu1lBckt34KXFE3OdaLl/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada perna',
            rest: '45 segundos entre séries',
            tips: ['Passo amplo', 'Joelho 90 graus', 'Tronco ereto']
          },
          equipment: ['Halteres (opcional)'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-006',
          title: 'Afundo com salto',
          description: 'Afundo alternado com impulsão',
          duration: '19 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1aQnIKkuzHKhCo-XVF1dSFeIvi7uqs9zU/preview',
          instructions: {
            series: '3 séries',
            repetitions: '16 alternados',
            rest: '60 segundos entre séries',
            tips: ['Aterrissagem suave', 'Explosão na troca', 'Equilíbrio constante']
          },
          equipment: [],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Panturrilha', 'Potência'],
          points: 10
        },
        {
          id: 'fort-007',
          title: 'Agachamento com deslocamento lateral',
          description: 'Agachamento com passo lateral',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1OW0urO8ygy4ZUxGkvzmpL_JdvJfR5TRj/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições cada lado',
            rest: '50 segundos entre séries',
            tips: ['Passo lateral amplo', 'Agachamento profundo', 'Pés paralelos']
          },
          equipment: ['Elástico (opcional)'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Adutores'],
          points: 10
        },
        {
          id: 'fort-008',
          title: 'Agachamento com elástico',
          description: 'Agachamento com resistência elástica',
          duration: '16 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1fp55eMErnUkigtYQNTWIEZ7JTw5EbcCb/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Elástico sob os pés', 'Costas retas', 'Joelhos alinhados']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'fort-009',
          title: 'Agachamento isométrico',
          description: 'Agachamento mantido em posição estática',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/13znSBfj42Mo5mCjSPOJmwuWNwUUSLFxd/preview',
          instructions: {
            series: '4 séries',
            repetitions: '30-45 segundos',
            rest: '60 segundos entre séries',
            tips: ['Coxas paralelas ao chão', 'Costas retas', 'Respiração constante']
          },
          equipment: [],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Resistência'],
          points: 10
        },
        {
          id: 'fort-010',
          title: 'Agachamento isométrico na parede',
          description: 'Agachamento estático com apoio na parede',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/13znSBfj42Mo5mCjSPOJmwuWNwUUSLFxd/preview',
          instructions: {
            series: '3 séries',
            repetitions: '40-60 segundos',
            rest: '60 segundos entre séries',
            tips: ['Costas apoiadas na parede', 'Joelhos 90 graus', 'Pés alinhados']
          },
          equipment: ['Parede'],
          targetMuscles: ['Quadríceps', 'Resistência muscular'],
          points: 10
        },
        {
          id: 'fort-011',
          title: 'Deslocamento lateral com agachamento',
          description: 'Passo lateral seguido de agachamento',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1IGc-9s9yaPdhIBLuh04lx28_LOMoAFYE/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Movimento fluido', 'Agachamento profundo', 'Elástico adiciona intensidade']
          },
          equipment: ['Elástico (opcional)'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Adutores'],
          points: 10
        },
        {
          id: 'fort-012',
          title: 'Deslocamento lateral com carga',
          description: 'Passo lateral carregando peso',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1Rc2KUwTo5zQebR_-vPQsGpnptP4KGFqg/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 passos cada lado',
            rest: '50 segundos entre séries',
            tips: ['Carga nos ombros ou mãos', 'Passos controlados', 'Postura ereta']
          },
          equipment: ['Halteres ou barra'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'fort-013',
          title: 'Deslocamento lateral com elástico',
          description: 'Caminhada lateral com resistência',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1_52wtp2Ox_hfjYi2aQ5V5abR9SdjKZU5/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 passos cada lado',
            rest: '40 segundos entre séries',
            tips: ['Elástico acima dos joelhos', 'Semi-agachado', 'Tensão constante']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Glúteo médio', 'Quadríceps'],
          points: 10
        },
        {
          id: 'fort-014',
          title: 'Elevação de perna alternado com elástico',
          description: 'Elevação alternada de pernas com resistência',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1arwnlXGJqH77IRS2tFrrK_iF2d7jtBqE/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 alternados',
            rest: '45 segundos entre séries',
            tips: ['Elástico no tornozelo', 'Perna reta', 'Core estabilizado']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'fort-015',
          title: 'Elevação de perna com elástico',
          description: 'Elevação posterior da perna',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1igQDzmjI42GudQlQu0n7Uq73qTHmZeee/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '40 segundos entre séries',
            tips: ['Movimento controlado', 'Glúteo contraído', 'Quadril estável']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-016',
          title: 'Elevação de perna deitado',
          description: 'Elevação de pernas na posição deitada',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/16HYwEEt1Cy1_ULwVKgAw2r7P61v6s7rB/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '40 segundos entre séries',
            tips: ['Pernas retas', 'Lombar no chão', 'Movimento controlado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen inferior', 'Hip flexors'],
          points: 10
        },
        {
          id: 'fort-017',
          title: 'Extensão de quadril com elástico',
          description: 'Extensão posterior do quadril',
          duration: '16 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1VQre8kv7-dZqDkGxCn65i9AbZMs-dofH/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '40 segundos entre séries',
            tips: ['Elástico amarrado', 'Movimento para trás', 'Glúteo ativo']
          },
          equipment: ['Elástico', 'Ponto de ancoragem'],
          targetMuscles: ['Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-018',
          title: 'Flexão com elástico',
          description: 'Flexão de braços com resistência adicional',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1B4ybd8--6IFrQaGYC54pR7tfr8SmRCwK/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Elástico nas costas', 'Descida controlada', 'Core ativado']
          },
          equipment: ['Elástico'],
          targetMuscles: ['Peitoral', 'Tríceps', 'Core'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'fort-019',
          title: 'Flexão com parada',
          description: 'Flexão com pausa no ponto médio',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1oB3ENhrRz-HJSbzp0CCRvdjy0J8KiTyN/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições',
            rest: '50 segundos entre séries',
            tips: ['Pausa de 2 segundos', 'Corpo alinhado', 'Tensão constante']
          },
          equipment: [],
          targetMuscles: ['Peitoral', 'Tríceps', 'Resistência'],
          points: 10
        },
        {
          id: 'fort-020',
          title: 'Flexão plantar',
          description: 'Elevação dos calcanhares',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1ynkHjQ4EZsENIx__sYoLjal42kJsB8Pu/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '40 segundos entre séries',
            tips: ['Movimento completo', 'Pausa no topo', 'Descida controlada']
          },
          equipment: ['Degrau (opcional)'],
          targetMuscles: ['Panturrilha', 'Sóleo'],
          points: 10
        },
        {
          id: 'fort-021',
          title: 'Panturrilha unilateral',
          description: 'Elevação de calcanhar com uma perna',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1EM1VOC5ftgaYxNeIrf1yeI6wX9PIkyq9/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '45 segundos entre séries',
            tips: ['Equilíbrio', 'Amplitude completa', 'Controle total']
          },
          equipment: ['Degrau ou parede para apoio'],
          targetMuscles: ['Panturrilha', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-022',
          title: 'Passada com carga',
          description: 'Caminhada com passadas longas e peso',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/11GzOTmjjXxFIZUPl25JPQX6rZ8fRe4l6/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 passos totais',
            rest: '50 segundos entre séries',
            tips: ['Halteres nas mãos', 'Passadas longas', 'Tronco ereto']
          },
          equipment: ['Halteres ou mochila'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Core'],
          points: 10
        },
        {
          id: 'fort-023',
          title: 'Passada sem carga',
          description: 'Caminhada com passadas longas',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1550Gre1gwEwGkFIfd_0TlgucgXNxJzjv/preview',
          instructions: {
            series: '3 séries',
            repetitions: '24 passos totais',
            rest: '40 segundos entre séries',
            tips: ['Passadas amplas', 'Joelho 90 graus', 'Movimento fluido']
          },
          equipment: [],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-024',
          title: 'Peso morto',
          description: 'Levantamento com articulação do quadril',
          duration: '19 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1ebLJoIC4G7VPc003Y_NwfinLEnW5ZdhE/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Costas retas', 'Articulação do quadril', 'Carga próxima ao corpo']
          },
          equipment: ['Barra, halteres ou mochila'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Lombar'],
          points: 10
        },
        {
          id: 'fort-025',
          title: 'Ponte de glúteo',
          description: 'Elevação de quadril deitado',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1fRHkyaThlapVL9LMVzNpxO5j8LOQpoIt/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 repetições',
            rest: '40 segundos entre séries',
            tips: ['Glúteos contraídos', 'Lombar neutra', 'Pausa no topo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-026',
          title: 'Ponte de glúteo com elástico',
          description: 'Ponte com resistência elástica',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1VO35SH7QHpZBeDobf-SYrA2GvO9jDaGi/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Elástico acima dos joelhos', 'Abdução no topo', 'Contração máxima']
          },
          equipment: ['Colchonete', 'Elástico'],
          targetMuscles: ['Glúteos', 'Abdutores'],
          points: 10
        },
        {
          id: 'fort-027',
          title: 'Ponte de glúteo unilateral com elástico',
          description: 'Ponte com uma perna e resistência',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1I7tzmv52_l95mTQjR1vyq1LvonquVazr/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições cada perna',
            rest: '50 segundos entre séries',
            tips: ['Elástico acima dos joelhos', 'Equilíbrio do quadril', 'Glúteo ativo']
          },
          equipment: ['Colchonete', 'Elástico'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'fort-028',
          title: 'Ponte com isometria unilateral',
          description: 'Ponte com uma perna mantida',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1SXWwESVmF1S75AKkxHMmEMbFcv6TGbXV/preview',
          instructions: {
            series: '3 séries',
            repetitions: '30 segundos cada perna',
            rest: '50 segundos entre séries',
            tips: ['Quadril elevado', 'Perna estendida', 'Estabilidade total']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Core', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-029',
          title: 'Ponte dinâmica',
          description: 'Ponte com movimento rápido',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1StXzC5KDMr17hQqhr85mWHgQwblFciCf/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Movimento explosivo', 'Controle na descida', 'Ritmo constante']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Potência'],
          points: 10
        },
        {
          id: 'fort-030',
          title: 'Ponte isométrica unilateral',
          description: 'Manutenção de ponte com uma perna',
          duration: '14 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1SXWwESVmF1S75AKkxHMmEMbFcv6TGbXV/preview',
          instructions: {
            series: '3 séries',
            repetitions: '40 segundos cada perna',
            rest: '60 segundos entre séries',
            tips: ['Quadril nivelado', 'Glúteo contraído', 'Respiração controlada']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Core', 'Resistência'],
          points: 10
        },
        {
          id: 'fort-031',
          title: 'Ponte unilateral',
          description: 'Elevação de quadril com uma perna',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1ljtd-j1vXuGiZZBMN1_jXO7cLIrsSz75/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada perna',
            rest: '50 segundos entre séries',
            tips: ['Uma perna estendida', 'Quadril estável', 'Movimento completo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Glúteos', 'Isquiotibiais', 'Core'],
          points: 10
        },
        {
          id: 'fort-032',
          title: 'Posição da canoa',
          description: 'Postura de V com corpo',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1GZeJc5EIYuNTEXN4BNF26ept1rV-_-7t/preview',
          instructions: {
            series: '3 séries',
            repetitions: '30 segundos',
            rest: '50 segundos entre séries',
            tips: ['Pernas e tronco elevados', 'Core ativo', 'Equilíbrio no quadril']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Hip flexors', 'Core'],
          points: 10
        },
        {
          id: 'fort-033',
          title: 'Prancha com abertura de pernas',
          description: 'Prancha com afastamento dos pés',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1TvBA0RAfhmsaJiISgfyB_ihE-LRHFWK7/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 abertura',
            rest: '45 segundos entre séries',
            tips: ['Prancha estável', 'Movimento lateral dos pés', 'Core contraído']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Oblíquos', 'Ombros'],
          points: 10
        },
        {
          id: 'fort-034',
          title: 'Prancha com deslocamento lateral',
          description: 'Prancha com movimento lateral',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/12wCwiUJXxttaw8a-Rt1MG9iYRS7THOTV/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 passos cada lado',
            rest: '50 segundos entre séries',
            tips: ['Movimento simultâneo de mão e pé', 'Quadril estável', 'Core firme']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Estabilidade'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'fort-035',
          title: 'Prancha com toque no ombro',
          description: 'Prancha com toque alternado',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1MUkC4DNsGocicyB4DW6gtDOrVPALVLAk/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 toques alternados',
            rest: '45 segundos entre séries',
            tips: ['Quadril estável', 'Movimento controlado', 'Core ativado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Estabilidade'],
          points: 10
        },
        {
          id: 'fort-036',
          title: 'Prancha isométrica',
          description: 'Manutenção da posição de prancha',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1W3aSt9Fim3P5qJQcxuQcDLSuVQl_eNaL/preview',
          instructions: {
            series: '3 séries',
            repetitions: '45-60 segundos',
            rest: '50 segundos entre séries',
            tips: ['Corpo alinhado', 'Core contraído', 'Respiração constante']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Resistência'],
          points: 10
        },
        {
          id: 'fort-037',
          title: 'Prancha isométrica com elevação',
          description: 'Prancha com elevação de membros',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1vPH5HUXuanGTnl_rUuXPhHW59qawHJdy/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 elevações cada lado',
            rest: '50 segundos entre séries',
            tips: ['Eleve braço e perna oposta', 'Equilíbrio total', 'Core estável']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Ombros', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-038',
          title: 'Prancha lateral com rotação',
          description: 'Prancha lateral com giro de tronco',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1pp3sPf4zSWxG5elS9xWbmWMdq5UG5_OW/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 rotações cada lado',
            rest: '50 segundos entre séries',
            tips: ['Rotação completa', 'Quadril elevado', 'Oblíquos ativos']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Oblíquos', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'fort-039',
          title: 'Step lateral',
          description: 'Subida lateral em degrau',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1-P_HzlqBoCquNPPuUeHRpaik17n38lrG/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Movimento lateral', 'Pé completo no step', 'Equilíbrio']
          },
          equipment: ['Step, banco ou escada'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Adutores'],
          points: 10
        },
        {
          id: 'fort-040',
          title: 'Abdução de quadril com perna direita',
          description: 'Afastamento lateral da perna direita',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1_7bVfJ87ZvZTy91KL3OlWPIhI3gcyH6j/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 repetições',
            rest: '40 segundos entre séries',
            tips: ['Movimento lateral', 'Glúteo médio ativo', 'Controle total']
          },
          equipment: ['Elástico (opcional)'],
          targetMuscles: ['Glúteo médio', 'Abdutores'],
          points: 10
        },
        {
          id: 'fort-041',
          title: 'Abdução de quadril com perna esquerda',
          description: 'Afastamento lateral da perna esquerda',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1go3To8XUuQSuBwG9GtNIU2Osi35he743/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 repetições',
            rest: '40 segundos entre séries',
            tips: ['Movimento lateral', 'Glúteo médio ativo', 'Controle total']
          },
          equipment: ['Elástico (opcional)'],
          targetMuscles: ['Glúteo médio', 'Abdutores'],
          points: 10
        },
        {
          id: 'fort-042',
          title: 'Agachamento búlgaro',
          description: 'Agachamento unilateral com perna elevada',
          duration: '19 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1RlYpB3-iWj9Ci4OFwb9fQ44Oja1cEuqS/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições cada perna',
            rest: '60 segundos entre séries',
            tips: ['Pé de trás elevado', 'Descida profunda', 'Joelho alinhado']
          },
          equipment: ['Banco ou cadeira', 'Halteres (opcional)'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-043',
          title: 'Cadeira romana',
          description: 'Extensão de lombar em banco',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1RfcY4HAtDmXMlXWZlbzIpJYS4mBBIZPZ/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Extensão controlada', 'Lombar ativa', 'Movimento completo']
          },
          equipment: ['Banco inclinado ou mesa'],
          targetMuscles: ['Lombar', 'Glúteos', 'Isquiotibiais'],
          points: 10
        },
        {
          id: 'fort-044',
          title: 'Agachamento afastado',
          description: 'Agachamento com pés afastados',
          duration: '16 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1uSQhyYWKm7xSYdwSFTF91_yxXvTqQFud/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Pés mais largos que ombros', 'Pontas dos pés para fora', 'Agachamento profundo']
          },
          equipment: [],
          targetMuscles: ['Glúteos', 'Adutores', 'Quadríceps'],
          points: 10
        },
        {
          id: 'fort-045',
          title: 'Elevação de calcanhar bilateral',
          description: 'Elevação dos calcanhares com ambos os pés',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1oQDZP74TfR7kBrGGZ2SzQcLOXIZDzRDn/preview',
          instructions: {
            series: '4 séries',
            repetitions: '25 repetições',
            rest: '40 segundos entre séries',
            tips: ['Amplitude total', 'Pausa no topo', 'Controle na descida']
          },
          equipment: ['Degrau (opcional)'],
          targetMuscles: ['Panturrilha', 'Sóleo'],
          points: 10
        },
        {
          id: 'fort-046',
          title: 'Stiff unilateral',
          description: 'Peso morto unilateral',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1_MpQTYRBQzvGm9Hj0b0vx23lnCi0Vs_p/preview',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições cada perna',
            rest: '50 segundos entre séries',
            tips: ['Uma perna de base', 'Articulação do quadril', 'Equilíbrio']
          },
          equipment: ['Halter ou garrafa'],
          targetMuscles: ['Isquiotibiais', 'Glúteos', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-047',
          title: 'Mesa de quatro apoios',
          description: 'Posição de mesa com membros elevados',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1oAmXUNaKVaC93yR5eZdUJKPG5lVXo0sN/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 elevações alternadas',
            rest: '45 segundos entre séries',
            tips: ['Braço e perna oposta', 'Core estável', 'Coluna neutra']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Core', 'Glúteos', 'Ombros', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'fort-048',
          title: 'Remada invertida',
          description: 'Puxada invertida em barra baixa',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1kf2kzWQgKn6_4pv6BZrsBnfmQq3OHl6Y/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições',
            rest: '50 segundos entre séries',
            tips: ['Corpo reto', 'Puxar omoplatas', 'Peitoral toca a barra']
          },
          equipment: ['Barra baixa ou mesa firme'],
          targetMuscles: ['Dorsais', 'Bíceps', 'Core'],
          points: 10
        },
        {
          id: 'fort-049',
          title: 'Extensão lombar no chão',
          description: 'Extensão da coluna deitado',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1V_8YLBQ9aQJ3GnkKSUYZ4UklbVX0SSGF/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '40 segundos entre séries',
            tips: ['Eleve tronco e pernas', 'Lombar contraída', 'Movimento controlado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Lombar', 'Glúteos', 'Eretores'],
          points: 10
        },
        {
          id: 'fort-050',
          title: 'Abdominal bicicleta',
          description: 'Abdominal com movimento de pedalar',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1LOdC0WFKUPqf0ixJcBb5gFE0mQe8uL3z/preview',
          instructions: {
            series: '3 séries',
            repetitions: '30 alternados',
            rest: '45 segundos entre séries',
            tips: ['Cotovelo toca joelho oposto', 'Rotação de tronco', 'Movimento alternado']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Oblíquos'],
          points: 10
        },
        {
          id: 'fort-051',
          title: 'Prancha lateral',
          description: 'Prancha em apoio lateral',
          duration: '13 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1K2J9tBcDUOLj36rlGXEDCJjnvuwN6aQG/preview',
          instructions: {
            series: '3 séries',
            repetitions: '30-45 segundos cada lado',
            rest: '45 segundos entre séries',
            tips: ['Corpo alinhado', 'Quadril elevado', 'Oblíquos contraídos']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Oblíquos', 'Core', 'Ombros'],
          points: 10
        },
        {
          id: 'fort-052',
          title: 'Rosca direta com garrafa',
          description: 'Flexão de bíceps com improviso',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1_LTQyxVfVtD68wgaOXJHbARxVjHjxjOH/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '40 segundos entre séries',
            tips: ['Garrafas cheias de água/areia', 'Cotovelos fixos', 'Movimento completo']
          },
          equipment: ['Garrafas ou objetos pesados'],
          targetMuscles: ['Bíceps', 'Antebraços'],
          points: 10
        },
        {
          id: 'fort-053',
          title: 'Tríceps banco',
          description: 'Extensão de tríceps em banco',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1mQ1mKCp_Qb6X2_r_UY2DtAvUpVmfxpuG/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Mãos no banco', 'Cotovelos para trás', 'Descida controlada']
          },
          equipment: ['Banco ou cadeira firme'],
          targetMuscles: ['Tríceps', 'Ombros'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'elasticidade',
    name: 'Elasticidade/Mobilidade',
    description: 'Melhore flexibilidade e amplitude de movimento',
    icon: '🤸‍♂️',
    color: 'bg-green-500',
    trainings: {
      academia: [
        {
          id: 'ela-acad-001',
          title: 'Alongamento Dinâmico Completo',
          description: 'Sequência de alongamentos dinâmicos para aquecer e preparar o corpo todo',
          duration: '20 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '2 séries',
            repetitions: '10 movimentos cada',
            rest: '30 segundos entre exercícios',
            tips: [
              'Movimentos controlados',
              'Não force além do limite',
              'Respire profundamente'
            ]
          },
          equipment: ['Colchonete', 'Espelho'],
          targetMuscles: ['Corpo inteiro', 'Articulações'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'ela-livre-001',
          title: 'Mobilidade de Quadril',
          description: 'Exercícios específicos para aumentar a mobilidade e flexibilidade do quadril',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '15 movimentos',
            rest: '45 segundos entre séries',
            tips: [
              'Amplitude completa de movimento',
              'Mantenha postura ereta',
              'Concentre-se na respiração'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadril', 'Glúteos', 'Flexores'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'ela-equip-001',
          title: 'Alongamento com Elástico',
          description: 'Use elásticos para aprofundar os alongamentos e melhorar a flexibilidade',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '12 alongamentos',
            rest: '30 segundos entre exercícios',
            tips: [
              'Tensão progressiva no elástico',
              'Mantenha 20-30 segundos',
              'Não faça movimentos bruscos'
            ]
          },
          equipment: ['Elástico', 'Ponto de ancoragem'],
          targetMuscles: ['Isquiotibiais', 'Quadríceps', 'Ombros'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'resistencia',
    name: 'Resistência',
    description: 'Desenvolva capacidade cardiovascular',
    icon: '🏃‍♂️',
    color: 'bg-orange-500',
    trainings: {
      academia: [
        {
          id: 'res-acad-001',
          title: 'Bike Intervalada',
          description: 'Treino intervalado de alta intensidade para melhorar a resistência cardiovascular',
          duration: '30 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '6 intervalos',
            repetitions: '3 min intenso + 2 min leve',
            rest: 'Ativo durante intervalos leves',
            tips: [
              'Mantenha cadência alta nos intensos',
              'Recuperação ativa nos intervalos',
              'Hidrate-se regularmente'
            ]
          },
          equipment: ['Bicicleta ergométrica', 'Monitor cardíaco'],
          targetMuscles: ['Sistema cardiovascular', 'Pernas'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'res-livre-001',
          title: 'Corrida Contínua 5km',
          description: 'Desenvolva sua base aeróbica com uma corrida de 5km em ritmo moderado',
          duration: '35 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '1 série contínua',
            repetitions: '5 km',
            rest: 'Sem paradas',
            tips: [
              'Ritmo constante e confortável',
              'Respiração ritmada',
              'Postura ereta durante toda corrida'
            ]
          },
          equipment: ['Tênis de corrida', 'Cronômetro'],
          targetMuscles: ['Sistema cardiovascular', 'Pernas'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'res-equip-001',
          title: 'Circuito Funcional',
          description: 'Circuito de alta intensidade com peso corporal para resistência e condicionamento',
          duration: '25 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 circuitos',
            repetitions: '45 seg trabalho + 15 seg descanso',
            rest: '2 minutos entre circuitos',
            tips: [
              'Mantenha intensidade alta',
              'Foque na técnica mesmo cansado',
              'Controle a respiração'
            ]
          },
          equipment: ['Peso corporal', 'Cronômetro'],
          targetMuscles: ['Corpo inteiro', 'Sistema cardiovascular'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'velocidade',
    name: 'Velocidade de Reação',
    description: 'Aprimore reflexos e tempo de reação',
    icon: '⚡',
    color: 'bg-yellow-500',
    trainings: {
      academia: [
        {
          id: 'vel-acad-001',
          title: 'Reação Visual com Luzes',
          description: 'Treine seus reflexos e tempo de reação com estímulos visuais rápidos',
          duration: '20 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '10 reações',
            rest: '2 minutos entre séries',
            tips: [
              'Foque no estímulo visual',
              'Reação imediata',
              'Mantenha posição atlética'
            ]
          },
          equipment: ['Sistema de luzes', 'Cones'],
          targetMuscles: ['Sistema nervoso', 'Pernas'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'vel-livre-001',
          title: 'Reação ao Comando',
          description: 'Exercícios de reação rápida a comandos auditivos para melhorar a agilidade mental',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '6 séries',
            repetitions: '8 reações',
            rest: '90 segundos entre séries',
            tips: [
              'Posição de prontidão',
              'Reação imediata ao comando',
              'Movimentos explosivos'
            ]
          },
          equipment: ['Apito', 'Cones'],
          targetMuscles: ['Sistema nervoso', 'Pernas'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'vel-equip-001',
          title: 'Reação com Bola',
          description: 'Desenvolva reflexos e controle de bola com exercícios de reação específicos do futebol',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 toques rápidos',
            rest: '90 segundos entre séries',
            tips: [
              'Primeiro toque perfeito',
              'Reação rápida à bola',
              'Mantenha concentração'
            ]
          },
          equipment: ['Bola', 'Parede'],
          targetMuscles: ['Coordenação', 'Reflexos'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'coordenacao',
    name: 'Coordenação/Agilidade',
    description: 'Desenvolva coordenação motora e agilidade',
    icon: '🎯',
    color: 'bg-purple-500',
    trainings: {
      academia: [
        {
          id: 'agil-001',
          title: 'Burpe com agilidade',
          description: 'Exercício explosivo que combina força e agilidade',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1vf33vq15bpu3Ew01tOjpp7JItnvX_KNk/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Movimento explosivo', 'Aterrissagem controlada', 'Core ativado']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-002',
          title: 'Burpe com elevação de peso',
          description: 'Variação avançada do burpe com resistência adicional',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Mantenha postura', 'Controle o peso', 'Respiração ritmada']
          },
          equipment: ['Halteres', 'Colchonete'],
          targetMuscles: ['Corpo inteiro', 'Força'],
          points: 10
        },
        {
          id: 'agil-003',
          title: 'Abdominal com triangulo',
          description: 'Fortalecimento abdominal com movimento em padrão triangular',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições',
            rest: '45 segundos entre séries',
            tips: ['Lombar no chão', 'Movimento controlado', 'Respiração constante']
          },
          equipment: ['Colchonete', 'Triângulos'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'agil-004',
          title: 'Abdominal dinâmico com salto',
          description: 'Combinação de abdominais com movimento explosivo',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1FMqkDZ1CQtLKTkh3-8MQIXG7xBTgqbH9/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Explosão controlada', 'Aterrissagem suave', 'Core sempre ativo']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Pernas'],
          points: 10
        },
        {
          id: 'agil-005',
          title: 'Abdominal dinâmico',
          description: 'Exercício abdominal com movimento fluido e contínuo',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1Xnz03UxLSayEBDfoAeflgIOcWYnI1uAO/preview',
          instructions: {
            series: '4 séries',
            repetitions: '20 repetições',
            rest: '45 segundos entre séries',
            tips: ['Movimento fluido', 'Não force o pescoço', 'Controle a descida']
          },
          equipment: ['Colchonete'],
          targetMuscles: ['Abdômen', 'Core'],
          points: 10
        },
        {
          id: 'agil-006',
          title: 'Abdominal dinâmico com bola',
          description: 'Exercício abdominal com instabilidade da bola',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/14WbpsVo_wu4N6EpXKnJTQeouMiaN8i2J/preview',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '60 segundos entre séries',
            tips: ['Mantenha equilíbrio', 'Controle a bola', 'Core estável']
          },
          equipment: ['Bola suíça', 'Colchonete'],
          targetMuscles: ['Abdômen', 'Core', 'Estabilizadores'],
          points: 10
        },
        {
          id: 'agil-007',
          title: 'Afundo alternado ágil',
          description: 'Afundos rápidos alternando as pernas com agilidade',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1dBMciettU2-X70gbJHj25gG-BGwrdQsW/preview',
          instructions: {
            series: '4 séries',
            repetitions: '16 repetições (8 cada perna)',
            rest: '60 segundos entre séries',
            tips: ['Movimento rápido', 'Joelho alinhado', 'Equilíbrio constante']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-008',
          title: 'Agachamento com bola e elevação',
          description: 'Agachamento com bola e elevação dos braços',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1S_uykcmgn-M-H4ivDTV43fAIExBwre4P/preview',
          instructions: {
            series: '3 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Costas retas', 'Desça até 90 graus', 'Elevação controlada']
          },
          equipment: ['Bola medicinal'],
          targetMuscles: ['Pernas', 'Ombros', 'Core'],
          points: 10
        },
        {
          id: 'agil-009',
          title: 'Agachamento com saída em explosão',
          description: 'Agachamento seguido de movimento explosivo',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Explosão máxima', 'Aterrissagem segura', 'Potência nas pernas']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Potência'],
          points: 10
        },
        {
          id: 'agil-010',
          title: 'Agachamento com salto na bola',
          description: 'Agachamento com salto usando bola para equilíbrio',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Equilíbrio na bola', 'Salto controlado', 'Foco e concentração']
          },
          equipment: ['Bola de equilíbrio'],
          targetMuscles: ['Pernas', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'agil-011',
          title: 'Prancha com toques nos cones',
          description: 'Prancha isométrica com movimento de toque alternado nos cones',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1Zh6K_lsqhgVqJSPPJNcl5xI_iSkkTlPI/preview',
          instructions: {
            series: '3 séries',
            repetitions: '20 toques (10 cada lado)',
            rest: '60 segundos entre séries',
            tips: ['Corpo alinhado', 'Quadril estável', 'Movimento controlado']
          },
          equipment: ['Colchonete', 'Cones'],
          targetMuscles: ['Core', 'Ombros', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-012',
          title: 'Polichinelo',
          description: 'Exercício clássico de aquecimento e condicionamento',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1ria6uQs-i_RPQtXD71mrGHf85Ir4DSk6/preview',
          instructions: {
            series: '4 séries',
            repetitions: '30 repetições',
            rest: '30 segundos entre séries',
            tips: ['Movimento ritmado', 'Coordenação braços e pernas', 'Respiração constante']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Cardio'],
          points: 10
        },
        {
          id: 'agil-013',
          title: 'Corrida controlada com elástico',
          description: 'Corrida com resistência de elástico para potência',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1oBr-EaJ7gP_QyTAXC0UlnjyKXG0gcveb/preview',
          instructions: {
            series: '4 séries',
            repetitions: '30 segundos',
            rest: '90 segundos entre séries',
            tips: ['Mantenha postura', 'Força contra resistência', 'Passos curtos e rápidos']
          },
          equipment: ['Elástico de resistência'],
          targetMuscles: ['Pernas', 'Glúteos', 'Potência'],
          points: 10
        },
        {
          id: 'agil-014',
          title: 'Agachamento isométrico com salto',
          description: 'Agachamento isométrico seguido de salto explosivo',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1kodwACa1FBWBEAYV-hTYcvBmykMIK_4y/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '90 segundos entre séries',
            tips: ['Segurar 3 segundos', 'Explosão máxima', 'Aterrissagem controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Potência'],
          points: 10
        },
        {
          id: 'agil-015',
          title: 'Corrida com elevação dos braços',
          description: 'Corrida no lugar com elevação alternada dos braços',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1uQjDT5-AypWxr5Czh_diAgc2CqfqqIXm/preview',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos',
            rest: '45 segundos entre séries',
            tips: ['Coordenação braços-pernas', 'Ritmo constante', 'Respiração controlada']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Cardio', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-016',
          title: 'Corrida com elevação dos joelhos',
          description: 'Corrida estacionária com joelhos elevados',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1oCjNWo7JxBT_uZMxQEt4ehbJOpsQrxwL/preview',
          instructions: {
            series: '4 séries',
            repetitions: '30 segundos',
            rest: '60 segundos entre séries',
            tips: ['Joelhos até altura do quadril', 'Ritmo acelerado', 'Core ativado']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Quadríceps', 'Cardio', 'Core'],
          points: 10
        },
        {
          id: 'agil-017',
          title: 'Corrida de 5 segundos com explosão',
          description: 'Sprints curtos de 5 segundos com intensidade máxima',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/11Q5vb8tmRixHk36WYTmu6BJK6MUb8c0n/preview',
          instructions: {
            series: '6 séries',
            repetitions: '5 segundos máxima intensidade',
            rest: '2 minutos entre séries',
            tips: ['Explosão total', 'Recuperação completa', 'Aquecimento adequado']
          },
          equipment: ['Cronômetro'],
          targetMuscles: ['Velocidade', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'agil-018',
          title: 'Agachamento com toque no cone mais salto em agilidade',
          description: 'Combinação de agachamento, toque no cone e salto',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Movimento fluido', 'Toque preciso no cone', 'Salto explosivo']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Coordenação', 'Agilidade'],
          points: 10
        },
        {
          id: 'agil-019',
          title: 'Corrida ágil com burpe',
          description: 'Corrida seguida de burpe para treino completo',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1fU7TWfxOF8Mf8P0eDA9VajsW_EQLO6zC/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 metros corrida + 1 burpe (repetir 6x)',
            rest: '2 minutos entre séries',
            tips: ['Transição rápida', 'Mantenha intensidade', 'Recuperação ativa']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Condicionamento'],
          points: 10
        },
        {
          id: 'agil-020',
          title: 'Corrida com explosão e agachamento',
          description: 'Alternância de corrida explosiva com agachamento',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1tq6gFb6ZKlfFY1WFT-j9R8cxeR3VfFyQ/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '75 segundos entre séries',
            tips: ['Sprint de 5 metros', 'Agachamento profundo', 'Explosão na saída']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Cardio', 'Potência'],
          points: 10
        },
        {
          id: 'agil-021',
          title: 'Corrida com giro e saída',
          description: 'Corrida com mudança de direção através de giro e saída explosiva',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Academia',
          videoUrl: 'https://drive.google.com/file/d/1A6bMsocV4HgMCL93zyDq6vJa9C_VlRul/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Giro de 180 graus', 'Salto controlado', 'Aterrissagem estável']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Core', 'Coordenação'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'agil-022',
          title: 'Corrida ida e volta em T com cones',
          description: 'Padrão de corrida em formato T para agilidade máxima',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '4 repetições completas',
            rest: '90 segundos entre séries',
            tips: ['Mudança rápida de direção', 'Toque em cada cone', 'Máxima velocidade']
          },
          equipment: ['4 cones'],
          targetMuscles: ['Agilidade', 'Velocidade', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-023',
          title: 'Corrida alternada com saída de joelhos',
          description: 'Explosão partindo da posição de joelhos',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1qVH2vbruLAmjZN21pHlR1ujftubt_U1n/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '90 segundos entre séries',
            tips: ['Explosão rápida', 'Transição eficiente', 'Sprint de 10 metros']
          },
          equipment: ['Colchonete', 'Cones'],
          targetMuscles: ['Explosão', 'Velocidade', 'Potência'],
          points: 10
        },
        {
          id: 'agil-024',
          title: 'Corrida com agachamento',
          description: 'Corrida intercalada com agachamentos profundos',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1oO6b_hDN7VyMsIkIjxF_PYxxP3vSyosT/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 metros corrida + 5 agachamentos (repetir 4x)',
            rest: '75 segundos entre séries',
            tips: ['Ritmo constante', 'Agachamento completo', 'Transição fluida']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Cardio', 'Resistência'],
          points: 10
        },
        {
          id: 'agil-025',
          title: 'Corrida com agachamento com toque alternado no cone',
          description: 'Agachamentos com toque alternado em cones laterais',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/14-kO63t-9M5bsx3OpH2Obj37L9VzIv9P/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Toque preciso', 'Agachamento profundo', 'Alternância rápida']
          },
          equipment: ['3 cones'],
          targetMuscles: ['Pernas', 'Core', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-026',
          title: 'Corrida com agachamento de triângulo',
          description: 'Corrida em padrão triangular com agachamentos',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1bmE-14ZWo5Ex6IChLwBACKlG8h9LhWZb/preview',
          instructions: {
            series: '4 séries',
            repetitions: '3 voltas completas',
            rest: '90 segundos entre séries',
            tips: ['Padrão em triângulo', 'Agachamento em cada vértice', 'Sprint nas laterais']
          },
          equipment: ['3 cones'],
          targetMuscles: ['Agilidade', 'Pernas', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-027',
          title: 'Corrida com giro entre os triângulos',
          description: 'Movimentação entre triângulos com giros de 360°',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1Bgpx3Ce3h4bYgRB0SFNHfH5a5qGCRomK/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '90 segundos entre séries',
            tips: ['Giro completo', 'Equilíbrio mantido', 'Velocidade constante']
          },
          equipment: ['6 cones'],
          targetMuscles: ['Coordenação', 'Core', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'agil-028',
          title: 'Corrida com parada brusca',
          description: 'Sprints com paradas súbitas para controle',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '5 séries',
            repetitions: '6 sprints de 10 metros',
            rest: '75 segundos entre séries',
            tips: ['Parada imediata', 'Controle do corpo', 'Equilíbrio na frenagem']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Core', 'Controle'],
          points: 10
        },
        {
          id: 'agil-029',
          title: 'Corrida com rotação',
          description: 'Corrida com rotações de tronco para mobilidade',
          duration: '15 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '40 segundos',
            rest: '60 segundos entre séries',
            tips: ['Rotação ampla', 'Ritmo moderado', 'Coordenação braços-tronco']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Core', 'Mobilidade', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-030',
          title: 'Corrida com toque no chão',
          description: 'Corrida intercalada com toques no chão',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições',
            rest: '60 segundos entre séries',
            tips: ['Toque completo no chão', 'Retorno rápido', 'Flexibilidade e velocidade']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Flexibilidade', 'Agilidade'],
          points: 10
        },
        {
          id: 'agil-031',
          title: 'Corrida com giro e saída explosiva e volta devagar',
          description: 'Contraste entre sprint explosivo com giro e retorno controlado',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1fcBqAXtIXZaVXy1RXift22PUBt9spr9O/preview',
          instructions: {
            series: '5 séries',
            repetitions: '8 sprints de 15 metros',
            rest: '90 segundos entre séries',
            tips: ['Máxima velocidade na ida', 'Caminhada na volta', 'Recuperação ativa']
          },
          equipment: ['Cones'],
          targetMuscles: ['Velocidade', 'Recuperação', 'Condicionamento'],
          points: 10
        },
        {
          id: 'agil-032',
          title: 'Corrida com salto unilateral em equilíbrio',
          description: 'Corrida com saltos em uma perna mantendo equilíbrio',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '90 segundos entre séries',
            tips: ['Equilíbrio unilateral', 'Saltos controlados', 'Core estável']
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'agil-033',
          title: 'Corrida de costas com giro',
          description: 'Corrida de costas seguida de giro e sprint frontal',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1F89u16MCwh4dWx4OUbl7G1GoRrzmkjzs/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '75 segundos entre séries',
            tips: ['Atenção ao terreno', 'Giro rápido', 'Aceleração imediata']
          },
          equipment: ['Cones'],
          targetMuscles: ['Coordenação', 'Agilidade', 'Velocidade'],
          points: 10
        },
        {
          id: 'agil-034',
          title: 'Corrida em deslocamento lateral com cone',
          description: 'Movimentação lateral rápida entre cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '10 idas e voltas',
            rest: '60 segundos entre séries',
            tips: ['Passos laterais rápidos', 'Postura baixa', 'Toque nos cones']
          },
          equipment: ['2 cones'],
          targetMuscles: ['Adutores', 'Abdutores', 'Agilidade'],
          points: 10
        },
        {
          id: 'agil-035',
          title: 'Corrida em T com cones mais deslocamento lateral',
          description: 'Combinação de padrão T com deslocamento lateral',
          duration: '18 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '5 repetições completas',
            rest: '2 minutos entre séries',
            tips: ['Padrão T completo', 'Deslocamento lateral rápido', 'Coordenação total']
          },
          equipment: ['4 cones'],
          targetMuscles: ['Agilidade', 'Coordenação', 'Velocidade'],
          points: 10
        },
        {
          id: 'agil-036',
          title: 'Corrida entre os cones',
          description: 'Slalom rápido entre cones em linha',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1t6Q1xsqRqh6kcSoiJBXcVehuDnApqyjb/preview',
          instructions: {
            series: '5 séries',
            repetitions: '4 voltas completas',
            rest: '60 segundos entre séries',
            tips: ['Passos curtos', 'Mudança rápida de direção', 'Centro de gravidade baixo']
          },
          equipment: ['6-8 cones'],
          targetMuscles: ['Agilidade', 'Coordenação', 'Pernas'],
          points: 10
        },
        {
          id: 'agil-037',
          title: 'Corrida ida e volta com agachamento',
          description: 'Sprint com agachamento profundo no retorno',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1PyAr9AsTXCgZw_IA_cBFy2pu0hjbXr7q/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '75 segundos entre séries',
            tips: ['Sprint completo na ida', 'Agachamento antes do retorno', 'Recuperação no retorno']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Cardio', 'Força'],
          points: 10
        },
        {
          id: 'agil-038',
          title: 'Corrida ida e volta com explosão',
          description: 'Sprints máximos com mudanças rápidas de direção',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1tocySiHoZIY8NldreTMZ_cSsJRPqESH9/preview',
          instructions: {
            series: '5 séries',
            repetitions: '6 sprints de 20 metros',
            rest: '2 minutos entre séries',
            tips: ['Explosão máxima', 'Frenagem controlada', 'Mudança imediata']
          },
          equipment: ['Cones'],
          targetMuscles: ['Velocidade', 'Potência', 'Agilidade'],
          points: 10
        },
        {
          id: 'agil-039',
          title: 'Corrida ida e volta com toques nos cones',
          description: 'Sprint com toque obrigatório nos cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1PKB7Rr0s7WOb4ljkWsGdZzQYO1DbHInV/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '75 segundos entre séries',
            tips: ['Toque com a mão', 'Agachar para tocar', 'Velocidade mantida']
          },
          equipment: ['2 cones'],
          targetMuscles: ['Agilidade', 'Flexibilidade', 'Velocidade'],
          points: 10
        },
        {
          id: 'agil-040',
          title: 'Corrida ida e volta no triângulo com polichinelo',
          description: 'Percurso triangular com polichinelos em cada vértice',
          duration: '17 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1cv7hNSYWg8OZrWi-JJfsy6vfeNxe5Yg3/preview',
          instructions: {
            series: '4 séries',
            repetitions: '3 voltas completas',
            rest: '90 segundos entre séries',
            tips: ['5 polichinelos por vértice', 'Corrida rápida entre pontos', 'Ritmo constante']
          },
          equipment: ['3 cones'],
          targetMuscles: ['Cardio', 'Coordenação', 'Resistência'],
          points: 10
        },
        {
          id: 'agil-041',
          title: 'Corrida mais rápida lateral',
          description: 'Deslocamento lateral em alta velocidade',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1xdQc_W0_psUk7SC0PQypCbAevE17ZRj6/preview',
          instructions: {
            series: '5 séries',
            repetitions: '30 segundos cada lado',
            rest: '60 segundos entre séries',
            tips: ['Máxima velocidade lateral', 'Pés rápidos', 'Postura atlética']
          },
          equipment: ['Cones'],
          targetMuscles: ['Adutores', 'Abdutores', 'Velocidade'],
          points: 10
        },
        {
          id: 'agil-042',
          title: 'Corrida mais saída lateral',
          description: 'Corrida com saída lateral explosiva',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Ar Livre',
          videoUrl: 'https://drive.google.com/file/d/1IFd-lIjOuNM84SFX5gRScrAZkU53tiZB/preview',
          instructions: {
            series: '4 séries',
            repetições: '10 repetições',
            rest: '90 segundos entre séries',
            tips: ['Salto amplo lateral', 'Aterrissagem controlada', 'Sprint entre saltos']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'agil-043',
          title: 'Deslocamento lateral com os dois pés dentro do cone',
          description: 'Exercício de precisão e agilidade com ambos os pés',
          duration: '14 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1-UTNJvu3eecsVJvqQO_wzqVY718mNzbM/preview',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições cada lado',
            rest: '45 segundos entre séries',
            tips: ['Ambos pés dentro do cone', 'Movimento rápido', 'Equilíbrio mantido']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Coordenação', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'agil-044',
          title: 'Deslocamento lateral com os dois pés dentro do cone com agachamento',
          description: 'Deslocamento lateral com agachamento profundo',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1qvTFCnai3SX4KGUvXvyEYGqYnvZO-4KI/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: ['Agachamento em cada cone', 'Dois pés dentro', 'Postura baixa']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-045',
          title: 'Deslocamento lateral com os dois pés dentro do cone com salto',
          description: 'Saltos laterais precisos dentro dos cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1eMgvsm-J9ipFzs_dwDKJpNKz2jARU_w_/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada lado',
            rest: '60 segundos entre séries',
            tips: ['Salto preciso', 'Aterrissagem suave', 'Ambos pés no cone']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Explosão', 'Precisão'],
          points: 10
        },
        {
          id: 'agil-046',
          title: 'Deslocamento lateral com salto entre os cones',
          description: 'Saltos laterais contínuos entre cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 saltos',
            rest: '60 segundos entre séries',
            tips: ['Ritmo constante', 'Saltos contínuos', 'Aterrissagem controlada']
          },
          equipment: ['5-6 cones'],
          targetMuscles: ['Panturrilha', 'Pernas', 'Resistência'],
          points: 10
        },
        {
          id: 'agil-047',
          title: 'Deslocamento lateral com um pé dentro do cone',
          description: 'Agilidade unilateral com precisão',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '15 repetições cada perna',
            rest: '45 segundos entre séries',
            tips: ['Alternância rápida', 'Precisão no toque', 'Equilíbrio unilateral']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Propriocepção'],
          points: 10
        },
        {
          id: 'agil-048',
          title: 'Deslocamento lateral entre os cones com afundo alternado',
          description: 'Afundos laterais alternados com deslocamento',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1H-cYmOW5Ltp45__4JQddjSVnd8_1EwLc/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 afundos',
            rest: '60 segundos entre séries',
            tips: ['Afundo profundo', 'Alternância rápida', 'Movimento lateral fluido']
          },
          equipment: ['Cones'],
          targetMuscles: ['Quadríceps', 'Glúteos', 'Adutores'],
          points: 10
        },
        {
          id: 'agil-049',
          title: 'Deslocamento lateral entre os cones com explosão',
          description: 'Movimentos laterais explosivos entre cones',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1yPXZhs0ZzlDWGNbRvIOvv9H32uszm5T_/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 explosões cada lado',
            rest: '75 segundos entre séries',
            tips: ['Máxima explosão', 'Mudança rápida', 'Potência lateral']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Potência', 'Explosão'],
          points: 10
        },
        {
          id: 'agil-050',
          title: 'Passos laterais com agilidade',
          description: 'Passos laterais rápidos e coordenados',
          duration: '13 min',
          difficulty: 'Iniciante',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1qkAw_YVxGLVrCutuCEA_D6FW2JcU_b5H/preview',
          instructions: {
            series: '5 séries',
            repetitions: '30 segundos cada lado',
            rest: '45 segundos entre séries',
            tips: ['Passos pequenos e rápidos', 'Postura atlética', 'Pés sempre em movimento']
          },
          equipment: ['Cones'],
          targetMuscles: ['Adutores', 'Abdutores', 'Coordenação'],
          points: 10
        },
        {
          id: 'agil-051',
          title: 'Salto entre os cones',
          description: 'Saltos coordenados entre múltiplos cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1FCQiFSB-Q1MDacHzWd-tWU9T5-YVsnTe/preview',
          instructions: {
            series: '4 séries',
            repetitions: '12 saltos',
            rest: '60 segundos entre séries',
            tips: ['Saltos controlados', 'Aterrissagem suave', 'Ritmo constante']
          },
          equipment: ['6 cones'],
          targetMuscles: ['Pernas', 'Coordenação', 'Explosão'],
          points: 10
        },
        {
          id: 'agil-052',
          title: 'Salto ida e volta entre os cones',
          description: 'Padrão de saltos em zigue-zague',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1BD71khZVHxnV2CIbVO2Sj1UcBlgI67Ft/preview',
          instructions: {
            series: '4 séries',
            repetitions: '4 voltas completas',
            rest: '75 segundos entre séries',
            tips: ['Padrão em zigue-zague', 'Saltos contínuos', 'Coordenação mantida']
          },
          equipment: ['6-8 cones'],
          targetMuscles: ['Pernas', 'Agilidade', 'Resistência'],
          points: 10
        },
        {
          id: 'agil-053',
          title: 'Salto lateral com agachamento',
          description: 'Saltos laterais seguidos de agachamento profundo',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1pdVbR7RWJzn8_gsPFlZjg81dbZ9DSeOY/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 repetições cada lado',
            rest: '60 segundos entre séries',
            tips: ['Salto lateral explosivo', 'Agachamento profundo', 'Estabilização']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Glúteos', 'Força'],
          points: 10
        },
        {
          id: 'agil-054',
          title: 'Salto lateral com agilidade',
          description: 'Saltos laterais rápidos e coordenados',
          duration: '14 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '20 saltos',
            rest: '45 segundos entre séries',
            tips: ['Ritmo acelerado', 'Saltos curtos', 'Agilidade máxima']
          },
          equipment: ['Cones'],
          targetMuscles: ['Panturrilha', 'Coordenação', 'Agilidade'],
          points: 10
        },
        {
          id: 'agil-055',
          title: 'Salto lateral com saída em agilidade',
          description: 'Salto lateral seguido de sprint explosivo',
          duration: '16 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1x_cdIfCu4vstr7gKEXNoKR3TtzSTFRIS/preview',
          instructions: {
            series: '4 séries',
            repetitions: '8 repetições',
            rest: '90 segundos entre séries',
            tips: ['Salto explosivo', 'Sprint imediato', 'Transição rápida']
          },
          equipment: ['Cones'],
          targetMuscles: ['Pernas', 'Velocidade', 'Explosão'],
          points: 10
        },
        {
          id: 'agil-056',
          title: 'Salto unilateral entre os cones',
          description: 'Saltos em uma perna alternando entre cones',
          duration: '15 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1b7-W7wbXuVflst7QXTrPT1k2jl7C-Lim/preview',
          instructions: {
            series: '4 séries',
            repetitions: '10 saltos cada perna',
            rest: '75 segundos entre séries',
            tips: ['Equilíbrio unilateral', 'Força em uma perna', 'Coordenação']
          },
          equipment: ['5-6 cones'],
          targetMuscles: ['Pernas', 'Equilíbrio', 'Força'],
          points: 10
        },
        {
          id: 'agil-057',
          title: 'Salto unilateral entre os triângulos',
          description: 'Padrão triangular com saltos unilaterais',
          duration: '17 min',
          difficulty: 'Avançado',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1E6TwhjhXgddCUWM5gyV7fOKqKQqgX86k/preview',
          instructions: {
            series: '3 séries',
            repetitions: '3 voltas cada perna',
            rest: '2 minutos entre séries',
            tips: ['Manter equilíbrio', 'Padrão triangular preciso', 'Força unilateral']
          },
          equipment: ['3 triângulos ou cones'],
          targetMuscles: ['Pernas', 'Propriocepção', 'Equilíbrio'],
          points: 10
        },
        {
          id: 'agil-058',
          title: 'Salto entre os triângulos',
          description: 'Saltos bilaterais entre marcações triangulares',
          duration: '16 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1E6TwhjhXgddCUWM5gyV7fOKqKQqgX86k/preview',
          instructions: {
            series: '4 séries',
            repetitions: '4 voltas completas',
            rest: '75 segundos entre séries',
            tips: ['Padrão em triângulo', 'Saltos coordenados', 'Ritmo mantido']
          },
          equipment: ['3 triângulos ou cones'],
          targetMuscles: ['Pernas', 'Coordenação', 'Resistência'],
          points: 10
        },
        {
          id: 'agil-059',
          title: 'Zigue-zague entre os cones',
          description: 'Corrida em padrão zigue-zague entre cones',
          duration: '15 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://drive.google.com/file/d/1iS6JaItaLqHqL2DEblU825AIM0MODeuN/preview',
          instructions: {
            series: '5 séries',
            repetitions: '4 voltas completas',
            rest: '60 segundos entre séries',
            tips: ['Mudança rápida de direção', 'Passos curtos', 'Velocidade máxima']
          },
          equipment: ['8-10 cones'],
          targetMuscles: ['Agilidade', 'Coordenação', 'Velocidade'],
          points: 10
        }
      ]
    }
  },
  {
    id: 'prevencao',
    name: 'Prevenção de Lesões',
    description: 'Exercícios para prevenir lesões comuns',
    icon: '🛡️',
    color: 'bg-teal-500',
    trainings: {
      academia: [
        {
          id: 'pre-acad-001',
          title: 'Fortalecimento de Joelhos',
          description: 'Exercícios específicos para fortalecer os músculos ao redor dos joelhos e prevenir lesões',
          duration: '25 min',
          difficulty: 'Iniciante',
          environment: 'Academia',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '3 séries',
            repetitions: '15 repetições',
            rest: '90 segundos entre séries',
            tips: [
              'Movimentos controlados',
              'Não force se sentir dor',
              'Foque na técnica perfeita'
            ]
          },
          equipment: ['Leg press', 'Extensora'],
          targetMuscles: ['Quadríceps', 'Isquiotibiais', 'Glúteos'],
          points: 10
        }
      ],
      arLivre: [
        {
          id: 'pre-livre-001',
          title: 'Aquecimento Dinâmico',
          description: 'Prepare seu corpo para a atividade física com um aquecimento dinâmico completo',
          duration: '12 min',
          difficulty: 'Iniciante',
          environment: 'Ar Livre',
          videoUrl: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '2 séries',
            repetitions: '10 movimentos cada',
            rest: '30 segundos entre exercícios',
            tips: [
              'Aumente intensidade gradualmente',
              'Movimente todas as articulações',
              'Prepare-se mentalmente'
            ]
          },
          equipment: ['Peso corporal'],
          targetMuscles: ['Corpo inteiro', 'Articulações'],
          points: 10
        }
      ],
      equipamentosSimples: [
        {
          id: 'pre-equip-001',
          title: 'Estabilização de Core',
          description: 'Fortaleça o core para melhorar a estabilidade e prevenir lesões na região lombar',
          duration: '18 min',
          difficulty: 'Intermediário',
          environment: 'Equipamentos Simples',
          videoUrl: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
          instructions: {
            series: '4 séries',
            repetitions: '45 segundos cada exercício',
            rest: '60 segundos entre séries',
            tips: [
              'Mantenha respiração constante',
              'Core sempre contraído',
              'Postura neutra da coluna'
            ]
          },
          equipment: ['Colchonete', 'Bola suíça'],
          targetMuscles: ['Core', 'Estabilizadores'],
          points: 10
        }
      ]
    }
  }
];

// Sistema de treinos diários
export interface DailyTraining {
  date: string;
  trainings: {
    topic: string;
    training: Training;
  }[];
  completed: boolean;
  pointsEarned: number;
}

export const generateDailyTrainings = (date: Date): DailyTraining => {
  const dateString = date.toISOString().split('T')[0];
  const dayOfWeek = date.getDay(); // 0 for Sunday, 1 for Monday, etc.
  // Calculate a simple week number (e.g., weeks since epoch, modulo a large number)
  // This ensures the selection changes weekly.
  const weekSeed = Math.floor(date.getTime() / (1000 * 60 * 60 * 24 * 7)) % 1000; // Modulo 1000 to keep it manageable
  
  // Rotaciona através dos treinos baseado no dia do mês
  const getTrainingForTopic = (topic: TrainingTopic, day: number, week: number) => {
    const environments = ['academia', 'arLivre', 'equipamentosSimples'] as const;
    // Cycle through environments weekly
    const envIndex = week % environments.length;
    const envTrainings = topic.trainings[environments[envIndex]];
    
    // Cycle through the 30 trainings based on day of week and week seed
    const trainingIndex = (day + week * 7) % envTrainings.length;
    return envTrainings[trainingIndex] || envTrainings[0]; // Fallback to first if index is out of bounds (shouldn't happen with modulo)
  };

  const dailyTrainings = trainingTopics.map(topic => ({
    topic: topic.id,
    training: getTrainingForTopic(topic, dayOfWeek, weekSeed)
  }));

  return {
    date: dateString,
    trainings: dailyTrainings,
    completed: false,
    pointsEarned: 0
  };
};

// Sistema de pontuação
export const calculateTrainingPoints = (completedTrainings: number): number => {
  let points = completedTrainings * 10; // 10 pontos por treino
  
  if (completedTrainings >= 2) {
    points += 5; // Bônus por fazer 2 tópicos
  }
  
  if (completedTrainings >= 3) {
    points += 10; // Bônus adicional por fazer 3 tópicos
  }
  
  return points;
};

// Níveis de atleta baseados em pontos
export const getAthleteLevel = (totalPoints: number): string => {
  if (totalPoints >= 5000) return 'Elite';
  if (totalPoints >= 2500) return 'Avançado';
  if (totalPoints >= 1000) return 'Intermediário';
  return 'Iniciante';
};

export const getLevelColor = (level: string): string => {
  switch (level) {
    case 'Elite': return 'bg-purple-100 text-purple-800';
    case 'Avançado': return 'bg-blue-100 text-blue-800';
    case 'Intermediário': return 'bg-yellow-100 text-yellow-800';
    case 'Iniciante': return 'bg-green-100 text-green-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};