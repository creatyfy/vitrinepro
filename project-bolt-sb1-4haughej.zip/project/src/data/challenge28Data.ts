export interface ChallengeExercise {
  id: string;
  name: string;
  duration?: string;
  reps?: string;
  imageUrl: string;
}

export interface ChallengeDay {
  day: number;
  week: number;
  title: string;
  description: string;
  duration: string;
  level: string;
  focusArea: string;
  equipment: string[];
  exercises: ChallengeExercise[];
  completed: boolean;
}

export interface Challenge28 {
  id: string;
  title: string;
  description: string;
  bannerImage: string;
  totalDays: number;
  completedDays: number;
  days: ChallengeDay[];
}

export const challenge28Days: Challenge28 = {
  id: 'upper-body-challenge',
  title: 'PARTE SUPERIOR DO CORPO ENORME',
  description: 'Transforme seu corpo em 28 dias com treinos focados na parte superior',
  bannerImage: 'https://images.pexels.com/photos/1229356/pexels-photo-1229356.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
  totalDays: 28,
  completedDays: 0,
  days: [
    // SEMANA 1
    {
      day: 1,
      week: 1,
      title: '1°DIA',
      description: 'Perca gordura da barriga e fique com o abdômen rasgado em apenas 4 semanas com este plano eficiente. Também ajuda a aumentar os braços, fortalecer as costas e os ombros. Sem necessidade de equipamentos!',
      duration: '9 min',
      level: 'Ajustável',
      focusArea: 'Peito',
      equipment: ['Banco reto'],
      exercises: [
        {
          id: 'ex1',
          name: 'Polichinelos',
          duration: '00:20',
          imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex2',
          name: 'Flexão Inclinada',
          reps: 'x 8',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex3',
          name: 'Abdominal Em Plié',
          reps: 'x 6',
          imageUrl: 'https://images.pexels.com/photos/4162485/pexels-photo-4162485.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex4',
          name: 'Flexões',
          reps: 'x 6',
          imageUrl: 'https://images.pexels.com/photos/4162512/pexels-photo-4162512.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex5',
          name: 'Toque de Calcanhar',
          reps: 'x 8',
          imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex6',
          name: 'Prancha',
          duration: '00:30',
          imageUrl: 'https://images.pexels.com/photos/4162449/pexels-photo-4162449.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex7',
          name: 'Flexão Ampla',
          reps: 'x 10',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex8',
          name: 'Burpees',
          reps: 'x 5',
          imageUrl: 'https://images.pexels.com/photos/4162462/pexels-photo-4162462.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex9',
          name: 'Elevação de Pernas',
          reps: 'x 12',
          imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex10',
          name: 'Mountain Climbers',
          duration: '00:30',
          imageUrl: 'https://images.pexels.com/photos/4162462/pexels-photo-4162462.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex11',
          name: 'Flexão Diamante',
          reps: 'x 8',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex12',
          name: 'Abdominal Cruzado',
          reps: 'x 16',
          imageUrl: 'https://images.pexels.com/photos/4162485/pexels-photo-4162485.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex13',
          name: 'Alongamento Final',
          duration: '00:40',
          imageUrl: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        }
      ],
      completed: false
    },
    {
      day: 2,
      week: 1,
      title: '2°DIA',
      description: 'Continue desenvolvendo força e resistência no tronco superior com foco em ombros e costas',
      duration: '10 min',
      level: 'Ajustável',
      focusArea: 'Ombros e Costas',
      equipment: [],
      exercises: [
        {
          id: 'ex1',
          name: 'Aquecimento Articular',
          duration: '00:30',
          imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex2',
          name: 'Pike Push-ups',
          reps: 'x 10',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex3',
          name: 'Superman',
          duration: '00:30',
          imageUrl: 'https://images.pexels.com/photos/4162485/pexels-photo-4162485.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex4',
          name: 'Flexão Arqueira',
          reps: 'x 6',
          imageUrl: 'https://images.pexels.com/photos/4162512/pexels-photo-4162512.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex5',
          name: 'Prancha Lateral',
          duration: '00:20',
          imageUrl: 'https://images.pexels.com/photos/4162449/pexels-photo-4162449.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex6',
          name: 'Mergulho de Tríceps',
          reps: 'x 12',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex7',
          name: 'Remada Isométrica',
          duration: '00:30',
          imageUrl: 'https://images.pexels.com/photos/4162462/pexels-photo-4162462.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        },
        {
          id: 'ex8',
          name: 'Flexão Hindu',
          reps: 'x 8',
          imageUrl: 'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        }
      ],
      completed: false
    },
    // Adicionar dias 3-7 da semana 1 com variações
    ...Array.from({ length: 5 }, (_, i) => ({
      day: i + 3,
      week: 1,
      title: `${i + 3}°DIA`,
      description: `Treino ${i + 3} focado em desenvolvimento muscular e resistência`,
      duration: `${8 + i} min`,
      level: 'Ajustável',
      focusArea: ['Peito', 'Costas', 'Ombros', 'Braços', 'Core'][i % 5],
      equipment: i % 2 === 0 ? [] : ['Banco reto'],
      exercises: Array.from({ length: 10 + i }, (__, j) => ({
        id: `ex${j + 1}`,
        name: ['Flexões', 'Prancha', 'Burpees', 'Polichinelos', 'Mountain Climbers'][j % 5],
        ...(j % 2 === 0 ? { duration: '00:30' } : { reps: `x ${8 + j}` }),
        imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
      })),
      completed: false
    })),
    // SEMANA 2-4: Gerar automaticamente com progressão
    ...Array.from({ length: 21 }, (_, i) => ({
      day: i + 8,
      week: Math.floor(i / 7) + 2,
      title: `${i + 8}°DIA`,
      description: `Treino avançado ${i + 8} com aumento de intensidade e complexidade`,
      duration: `${10 + (i % 7)} min`,
      level: i < 7 ? 'Intermediário' : i < 14 ? 'Avançado' : 'Expert',
      focusArea: ['Peito', 'Costas', 'Ombros', 'Braços', 'Core', 'Full Body', 'HIIT'][i % 7],
      equipment: i % 3 === 0 ? ['Banco reto'] : i % 3 === 1 ? ['Halteres'] : [],
      exercises: Array.from({ length: 12 + (i % 3) }, (__, j) => ({
        id: `ex${j + 1}`,
        name: [
          'Flexões Avançadas',
          'Prancha com Rotação',
          'Burpees com Salto',
          'Sprint no Lugar',
          'Mountain Climbers',
          'Flexão Diamante',
          'Superman Hold',
          'Pike Push-ups',
          'Mergulho de Tríceps',
          'Abdominal Cruzado'
        ][j % 10],
        ...(j % 2 === 0 ? { duration: `00:${30 + j * 2}` } : { reps: `x ${10 + j}` }),
        imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
      })),
      completed: false
    }))
  ]
};

export interface WorkoutSettings {
  musicEnabled: boolean;
  musicVolume: number;
  voiceGuidanceEnabled: boolean;
  voiceVolume: number;
  trainerVoice: string;
  soundEffectsEnabled: boolean;
  soundEffectsVolume: number;
  restTime: number;
  workTime: number;
}

export const defaultWorkoutSettings: WorkoutSettings = {
  musicEnabled: true,
  musicVolume: 50,
  voiceGuidanceEnabled: true,
  voiceVolume: 75,
  trainerVoice: 'Rodrigo',
  soundEffectsEnabled: true,
  soundEffectsVolume: 60,
  restTime: 30,
  workTime: 45
};

// Helper function to generate days
const generateChallengeDays = (totalDays: number, focusAreas: string[], baseDescription: string): ChallengeDay[] => {
  return Array.from({ length: totalDays }, (_, i) => {
    const day = i + 1;
    const week = Math.floor(i / 7) + 1;
    const focusArea = focusAreas[i % focusAreas.length];

    return {
      day,
      week,
      title: `${day}°DIA`,
      description: `${baseDescription} - Dia ${day} focado em ${focusArea.toLowerCase()}`,
      duration: `${8 + (i % 7)} min`,
      level: i < 7 ? 'Iniciante' : i < 14 ? 'Intermediário' : i < 21 ? 'Avançado' : 'Expert',
      focusArea,
      equipment: i % 3 === 0 ? ['Banco reto'] : i % 3 === 1 ? ['Halteres'] : [],
      exercises: Array.from({ length: 10 + (i % 5) }, (__, j) => ({
        id: `ex${j + 1}`,
        name: [
          'Polichinelos',
          'Flexão Inclinada',
          'Abdominal Em Plié',
          'Flexões',
          'Prancha',
          'Mountain Climbers',
          'Burpees',
          'Agachamento com Salto',
          'Elevação de Pernas',
          'Alongamento'
        ][j % 10],
        ...(j % 2 === 0 ? { duration: `00:${20 + j * 2}` } : { reps: `x ${6 + j}` }),
        imageUrl: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
      })),
      completed: false
    };
  });
};

// Preparação Física Completa - 28 dias
export const preparacaoFisicaCompleta: Challenge28 = {
  id: 'preparacao-fisica-completa',
  title: 'PREPARAÇÃO FÍSICA COMPLETA',
  description: 'Desenvolva força, explosão e resistência com treinos específicos para futebol em 4 semanas',
  bannerImage: 'https://images.pexels.com/photos/3764011/pexels-photo-3764011.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
  totalDays: 28,
  completedDays: 0,
  days: generateChallengeDays(28, ['Explosão', 'Força', 'Resistência', 'Agilidade', 'Core', 'Pernas', 'Full Body'], 'Desenvolva força, explosão e resistência')
};

// Definição e Agilidade - 30 dias com treinos detalhados
const definicaoAgilidadeExercises = {
  week1: [
    ['Polichinelos', 'High Knees', 'Burpees', 'Mountain Climbers', 'Jumping Jacks', 'Agachamento com Salto', 'Prancha Dinâmica', 'Sprint no Lugar'],
    ['Corrida Estacionária', 'Chutes Alternados', 'Flexão com Rotação', 'Skipping', 'Abdominal Bicicleta', 'Pular Corda', 'Agachamento Explosivo', 'Russian Twist'],
    ['Box Jumps', 'Burpee com Flexão', 'Escalador Cruzado', 'Lateral Bounds', 'Prancha Lateral', 'Joelho ao Cotovelo', 'Sprint 20m', 'Alongamento Ativo'],
    ['HIIT Tabata', 'Jump Squats', 'Mountain Climbers Rápido', 'Polichinelos 180°', 'Prancha com Toque', 'Burpees Modificados', 'High Knees Intenso', 'Relaxamento'],
    ['Corrida Intervalada', 'Chutes Frontais', 'Flexão Espartana', 'Agachamento Búlgaro', 'Prancha Estrela', 'Side Shuffle', 'Sprint Curto', 'Mobilidade'],
    ['Circuito HIIT', 'Saltos Laterais', 'Abdominal V-Up', 'Burpee Completo', 'Skater Jumps', 'Prancha Comando', 'Velocidade Máxima', 'Descanso Ativo'],
    ['Treino Cardio Mix', 'Jump Lunges', 'Prancha Alternada', 'Mountain Climbers Cross', 'Agachamento Isométrico', 'Corrida Zig-Zag', 'Polichinelos Duplos', 'Alongamento Completo']
  ],
  week2: [
    ['HIIT Avançado', 'Burpee Box Jump', 'Sprint 30m', 'Prancha com Elevação', 'Mountain Climbers 2x', 'Jump Squats Explosivo', 'Skipping Alto', 'Core Finisher'],
    ['Agilidade Ladder', 'Cone Drills', 'Shuttle Run', 'Lateral Hops', 'Prancha Spider', 'Burpee Tuck Jump', 'High Knees Velocidade', 'Mobilidade Avançada'],
    ['Cardio Intenso', 'Double Unders', 'Box Step-ups', 'Abdominal Completo', 'Sprint Resistance', 'Jump Rope HIIT', 'Agachamento 1.5', 'Recuperação'],
    ['Explosão Total', 'Broad Jumps', 'Burpee Estrela', 'Mountain Climbers Pike', 'Salto Vertical', 'Prancha Instável', 'Sprint Intervalado', 'Alongamento'],
    ['Definição Core', 'Russian Twist Peso', 'V-Ups', 'Bicycle Crunches Rápido', 'Prancha Lateral com Hip Dip', 'Leg Raises', 'Flutter Kicks', 'Dead Bug'],
    ['HIIT Tabata Pro', 'Jumping Lunges', 'Burpee Triple', 'Sprint 40m', 'Mountain Climbers Cross Wide', 'Box Jumps Alto', 'Skater Jumps Long', 'Cool Down'],
    ['Cardio Resistance', 'Jump Rope Duplo', 'Agachamento com Band', 'Prancha Push-up', 'High Knees Resistance', 'Burpee Broad Jump', 'Sprint Final', 'Stretching Profundo']
  ],
  week3: [
    ['Power HIIT', 'Burpee Muscle Up', 'Sprint 50m', 'Prancha Hollow Hold', 'Mountain Climbers Explosivo', 'Jump Squats Peso', 'Double Unders Pro', 'Core Destroyer'],
    ['Agilidade Elite', 'T-Drill', '5-10-5 Shuttle', 'Lateral Quick Feet', 'Prancha Dinâmica Avançada', 'Burpee 360', 'High Knees Sprint', 'Mobilidade Elite'],
    ['Cardio Extremo', 'Triple Unders', 'Box Jumps Continuos', 'Abdominal Dragon Flag', 'Sprint com Peso', 'Jump Rope Marathon', 'Agachamento Pistol', 'Recovery Pro'],
    ['Explosão Máxima', 'Vertical Jump Max', 'Burpee Box Jump Alto', 'Mountain Climbers Wide', 'Salto Horizontal', 'Prancha Instável Pro', 'Sprint 100m', 'Deep Stretch'],
    ['Definição Extrema', 'Weighted Russian Twist', 'Toes to Bar', 'Bicycle Crunches Weighted', 'Side Plank com Rotation', 'Hanging Leg Raises', 'V-Ups Weighted', 'Ab Wheel'],
    ['HIIT Ultimate', 'Jumping Lunges Weighted', 'Burpee Quádruplo', 'Sprint 60m', 'Mountain Climbers Cross Explosivo', 'Box Jumps Depth', 'Broad Jump Series', 'Complete Cool Down'],
    ['Cardio Finisher', 'Jump Rope EMOM', 'Agachamento Overhead', 'Prancha Pike Push-up', 'High Knees Max', 'Burpee Over Bar', 'Sprint Max Effort', 'Full Body Stretch']
  ],
  week4: [
    ['Master HIIT', 'Burpee Complex', 'Sprint 70m', 'Prancha L-Sit', 'Mountain Climbers com Pausa', 'Jump Squats Complexo', 'Triple Unders Attempt', 'Core Master'],
    ['Agilidade Pro', 'Pro Agility Drill', 'Three Cone Drill', 'Quick Feet Diamond', 'Prancha Hollow Rock', 'Burpee Bar Facing', 'High Knees Ultra', 'Mobility Master'],
    ['Cardio Legend', 'Quadruple Unders Practice', 'Box Jumps Máximo', 'Abdominal Complete Complex', 'Sprint Resistance Pro', 'Jump Rope Challenge', 'Agachamento Bulgarian', 'Active Recovery'],
    ['Explosão Legend', 'Vertical Jump Record', 'Burpee Complex Ultra', 'Mountain Climbers Evolution', 'Salto Triplo', 'Prancha Ultimate', 'Sprint Record', 'Deep Recovery'],
    ['Definição Legend', 'Weighted Core Complex', 'Toes to Bar Series', 'Advanced Bicycle', 'Plank Rotation Heavy', 'Hanging Knee Raises', 'Weighted V-Ups', 'Ab Roller Pro'],
    ['HIIT God Mode', 'Jumping Lunges Complex', 'Burpee Quintuplo', 'Sprint 80m', 'Mountain Climbers God', 'Box Jumps Ultimate', 'Long Jump Max', 'Perfect Cool Down'],
    ['Victory Lap', 'Jump Rope Victory', 'Agachamento Final', 'Prancha Hold Max', 'High Knees Record', 'Burpee Challenge Final', 'Sprint Victory', 'Celebration Stretch']
  ]
};

export const definicaoAgilidade: Challenge28 = {
  id: 'definicao-agilidade',
  title: 'DEFINIÇÃO E AGILIDADE',
  description: 'Queime gordura e desenvolva agilidade com treinos de alta intensidade',
  bannerImage: 'https://images.pexels.com/photos/4162449/pexels-photo-4162449.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
  totalDays: 30,
  completedDays: 0,
  days: Array.from({ length: 30 }, (_, i) => {
    const day = i + 1;
    const week = Math.floor(i / 7) + 1;
    const dayInWeek = i % 7;
    const weekKey = `week${week}` as keyof typeof definicaoAgilidadeExercises;
    const exercises = definicaoAgilidadeExercises[weekKey]?.[dayInWeek] || definicaoAgilidadeExercises.week1[0];

    const focusAreas = ['HIIT', 'Cardio', 'Agilidade', 'Definição', 'Core', 'Resistência', 'Full Body'];
    const focusArea = focusAreas[dayInWeek % 7];

    return {
      day,
      week,
      title: `${day}°DIA`,
      description: `Treino intenso de ${focusArea.toLowerCase()} para queimar gordura e desenvolver agilidade. Prepare-se para suar!`,
      duration: `${10 + (i % 8)} min`,
      level: i < 7 ? 'Iniciante' : i < 14 ? 'Intermediário' : i < 21 ? 'Avançado' : 'Expert',
      focusArea,
      equipment: dayInWeek % 3 === 0 ? ['Corda de pular'] : dayInWeek % 3 === 1 ? ['Cones', 'Escada de agilidade'] : [],
      exercises: exercises.map((name, j) => ({
        id: `ex${day}_${j + 1}`,
        name,
        ...(j % 2 === 0 ? { duration: `00:${25 + j * 5}` } : { reps: `x ${8 + j * 2}` }),
        imageUrl: [
          'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
          'https://images.pexels.com/photos/4162519/pexels-photo-4162519.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
          'https://images.pexels.com/photos/4162485/pexels-photo-4162485.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
          'https://images.pexels.com/photos/4162512/pexels-photo-4162512.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
          'https://images.pexels.com/photos/4162449/pexels-photo-4162449.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
          'https://images.pexels.com/photos/4162462/pexels-photo-4162462.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
        ][j % 6]
      })),
      completed: false
    };
  })
};

// Export all challenges
export const allChallenges = {
  'upper-body-challenge': challenge28Days,
  'preparacao-fisica-completa': preparacaoFisicaCompleta,
  'definicao-agilidade': definicaoAgilidade
};
