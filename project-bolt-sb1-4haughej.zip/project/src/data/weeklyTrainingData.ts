export interface ExerciseVariant {
  video_url: string;
  instructions: string;
  notes: string;
  sets: string;
  reps: string;
  rest: string;
}

export interface Exercise {
  id: string;
  name: string;
  pillar: string;
  unilateral: boolean;
  variants: {
    ar_livre: ExerciseVariant;
    academia: ExerciseVariant;
    simples: ExerciseVariant;
  };
}

export interface WeekTemplate {
  week: number;
  title: string;
  subtitle: string;
  exercise_ids: string[];
  progression: {
    sets_boost: number;
    volume_factor: number;
    rest_factor: number;
  };
}

export interface DailyExercise {
  exercise_id: string;
  chosen_env: 'ar_livre' | 'academia' | 'simples';
  status: 'pending' | 'completed';
  completed_at?: string;
  points_earned?: number;
}

export interface DailySession {
  date: string;
  week: number;
  day_in_week: number;
  exercises: DailyExercise[];
  total_points: number;
  completed: boolean;
}

// Catálogo completo de exercícios
export const exerciseCatalog: Exercise[] = [
  // FORÇA
  {
    id: 'ex_bulgaro',
    name: 'Agachamento Búlgaro',
    pillar: 'Força',
    unilateral: true,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3-4 séries x 8-10 reps por perna',
        notes: 'Use banco/arquibancada. Tronco levemente inclinado; joelho alinhado ao pé.',
        sets: '3-4',
        reps: '8-10 por perna',
        rest: '90s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 8-10 reps por perna com halteres',
        notes: 'Controle na descida (2-3s), subir explosivo. Use halteres ou barra leve.',
        sets: '4',
        reps: '8-10 por perna',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 10-12 reps por perna',
        notes: 'Use cadeira firme ou step. Pode adicionar mochila com peso.',
        sets: '3',
        reps: '10-12 por perna',
        rest: '60s'
      }
    }
  },
  {
    id: 'ex_step_up',
    name: 'Step-up com Joelhada',
    pillar: 'Força',
    unilateral: true,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 8 reps por perna',
        notes: 'Use banco/arquibancada. Joelhada explosiva no final.',
        sets: '3',
        reps: '8 por perna',
        rest: '75s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 8 reps por perna com halteres',
        notes: 'Box jump ou banco alto. Halteres nas mãos para sobrecarga.',
        sets: '4',
        reps: '8 por perna',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 10 reps por perna',
        notes: 'Use cadeira resistente. Foque na explosão da joelhada.',
        sets: '3',
        reps: '10 por perna',
        rest: '60s'
      }
    }
  },
  {
    id: 'ex_hip_thrust',
    name: 'Hip Thrust',
    pillar: 'Força',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 12-15 reps',
        notes: 'Use banco/arquibancada. Aperte glúteos no topo.',
        sets: '3',
        reps: '12-15',
        rest: '60s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 10-12 reps com barra',
        notes: 'Barra sobre quadril. Pausa de 1s no topo.',
        sets: '4',
        reps: '10-12',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 15-20 reps',
        notes: 'Use sofá/cama. Pode adicionar peso no quadril.',
        sets: '3',
        reps: '15-20',
        rest: '45s'
      }
    }
  },
  {
    id: 'ex_stiff_unilateral',
    name: 'Stiff Unilateral',
    pillar: 'Força',
    unilateral: true,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 8-10 reps por perna',
        notes: 'Mantenha perna de apoio levemente flexionada. Desça controlado.',
        sets: '3',
        reps: '8-10 por perna',
        rest: '75s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 8 reps por perna com halteres',
        notes: 'Halteres nas mãos. Foque no alongamento dos isquiotibiais.',
        sets: '4',
        reps: '8 por perna',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 10 reps por perna',
        notes: 'Peso corporal. Pode usar garrafa d\'água como peso.',
        sets: '3',
        reps: '10 por perna',
        rest: '60s'
      }
    }
  },

  // EXPLOSÃO
  {
    id: 'ex_drop_jump',
    name: 'Drop Jump',
    pillar: 'Explosão',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 5 saltos',
        notes: 'Use banco baixo (30-40cm). Aterrisse e salte imediatamente.',
        sets: '4',
        reps: '5 saltos',
        rest: '2min'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 5 saltos',
        notes: 'Box pliométrico. Altura progressiva conforme evolução.',
        sets: '5',
        reps: '5 saltos',
        rest: '2min'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 6 saltos',
        notes: 'Use cadeira resistente. Foque na reatividade.',
        sets: '3',
        reps: '6 saltos',
        rest: '90s'
      }
    }
  },
  {
    id: 'ex_sprint_20m',
    name: 'Sprint 20 metros',
    pillar: 'Explosão',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '6 séries x 1 sprint',
        notes: 'Partida baixa. Primeiros passos curtos e rápidos.',
        sets: '6',
        reps: '1 sprint 20m',
        rest: '2min'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '8 séries x 1 sprint na esteira',
        notes: 'Esteira inclinada (5-8%). Velocidade máxima por 15s.',
        sets: '8',
        reps: '15s máxima',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x corrida no lugar',
        notes: 'Corrida no lugar máxima intensidade por 20s.',
        sets: '5',
        reps: '20s máxima',
        rest: '60s'
      }
    }
  },
  {
    id: 'ex_box_jump',
    name: 'Box Jump',
    pillar: 'Explosão',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 6 saltos',
        notes: 'Use banco/mureta. Aterrisse suavemente.',
        sets: '4',
        reps: '6 saltos',
        rest: '2min'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 6 saltos',
        notes: 'Box pliométrico ajustável. Aumente altura progressivamente.',
        sets: '5',
        reps: '6 saltos',
        rest: '2min'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 8 saltos',
        notes: 'Use cadeira resistente ou degrau. Foque na explosão.',
        sets: '3',
        reps: '8 saltos',
        rest: '90s'
      }
    }
  },

  // COORDENAÇÃO/AGILIDADE
  {
    id: 'ex_ladder_var',
    name: 'Escada de Agilidade',
    pillar: 'Coordenação',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 6 padrões',
        notes: 'Use escada ou marque no chão. Pés rápidos e leves.',
        sets: '4',
        reps: '6 padrões',
        rest: '60s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 8 padrões',
        notes: 'Escada profissional. Varie velocidade e padrões.',
        sets: '5',
        reps: '8 padrões',
        rest: '75s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 5 padrões',
        notes: 'Marque quadrados no chão com fita. Mantenha postura atlética.',
        sets: '3',
        reps: '5 padrões',
        rest: '45s'
      }
    }
  },
  {
    id: 'ex_cones_zigzag',
    name: 'Cones Zigue-zague',
    pillar: 'Agilidade',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 3 voltas',
        notes: '6 cones espaçados 2m. Cortes rápidos e precisos.',
        sets: '5',
        reps: '3 voltas',
        rest: '90s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '6 séries x 3 voltas',
        notes: 'Use cones profissionais. Adicione cronometragem.',
        sets: '6',
        reps: '3 voltas',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 3 voltas',
        notes: 'Use garrafas ou objetos como marcadores.',
        sets: '4',
        reps: '3 voltas',
        rest: '75s'
      }
    }
  },

  // PREVENÇÃO
  {
    id: 'ex_prancha_frontal',
    name: 'Prancha Frontal',
    pillar: 'Prevenção',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 30-45s',
        notes: 'Corpo alinhado. Core contraído. Respiração constante.',
        sets: '3',
        reps: '30-45s',
        rest: '60s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 45-60s',
        notes: 'Use colchonete. Pode adicionar peso nas costas.',
        sets: '4',
        reps: '45-60s',
        rest: '75s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 30s',
        notes: 'No chão ou tapete. Mantenha postura neutra.',
        sets: '3',
        reps: '30s',
        rest: '45s'
      }
    }
  },
  {
    id: 'ex_copenhagen_plank',
    name: 'Copenhagen Plank',
    pillar: 'Prevenção',
    unilateral: true,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 15-20s por lado',
        notes: 'Use banco. Fortaleça adutores. Corpo alinhado.',
        sets: '3',
        reps: '15-20s por lado',
        rest: '60s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 20-30s por lado',
        notes: 'Banco ajustável. Progressão: joelho apoiado → pé apoiado.',
        sets: '4',
        reps: '20-30s por lado',
        rest: '75s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '2 séries x 10-15s por lado',
        notes: 'Use sofá/cama. Versão mais fácil: joelho no chão.',
        sets: '2',
        reps: '10-15s por lado',
        rest: '45s'
      }
    }
  },

  // MOBILIDADE
  {
    id: 'ex_mob_quadril',
    name: 'Mobilidade de Quadril',
    pillar: 'Mobilidade',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 10 movimentos',
        notes: 'Posição 90/90. Amplitude completa de movimento.',
        sets: '3',
        reps: '10 movimentos',
        rest: '30s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 12 movimentos',
        notes: 'Use colchonete. Adicione rotações de tronco.',
        sets: '4',
        reps: '12 movimentos',
        rest: '30s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '2 séries x 8 movimentos',
        notes: 'No chão. Movimentos lentos e controlados.',
        sets: '2',
        reps: '8 movimentos',
        rest: '30s'
      }
    }
  },

  // VELOCIDADE DE REAÇÃO
  {
    id: 'ex_reacao_cor',
    name: 'Reação a Cor',
    pillar: 'Velocidade de Reação',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 8 reações',
        notes: 'Cones coloridos. Parceiro grita cor, você corre até ela.',
        sets: '5',
        reps: '8 reações',
        rest: '90s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '6 séries x 10 reações',
        notes: 'Sistema de luzes ou app. Reação imediata ao estímulo.',
        sets: '6',
        reps: '10 reações',
        rest: '2min'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 6 reações',
        notes: 'Use objetos coloridos. App no celular para comandos.',
        sets: '4',
        reps: '6 reações',
        rest: '75s'
      }
    }
  },

  // RESISTÊNCIA
  {
    id: 'ex_hiit_simples',
    name: 'HIIT Simples',
    pillar: 'Resistência',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 rounds x 30s trabalho/30s descanso',
        notes: 'Burpees, mountain climbers, jumping jacks. Intensidade máxima.',
        sets: '4 rounds',
        reps: '30s trabalho',
        rest: '30s ativo'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 rounds x 45s trabalho/15s descanso',
        notes: 'Use equipamentos variados. Monitore frequência cardíaca.',
        sets: '5 rounds',
        reps: '45s trabalho',
        rest: '15s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 rounds x 30s trabalho/30s descanso',
        notes: 'Peso corporal apenas. Mantenha intensidade alta.',
        sets: '3 rounds',
        reps: '30s trabalho',
        rest: '30s'
      }
    }
  },

  // EXERCÍCIOS ADICIONAIS PARA COMPLETAR 10 POR SEMANA
  {
    id: 'ex_skater_jump',
    name: 'Skater Jumps',
    pillar: 'Explosão',
    unilateral: true,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 10 saltos por lado',
        notes: 'Saltos laterais explosivos. Aterrisse em uma perna.',
        sets: '4',
        reps: '10 por lado',
        rest: '75s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 12 saltos por lado',
        notes: 'Use espaço amplo. Adicione cones para direcionamento.',
        sets: '5',
        reps: '12 por lado',
        rest: '90s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 8 saltos por lado',
        notes: 'Em casa. Cuidado com móveis. Foque no equilíbrio.',
        sets: '3',
        reps: '8 por lado',
        rest: '60s'
      }
    }
  },
  {
    id: 'ex_drible_curto',
    name: 'Drible em Espaço Reduzido',
    pillar: 'Coordenação',
    unilateral: false,
    variants: {
      ar_livre: {
        video_url: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '4 séries x 30s',
        notes: 'Quadrado 2x2m. Use ambos os pés. Varie velocidade.',
        sets: '4',
        reps: '30s',
        rest: '60s'
      },
      academia: {
        video_url: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '5 séries x 45s',
        notes: 'Espaço delimitado. Adicione obstáculos baixos.',
        sets: '5',
        reps: '45s',
        rest: '75s'
      },
      simples: {
        video_url: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        instructions: '3 séries x 30s',
        notes: 'Quintal ou garagem. Cuidado com espaço limitado.',
        sets: '3',
        reps: '30s',
        rest: '45s'
      }
    }
  }
];

// Templates das 12 semanas
export const weekTemplates: WeekTemplate[] = [
  // SEMANA 1 - Base Técnica
  {
    week: 1,
    title: 'Base Técnica e Força Unilateral',
    subtitle: 'Fundamentos e técnica',
    exercise_ids: [
      'ex_bulgaro',
      'ex_step_up',
      'ex_hip_thrust',
      'ex_stiff_unilateral',
      'ex_drop_jump',
      'ex_sprint_20m',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril',
      'ex_ladder_var'
    ],
    progression: { sets_boost: 0, volume_factor: 1.0, rest_factor: 1.0 }
  },
  
  // SEMANA 2 - Coordenação e Agilidade
  {
    week: 2,
    title: 'Coordenação e Agilidade',
    subtitle: 'Movimento e controle',
    exercise_ids: [
      'ex_skater_jump',
      'ex_cones_zigzag',
      'ex_drible_curto',
      'ex_reacao_cor',
      'ex_bulgaro',
      'ex_box_jump',
      'ex_hiit_simples',
      'ex_prancha_frontal',
      'ex_mob_quadril',
      'ex_ladder_var'
    ],
    progression: { sets_boost: 0, volume_factor: 1.1, rest_factor: 0.95 }
  },

  // SEMANA 3 - Força e Potência
  {
    week: 3,
    title: 'Força e Potência',
    subtitle: 'Desenvolvimento muscular',
    exercise_ids: [
      'ex_hip_thrust',
      'ex_step_up',
      'ex_stiff_unilateral',
      'ex_drop_jump',
      'ex_box_jump',
      'ex_sprint_20m',
      'ex_skater_jump',
      'ex_copenhagen_plank',
      'ex_prancha_frontal',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 1, volume_factor: 1.1, rest_factor: 0.9 }
  },

  // SEMANA 4 - Integração
  {
    week: 4,
    title: 'Integração de Movimentos',
    subtitle: 'Combinações complexas',
    exercise_ids: [
      'ex_drible_curto',
      'ex_cones_zigzag',
      'ex_reacao_cor',
      'ex_bulgaro',
      'ex_hiit_simples',
      'ex_ladder_var',
      'ex_sprint_20m',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 1, volume_factor: 1.15, rest_factor: 0.85 }
  },

  // SEMANA 5 - Potência Avançada
  {
    week: 5,
    title: 'Potência Avançada',
    subtitle: 'Explosão máxima',
    exercise_ids: [
      'ex_drop_jump',
      'ex_box_jump',
      'ex_skater_jump',
      'ex_sprint_20m',
      'ex_step_up',
      'ex_hip_thrust',
      'ex_reacao_cor',
      'ex_hiit_simples',
      'ex_prancha_frontal',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 1, volume_factor: 1.2, rest_factor: 0.8 }
  },

  // SEMANA 6 - Agilidade Específica
  {
    week: 6,
    title: 'Agilidade Específica',
    subtitle: 'Movimentos de jogo',
    exercise_ids: [
      'ex_cones_zigzag',
      'ex_drible_curto',
      'ex_ladder_var',
      'ex_reacao_cor',
      'ex_bulgaro',
      'ex_stiff_unilateral',
      'ex_skater_jump',
      'ex_copenhagen_plank',
      'ex_prancha_frontal',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 1, volume_factor: 1.2, rest_factor: 0.75 }
  },

  // SEMANA 7 - Resistência Específica
  {
    week: 7,
    title: 'Resistência Específica',
    subtitle: 'Condicionamento de jogo',
    exercise_ids: [
      'ex_hiit_simples',
      'ex_sprint_20m',
      'ex_cones_zigzag',
      'ex_drible_curto',
      'ex_hip_thrust',
      'ex_step_up',
      'ex_box_jump',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 2, volume_factor: 1.25, rest_factor: 0.7 }
  },

  // SEMANA 8 - Força Máxima
  {
    week: 8,
    title: 'Força Máxima',
    subtitle: 'Pico de força',
    exercise_ids: [
      'ex_bulgaro',
      'ex_hip_thrust',
      'ex_stiff_unilateral',
      'ex_step_up',
      'ex_drop_jump',
      'ex_sprint_20m',
      'ex_reacao_cor',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 2, volume_factor: 1.25, rest_factor: 1.1 }
  },

  // SEMANA 9 - Específico de Jogo
  {
    week: 9,
    title: 'Específico de Jogo',
    subtitle: 'Situações reais',
    exercise_ids: [
      'ex_drible_curto',
      'ex_cones_zigzag',
      'ex_reacao_cor',
      'ex_skater_jump',
      'ex_sprint_20m',
      'ex_hiit_simples',
      'ex_ladder_var',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 2, volume_factor: 1.3, rest_factor: 0.65 }
  },

  // SEMANA 10 - Complexidade Máxima
  {
    week: 10,
    title: 'Complexidade Máxima',
    subtitle: 'Desafios avançados',
    exercise_ids: [
      'ex_box_jump',
      'ex_drop_jump',
      'ex_drible_curto',
      'ex_reacao_cor',
      'ex_cones_zigzag',
      'ex_bulgaro',
      'ex_hiit_simples',
      'ex_prancha_frontal',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 2, volume_factor: 1.3, rest_factor: 0.6 }
  },

  // SEMANA 11 - Pico de Performance
  {
    week: 11,
    title: 'Pico de Performance',
    subtitle: 'Máximo rendimento',
    exercise_ids: [
      'ex_sprint_20m',
      'ex_skater_jump',
      'ex_drible_curto',
      'ex_reacao_cor',
      'ex_ladder_var',
      'ex_hip_thrust',
      'ex_step_up',
      'ex_hiit_simples',
      'ex_prancha_frontal',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 3, volume_factor: 1.35, rest_factor: 0.6 }
  },

  // SEMANA 12 - Consolidação
  {
    week: 12,
    title: 'Consolidação',
    subtitle: 'Finalização do ciclo',
    exercise_ids: [
      'ex_bulgaro',
      'ex_hip_thrust',
      'ex_drop_jump',
      'ex_box_jump',
      'ex_sprint_20m',
      'ex_drible_curto',
      'ex_cones_zigzag',
      'ex_hiit_simples',
      'ex_copenhagen_plank',
      'ex_mob_quadril'
    ],
    progression: { sets_boost: 3, volume_factor: 1.4, rest_factor: 0.55 }
  }
];

// Função para obter a semana atual baseada na data
export const getCurrentWeek = (): number => {
  const startDate = new Date('2025-01-01'); // Data de início do programa
  const today = new Date();
  const diffTime = Math.abs(today.getTime() - startDate.getTime());
  const diffWeeks = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7));
  return (diffWeeks % 12) + 1; // Ciclo de 12 semanas
};

// Função para obter o dia da semana (1-7)
export const getCurrentDayOfWeek = (): number => {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0 = domingo, 1 = segunda, etc.
  return dayOfWeek === 0 ? 7 : dayOfWeek; // Converter para 1-7 (segunda = 1, domingo = 7)
};

// Função para gerar sessão diária
export const generateDailySession = (date: Date): DailySession => {
  const currentWeek = getCurrentWeek();
  const dayOfWeek = getCurrentDayOfWeek();
  const template = weekTemplates.find(w => w.week === currentWeek) || weekTemplates[0];
  
  const exercises: DailyExercise[] = template.exercise_ids.map(id => ({
    exercise_id: id,
    chosen_env: 'simples', // Default
    status: 'pending'
  }));

  return {
    date: date.toISOString().split('T')[0],
    week: currentWeek,
    day_in_week: dayOfWeek,
    exercises,
    total_points: 0,
    completed: false
  };
};

// Função para obter exercício por ID
export const getExerciseById = (id: string): Exercise | undefined => {
  return exerciseCatalog.find(ex => ex.id === id);
};

// Função para calcular pontos por exercício
export const calculateExercisePoints = (exercise: Exercise, difficulty: string): number => {
  let basePoints = 10;
  
  // Bônus por pilar
  if (exercise.pillar === 'Explosão' || exercise.pillar === 'Velocidade de Reação') {
    basePoints += 5;
  }
  
  // Bônus por unilateral
  if (exercise.unilateral) {
    basePoints += 3;
  }
  
  return basePoints;
};

// Função para obter cor do pilar
export const getPillarColor = (pillar: string): string => {
  switch (pillar) {
    case 'Explosão': return 'bg-gradient-to-br from-yellow-400 to-orange-500';
    case 'Força': return 'bg-gradient-to-br from-red-500 to-pink-600';
    case 'Mobilidade': return 'bg-gradient-to-br from-green-400 to-emerald-600';
    case 'Resistência': return 'bg-gradient-to-br from-blue-400 to-blue-600';
    case 'Velocidade de Reação': return 'bg-gradient-to-br from-yellow-400 to-orange-500';
    case 'Coordenação': return 'bg-gradient-to-br from-purple-500 to-indigo-600';
    case 'Agilidade': return 'bg-gradient-to-br from-cyan-400 to-blue-500';
    case 'Prevenção': return 'bg-gradient-to-br from-teal-400 to-green-600';
    default: return 'bg-gradient-to-br from-gray-400 to-gray-600';
  }
};

// Função para obter ícone do pilar
export const getPillarIcon = (pillar: string): string => {
  switch (pillar) {
    case 'Explosão': return '⚡';
    case 'Força': return '🔥';
    case 'Mobilidade': return '🦵';
    case 'Resistência': return '⏱️';
    case 'Velocidade de Reação': return '⚡';
    case 'Coordenação': return '⚽';
    case 'Agilidade': return '🏃';
    case 'Prevenção': return '🛡️';
    default: return '⚽';
  }
};