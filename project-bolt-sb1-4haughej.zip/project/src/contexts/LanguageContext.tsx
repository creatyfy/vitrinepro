import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'pt' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  pt: {
    // Tela Inicial
    'welcome': 'Bem-vindo ao Vitrine Pro',
    'getStarted': 'Começar',
    'alreadyHaveAccount': 'Já tem uma conta?',
    'loginHere': 'Entre aqui',

    // Hub Principal
    'mainHub': 'Vitrine Pro',
    'yourJourney': 'Sua jornada rumo ao profissional',
    'classicPlan': 'Plano clássico',
    'quickStart': 'INÍCIO RÁPIDO',
    'classicTrainings': 'Treinos Clássicos',
    'fullBody': 'Todo O Corpo',
    'explosion': 'Explosão',
    'strength': 'Força',
    'agility': 'Agilidade',
    'beginner': 'Iniciante',
    'amateur': 'Amador',
    'intermediate': 'Intermediário',
    'advanced': 'Avançado',
    'tryouts': 'Peneiras',
    'pickupGames': 'Peladas',
    'nutrition': 'Nutrição',
    'ranking': 'Ranking',
    'mindset': 'Mentalidade',
    'marketplace': 'Marketplace',

    // Navegação
    'classic': 'Clássico',
    'training': 'Treino',
    'personal': 'Pessoal',
    'daily': 'Diariamente',
    'settings': 'Configurações',

    // Configurações
    'profile': 'Perfil',
    'editProfile': 'Editar Perfil',
    'changeTheme': 'Alterar Tema',
    'privacy': 'Privacidade',
    'helpSupport': 'Ajuda e Suporte',
    'identityVerification': 'Validação de Identidade',
    'light': 'Claro',
    'dark': 'Escuro',
    'followSystem': 'Seguir o sistema',

    // Treinos
    'myTrainings': 'Meus Treinos',
    'trainingOfDay': 'Treino do Dia',
    'personalizedTraining': 'Treino Personalizado',
    'exercises': 'Exercícios',
    'duration': 'Duração',
    'calories': 'Calorias',
    'points': 'Pontos',
    'startDailyTraining': 'Começar Treino do Dia',
    'otherTrainings': 'Outros Treinos',
    'level': 'Nível',
    'category': 'Categoria',
    'all': 'Todos',
    'skip': 'Pular',
    'complete': 'Concluir',
    'next': 'Próximo',
    'previous': 'Anterior',
    'skipRest': 'Pular Descanso',
    'prepareForNext': 'Prepare-se para o próximo',

    // Publicar Treino
    'publishTraining': 'Publicar Treino',
    'takePhoto': 'Tire uma foto',
    'photoDescription': 'Tire uma selfie ou foto do seu treino para validar que você realmente treinou!',
    'uploadPhoto': 'Enviar Foto',
    'publish': 'Publicar',

    // Conclusão
    'congratulations': 'Parabéns!',
    'trainingCompleted': 'Treino do dia concluído com sucesso!',
    'pointsEarned': 'Pontos Ganhos',
    'completed': 'Concluídos',
    'rate': 'Taxa',
    'medalsEarned': 'Medalhas Conquistadas',
    'finishTraining': 'Finalizar Treino'
  },
  en: {
    // Initial Screen
    'welcome': 'Welcome to Vitrine Pro',
    'getStarted': 'Get Started',
    'alreadyHaveAccount': 'Already have an account?',
    'loginHere': 'Login here',

    // Main Hub
    'mainHub': 'Vitrine Pro',
    'yourJourney': 'Your journey to professional',
    'classicPlan': 'Classic plan',
    'quickStart': 'QUICK START',
    'classicTrainings': 'Classic Trainings',
    'fullBody': 'Full Body',
    'explosion': 'Explosion',
    'strength': 'Strength',
    'agility': 'Agility',
    'beginner': 'Beginner',
    'amateur': 'Amateur',
    'intermediate': 'Intermediate',
    'advanced': 'Advanced',
    'tryouts': 'Tryouts',
    'pickupGames': 'Pickup Games',
    'nutrition': 'Nutrition',
    'ranking': 'Ranking',
    'mindset': 'Mindset',
    'marketplace': 'Marketplace',

    // Navigation
    'classic': 'Classic',
    'training': 'Training',
    'personal': 'Personal',
    'daily': 'Daily',
    'settings': 'Settings',

    // Settings
    'profile': 'Profile',
    'editProfile': 'Edit Profile',
    'changeTheme': 'Change Theme',
    'privacy': 'Privacy',
    'helpSupport': 'Help & Support',
    'identityVerification': 'Identity Verification',
    'light': 'Light',
    'dark': 'Dark',
    'followSystem': 'Follow system',

    // Trainings
    'myTrainings': 'My Trainings',
    'trainingOfDay': 'Training of the Day',
    'personalizedTraining': 'Personalized Training',
    'exercises': 'Exercises',
    'duration': 'Duration',
    'calories': 'Calories',
    'points': 'Points',
    'startDailyTraining': 'Start Daily Training',
    'otherTrainings': 'Other Trainings',
    'level': 'Level',
    'category': 'Category',
    'all': 'All',
    'skip': 'Skip',
    'complete': 'Complete',
    'next': 'Next',
    'previous': 'Previous',
    'skipRest': 'Skip Rest',
    'prepareForNext': 'Prepare for next',

    // Publish Training
    'publishTraining': 'Publish Training',
    'takePhoto': 'Take a photo',
    'photoDescription': 'Take a selfie or photo of your training to validate that you actually trained!',
    'uploadPhoto': 'Upload Photo',
    'publish': 'Publish',

    // Completion
    'congratulations': 'Congratulations!',
    'trainingCompleted': 'Daily training completed successfully!',
    'pointsEarned': 'Points Earned',
    'completed': 'Completed',
    'rate': 'Rate',
    'medalsEarned': 'Medals Earned',
    'finishTraining': 'Finish Training'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const savedLang = localStorage.getItem('app-language') as Language;
    return savedLang || 'pt';
  });

  useEffect(() => {
    localStorage.setItem('app-language', language);
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
