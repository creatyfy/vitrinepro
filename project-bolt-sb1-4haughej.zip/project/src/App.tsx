import React, { useState, useEffect, Suspense, lazy } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useTheme } from './contexts/ThemeContext';
import { useProfile } from './hooks/useProfile';
import ErrorBoundary from './components/ErrorBoundary';
import LoadingScreen from './components/LoadingScreen';
import { authService } from './services/authService';

const SuspenseFallback = () => <div className="min-h-screen" />;

const GenderSelection = lazy(() => import('./components/GenderSelection'));
const UserTypeSelection = lazy(() => import('./components/UserTypeSelection'));
const TrainingFrequency = lazy(() => import('./components/TrainingFrequency'));
const VitrineProVisibility = lazy(() => import('./components/VitrineProVisibility'));
const HeightWeight = lazy(() => import('./components/HeightWeight'));
const BirthDate = lazy(() => import('./components/BirthDate'));
const ReferralSource = lazy(() => import('./components/ReferralSource'));
const ObjectiveSelection = lazy(() => import('./components/ObjectiveSelection'));
const ObstacleSelection = lazy(() => import('./components/ObstacleSelection'));
const GoalsSelection = lazy(() => import('./components/GoalsSelection'));
const ResultsScreen = lazy(() => import('./components/ResultsScreen'));
const VitrineProKnowledge = lazy(() => import('./components/VitrineProKnowledge'));
const SuccessStories = lazy(() => import('./components/SuccessStories'));
const AthleteNameCollection = lazy(() => import('./components/AthleteNameCollection'));
const EmailCollection = lazy(() => import('./components/EmailCollection'));
const PhoneCollection = lazy(() => import('./components/PhoneCollection'));
const ReferralCodeCollection = lazy(() => import('./components/ReferralCodeCollection'));
const LoginScreen = lazy(() => import('./components/LoginScreen'));
const ForgotPasswordScreen = lazy(() => import('./components/ForgotPasswordScreen'));
const PlayerPositionSelection = lazy(() => import('./components/PlayerPositionSelection'));
const CongratulationsScreen = lazy(() => import('./components/CongratulationsScreen'));
const MainHub = lazy(() => import('./components/MainHub'));
const MyTrainings = lazy(() => import('./components/MyTrainings'));
const PeneirasScreen = lazy(() => import('./components/PeneirasScreen'));
const NutritionScreen = lazy(() => import('./components/NutritionScreen'));
const DailyNutritionChallenge = lazy(() => import('./components/DailyNutritionChallenge'));
const MindsetScreen = lazy(() => import('./components/MindsetScreen'));
const RankingScreen = lazy(() => import('./components/RankingScreen'));
const MarketplaceScreen = lazy(() => import('./components/MarketplaceScreen'));
const ProofHistoryScreen = lazy(() => import('./components/ProofHistoryScreen'));
const ClubNameCollection = lazy(() => import('./components/ClubNameCollection'));
const ClubAddressCollection = lazy(() => import('./components/ClubAddressCollection'));
const ClubLogoUpload = lazy(() => import('./components/ClubLogoUpload'));
const ClubResponsibleCollection = lazy(() => import('./components/ClubResponsibleCollection'));
const ClubPositionSelection = lazy(() => import('./components/ClubPositionSelection'));
const ClubDocumentUpload = lazy(() => import('./components/ClubDocumentUpload'));
const ClubAgreementScreen = lazy(() => import('./components/ClubAgreementScreen'));
const ClubCategorySelection = lazy(() => import('./components/ClubCategorySelection'));
const AgentNameCollection = lazy(() => import('./components/AgentNameCollection'));
const AgentCompanyCollection = lazy(() => import('./components/AgentCompanyCollection'));
const AgentAddressCollection = lazy(() => import('./components/AgentAddressCollection'));
const AgentCredentialsCollection = lazy(() => import('./components/AgentCredentialsCollection'));
const AgentSocialLinksCollection = lazy(() => import('./components/AgentSocialLinksCollection'));
const AgentExperienceSelection = lazy(() => import('./components/AgentExperienceSelection'));
const AgentLicenseUpload = lazy(() => import('./components/AgentLicenseUpload'));
const ClubHub = lazy(() => import('./components/ClubHub'));
const AgentHub = lazy(() => import('./components/AgentHub'));
const WeeklyTrainingProgram = lazy(() => import('./components/WeeklyTrainingProgram'));
const SettingsScreen = lazy(() => import('./components/SettingsScreen'));
const AgentSettingsScreen = lazy(() => import('./components/AgentSettingsScreen'));
const ClubSettingsScreen = lazy(() => import('./components/ClubSettingsScreen'));
const PrivacyScreen = lazy(() => import('./components/PrivacyScreen'));
const SupportScreen = lazy(() => import('./components/SupportScreen'));
const ProfileScreen = lazy(() => import('./components/ProfileScreen'));
const PlayerProfileScreen = lazy(() => import('./components/PlayerProfileScreen'));
const DailyProgressScreen = lazy(() => import('./components/DailyProgressScreen'));
const MyAccountScreen = lazy(() => import('./components/MyAccountScreen'));
const PeladasScreen = lazy(() => import('./components/PeladasScreen'));
const TrainingCategoryScreen = lazy(() => import('./components/TrainingCategoryScreen'));
const ExerciseExecutionScreen = lazy(() => import('./components/ExerciseExecutionScreen'));
const TrainingPreRollScreen = lazy(() => import('./components/TrainingPreRollScreen'));
const UniversalAntiCheatVerification = lazy(() => import('./components/UniversalAntiCheatVerification'));
const Challenge28Screen = lazy(() => import('./components/Challenge28Screen'));
const Challenge28DayDetailScreen = lazy(() => import('./components/Challenge28DayDetailScreen'));
const Challenge28SettingsScreen = lazy(() => import('./components/Challenge28SettingsScreen'));
const Challenge28ExecutionScreen = lazy(() => import('./components/Challenge28ExecutionScreen'));
const TreinoDoDiaScreen = lazy(() => import('./components/TreinoDoDiaScreen'));
import type { Exercise, ExerciseVariant } from './data/weeklyTrainingData';
import type { Training } from './data/trainingData';

function App() {
  const { userId, profile, playerProfile, loading: userLoading, completeOnboarding, syncQuizDataToProfile } = useProfile();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentStep, setCurrentStep] = useState('onboarding');
  const [selectedUserType, setSelectedUserType] = useState('');
  const [selectedTrainingCategory, setSelectedTrainingCategory] = useState('');
  const [currentTraining, setCurrentTraining] = useState<Training | null>(null);
  const [currentExercise, setCurrentExercise] = useState<{ exercise: Exercise; variant: ExerciseVariant } | null>(null);
  const [workoutPoints, setWorkoutPoints] = useState(0);
  const [workoutId, setWorkoutId] = useState<string>('');
  const [selectedClubCategory, setSelectedClubCategory] = useState('');
  const [selectedChallengeId, setSelectedChallengeId] = useState<string>('upper-body-challenge');
  const [selectedChallengeDay, setSelectedChallengeDay] = useState<number>(1);
  const [selectedGender, setSelectedGender] = useState('');
  const [selectedFrequency, setSelectedFrequency] = useState('');
  const [selectedHeight, setSelectedHeight] = useState(170);
  const [selectedWeight, setSelectedWeight] = useState(70);
  const [selectedDay, setSelectedDay] = useState(1);
  const [selectedMonth, setSelectedMonth] = useState(1);
  const [selectedYear, setSelectedYear] = useState(2000);
  const [selectedSource, setSelectedSource] = useState('');
  const [selectedObjective, setSelectedObjective] = useState('');
  const [selectedObstacles, setSelectedObstacles] = useState<string[]>([]);
  const [selectedGoal, setSelectedGoal] = useState('');
  const [athleteName, setAthleteName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [selectedPosition, setSelectedPosition] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Agent-specific states
  const [agentName, setAgentName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [agentAddress, setAgentAddress] = useState('');
  const [agentPassword, setAgentPassword] = useState('');
  const [agentConfirmPassword, setAgentConfirmPassword] = useState('');
  const [socialLinks, setSocialLinks] = useState({
    instagram: '',
    linkedin: '',
    website: ''
  });
  const [athletesRepresented, setAthletesRepresented] = useState('');
  const [yearsExperience, setYearsExperience] = useState('');
  const [hasLicense, setHasLicense] = useState('');
  const [licenseDocument, setLicenseDocument] = useState('');
  
  // Club-specific states
  const [clubName, setClubName] = useState('');
  const [clubAddress, setClubAddress] = useState('');
  const [clubLogo, setClubLogo] = useState('');
  const [responsibleName, setResponsibleName] = useState('');
  const [responsiblePosition, setResponsiblePosition] = useState('');
  const [clubDocument, setClubDocument] = useState('');
  const [clubPassword, setClubPassword] = useState('');
  const [clubConfirmPassword, setClubConfirmPassword] = useState('');
  
  // Current view state
  const [clubCurrentView, setClubCurrentView] = useState('main'); // 'main', 'create-peneira', 'scout-athletes', 'club-marketplace', 'reports'
  const [agentCurrentView, setAgentCurrentView] = useState('main'); // 'main', 'scout-center', 'observed-athletes', 'publish-opportunities', 'agent-ranking', 'agent-profile', 'agent-settings', 'agent-reports', 'agent-contracts'

  // Theme state from context
  const { isDarkMode, setTheme, theme } = useTheme();
  
  const totalSlides = 3;

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const slides = [
    {
      title: "O seu talento no futebol é visto aqui",
      subtitle: "Conecte-se com clubes, empresários, aumente suas chances no futebol profissional",
      buttonText: "Iniciar Quiz"
    },
    {
      title: "Transforme seu esforço em vitrine",
      subtitle: "Receba os treinamentos diários dos melhores jogadores do mundo e publique seu progresso aqui",
      buttonText: "Iniciar Quiz"
    },
    {
      title: "Sua jornada rumo ao profissinal começa agora",
      subtitle: "Chegou a hora de ser visto.",
      buttonText: "Iniciar Quiz"
    }
  ];

  const handleStartQuiz = () => {
    setCurrentStep('user-type');
  };

  const handleLogin = () => {
    setCurrentStep('login');
  };

  const handleLoginSubmit = async (email: string, password: string) => {
    try {
      const { user, session } = await authService.signIn({ email, password });

      if (user) {
        const profile = await authService.getProfile(user.id);

        if (profile) {
          setSelectedUserType(profile.user_type || 'atleta');
          setAthleteName(profile.full_name || 'Atleta');
          setEmail(profile.email || '');
          setPhone(profile.phone || '');
          setSelectedGender(profile.gender || '');
          setSelectedHeight(profile.height || 170);
          setSelectedWeight(profile.weight || 70);
          setSelectedPosition(profile.player_position || '');
          setSelectedObjective(profile.objective || '');
          setSelectedObstacles(profile.obstacles || []);
          setSelectedFrequency(profile.training_frequency || '');
          setReferralCode(profile.referral_code || '');
          setSelectedSource(profile.referral_source || '');

          if (profile.birth_date) {
            const date = new Date(profile.birth_date);
            setSelectedDay(date.getDate());
            setSelectedMonth(date.getMonth() + 1);
            setSelectedYear(date.getFullYear());
          }
        }

        setCurrentStep('main-hub');
      }
    } catch (error: any) {
      console.error('Login error:', error);
      alert(error.message || 'Erro ao fazer login. Verifique suas credenciais.');
    }
  };

  const handleForgotPassword = () => {
    setCurrentStep('forgot-password');
  };

  const handleSendCode = (email: string) => {
    // Aqui você pode implementar a lógica de envio do código
    console.log('Sending verification code to:', email);
    alert(`Código de verificação enviado para: ${email}`);
  };

  const handleBackToLogin = () => {
    setCurrentStep('login');
  };

  const handleUserTypeNext = () => {
    if (selectedUserType) {
      if (selectedUserType === 'atleta') {
        setCurrentStep('gender');
      } else if (selectedUserType === 'clube') {
        setCurrentStep('club-category');
      } else if (selectedUserType === 'empresario') {
        setCurrentStep('agent-name');
      } else if (selectedUserType === 'empresario') {
        setCurrentStep('agent-name');
      } else {
        setCurrentStep('gender');
      }
    }
  };

  const handleGenderNext = () => {
    if (selectedGender) {
      setCurrentStep('training');
    }
  };

  const handleTrainingNext = () => {
    if (selectedFrequency) {
      setCurrentStep('visibility');
    }
  };

  const handleVisibilityNext = () => {
    if (selectedGender && selectedFrequency) {
      setCurrentStep('height-weight');
    }
  };

  const handleHeightWeightNext = () => {
    if (selectedHeight && selectedWeight) {
      setCurrentStep('birthdate');
    }
  };

  const handleBirthDateNext = () => {
    if (selectedDay && selectedMonth && selectedYear) {
      setCurrentStep('referral');
    }
  };

  const handleReferralNext = () => {
    if (selectedSource) {
      setCurrentStep('objective');
    }
  };

  const handleObjectiveNext = () => {
    if (selectedObjective) {
      setCurrentStep('obstacles');
    }
  };

  const handleObstacleToggle = (obstacle: string) => {
    setSelectedObstacles(prev => {
      if (prev.includes(obstacle)) {
        return prev.filter(o => o !== obstacle);
      } else {
        return [...prev, obstacle];
      }
    });
  };

  const handleObstaclesNext = () => {
    if (selectedObstacles.length > 0) {
      setCurrentStep('goals');
    }
  };

  const handleGoalsNext = () => {
    if (selectedGoal) {
      setCurrentStep('results');
    }
  };

  const handleResultsNext = () => {
    setCurrentStep('vitrine-knowledge');
  };

  const handleVitrineKnowledgeNext = () => {
    setCurrentStep('success-stories');
  };

  const handleSuccessStoriesNext = () => {
    setCurrentStep('athlete-name');
  };

  const handleAthleteNameNext = () => {
    setCurrentStep('email');
  };

  const handleEmailNext = () => {
    setCurrentStep('phone');
  };

  const handlePhoneNext = () => {
    setCurrentStep('referral-code');
  };

  const handleReferralCodeNext = () => {
    setCurrentStep('player-position');
  };

  const handleReferralCodeSkip = () => {
    setCurrentStep('player-position');
  };

  const handlePlayerPositionNext = () => {
    if (selectedPosition) {
      setCurrentStep('loading');
    }
  };

  const handleFinalizeOnboarding = () => {
    setCurrentStep('congratulations');
  };

  const handleCongratulationsNext = async () => {
    try {
      const birthDate = `${selectedDay.toString().padStart(2, '0')}/${selectedMonth.toString().padStart(2, '0')}/${selectedYear}`;

      const { user, session } = await authService.signUp({
        email,
        password,
        userData: {
          full_name: athleteName,
          phone,
          birth_date: birthDate,
          gender: selectedGender,
          height: selectedHeight,
          weight: selectedWeight,
          user_type: 'athlete',
          player_position: selectedPosition,
          goals: selectedGoal ? [selectedGoal] : [],
          objective: selectedObjective,
          obstacles: selectedObstacles,
          training_frequency: selectedFrequency,
          referral_source: selectedSource,
          referral_code: referralCode,
        },
      });

      if (user) {
        const onboardingData = {
          full_name: athleteName,
          phone,
          birth_date: birthDate,
          gender: selectedGender,
          height: selectedHeight,
          weight: selectedWeight,
          user_type: 'athlete' as const,
          player_position: selectedPosition,
          goals: selectedGoal ? [selectedGoal] : [],
          objective: selectedObjective,
          obstacles: selectedObstacles,
          training_frequency: selectedFrequency,
          referral_source: selectedSource,
          referral_code: referralCode,
        };

        const success = await completeOnboarding(onboardingData);

        if (success) {
          console.log('Profile saved successfully!');
        } else {
          console.warn('Profile may not have been fully saved');
        }

        setCurrentStep('main-hub');
      }
    } catch (error: any) {
      console.error('Sign up error:', error);
      alert(error.message || 'Erro ao criar conta. Por favor, tente novamente.');
    }
  };

  const handleBackToOnboarding = () => {
    setCurrentStep('onboarding');
  };

  const handleBackToUserType = () => {
    setCurrentStep('user-type');
  };

  const handleBackToGender = () => {
    setCurrentStep('user-type');
  };

  const handleBackToTraining = () => {
    setCurrentStep('training');
  };

  const handleBackToVisibility = () => {
    setCurrentStep('visibility');
  };

  const handleBackToHeightWeight = () => {
    setCurrentStep('height-weight');
  };

  const handleBackToBirthDate = () => {
    setCurrentStep('birthdate');
  };

  const handleBackToReferral = () => {
    setCurrentStep('referral');
  };

  const handleBackToObjective = () => {
    setCurrentStep('objective');
  };

  const handleBackToObstacles = () => {
    setCurrentStep('obstacles');
  };

  const handleBackToGoals = () => {
    setCurrentStep('goals');
  };

  const handleBackToResults = () => {
    setCurrentStep('results');
  };

  const handleBackToVitrineKnowledge = () => {
    setCurrentStep('vitrine-knowledge');
  };

  const handleBackToSuccessStories = () => {
    setCurrentStep('success-stories');
  };

  const handleBackToAthleteName = () => {
    setCurrentStep('athlete-name');
  };

  const handleBackToEmail = () => {
    setCurrentStep('email');
  };

  const handleBackToPhone = () => {
    setCurrentStep('phone');
  };

  const handleBackToReferralCode = () => {
    setCurrentStep('referral-code');
  };

  const handleBackToLoading = () => {
    setCurrentStep('loading');
  };

  const handleBackToOnboardingFromLogin = () => {
    setCurrentStep('onboarding');
  };

  // Club funnel handlers
  const handleClubCategoryNext = () => {
    if (selectedClubCategory) {
      setCurrentStep('club-name');
    }
  };

  const handleClubNameNext = () => {
    if (clubName) {
      setCurrentStep('club-address');
    }
  };

  const handleClubAddressNext = () => {
    if (clubAddress) {
      setCurrentStep('club-logo');
    }
  };

  const handleClubLogoNext = () => {
    setCurrentStep('club-responsible');
  };

  const handleClubLogoSkip = () => {
    setCurrentStep('club-responsible');
  };

  const handleClubResponsibleNext = () => {
    if (responsibleName) {
      setCurrentStep('club-email');
    }
  };

  const handleClubEmailNext = () => {
    setCurrentStep('club-position');
  };

  const handleClubPositionNext = () => {
    if (responsiblePosition) {
      setCurrentStep('club-phone');
    }
  };

  const handleClubPhoneNext = () => {
    setCurrentStep('club-document');
  };

  const handleClubDocumentNext = () => {
    setCurrentStep('club-agreement');
  };

  const handleClubDocumentSkip = () => {
    setCurrentStep('club-agreement');
  };

  const handleClubAgreementNext = () => {
    setCurrentStep('main-hub');
  };

  // Club back handlers
  const handleBackToClubCategory = () => {
    setCurrentStep('user-type');
  };

  const handleBackToClubName = () => {
    setCurrentStep('club-category');
  };

  const handleBackToClubAddress = () => {
    setCurrentStep('club-name');
  };

  const handleBackToClubLogo = () => {
    setCurrentStep('club-address');
  };

  const handleBackToClubResponsible = () => {
    setCurrentStep('club-logo');
  };

  const handleBackToClubPosition = () => {
    setCurrentStep('club-email');
  };

  const handleBackToClubPhone = () => {
    setCurrentStep('club-position');
  };

  const handleBackToClubEmail = () => {
    setCurrentStep('club-responsible');
  };

  const handleBackToClubDocument = () => {
    setCurrentStep('club-email');
  };

  const handleBackToClubAgreement = () => {
    setCurrentStep('club-document');
  };

  // Agent funnel handlers
  const handleAgentNameNext = () => {
    if (agentName) {
      setCurrentStep('agent-company');
    }
  };

  const handleAgentCompanyNext = () => {
    setCurrentStep('agent-address');
  };

  const handleAgentCompanySkip = () => {
    setCurrentStep('agent-address');
  };

  const handleAgentAddressNext = () => {
    if (agentAddress) {
      setCurrentStep('agent-phone');
    }
  };

  const handleAgentPhoneNext = () => {
    setCurrentStep('agent-credentials');
  };

  const handleAgentCredentialsNext = () => {
    setCurrentStep('agent-social');
  };

  const handleAgentSocialNext = () => {
    setCurrentStep('agent-experience');
  };

  const handleAgentSocialSkip = () => {
    setCurrentStep('agent-experience');
  };

  const handleAgentExperienceNext = () => {
    setCurrentStep('agent-license');
  };

  const handleAgentLicenseNext = () => {
    setCurrentStep('main-hub');
  };

  // Agent back handlers
  const handleBackToAgentName = () => {
    setCurrentStep('user-type');
  };

  const handleBackToAgentCompany = () => {
    setCurrentStep('agent-name');
  };

  const handleBackToAgentAddress = () => {
    setCurrentStep('agent-company');
  };

  const handleBackToAgentPhone = () => {
    setCurrentStep('agent-address');
  };

  const handleBackToAgentCredentials = () => {
    setCurrentStep('agent-phone');
  };

  const handleBackToAgentSocial = () => {
    setCurrentStep('agent-credentials');
  };

  const handleBackToAgentExperience = () => {
    setCurrentStep('agent-social');
  };

  const handleBackToAgentLicense = () => {
    setCurrentStep('agent-experience');
  };


  if (currentStep === 'user-type') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <UserTypeSelection
          selectedUserType={selectedUserType}
          onUserTypeSelect={setSelectedUserType}
          onNext={handleUserTypeNext}
          onBack={handleBackToOnboarding}
        />
      </Suspense>
    );
  }

  if (currentStep === 'gender') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <GenderSelection
          selectedGender={selectedGender}
          onGenderSelect={setSelectedGender}
          onNext={handleGenderNext}
          onBack={handleBackToUserType}
        />
      </Suspense>
    );
  }

  if (currentStep === 'login') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <LoginScreen
          onBack={handleBackToOnboardingFromLogin}
          onLogin={handleLoginSubmit}
          onForgotPassword={handleForgotPassword}
        />
      </Suspense>
    );
  }

  if (currentStep === 'forgot-password') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <ForgotPasswordScreen
          onBack={handleBackToLogin}
          onSendCode={handleSendCode}
        />
      </Suspense>
    );
  }

  if (currentStep === 'training') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <TrainingFrequency
          selectedFrequency={selectedFrequency}
          onFrequencySelect={setSelectedFrequency}
          onNext={handleTrainingNext}
          onBack={handleBackToGender}
        />
      </Suspense>
    );
  }

  if (currentStep === 'visibility') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <VitrineProVisibility
          onNext={handleVisibilityNext}
          onBack={handleBackToTraining}
        />
      </Suspense>
    );
  }

  if (currentStep === 'height-weight') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <HeightWeight
        selectedHeight={selectedHeight}
        selectedWeight={selectedWeight}
        onHeightSelect={setSelectedHeight}
        onWeightSelect={setSelectedWeight}
        onNext={handleHeightWeightNext}
        onBack={handleBackToVisibility}
      />
      </Suspense>
    );
  }

  if (currentStep === 'birthdate') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <BirthDate
        selectedDay={selectedDay}
        selectedMonth={selectedMonth}
        selectedYear={selectedYear}
        onDaySelect={setSelectedDay}
        onMonthSelect={setSelectedMonth}
        onYearSelect={setSelectedYear}
        onNext={handleBirthDateNext}
        onBack={handleBackToHeightWeight}
      />
      </Suspense>
    );
  }

  if (currentStep === 'referral') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ReferralSource
        selectedSource={selectedSource}
        onSourceSelect={setSelectedSource}
        onNext={handleReferralNext}
        onBack={handleBackToBirthDate}
      />
      </Suspense>
    );
  }

  if (currentStep === 'objective') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ObjectiveSelection
        selectedObjective={selectedObjective}
        onObjectiveSelect={setSelectedObjective}
        onNext={handleObjectiveNext}
        onBack={handleBackToReferral}
      />
      </Suspense>
    );
  }

  if (currentStep === 'obstacles') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ObstacleSelection
        selectedObstacles={selectedObstacles}
        onObstacleToggle={handleObstacleToggle}
        onNext={handleObstaclesNext}
        onBack={handleBackToObjective}
      />
      </Suspense>
    );
  }

  if (currentStep === 'goals') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <GoalsSelection
        selectedGoal={selectedGoal}
        onGoalSelect={setSelectedGoal}
        onNext={handleGoalsNext}
        onBack={handleBackToObstacles}
      />
      </Suspense>
    );
  }

  if (currentStep === 'results') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ResultsScreen
        onNext={handleResultsNext}
        onBack={handleBackToGoals}
      />
      </Suspense>
    );
  }

  if (currentStep === 'vitrine-knowledge') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <VitrineProKnowledge
        onNext={handleVitrineKnowledgeNext}
        onBack={handleBackToResults}
      />
      </Suspense>
    );
  }

  if (currentStep === 'success-stories') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <SuccessStories
        onNext={handleSuccessStoriesNext}
        onBack={handleBackToVitrineKnowledge}
      />
      </Suspense>
    );
  }

  if (currentStep === 'athlete-name') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AthleteNameCollection
        athleteName={athleteName}
        onNameChange={setAthleteName}
        onNext={handleAthleteNameNext}
        onBack={handleBackToSuccessStories}
      />
      </Suspense>
    );
  }

  if (currentStep === 'email') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <EmailCollection
        email={email}
        password={password}
        confirmPassword={confirmPassword}
        onEmailChange={setEmail}
        onPasswordChange={setPassword}
        onConfirmPasswordChange={setConfirmPassword}
        onNext={handleEmailNext}
        onBack={handleBackToAthleteName}
      />
      </Suspense>
    );
  }

  if (currentStep === 'phone') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PhoneCollection
        phone={phone}
        onPhoneChange={setPhone}
        onNext={handlePhoneNext}
        onBack={handleBackToEmail}
      />
      </Suspense>
    );
  }

  if (currentStep === 'referral-code') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ReferralCodeCollection
        referralCode={referralCode}
        onReferralCodeChange={setReferralCode}
        onNext={handleReferralCodeNext}
        onSkip={handleReferralCodeSkip}
        onBack={handleBackToPhone}
      />
      </Suspense>
    );
  }

  if (currentStep === 'player-position') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PlayerPositionSelection
        selectedPosition={selectedPosition}
        onPositionSelect={setSelectedPosition}
        onNext={handlePlayerPositionNext}
        onBack={handleBackToReferralCode}
      />
      </Suspense>
    );
  }

  if (currentStep === 'loading') {
    return (
      <LoadingScreen
        onComplete={handleFinalizeOnboarding}
      />
    );
  }

  if (currentStep === 'congratulations') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <CongratulationsScreen
          onNext={handleCongratulationsNext}
          onBack={handleBackToLoading}
        />
      </Suspense>
    );
  }

  if (currentStep === 'main-hub') {
    // Show different hub based on user type
    if (selectedUserType === 'clube') {
      return (
        <Suspense fallback={<SuspenseFallback />}>
          <ClubHub
            clubName={clubName || 'Clube'}
            currentView={clubCurrentView}
            onNavigateToCreatePeneira={() => setClubCurrentView('create-peneira')}
            onNavigateToScoutAthletes={() => setClubCurrentView('scout-athletes')}
            onNavigateToMarketplace={() => setCurrentStep('marketplace')}
            onNavigateToPeladas={() => setCurrentStep('peladas')}
            onNavigateToReports={() => setClubCurrentView('reports')}
            onNavigateToSettings={() => setClubCurrentView('club-settings')}
            onNavigateToTrainings={() => setCurrentStep('my-trainings')}
            onBackToMain={() => setClubCurrentView('main')}
          />
        </Suspense>
      );
    } else if (selectedUserType === 'empresario') {
      return (
        <Suspense fallback={<SuspenseFallback />}>
          <AgentHub
            agentName={agentName || 'Empresário'}
            currentView={agentCurrentView}
            onNavigateToScoutCenter={() => setAgentCurrentView('scout-center')}
            onNavigateToObservedAthletes={() => setAgentCurrentView('observed-athletes')}
            onNavigateToPublishOpportunities={() => setAgentCurrentView('publish-opportunities')}
            onNavigateToAgentRanking={() => setAgentCurrentView('agent-ranking')}
            onNavigateToAgentProfile={() => setAgentCurrentView('agent-profile')}
            onNavigateToAgentSettings={() => setAgentCurrentView('agent-settings')}
            onNavigateToAgentReports={() => setAgentCurrentView('agent-reports')}
            onNavigateToAgentContracts={() => setAgentCurrentView('agent-contracts')}
            onNavigateToMarketplace={() => setCurrentStep('marketplace')}
            onNavigateToPeladas={() => setCurrentStep('peladas')}
            onNavigateToTrainings={() => setCurrentStep('my-trainings')}
            onBackToMain={() => setAgentCurrentView('main')}
          />
        </Suspense>
      );
    } else {
      return (
        <Suspense fallback={<SuspenseFallback />}>
          <ErrorBoundary>
            <MainHub
              athleteName={profile?.full_name || athleteName || 'Atleta'}
              profile={profile}
              playerProfile={playerProfile}
              onThemeChange={(isDark) => setTheme(isDark ? 'dark' : 'light')}
              onNavigateToTrainings={() => setCurrentStep('my-trainings')}
              onNavigateToPeneiras={() => setCurrentStep('peneiras')}
              onNavigateToNutrition={() => setCurrentStep('nutrition')}
              onNavigateToMindset={() => setCurrentStep('mindset')}
              onNavigateToRanking={() => setCurrentStep('ranking')}
            onNavigateToMarketplace={() => setCurrentStep('marketplace')}
            onNavigateToPeladas={() => setCurrentStep('peladas')}
            onNavigateToProofHistory={() => setCurrentStep('proof-history')}
            onNavigateToChallenge28={() => setCurrentStep('challenge28')}
            onNavigateToSettings={() => setCurrentStep('settings')}
            onNavigateToProfile={() => setCurrentStep('profile')}
            setCurrentStep={setCurrentStep}
          />
        </ErrorBoundary>
        </Suspense>
      );
    }
  }


  if (currentStep === 'treino-do-dia') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
        <TreinoDoDiaScreen
          onComplete={() => setCurrentStep('my-trainings')}
          onBack={() => setCurrentStep('my-trainings')}
          isDarkMode={isDarkMode}
        />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <Challenge28Screen
        challengeId="upper-body-challenge"
        onBack={() => setCurrentStep('main-hub')}
        onDaySelect={(day) => {
          setSelectedChallengeId("upper-body-challenge");
          setSelectedChallengeDay(day);
          setCurrentStep('challenge28-day-detail');
        }}
        onSettings={() => setCurrentStep('challenge28-settings')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28-day-detail') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <Challenge28DayDetailScreen
        challengeId={selectedChallengeId}
        day={selectedChallengeDay}
        onBack={() => setCurrentStep(selectedChallengeId)}
        onStart={() => {
          setCurrentStep('challenge28-pre-roll');
        }}
        onSettings={() => setCurrentStep('challenge28-settings')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28-settings') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <Challenge28SettingsScreen
        onBack={() => setCurrentStep('challenge28-day-detail')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28-pre-roll') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <TrainingPreRollScreen
        categoryName={`Desafio 28 Dias - Dia ${selectedChallengeDay}`}
        categoryIcon="💪"
        videoUrl="https://drive.google.com/file/d/1_LO8q6RQ1zQsW0aKFWh-k9zHJBxdXfcg/view?usp=sharing"
        isDarkMode={isDarkMode}
        onStart={() => {
          setCurrentStep('challenge28-execution');
        }}
        onExit={() => setCurrentStep('challenge28-day-detail')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28-execution') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <Challenge28ExecutionScreen
        challengeId={selectedChallengeId}
        day={selectedChallengeDay}
        isDarkMode={isDarkMode}
        onComplete={() => setCurrentStep('challenge28-proof')}
        onExit={() => setCurrentStep('challenge28-day-detail')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'challenge28-proof') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <UniversalAntiCheatVerification
        sessionId={`challenge28-day${selectedChallengeDay}`}
        isDarkMode={isDarkMode}
        onComplete={(points) => {
          console.log('Challenge28 proof completed with points:', points);
          setCurrentStep('challenge28-day-detail');
        }}
        onSkip={() => {
          console.log('Challenge28 proof skipped');
          setCurrentStep('challenge28-day-detail');
        }}
      />
      </Suspense>
    );
  }

  if (currentStep === 'profile') {
    if (userLoading || !userId) {
      return (
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: theme.surface }}>
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: theme.accent }} />
        </div>
      );
    }
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PlayerProfileScreen
        userId={userId}
        isOwnProfile={true}
        onBack={() => setCurrentStep('main-hub')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'daily-progress') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <DailyProgressScreen
        onBack={() => setCurrentStep('main-hub')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'my-account') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <MyAccountScreen
        onBack={() => setCurrentStep('main-hub')}
        onNavigateToProfile={() => setCurrentStep('profile')}
        onNavigateToSettings={() => setCurrentStep('settings')}
        onNavigateToPrivacy={() => setCurrentStep('privacy')}
        onNavigateToSupport={() => setCurrentStep('support')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'my-trainings') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <MyTrainings
        selectedPosition={selectedPosition}
        onBack={() => setCurrentStep('main-hub')}
        onNavigateToTreinoDoDia={() => setCurrentStep('treino-do-dia')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'proof-history') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ProofHistoryScreen
        onBack={() => setCurrentStep('main-hub')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'settings') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <SettingsScreen
        onBack={() => setCurrentStep('main-hub')}
        onThemeChange={(isDark) => setTheme(isDark ? 'dark' : 'light')}
        onNavigateToPrivacy={() => setCurrentStep('privacy')}
        onNavigateToSupport={() => setCurrentStep('support')}
      />
      </Suspense>
    );
  }

  if (agentCurrentView === 'agent-settings') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentSettingsScreen
        onBack={() => setAgentCurrentView('main')}
        onNavigateToAgentProfile={() => setAgentCurrentView('agent-profile')}
        onNavigateToPrivacy={() => setCurrentStep('privacy')}
        onNavigateToSupport={() => setCurrentStep('support')}
        onNavigateToVerification={() => setCurrentStep('identity-verification')}
      />
      </Suspense>
    );
  }

  if (clubCurrentView === 'club-settings') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubSettingsScreen
        onBack={() => setClubCurrentView('main')}
        onNavigateToClubProfile={() => setClubCurrentView('club-profile')}
        onNavigateToPrivacy={() => setCurrentStep('privacy')}
        onNavigateToSupport={() => setCurrentStep('support')}
        onNavigateToVerification={() => setCurrentStep('identity-verification')}
      />
      </Suspense>
    );
  }

  if (currentStep === 'privacy') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PrivacyScreen
        onBack={() => {
          if (window.history.length > 1) {
            const previousStep = document.referrer.includes('settings') ? 'settings' : 'my-account';
            setCurrentStep(previousStep);
          } else {
            setCurrentStep('settings');
          }
        }}
      />
      </Suspense>
    );
  }

  if (currentStep === 'support') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <SupportScreen
        onBack={() => {
          if (agentCurrentView !== 'main') {
            setAgentCurrentView('agent-settings');
          } else if (clubCurrentView !== 'main') {
            setClubCurrentView('club-settings');
          } else {
            setCurrentStep('settings');
          }
        }}
      />
      </Suspense>
    );
  }

  if (currentStep === 'peneiras') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <PeneirasScreen
          onBack={() => setCurrentStep('main-hub')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'peladas') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <PeladasScreen
          onBack={() => setCurrentStep('main-hub')}
          userType={selectedUserType as 'atleta' | 'clube' | 'empresario'}
          userName={athleteName || clubName || agentName || 'Usuário'}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'nutrition') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <NutritionScreen
          onBack={() => setCurrentStep('main-hub')}
          onNavigateToDailyChallenge={() => setCurrentStep('daily-nutrition-challenge')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'daily-nutrition-challenge') {
    if (userLoading || !userId) {
      return (
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: theme.surface }}>
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: theme.accent }} />
        </div>
      );
    }
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <DailyNutritionChallenge
          userId={userId}
          onBack={() => setCurrentStep('nutrition')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'mindset') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <MindsetScreen
          onBack={() => setCurrentStep('main-hub')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'ranking') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <RankingScreen
          onBack={() => setCurrentStep('main-hub')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep === 'marketplace') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ErrorBoundary>
        <MarketplaceScreen
          onBack={() => setCurrentStep('main-hub')}
        />
      </ErrorBoundary>
      </Suspense>
    );
  }

  if (currentStep.startsWith('category-')) {
    const categoryId = currentStep.replace('category-', '');
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <TrainingCategoryScreen
        categoryId={categoryId}
        isDarkMode={isDarkMode}
        onBack={() => setCurrentStep('main-hub')}
        onStartTraining={(training) => {
          setCurrentTraining(training);
          setCurrentStep('training-execution');
        }}
      />
      </Suspense>
    );
  }

  if (currentStep === 'training-execution' && currentTraining) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-white'} flex items-center justify-center`}>
        <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'} text-center p-6`}>
          <h2 className="text-2xl font-bold mb-4">Treino em Execução</h2>
          <p className="text-lg mb-6">{currentTraining.title}</p>
          <button
            onClick={() => setCurrentStep('main-hub')}
            className="bg-blue-500 text-white px-6 py-3 rounded-2xl font-bold"
          >
            Voltar ao Hub
          </button>
        </div>
      </div>
    );
  }

  if (currentStep.startsWith('training-preroll-')) {
    const categoryId = currentStep.replace('training-preroll-', '');
    const categories = [
      {
        id: 'explosao',
        name: 'Explosão',
        icon: '💥',
        videoUrl: 'https://drive.google.com/file/d/1YQHsXMglC9yx1I8Jr3fo_2NVcJvzMk4E/view?usp=drive_link'
      },
      {
        id: 'forca',
        name: 'Força',
        icon: '💪',
        videoUrl: 'https://drive.google.com/file/d/1_LO8q6RQ1zQsW0aKFWh-k9zHJBxdXfcg/view?usp=sharing'
      },
      {
        id: 'coordenacao',
        name: 'Agilidade',
        icon: '🎯',
        videoUrl: 'https://drive.google.com/file/d/1YQHsXMglC9yx1I8Jr3fo_2NVcJvzMk4E/view?usp=drive_link'
      }
    ];
    const category = categories.find(c => c.id === categoryId);

    if (!category) return null;

    return (
      <TrainingPreRollScreen
        categoryName={category.name}
        categoryIcon={category.icon}
        videoUrl={category.videoUrl}
        isDarkMode={isDarkMode}
        onStart={() => {
          setWorkoutId(`workout_${Date.now()}`);
          setCurrentStep(`category-${categoryId}`);
        }}
        onExit={() => setCurrentStep('main-hub')}
      />
    );
  }

  if (currentStep === 'exercise-execution' && currentExercise) {
    return (
      <ExerciseExecutionScreen
        exercise={currentExercise.exercise}
        variant={currentExercise.variant}
        onComplete={() => {
          setCurrentStep('training-proof');
        }}
        onExit={() => setCurrentStep('main-hub')}
      />
    );
  }

  if (currentStep === 'training-proof') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <UniversalAntiCheatVerification
        sessionId={workoutId || `workout_${Date.now()}`}
        isDarkMode={isDarkMode}
        onComplete={(points) => {
          console.log('Training proof completed with points:', points);
          setWorkoutPoints(points);
          setCurrentStep('congratulations');
        }}
        onSkip={() => {
          console.log('Training proof skipped');
          setWorkoutPoints(50);
          setCurrentStep('congratulations');
        }}
      />
      </Suspense>
    );
  }

  // Club funnel screens
  if (currentStep === 'club-category') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubCategorySelection
        selectedCategory={selectedClubCategory}
        onCategorySelect={setSelectedClubCategory}
        onNext={handleClubCategoryNext}
        onBack={handleBackToClubCategory}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-name') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubNameCollection
        clubName={clubName}
        onNameChange={setClubName}
        onNext={handleClubNameNext}
        onBack={handleBackToClubName}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-address') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubAddressCollection
        clubAddress={clubAddress}
        onAddressChange={setClubAddress}
        onNext={handleClubAddressNext}
        onBack={handleBackToClubAddress}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-logo') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubLogoUpload
        clubLogo={clubLogo}
        onLogoChange={setClubLogo}
        onNext={handleClubLogoNext}
        onSkip={handleClubLogoSkip}
        onBack={handleBackToClubLogo}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-responsible') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubResponsibleCollection
        responsibleName={responsibleName}
        onNameChange={setResponsibleName}
        onNext={handleClubResponsibleNext}
        onBack={handleBackToClubResponsible}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-email') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <EmailCollection
        email={email}
        onEmailChange={setEmail}
        onNext={handleClubEmailNext}
        onBack={handleBackToClubEmail}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-position') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubPositionSelection
        selectedPosition={responsiblePosition}
        onPositionSelect={setResponsiblePosition}
        onNext={handleClubPositionNext}
        onBack={handleBackToClubPosition}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-phone') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PhoneCollection
        phone={phone}
        onPhoneChange={setPhone}
        onNext={handleClubPhoneNext}
        onBack={handleBackToClubPhone}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-document') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubDocumentUpload
        clubDocument={clubDocument}
        onDocumentChange={setClubDocument}
        onNext={handleClubDocumentNext}
        onSkip={handleClubDocumentSkip}
        onBack={handleBackToClubDocument}
      />
      </Suspense>
    );
  }

  if (currentStep === 'club-agreement') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <ClubAgreementScreen
        onNext={handleClubAgreementNext}
        onBack={handleBackToClubAgreement}
      />
      </Suspense>
    );
  }

  // Agent funnel screens
  if (currentStep === 'agent-name') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentNameCollection
        agentName={agentName}
        onNameChange={setAgentName}
        onNext={handleAgentNameNext}
        onBack={handleBackToAgentName}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-company') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentCompanyCollection
        companyName={companyName}
        onCompanyChange={setCompanyName}
        onNext={handleAgentCompanyNext}
        onSkip={handleAgentCompanySkip}
        onBack={handleBackToAgentCompany}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-address') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentAddressCollection
        agentAddress={agentAddress}
        onAddressChange={setAgentAddress}
        onNext={handleAgentAddressNext}
        onBack={handleBackToAgentAddress}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-phone') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <PhoneCollection
        phone={phone}
        onPhoneChange={setPhone}
        onNext={handleAgentPhoneNext}
        onBack={handleBackToAgentPhone}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-credentials') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentCredentialsCollection
        email={email}
        password={agentPassword}
        confirmPassword={agentConfirmPassword}
        onEmailChange={setEmail}
        onPasswordChange={setAgentPassword}
        onConfirmPasswordChange={setAgentConfirmPassword}
        onNext={handleAgentCredentialsNext}
        onBack={handleBackToAgentCredentials}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-social') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentSocialLinksCollection
        socialLinks={socialLinks}
        onSocialLinksChange={setSocialLinks}
        onNext={handleAgentSocialNext}
        onSkip={handleAgentSocialSkip}
        onBack={handleBackToAgentSocial}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-experience') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentExperienceSelection
        athletesRepresented={athletesRepresented}
        yearsExperience={yearsExperience}
        onAthletesChange={setAthletesRepresented}
        onYearsChange={setYearsExperience}
        onNext={handleAgentExperienceNext}
        onBack={handleBackToAgentExperience}
      />
      </Suspense>
    );
  }

  if (currentStep === 'agent-license') {
    return (
      <Suspense fallback={<SuspenseFallback />}>
      <AgentLicenseUpload
        hasLicense={hasLicense}
        licenseDocument={licenseDocument}
        onLicenseChange={setHasLicense}
        onDocumentChange={setLicenseDocument}
        onNext={handleAgentLicenseNext}
        onBack={handleBackToAgentLicense}
      />
      </Suspense>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex flex-col">
      <div className="pt-12"></div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        {/* Main Image */}
        <div className="w-full max-w-md mb-8">
          <img
            src="/Vitrine pro Sem fundo copy.png"
            alt="Vitrine Pro"
            className="w-full h-auto object-contain"
          />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col items-center text-center max-w-sm">
          <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">
            {slides[currentSlide].title}
          </h1>
          
          <p className="text-gray-600 text-lg mb-8 leading-relaxed">
            {slides[currentSlide].subtitle}
          </p>

          {/* Page Indicators */}
          <div className="flex space-x-2 mb-12">
            {[0, 1, 2].map((index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentSlide ? 'bg-green-500 w-6' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <div className="w-full max-w-sm space-y-6 pb-8">
          <button 
            onClick={handleStartQuiz}
            className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg shadow-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
          >
            {slides[currentSlide].buttonText}
          </button>
          
          <p className="text-center text-gray-600">
            Já tem uma conta? 
            <button 
              onClick={handleLogin}
              className="text-green-600 font-medium ml-1 hover:text-green-700 transition-colors"
            >
              Entre aqui
            </button>
          </p>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}

export default App;