import { supabase } from '../lib/supabase';
import { realtimeService } from './realtimeService';

export interface RankingPlayer {
  user_id: string;
  name: string;
  total_points: number;
  position_1: string;
  city: string;
  state: string;
  avatar_url?: string;
  age?: number;
}

export interface RankingUpdate {
  user_id: string;
  old_points: number;
  new_points: number;
  change: number;
  timestamp: string;
}

class RankingService {
  private rankingCache: RankingPlayer[] = [];
  private lastUpdate: Date | null = null;

  async getGlobalRanking(limit: number = 100): Promise<RankingPlayer[]> {
    const { data, error } = await supabase
      .from('player_profiles')
      .select('user_id, name, total_points, position_1, city, state, avatar_url, birth_date')
      .order('total_points', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching ranking:', error);
      return [];
    }

    const players = data.map(player => ({
      ...player,
      age: player.birth_date ? this.calculateAge(player.birth_date) : undefined
    }));

    this.rankingCache = players;
    this.lastUpdate = new Date();

    return players;
  }

  async getWeeklyRanking(limit: number = 50): Promise<RankingPlayer[]> {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const { data, error } = await supabase
      .rpc('get_weekly_ranking', {
        since_date: oneWeekAgo.toISOString(),
        result_limit: limit
      });

    if (error) {
      console.error('Error fetching weekly ranking:', error);
      return this.getGlobalRanking(limit);
    }

    return data || [];
  }

  async getRankingByPosition(position: string, limit: number = 50): Promise<RankingPlayer[]> {
    const { data, error } = await supabase
      .from('player_profiles')
      .select('user_id, name, total_points, position_1, city, state, avatar_url, birth_date')
      .or(`position_1.eq.${position},position_2.eq.${position}`)
      .order('total_points', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching ranking by position:', error);
      return [];
    }

    return data.map(player => ({
      ...player,
      age: player.birth_date ? this.calculateAge(player.birth_date) : undefined
    }));
  }

  async getRankingByState(state: string, limit: number = 50): Promise<RankingPlayer[]> {
    const { data, error } = await supabase
      .from('player_profiles')
      .select('user_id, name, total_points, position_1, city, state, avatar_url, birth_date')
      .eq('state', state)
      .order('total_points', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching ranking by state:', error);
      return [];
    }

    return data.map(player => ({
      ...player,
      age: player.birth_date ? this.calculateAge(player.birth_date) : undefined
    }));
  }

  async getUserRank(userId: string): Promise<{ rank: number; total: number; player: RankingPlayer | null }> {
    const { data: allPlayers, error } = await supabase
      .from('player_profiles')
      .select('user_id, name, total_points, position_1, city, state, avatar_url, birth_date')
      .order('total_points', { ascending: false });

    if (error || !allPlayers) {
      return { rank: 0, total: 0, player: null };
    }

    const rank = allPlayers.findIndex(p => p.user_id === userId) + 1;
    const player = allPlayers.find(p => p.user_id === userId);

    return {
      rank,
      total: allPlayers.length,
      player: player ? {
        ...player,
        age: player.birth_date ? this.calculateAge(player.birth_date) : undefined
      } : null
    };
  }

  subscribeToRankingUpdates(callback: (update: RankingUpdate) => void) {
    return realtimeService.subscribeToRanking((payload) => {
      if (payload.eventType === 'UPDATE') {
        const oldRecord = payload.old;
        const newRecord = payload.new;

        if (oldRecord.total_points !== newRecord.total_points) {
          callback({
            user_id: newRecord.user_id,
            old_points: oldRecord.total_points,
            new_points: newRecord.total_points,
            change: newRecord.total_points - oldRecord.total_points,
            timestamp: new Date().toISOString()
          });

          const playerIndex = this.rankingCache.findIndex(p => p.user_id === newRecord.user_id);
          if (playerIndex !== -1) {
            this.rankingCache[playerIndex].total_points = newRecord.total_points;
            this.rankingCache.sort((a, b) => b.total_points - a.total_points);
          }
        }
      }
    });
  }

  async updatePlayerPoints(userId: string, pointsToAdd: number): Promise<void> {
    const { data: profile, error: fetchError } = await supabase
      .from('player_profiles')
      .select('total_points')
      .eq('user_id', userId)
      .single();

    if (fetchError) {
      throw new Error('Failed to fetch player profile');
    }

    const newPoints = profile.total_points + pointsToAdd;

    const { error: updateError } = await supabase
      .from('player_profiles')
      .update({ total_points: newPoints })
      .eq('user_id', userId);

    if (updateError) {
      throw new Error('Failed to update player points');
    }
  }

  getCachedRanking(): RankingPlayer[] {
    return this.rankingCache;
  }

  getLastUpdateTime(): Date | null {
    return this.lastUpdate;
  }

  private calculateAge(birthDate: string): number {
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }

    return age;
  }

  async getTopPlayersByFormation(): Promise<{
    goalkeeper: RankingPlayer | null;
    defenders: RankingPlayer[];
    midfielders: RankingPlayer[];
    forwards: RankingPlayer[];
  }> {
    const goalkeeper = await this.getRankingByPosition('Goleiro', 1);
    const defenders = await this.getRankingByPosition('Zagueiro', 4);
    const laterals = await this.getRankingByPosition('Lateral', 2);
    const midfielders = await this.getRankingByPosition('Meio-campo', 3);
    const forwards = await this.getRankingByPosition('Atacante', 3);

    return {
      goalkeeper: goalkeeper[0] || null,
      defenders: [...defenders, ...laterals].slice(0, 4),
      midfielders: midfielders.slice(0, 3),
      forwards: forwards.slice(0, 3)
    };
  }

  async getStatsOverview(): Promise<{
    totalPlayers: number;
    totalPoints: number;
    averagePoints: number;
    topState: string;
  }> {
    const { data: stats, error } = await supabase
      .rpc('get_ranking_stats');

    if (error) {
      console.error('Error fetching stats:', error);
      return {
        totalPlayers: 0,
        totalPoints: 0,
        averagePoints: 0,
        topState: 'SP'
      };
    }

    return stats || {
      totalPlayers: 0,
      totalPoints: 0,
      averagePoints: 0,
      topState: 'SP'
    };
  }
}

export const rankingService = new RankingService();
