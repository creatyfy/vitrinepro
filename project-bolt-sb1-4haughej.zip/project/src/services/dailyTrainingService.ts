import { supabase } from '../lib/supabase';

export interface DailyTrainingStatus {
  canStart: boolean;
  isCompleted: boolean;
  timeUntilNext: number;
  streak: number;
  todaysTraining: any | null;
  message?: string;
}

export interface TrainingHistory {
  training_date: string;
  status: string;
  completed_at: string | null;
  total_exercises: number;
  intensity_level: string;
}

export async function checkDailyTrainingStatus(userId: string): Promise<DailyTrainingStatus> {
  try {
    const today = new Date().toISOString().split('T')[0];

    const { data: todaysTraining, error: trainingError } = await supabase
      .from('daily_trainings')
      .select('*')
      .eq('user_id', userId)
      .eq('training_date', today)
      .maybeSingle();

    if (trainingError) {
      console.error('Error checking daily training status:', trainingError);
    }

    const isCompleted = todaysTraining?.status === 'completed';

    const { data: timeData } = await supabase.rpc('get_time_until_next_training');
    const timeUntilNext = timeData || 0;

    const { data: streakData } = await supabase.rpc('get_user_training_streak', {
      p_user_id: userId
    });
    const streak = streakData || 0;

    return {
      canStart: !isCompleted,
      isCompleted,
      timeUntilNext,
      streak,
      todaysTraining,
      message: isCompleted
        ? 'Você já completou o treino de hoje! Volte amanhã para um novo desafio.'
        : undefined
    };
  } catch (error) {
    console.error('Error in checkDailyTrainingStatus:', error);
    return {
      canStart: true,
      isCompleted: false,
      timeUntilNext: 0,
      streak: 0,
      todaysTraining: null
    };
  }
}

export async function validateTrainingCompletion(userId: string, trainingId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc('validate_daily_training_completion', {
      p_user_id: userId,
      p_training_id: trainingId
    });

    if (error) {
      console.error('Error validating training completion:', error);
      return false;
    }

    return data === true;
  } catch (error) {
    console.error('Exception in validateTrainingCompletion:', error);
    return false;
  }
}

export async function getRecentTrainingHistory(userId: string): Promise<TrainingHistory[]> {
  try {
    const { data, error } = await supabase.rpc('get_recent_training_history', {
      p_user_id: userId
    });

    if (error) {
      console.error('Error fetching training history:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Exception in getRecentTrainingHistory:', error);
    return [];
  }
}

export async function completeTraining(trainingId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return { success: false, error: 'Usuário não autenticado' };
    }

    const isValid = await validateTrainingCompletion(user.id, trainingId);

    if (!isValid) {
      return {
        success: false,
        error: 'Você já completou um treino hoje. Apenas um treino por dia é permitido.'
      };
    }

    const { error } = await supabase
      .from('daily_trainings')
      .update({
        status: 'completed',
        completed_at: new Date().toISOString()
      })
      .eq('id', trainingId)
      .eq('user_id', user.id);

    if (error) {
      console.error('Error completing training:', error);

      if (error.message.includes('already completed')) {
        return {
          success: false,
          error: 'Você já completou um treino hoje. Apenas um treino por dia é permitido.'
        };
      }

      return { success: false, error: 'Erro ao completar treino. Tente novamente.' };
    }

    return { success: true };
  } catch (error: any) {
    console.error('Exception in completeTraining:', error);

    if (error?.message?.includes('already completed')) {
      return {
        success: false,
        error: 'Você já completou um treino hoje. Apenas um treino por dia é permitido.'
      };
    }

    return { success: false, error: 'Erro ao completar treino. Tente novamente.' };
  }
}

export function formatTimeUntilNext(seconds: number): string {
  if (seconds <= 0) {
    return 'Disponível agora';
  }

  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (hours > 0) {
    return `${hours}h ${minutes}min`;
  }

  return `${minutes}min`;
}

export function getStreakMessage(streak: number): string {
  if (streak === 0) {
    return 'Comece sua sequência hoje!';
  } else if (streak === 1) {
    return 'Primeira conquista! Continue amanhã!';
  } else if (streak < 7) {
    return `${streak} dias seguidos! Continue assim!`;
  } else if (streak < 30) {
    return `${streak} dias de dedicação! Você é incrível!`;
  } else {
    return `${streak} dias consecutivos! Campeão absoluto!`;
  }
}
