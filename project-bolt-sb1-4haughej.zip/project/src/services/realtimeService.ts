import { supabase } from '../lib/supabase';
import { RealtimeChannel, RealtimePostgresChangesPayload } from '@supabase/supabase-js';

type SubscriptionCallback<T = any> = (payload: T) => void;

class RealtimeService {
  private channels: Map<string, RealtimeChannel> = new Map();
  private callbacks: Map<string, Set<SubscriptionCallback>> = new Map();

  subscribeToPeneiras(callback: SubscriptionCallback) {
    const channelName = 'peneiras_realtime';

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'peneiras'
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToPeneiraRegistrations(peneiraId: string, callback: SubscriptionCallback) {
    const channelName = `peneira_registrations_${peneiraId}`;

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'peneira_registrations',
            filter: `peneira_id=eq.${peneiraId}`
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToRanking(callback: SubscriptionCallback) {
    const channelName = 'ranking_realtime';

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'player_profiles'
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToNotifications(userId: string, callback: SubscriptionCallback) {
    const channelName = `notifications_${userId}`;

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'real_time_notifications',
            filter: `user_id=eq.${userId}`
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToMessages(userId: string, callback: SubscriptionCallback) {
    const channelName = `messages_${userId}`;

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'chat_messages',
            filter: `receiver_id=eq.${userId}`
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToProducts(callback: SubscriptionCallback) {
    const channelName = 'products_realtime';

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'marketplace_products'
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToOrders(userId: string, callback: SubscriptionCallback) {
    const channelName = `orders_${userId}`;

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'marketplace_orders',
            filter: `user_id=eq.${userId}`
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  subscribeToCommunityAchievements(callback: SubscriptionCallback) {
    const channelName = 'achievements_realtime';

    if (!this.channels.has(channelName)) {
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'community_achievements'
          },
          (payload: RealtimePostgresChangesPayload<any>) => {
            this.notifyCallbacks(channelName, payload);
          }
        )
        .subscribe();

      this.channels.set(channelName, channel);
      this.callbacks.set(channelName, new Set());
    }

    const callbacks = this.callbacks.get(channelName)!;
    callbacks.add(callback);

    return () => {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.unsubscribe(channelName);
      }
    };
  }

  private notifyCallbacks(channelName: string, payload: any) {
    const callbacks = this.callbacks.get(channelName);
    if (callbacks) {
      callbacks.forEach(callback => callback(payload));
    }
  }

  private unsubscribe(channelName: string) {
    const channel = this.channels.get(channelName);
    if (channel) {
      supabase.removeChannel(channel);
      this.channels.delete(channelName);
      this.callbacks.delete(channelName);
    }
  }

  unsubscribeAll() {
    this.channels.forEach((channel) => {
      supabase.removeChannel(channel);
    });
    this.channels.clear();
    this.callbacks.clear();
  }
}

export const realtimeService = new RealtimeService();

export async function markNotificationAsRead(notificationId: string) {
  const { error } = await supabase
    .from('real_time_notifications')
    .update({ is_read: true })
    .eq('id', notificationId);

  if (error) {
    console.error('Error marking notification as read:', error);
  }
}

export async function getUnreadNotificationCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('real_time_notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false);

  if (error) {
    console.error('Error getting unread count:', error);
    return 0;
  }

  return count || 0;
}

export async function registerForPeneira(peneiraId: string, userId: string) {
  const { data: peneira } = await supabase
    .from('peneiras')
    .select('*')
    .eq('id', peneiraId)
    .single();

  if (!peneira) {
    throw new Error('Peneira não encontrada');
  }

  if (peneira.current_participants >= peneira.max_participants) {
    throw new Error('Peneira com vagas esgotadas');
  }

  const { data, error } = await supabase
    .from('peneira_registrations')
    .insert({
      peneira_id: peneiraId,
      user_id: userId,
      status: peneira.fee_amount > 0 ? 'pending' : 'confirmed',
      payment_status: peneira.fee_amount > 0 ? 'pending' : 'paid',
      confirmed_at: peneira.fee_amount > 0 ? null : new Date().toISOString()
    })
    .select()
    .single();

  if (error) {
    if (error.code === '23505') {
      throw new Error('Você já está inscrito nesta peneira');
    }
    throw error;
  }

  return data;
}

export async function cancelPeneiraRegistration(registrationId: string) {
  const { error } = await supabase
    .from('peneira_registrations')
    .update({ status: 'cancelled' })
    .eq('id', registrationId);

  if (error) {
    throw error;
  }
}
