import { supabase } from '../lib/supabase';
import { convertDriveUrlToEmbed } from '../utils/driveVideoUtils';

export interface Exercise {
  id: string;
  name: string;
  category: string;
  video_url: string;
  video_embed_url: string | null;
  description: string;
  duration: number;
  sets: number;
  reps: string;
  difficulty: string;
  created_at: string;
  updated_at: string;
}

export const getExercisesByCategory = async (category: string): Promise<Exercise[]> => {
  try {
    const { data, error } = await supabase
      .from('exercises')
      .select('*')
      .eq('category', category)
      .order('name');

    if (error) {
      console.error('Error fetching exercises:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Error in getExercisesByCategory:', error);
    return [];
  }
};

export const getExerciseById = async (id: string): Promise<Exercise | null> => {
  try {
    const { data, error } = await supabase
      .from('exercises')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching exercise:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Error in getExerciseById:', error);
    return null;
  }
};

export const getAllCategories = async (): Promise<string[]> => {
  try {
    const { data, error } = await supabase
      .from('exercises')
      .select('category')
      .order('category');

    if (error) {
      console.error('Error fetching categories:', error);
      return [];
    }

    const uniqueCategories = [...new Set(data.map(item => item.category))];
    return uniqueCategories;
  } catch (error) {
    console.error('Error in getAllCategories:', error);
    return [];
  }
};

export const updateExerciseVideoEmbedUrl = async (exerciseId: string): Promise<boolean> => {
  try {
    const exercise = await getExerciseById(exerciseId);
    if (!exercise) return false;

    const embedUrl = convertDriveUrlToEmbed(exercise.video_url);

    const { error } = await supabase
      .from('exercises')
      .update({ video_embed_url: embedUrl })
      .eq('id', exerciseId);

    if (error) {
      console.error('Error updating video embed URL:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error in updateExerciseVideoEmbedUrl:', error);
    return false;
  }
};

export const batchUpdateVideoEmbedUrls = async (): Promise<void> => {
  try {
    const { data: exercises, error } = await supabase
      .from('exercises')
      .select('id, video_url')
      .is('video_embed_url', null);

    if (error) {
      console.error('Error fetching exercises without embed URL:', error);
      return;
    }

    if (!exercises || exercises.length === 0) {
      console.log('All exercises already have embed URLs');
      return;
    }

    for (const exercise of exercises) {
      const embedUrl = convertDriveUrlToEmbed(exercise.video_url);
      await supabase
        .from('exercises')
        .update({ video_embed_url: embedUrl })
        .eq('id', exercise.id);
    }

    console.log(`Updated ${exercises.length} exercises with embed URLs`);
  } catch (error) {
    console.error('Error in batchUpdateVideoEmbedUrls:', error);
  }
};

export const searchExercises = async (searchTerm: string): Promise<Exercise[]> => {
  try {
    const { data, error } = await supabase
      .from('exercises')
      .select('*')
      .ilike('name', `%${searchTerm}%`)
      .order('name');

    if (error) {
      console.error('Error searching exercises:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Error in searchExercises:', error);
    return [];
  }
};

export const getExerciseVideoUrl = (exercise: Exercise): string => {
  return exercise.video_embed_url || convertDriveUrlToEmbed(exercise.video_url);
};
