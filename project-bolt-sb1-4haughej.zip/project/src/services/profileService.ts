import { supabase } from '../lib/supabase';

export interface ProfileData {
  id?: string;
  email?: string;
  full_name?: string;
  phone?: string;
  birth_date?: string;
  gender?: string;
  height?: number;
  weight?: number;
  user_type?: 'athlete' | 'club' | 'agent';
  player_position?: string;
  goals?: string[];
  objective?: string;
  obstacles?: string[];
  training_frequency?: string;
  referral_source?: string;
  referral_code?: string;
  created_at?: string;
  updated_at?: string;
}

export interface PlayerProfileData {
  user_id?: string;
  name?: string;
  birth_date?: string;
  gender?: string;
  height_cm?: number;
  weight_kg?: number;
  position_1?: string;
  position_2?: string;
  city?: string;
  state?: string;
  country?: string;
  quiz_completed?: boolean;
}

export const profileService = {
  async getProfile(userId: string): Promise<ProfileData | null> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
  },

  async updateProfile(userId: string, profileData: Partial<ProfileData>): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          ...profileData,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating profile:', error);
      return false;
    }
  },

  async getPlayerProfile(userId: string): Promise<PlayerProfileData | null> {
    try {
      const { data, error } = await supabase
        .from('player_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching player profile:', error);
      return null;
    }
  },

  async syncQuizDataToProfile(userId: string, quizData: {
    name?: string;
    birth_date?: string;
    gender?: string;
    height?: number;
    weight?: number;
    position?: string;
    city?: string;
    state?: string;
    country?: string;
  }): Promise<boolean> {
    try {
      const birthDate = quizData.birth_date
        ? this.convertBirthDateToISO(quizData.birth_date)
        : null;

      const { error } = await supabase.rpc('upsert_profile_from_quiz', {
        p_user_id: userId,
        p_name: quizData.name || null,
        p_birth_date: birthDate,
        p_gender: quizData.gender || null,
        p_height_cm: quizData.height || null,
        p_weight_kg: quizData.weight || null,
        p_position: quizData.position || null,
        p_city: quizData.city || null,
        p_state: quizData.state || null,
        p_country: quizData.country || 'Brasil'
      });

      if (error) {
        console.error('Error syncing quiz data:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in syncQuizDataToProfile:', error);
      return false;
    }
  },

  async completeOnboarding(userId: string, data: {
    full_name: string;
    phone: string;
    birth_date: string;
    gender: string;
    height: number;
    weight: number;
    user_type: 'athlete' | 'club' | 'agent';
    player_position?: string;
    goals?: string[];
    objective?: string;
    obstacles?: string[];
    training_frequency?: string;
    referral_source?: string;
    referral_code?: string;
  }): Promise<boolean> {
    try {
      const birthDate = this.convertBirthDateToISO(data.birth_date);

      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          full_name: data.full_name,
          phone: data.phone,
          birth_date: birthDate,
          gender: data.gender,
          height: data.height,
          weight: data.weight,
          user_type: data.user_type,
          player_position: data.player_position,
          goals: data.goals,
          objective: data.objective,
          obstacles: data.obstacles,
          training_frequency: data.training_frequency,
          referral_source: data.referral_source,
          referral_code: data.referral_code,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId);

      if (profileError) throw profileError;

      if (data.user_type === 'athlete' && data.player_position) {
        const success = await this.syncQuizDataToProfile(userId, {
          name: data.full_name,
          birth_date: data.birth_date,
          gender: data.gender,
          height: data.height,
          weight: data.weight,
          position: data.player_position,
          country: 'Brasil'
        });

        if (!success) {
          console.warn('Failed to sync player profile, but main profile was updated');
        }
      }

      return true;
    } catch (error) {
      console.error('Error completing onboarding:', error);
      return false;
    }
  },

  convertBirthDateToISO(birthDate: string): string {
    if (birthDate.includes('-')) {
      return birthDate;
    }

    const parts = birthDate.split('/');
    if (parts.length === 3) {
      const [day, month, year] = parts;
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    return birthDate;
  },

  formatBirthDateForDisplay(isoDate: string): string {
    if (isoDate.includes('/')) {
      return isoDate;
    }

    const parts = isoDate.split('-');
    if (parts.length === 3) {
      const [year, month, day] = parts;
      return `${day}/${month}/${year}`;
    }
    return isoDate;
  },
};
