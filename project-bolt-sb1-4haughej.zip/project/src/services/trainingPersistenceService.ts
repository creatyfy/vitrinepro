import { supabase } from '../lib/supabase';

export interface TrainingSession {
  id?: string;
  user_id?: string;
  training_type: 'classic' | 'daily' | 'preparation' | 'strengthening' | 'challenge28';
  training_id: string;
  started_at?: string;
  last_updated_at?: string;
  completed_at?: string | null;
  status: 'active' | 'paused' | 'completed' | 'abandoned';
  total_exercises: number;
  completed_exercises: number;
  session_data?: any;
}

export interface TrainingExercise {
  id?: string;
  session_id: string;
  exercise_id: string;
  exercise_name: string;
  exercise_index: number;
  phase: 'prep' | 'active' | 'rest' | 'completed';
  current_set: number;
  total_sets: number;
  remaining_time: number;
  started_at?: string;
  completed_at?: string | null;
  exercise_data?: any;
}

export interface TrainingPreferences {
  user_id?: string;
  music_enabled: boolean;
  fullscreen_enabled: boolean;
  video_quality: '720p' | '1080p' | '1440p' | '4k';
  video_speed: number;
  haptic_feedback: boolean;
  default_rest_time: number;
  default_prep_time: number;
}

export async function createTrainingSession(session: TrainingSession): Promise<string | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('training_sessions')
      .insert({
        user_id: user.id,
        training_type: session.training_type,
        training_id: session.training_id,
        total_exercises: session.total_exercises,
        completed_exercises: session.completed_exercises,
        status: session.status,
        session_data: session.session_data || {}
      })
      .select('id')
      .maybeSingle();

    if (error) {
      console.error('Error creating training session:', error);
      return null;
    }

    return data?.id || null;
  } catch (error) {
    console.error('Exception creating training session:', error);
    return null;
  }
}

export async function updateTrainingSession(
  sessionId: string,
  updates: Partial<TrainingSession>
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('training_sessions')
      .update({
        ...updates,
        last_updated_at: new Date().toISOString()
      })
      .eq('id', sessionId);

    if (error) {
      console.error('Error updating training session:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Exception updating training session:', error);
    return false;
  }
}

export async function getActiveTrainingSession(
  trainingType: string,
  trainingId: string
): Promise<TrainingSession | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('training_sessions')
      .select('*')
      .eq('user_id', user.id)
      .eq('training_type', trainingType)
      .eq('training_id', trainingId)
      .eq('status', 'active')
      .order('started_at', { ascending: false })
      .maybeSingle();

    if (error) {
      console.error('Error getting active training session:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Exception getting active training session:', error);
    return null;
  }
}

export async function saveExerciseProgress(exercise: TrainingExercise): Promise<boolean> {
  try {
    const { data: existing } = await supabase
      .from('training_session_exercises')
      .select('id')
      .eq('session_id', exercise.session_id)
      .eq('exercise_index', exercise.exercise_index)
      .maybeSingle();

    if (existing) {
      const { error } = await supabase
        .from('training_session_exercises')
        .update({
          phase: exercise.phase,
          current_set: exercise.current_set,
          remaining_time: exercise.remaining_time,
          completed_at: exercise.phase === 'completed' ? new Date().toISOString() : null,
          exercise_data: exercise.exercise_data
        })
        .eq('id', existing.id);

      if (error) {
        console.error('Error updating exercise progress:', error);
        return false;
      }
    } else {
      const { error } = await supabase
        .from('training_session_exercises')
        .insert({
          session_id: exercise.session_id,
          exercise_id: exercise.exercise_id,
          exercise_name: exercise.exercise_name,
          exercise_index: exercise.exercise_index,
          phase: exercise.phase,
          current_set: exercise.current_set,
          total_sets: exercise.total_sets,
          remaining_time: exercise.remaining_time,
          exercise_data: exercise.exercise_data || {}
        });

      if (error) {
        console.error('Error inserting exercise progress:', error);
        return false;
      }
    }

    return true;
  } catch (error) {
    console.error('Exception saving exercise progress:', error);
    return false;
  }
}

export async function getSessionExercises(sessionId: string): Promise<TrainingExercise[]> {
  try {
    const { data, error } = await supabase
      .from('training_session_exercises')
      .select('*')
      .eq('session_id', sessionId)
      .order('exercise_index', { ascending: true });

    if (error) {
      console.error('Error getting session exercises:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Exception getting session exercises:', error);
    return [];
  }
}

export async function getUserPreferences(): Promise<TrainingPreferences | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('training_preferences')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (error && error.code !== 'PGRST116') {
      console.error('Error getting user preferences:', error);
      return null;
    }

    if (!data) {
      const defaultPrefs: TrainingPreferences = {
        music_enabled: true,
        fullscreen_enabled: false,
        video_quality: '1080p',
        video_speed: 1.0,
        haptic_feedback: true,
        default_rest_time: 10,
        default_prep_time: 10
      };

      await saveUserPreferences(defaultPrefs);
      return defaultPrefs;
    }

    return data;
  } catch (error) {
    console.error('Exception getting user preferences:', error);
    return null;
  }
}

export async function saveUserPreferences(prefs: Partial<TrainingPreferences>): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('training_preferences')
      .upsert({
        user_id: user.id,
        ...prefs,
        updated_at: new Date().toISOString()
      });

    if (error) {
      console.error('Error saving user preferences:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Exception saving user preferences:', error);
    return false;
  }
}

export async function completeTrainingSession(sessionId: string): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { data: session, error: sessionError } = await supabase
      .from('training_sessions')
      .select('*')
      .eq('id', sessionId)
      .maybeSingle();

    if (sessionError || !session) {
      console.error('Error fetching training session:', sessionError);
      return false;
    }

    const { error: updateError } = await supabase
      .from('training_sessions')
      .update({
        status: 'completed',
        completed_at: new Date().toISOString(),
        last_updated_at: new Date().toISOString()
      })
      .eq('id', sessionId);

    if (updateError) {
      console.error('Error completing training session:', updateError);
      return false;
    }

    const durationMinutes = Math.round(
      (new Date().getTime() - new Date(session.started_at).getTime()) / 60000
    );

    const pointsEarned = session.completed_exercises * 10;

    await supabase
      .from('training_history')
      .insert({
        user_id: user.id,
        training_name: session.training_id,
        training_type: session.training_type,
        date: new Date().toISOString(),
        completed: true,
        points_earned: pointsEarned,
        duration_minutes: durationMinutes
      });

    const { data: progress } = await supabase
      .from('player_progress')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    const today = new Date().toISOString().split('T')[0];
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const { data: recentHistory } = await supabase
      .from('training_history')
      .select('date')
      .eq('user_id', user.id)
      .eq('completed', true)
      .gte('date', thirtyDaysAgo);

    const uniqueDays7 = new Set(
      (recentHistory || [])
        .filter(h => h.date >= sevenDaysAgo)
        .map(h => h.date.split('T')[0])
    ).size;

    const uniqueDays30 = new Set(
      (recentHistory || []).map(h => h.date.split('T')[0])
    ).size;

    const { data: lastTraining } = await supabase
      .from('training_history')
      .select('date')
      .eq('user_id', user.id)
      .eq('completed', true)
      .order('date', { ascending: false })
      .limit(2);

    let newStreak = 1;
    if (lastTraining && lastTraining.length > 1) {
      const lastDate = new Date(lastTraining[1].date).toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      if (lastDate === yesterday || lastDate === today) {
        newStreak = (progress?.streak_current || 0) + 1;
      }
    }

    const newBestStreak = Math.max(newStreak, progress?.streak_best || 0);

    if (progress) {
      await supabase
        .from('player_progress')
        .update({
          days_trained_7d: uniqueDays7,
          days_trained_30d: uniqueDays30,
          total_minutes: (progress.total_minutes || 0) + durationMinutes,
          total_trainings: (progress.total_trainings || 0) + 1,
          streak_current: newStreak,
          streak_best: newBestStreak,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);
    } else {
      await supabase
        .from('player_progress')
        .insert({
          user_id: user.id,
          days_trained_7d: uniqueDays7,
          days_trained_30d: uniqueDays30,
          total_minutes: durationMinutes,
          total_trainings: 1,
          streak_current: newStreak,
          streak_best: newBestStreak
        });
    }

    return true;
  } catch (error) {
    console.error('Exception completing training session:', error);
    return false;
  }
}

export async function abandonTrainingSession(sessionId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('training_sessions')
      .update({
        status: 'abandoned',
        last_updated_at: new Date().toISOString()
      })
      .eq('id', sessionId);

    if (error) {
      console.error('Error abandoning training session:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Exception abandoning training session:', error);
    return false;
  }
}
