export interface ThemeTokens {
  background: string;
  surface: string;
  surfaceAlt: string;
  surfaceVariant: string;
  primary: string;
  primaryVariant: string;
  secondary: string;
  accent: string;
  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  border: string;
  borderLight: string;
  error: string;
  success: string;
  warning: string;
  info: string;
  shadow: string;
  shadowLight: string;
  overlay: string;
}

export const lightTheme: ThemeTokens = {
  background: '#FFFFFF',
  surface: '#F9FAFB',
  surfaceAlt: '#FFFFFF',
  surfaceVariant: '#F3F4F6',
  primary: '#111827',
  primaryVariant: '#1F2937',
  secondary: '#6B7280',
  accent: '#F97316',
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',
  border: '#E5E7EB',
  borderLight: '#F3F4F6',
  error: '#EF4444',
  success: '#10B981',
  warning: '#F59E0B',
  info: '#3B82F6',
  shadow: 'rgba(0, 0, 0, 0.1)',
  shadowLight: 'rgba(0, 0, 0, 0.05)',
  overlay: 'rgba(0, 0, 0, 0.5)',
};

export const darkTheme: ThemeTokens = {
  background: '#111827',
  surface: '#1F2937',
  surfaceAlt: '#374151',
  surfaceVariant: '#374151',
  primary: '#F9FAFB',
  primaryVariant: '#E5E7EB',
  secondary: '#9CA3AF',
  accent: '#F97316',
  textPrimary: '#F9FAFB',
  textSecondary: '#D1D5DB',
  textTertiary: '#9CA3AF',
  border: '#374151',
  borderLight: '#4B5563',
  error: '#EF4444',
  success: '#10B981',
  warning: '#F59E0B',
  info: '#3B82F6',
  shadow: 'rgba(0, 0, 0, 0.3)',
  shadowLight: 'rgba(0, 0, 0, 0.2)',
  overlay: 'rgba(0, 0, 0, 0.7)',
};
