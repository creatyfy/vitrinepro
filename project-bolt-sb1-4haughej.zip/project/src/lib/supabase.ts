import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type PrivacySettings = {
  user_id: string;
  profile_visibility: 'public' | 'connections_only' | 'private';
  video_visibility: 'public' | 'connections_only' | 'private';
  show_training_history: boolean;
  show_statistics: boolean;
  show_location: boolean;
  show_age: boolean;
  show_height_weight: boolean;
  allow_club_messages: boolean;
  allow_agent_messages: boolean;
  allow_athlete_messages: boolean;
  show_online_status: boolean;
  created_at: string;
  updated_at: string;
};

export type NotificationPreferences = {
  user_id: string;
  training_reminders: boolean;
  peneira_alerts: boolean;
  message_notifications: boolean;
  achievement_notifications: boolean;
  club_interest_notifications: boolean;
  agent_interest_notifications: boolean;
  marketing_emails: boolean;
  newsletter: boolean;
  do_not_disturb_start: string | null;
  do_not_disturb_end: string | null;
  notification_frequency: 'realtime' | 'daily' | 'weekly';
  created_at: string;
  updated_at: string;
};

export type BlockedUser = {
  id: string;
  blocker_id: string;
  blocked_id: string;
  blocked_type: 'club' | 'agent' | 'athlete' | 'other';
  reason: string | null;
  created_at: string;
};

export type LoginHistory = {
  id: string;
  user_id: string;
  login_timestamp: string;
  device_type: 'mobile' | 'tablet' | 'desktop' | 'unknown';
  device_name: string | null;
  browser: string | null;
  ip_address: string | null;
  location_city: string | null;
  location_country: string | null;
  is_suspicious: boolean;
  session_id: string | null;
};

export type DataAccessLog = {
  id: string;
  user_id: string;
  accessor_id: string | null;
  accessor_type: 'club' | 'agent' | 'athlete' | 'system';
  data_type: string;
  access_timestamp: string;
  ip_address: string | null;
};

export type TwoFactorAuth = {
  user_id: string;
  is_enabled: boolean;
  method: 'sms' | 'app' | 'email' | null;
  phone_number: string | null;
  backup_codes: string[] | null;
  created_at: string;
  updated_at: string;
};

export type TrainingSession = {
  id: string;
  user_id: string;
  training_type: 'classic' | 'daily' | 'preparation' | 'strengthening' | 'challenge28';
  training_id: string;
  started_at: string;
  last_updated_at: string;
  completed_at: string | null;
  status: 'active' | 'paused' | 'completed' | 'abandoned';
  total_exercises: number;
  completed_exercises: number;
  session_data: any;
  created_at: string;
};

export type TrainingSessionExercise = {
  id: string;
  session_id: string;
  exercise_id: string;
  exercise_name: string;
  exercise_index: number;
  phase: 'prep' | 'active' | 'rest' | 'completed';
  current_set: number;
  total_sets: number;
  remaining_time: number;
  started_at: string;
  completed_at: string | null;
  exercise_data: any;
  created_at: string;
};

export type TrainingPreferences = {
  user_id: string;
  music_enabled: boolean;
  fullscreen_enabled: boolean;
  video_quality: '720p' | '1080p' | '1440p' | '4k';
  video_speed: number;
  haptic_feedback: boolean;
  default_rest_time: number;
  default_prep_time: number;
  created_at: string;
  updated_at: string;
};
