import React, { useState, useRef } from 'react';
import { Camera, Upload, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';

interface PublishTrainingScreenProps {
  onPublish: (photoUrl: string) => void;
  onSkip: () => void;
}

export default function PublishTrainingScreen({ onPublish, onSkip }: PublishTrainingScreenProps) {
  const [photo, setPhoto] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t } = useLanguage();
  const { isDarkMode } = useTheme();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePublish = () => {
    if (photo) {
      setIsUploading(true);
      setTimeout(() => {
        onPublish(photo);
      }, 1500);
    }
  };

  const handleRemovePhoto = () => {
    setPhoto(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  return (
    <div className={`min-h-screen ${bgClass}`}>
      <div className="pt-12"></div>

      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className={`w-24 h-24 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-6`}>
            <Camera className="w-12 h-12 text-white" />
          </div>
          <h1 className={`text-3xl font-bold ${textClass} mb-4`}>
            {t('publishTraining')}
          </h1>
          <p className={`${secondaryTextClass} text-lg`}>
            {t('photoDescription')}
          </p>
        </div>

        {!photo ? (
          <div className={`${cardClass} rounded-2xl p-8 shadow-sm border mb-6`}>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="user"
              onChange={handleFileChange}
              className="hidden"
              id="photo-upload"
            />
            <label
              htmlFor="photo-upload"
              className={`flex flex-col items-center justify-center py-12 cursor-pointer border-2 border-dashed ${
                isDarkMode ? 'border-gray-700' : 'border-gray-300'
              } rounded-2xl hover:border-blue-500 transition-colors`}
            >
              <Upload className={`w-16 h-16 ${secondaryTextClass} mb-4`} />
              <p className={`text-lg font-semibold ${textClass} mb-2`}>
                {t('takePhoto')}
              </p>
              <p className={`text-sm ${secondaryTextClass}`}>
                {t('uploadPhoto')}
              </p>
            </label>
          </div>
        ) : (
          <div className={`${cardClass} rounded-2xl overflow-hidden shadow-sm border mb-6`}>
            <div className="relative">
              <img
                src={photo}
                alt="Training photo"
                className="w-full h-96 object-cover"
              />
              <button
                onClick={handleRemovePhoto}
                className="absolute top-4 right-4 w-10 h-10 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          <button
            onClick={handlePublish}
            disabled={!photo || isUploading}
            className={`w-full py-4 rounded-2xl font-bold text-lg transition-all duration-200 active:scale-95 ${
              photo && !isUploading
                ? isDarkMode
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : 'bg-green-500 text-white hover:bg-green-600'
                : isDarkMode
                ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            {isUploading ? 'Publicando...' : t('publish')}
          </button>

          <button
            onClick={onSkip}
            className={`w-full py-4 rounded-2xl font-semibold text-lg transition-colors ${
              isDarkMode
                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {t('skip')}
          </button>
        </div>
      </div>

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}
