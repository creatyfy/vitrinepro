import React, { useState } from 'react';
import { ChevronLeft, Eye, Users, Trophy, User, BarChart3, FileText, Settings, Search, Filter, MapPin, Calendar, Clock, Star, Heart, MessageCircle, Award, TrendingUp, Target, Bell, Shield, HelpCircle, LogOut, ChevronRight, Plus, DollarSign, Briefcase, Phone, Mail, ShoppingBag } from 'lucide-react';

interface AgentHubProps {
  agentName: string;
  currentView: string;
  onNavigateToScoutCenter: () => void;
  onNavigateToObservedAthletes: () => void;
  onNavigateToPublishOpportunities: () => void;
  onNavigateToAgentRanking: () => void;
  onNavigateToAgentProfile: () => void;
  onNavigateToAgentSettings: () => void;
  onNavigateToAgentReports: () => void;
  onNavigateToAgentContracts: () => void;
  onNavigateToMarketplace: () => void;
  onNavigateToPeladas: () => void;
  onNavigateToTrainings: () => void;
  isDarkMode?: boolean;
  onBackToMain: () => void;
}

export default function AgentHub({
  agentName,
  currentView,
  onNavigateToScoutCenter,
  onNavigateToObservedAthletes,
  onNavigateToPublishOpportunities,
  onNavigateToAgentRanking,
  onNavigateToAgentProfile,
  onNavigateToAgentSettings,
  onNavigateToAgentReports,
  onNavigateToAgentContracts,
  onNavigateToMarketplace,
  onNavigateToPeladas,
  onNavigateToTrainings,
  isDarkMode = false,
  onBackToMain
}: AgentHubProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('todos');

  // Scout Center Screen
  if (currentView === 'scout-center') {
    const athletes = [
      {
        id: 1,
        name: 'João Silva',
        age: 19,
        position: 'Atacante',
        location: 'São Paulo, SP',
        rating: 9.2,
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        trending: true,
        marketValue: 'R$ 500K',
        lastActivity: '2h atrás'
      },
      {
        id: 2,
        name: 'Pedro Santos',
        age: 20,
        position: 'Meio-campo',
        location: 'Rio de Janeiro, RJ',
        rating: 8.8,
        photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        trending: false,
        marketValue: 'R$ 350K',
        lastActivity: '1 dia atrás'
      }
    ];

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Central de Scout</h1>
          <Filter className="w-6 h-6 text-gray-600" />
        </div>

        <div className="px-6">
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar atletas em alta..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Athletes List */}
          <div className="space-y-4 mb-8">
            {athletes.map((athlete) => (
              <div key={athlete.id} className="bg-white rounded-2xl p-6 shadow-sm border">
                <div className="flex items-center mb-4">
                  <img 
                    src={athlete.photo} 
                    alt={athlete.name}
                    className="w-16 h-16 rounded-full mr-4 object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-xl font-bold text-gray-900">{athlete.name}</h3>
                      {athlete.trending && (
                        <div className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">
                          🔥 Em Alta
                        </div>
                      )}
                    </div>
                    <p className="text-blue-600 font-medium mb-1">{athlete.position} • {athlete.age} anos</p>
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span className="text-sm">{athlete.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">{athlete.rating}</div>
                    <div className="text-sm text-gray-600">Rating</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-green-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-green-600">{athlete.marketValue}</div>
                    <div className="text-sm text-gray-600">Valor de Mercado</div>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-blue-600">{athlete.lastActivity}</div>
                    <div className="text-sm text-gray-600">Última Atividade</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button className="flex-1 bg-blue-500 text-white py-3 rounded-xl font-semibold hover:bg-blue-600 transition-colors">
                    Observar Atleta
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <Heart className="w-5 h-5" />
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <MessageCircle className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Observed Athletes Screen
  if (currentView === 'observed-athletes') {
    const observedAthletes = [
      {
        id: 1,
        name: 'João Silva',
        position: 'Atacante',
        age: 19,
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        status: 'Em negociação',
        statusColor: 'bg-yellow-100 text-yellow-800',
        observingSince: '15 dias',
        lastUpdate: 'Hoje'
      },
      {
        id: 2,
        name: 'Pedro Santos',
        position: 'Meio-campo',
        age: 20,
        photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        status: 'Interessado',
        statusColor: 'bg-green-100 text-green-800',
        observingSince: '8 dias',
        lastUpdate: '2h atrás'
      }
    ];

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Atletas Observados</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Eye className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Seus Atletas</h2>
            <p className="text-gray-600">Gerencie seus atletas em observação</p>
          </div>

          <div className="space-y-4 mb-8">
            {observedAthletes.map((athlete) => (
              <div key={athlete.id} className="bg-white rounded-2xl p-6 shadow-sm border">
                <div className="flex items-center mb-4">
                  <img 
                    src={athlete.photo} 
                    alt={athlete.name}
                    className="w-16 h-16 rounded-full mr-4 object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{athlete.name}</h3>
                    <p className="text-blue-600 font-medium mb-2">{athlete.position} • {athlete.age} anos</p>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${athlete.statusColor}`}>
                      {athlete.status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-blue-50 rounded-lg p-3">
                    <div className="text-sm text-gray-600">Observando há</div>
                    <div className="text-lg font-bold text-blue-600">{athlete.observingSince}</div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3">
                    <div className="text-sm text-gray-600">Última atualização</div>
                    <div className="text-lg font-bold text-green-600">{athlete.lastUpdate}</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-colors">
                    Fazer Proposta
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <Phone className="w-5 h-5" />
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <Mail className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Publish Opportunities Screen
  if (currentView === 'publish-opportunities') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Publicar Oportunidade</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Nova Oportunidade</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Clube</label>
                <input
                  type="text"
                  placeholder="Nome do clube"
                  className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Posição</label>
                <select className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option>Selecione a posição</option>
                  <option>Atacante</option>
                  <option>Meio-campo</option>
                  <option>Zagueiro</option>
                  <option>Lateral</option>
                  <option>Goleiro</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Salário Oferecido</label>
                  <input
                    type="text"
                    placeholder="R$ 5.000/mês"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Duração do Contrato</label>
                  <input
                    type="text"
                    placeholder="2 anos"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Descrição da Oportunidade</label>
                <textarea
                  placeholder="Descreva os detalhes da vaga, benefícios, requisitos..."
                  rows={4}
                  className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <button className="w-full bg-purple-500 text-white py-4 rounded-xl font-semibold text-lg hover:bg-purple-600 transition-colors">
                Publicar Oportunidade
              </button>
            </div>
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Agent Reports Screen
  if (currentView === 'agent-reports') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Relatórios</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Performance Financeira</h2>
            <p className="text-gray-600">Análise dos seus ganhos e contratos</p>
          </div>

          {/* Financial Stats */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">R$ 45K</div>
                <div className="text-sm text-gray-600">Ganhos Este Mês</div>
                <div className="text-xs text-green-600 mt-1">+15% vs mês anterior</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">8</div>
                <div className="text-sm text-gray-600">Contratos Ativos</div>
                <div className="text-xs text-green-600 mt-1">+2 este mês</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">23</div>
                <div className="text-sm text-gray-600">Atletas Representados</div>
                <div className="text-xs text-green-600 mt-1">+5 este ano</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">92%</div>
                <div className="text-sm text-gray-600">Taxa de Sucesso</div>
                <div className="text-xs text-green-600 mt-1">Acima da média</div>
              </div>
            </div>
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Contracts Screen
  if (currentView === 'agent-contracts') {
    const contracts = [
      {
        id: 1,
        athlete: 'João Silva',
        club: 'Santos FC',
        value: 'R$ 500K',
        status: 'Ativo',
        statusColor: 'bg-green-100 text-green-800',
        startDate: '01/01/2024',
        endDate: '31/12/2025'
      },
      {
        id: 2,
        athlete: 'Pedro Santos',
        club: 'Palmeiras',
        value: 'R$ 350K',
        status: 'Pendente',
        statusColor: 'bg-yellow-100 text-yellow-800',
        startDate: '15/02/2024',
        endDate: '14/02/2026'
      }
    ];

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Contratos</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Gestão de Contratos</h2>
            <p className="text-gray-600">Acompanhe todos os seus contratos</p>
          </div>

          <div className="space-y-4 mb-8">
            {contracts.map((contract) => (
              <div key={contract.id} className="bg-white rounded-2xl p-6 shadow-sm border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{contract.athlete}</h3>
                    <p className="text-blue-600 font-medium">{contract.club}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${contract.statusColor}`}>
                    {contract.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-green-50 rounded-lg p-3">
                    <div className="text-sm text-gray-600">Valor do Contrato</div>
                    <div className="text-lg font-bold text-green-600">{contract.value}</div>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-3">
                    <div className="text-sm text-gray-600">Vigência</div>
                    <div className="text-lg font-bold text-blue-600">{contract.startDate} - {contract.endDate}</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button className="flex-1 bg-blue-500 text-white py-3 rounded-xl font-semibold hover:bg-blue-600 transition-colors">
                    Ver Detalhes
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <FileText className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Main Agent Hub
  return (
    <div className="min-h-screen bg-black">
      <div className="pt-12"></div>

      {/* Header */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">
              {agentName}
            </h1>
            <p className="text-gray-400 mt-1">Empresário/Olheiro Profissional</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center bg-green-500 rounded-full px-3 py-1">
              <span className="text-white text-sm font-bold">23 atletas</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">Central de Negócios</h2>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={onNavigateToTrainings}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Meus Treinos</h3>
            <p className="text-green-100 text-sm">Planos personalizados</p>
          </button>
          <button
            onClick={onNavigateToScoutCenter}
            className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-6 text-left hover:from-blue-600 hover:to-blue-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Central de Scout</h3>
            <p className="text-blue-100 text-sm">Descobrir novos talentos</p>
          </button>
          
          <button 
            onClick={onNavigateToObservedAthletes}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Atletas Observados</h3>
            <p className="text-green-100 text-sm">Gerenciar portfólio</p>
          </button>
          
          <button 
            onClick={onNavigateToPublishOpportunities}
            className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl p-6 text-left hover:from-purple-600 hover:to-purple-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Publicar Oportunidades</h3>
            <p className="text-purple-100 text-sm">Criar vagas em clubes</p>
          </button>
          
          <button 
            onClick={onNavigateToMarketplace}
            className="bg-gradient-to-br from-red-500 to-red-700 rounded-2xl p-6 text-left hover:from-red-600 hover:to-red-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Marketplace</h3>
            <p className="text-red-100 text-sm">Equipamentos esportivos</p>
          </button>
          
          <button 
            onClick={onNavigateToPeladas}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Peladas</h3>
            <p className="text-green-100 text-sm">Encontrar jogos</p>
          </button>
          
          <button 
            onClick={onNavigateToAgentContracts}
            className="bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl p-6 text-left hover:from-indigo-600 hover:to-indigo-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Contratos</h3>
            <p className="text-indigo-100 text-sm">Gestão de contratos</p>
          </button>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="px-6 mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">Performance do Mês</h2>
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-6 text-white">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold mb-1">R$ 45K</div>
              <div className="text-green-100 text-sm">Ganhos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold mb-1">12</div>
              <div className="text-green-100 text-sm">Negociações</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold mb-1">5</div>
              <div className="text-green-100 text-sm">Contratos</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="px-6 mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">Atividade Recente</h2>
        <div className="space-y-4">
          <div className="bg-gray-900 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-semibold">Contrato fechado com Santos FC</h4>
                <p className="text-gray-400 text-sm">João Silva assinou por 2 anos</p>
              </div>
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            </div>
          </div>
          <div className="bg-gray-900 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-semibold">Novo atleta em observação</h4>
                <p className="text-gray-400 text-sm">Pedro Santos adicionado à lista</p>
              </div>
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800">
        <div className="flex justify-around py-3 px-4">
          <button
            className="p-2 rounded-full transition-all active:scale-90"
          >
            <Eye className="w-6 h-6 text-blue-500" />
          </button>
          <button
            onClick={onNavigateToObservedAthletes}
            className="p-2 rounded-full transition-all active:scale-90"
          >
            <Users className="w-6 h-6 text-gray-400" />
          </button>
          <button
            onClick={onNavigateToAgentProfile}
            className="p-2 rounded-full transition-all active:scale-90"
          >
            <User className="w-6 h-6 text-gray-400" />
          </button>
          <button
            onClick={onNavigateToAgentContracts}
            className="p-2 rounded-full transition-all active:scale-90"
          >
            <FileText className="w-6 h-6 text-gray-400" />
          </button>
          <button
            onClick={onNavigateToAgentSettings}
            className="p-2 rounded-full transition-all active:scale-90"
          >
            <Settings className="w-6 h-6 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}