import React, { useState } from 'react';
import { ChevronLeft, Instagram, Linkedin, Globe } from 'lucide-react';

interface AgentSocialLinksCollectionProps {
  socialLinks: {
    instagram: string;
    linkedin: string;
    website: string;
  };
  onSocialLinksChange: (links: { instagram: string; linkedin: string; website: string; }) => void;
  onNext: () => void;
  onSkip: () => void;
  onBack: () => void;
}

export default function AgentSocialLinksCollection({ 
  socialLinks,
  onSocialLinksChange,
  onNext, 
  onSkip,
  onBack 
}: AgentSocialLinksCollectionProps) {
  const [links, setLinks] = useState(socialLinks);

  const handleLinkChange = (platform: string, value: string) => {
    const newLinks = { ...links, [platform]: value };
    setLinks(newLinks);
    onSocialLinksChange(newLinks);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  const handleSkip = () => {
    onSkip();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '66%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Redes sociais
          </h1>
          <p className="text-gray-600 text-xl mb-2">
            Adicione seus links profissionais
          </p>
          <p className="text-gray-500 text-lg">
            Esta etapa é opcional
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="instagram" className="block text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Instagram className="w-5 h-5 mr-2 text-pink-500" />
              Instagram
            </label>
            <input
              type="url"
              id="instagram"
              value={links.instagram}
              onChange={(e) => handleLinkChange('instagram', e.target.value)}
              placeholder="https://instagram.com/seuperfil"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
            />
          </div>

          <div>
            <label htmlFor="linkedin" className="block text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Linkedin className="w-5 h-5 mr-2 text-blue-600" />
              LinkedIn
            </label>
            <input
              type="url"
              id="linkedin"
              value={links.linkedin}
              onChange={(e) => handleLinkChange('linkedin', e.target.value)}
              placeholder="https://linkedin.com/in/seuperfil"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
            />
          </div>

          <div>
            <label htmlFor="website" className="block text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Globe className="w-5 h-5 mr-2 text-gray-600" />
              Site/Portfólio
            </label>
            <input
              type="url"
              id="website"
              value={links.website}
              onChange={(e) => handleLinkChange('website', e.target.value)}
              placeholder="https://seusite.com"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
            />
          </div>
        </form>
      </div>

      {/* Buttons */}
      <div className="px-6 pb-8 space-y-4">
        <button
          onClick={handleSubmit}
          className="w-full bg-orange-500 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-orange-600 transition-colors duration-200 active:scale-95 transform"
        >
          Continuar
        </button>
        
        <button
          onClick={handleSkip}
          className="w-full text-gray-600 py-2 font-medium text-lg hover:text-gray-800 transition-colors duration-200"
        >
          Pular esta etapa
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}