import React, { useState } from 'react';
import { ChevronLeft, MapPin, Calendar, Users, Clock, Star, Filter, Search, Trophy, Target, AlertCircle, CheckCircle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface PeneirasScreenProps {
  onBack: () => void;
}

export default function PeneirasScreen({ onBack }: PeneirasScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [selectedFilter, setSelectedFilter] = useState('todas');
  const [searchTerm, setSearchTerm] = useState('');
  const [hasOpportunities] = useState(Math.random() > 0.3); // 70% chance de ter peneiras

  const filters = [
    { id: 'todas', label: 'Todas', count: 8 },
    { id: 'abertas', label: 'Abertas', count: 5 },
    { id: 'fechando', label: 'Fechando', count: 2 },
    { id: 'encerradas', label: 'Encerradas', count: 1 }
  ];

  const peneiras = hasOpportunities ? [
    {
      id: 1,
      club: 'Santos FC',
      logo: '⚪',
      title: 'Peneira Sub-20 - Categoria de Base',
      description: 'O Santos FC está em busca de jovens talentos para integrar as categorias de base do clube.',
      location: 'Vila Belmiro - Santos, SP',
      date: '2024-02-15',
      time: '14:00',
      ageRange: '16-20 anos',
      positions: ['Atacante', 'Meio-campo', 'Lateral'],
      maxParticipants: 100,
      currentParticipants: 67,
      status: 'aberta',
      requirements: ['Documento com foto', 'Atestado médico', 'Chuteira'],
      contact: 'peneiras@santosfc.com.br',
      fee: 'Gratuita',
      priority: 'alta'
    },
    {
      id: 2,
      club: 'Palmeiras',
      logo: '🟢',
      title: 'Seleção para Academia de Futebol',
      description: 'Oportunidade única para integrar a renomada Academia de Futebol do Palmeiras.',
      location: 'Academia de Futebol - São Paulo, SP',
      date: '2024-02-20',
      time: '09:00',
      ageRange: '17-21 anos',
      positions: ['Zagueiro', 'Volante', 'Atacante'],
      maxParticipants: 80,
      currentParticipants: 45,
      status: 'aberta',
      requirements: ['RG', 'CPF', 'Comprovante de residência', 'Atestado médico'],
      contact: 'captacao@palmeiras.com.br',
      fee: 'R$ 50,00',
      priority: 'alta'
    },
    {
      id: 3,
      club: 'Corinthians',
      logo: '⚫',
      title: 'Peneira Feminina - Corinthians/Audax',
      description: 'Seleção para o time feminino profissional do Sport Club Corinthians Paulista.',
      location: 'CT Dr. Joaquim Grava - São Paulo, SP',
      date: '2024-02-18',
      time: '15:30',
      ageRange: '18-25 anos',
      positions: ['Todas as posições'],
      maxParticipants: 60,
      currentParticipants: 58,
      status: 'fechando',
      requirements: ['Documento com foto', 'Atestado médico', 'Experiência comprovada'],
      contact: 'futebol.feminino@corinthians.com.br',
      fee: 'Gratuita',
      priority: 'alta'
    },
    {
      id: 4,
      club: 'São Paulo FC',
      logo: '🔴',
      title: 'Captação de Talentos - Cotia',
      description: 'O São Paulo FC busca jovens promessas para as categorias de base em Cotia.',
      location: 'Centro de Treinamento - Cotia, SP',
      date: '2024-02-25',
      time: '08:00',
      ageRange: '15-19 anos',
      positions: ['Goleiro', 'Zagueiro', 'Meio-campo'],
      maxParticipants: 120,
      currentParticipants: 23,
      status: 'aberta',
      requirements: ['RG', 'Atestado médico', 'Autorização dos pais (menores)'],
      contact: 'base@saopaulofc.net',
      fee: 'R$ 30,00',
      priority: 'media'
    },
    {
      id: 5,
      club: 'Flamengo',
      logo: '🔴',
      title: 'Peneira Nacional - Ninho do Urubu',
      description: 'Peneira nacional do Clube de Regatas do Flamengo para descobrir novos talentos.',
      location: 'CT Ninho do Urubu - Rio de Janeiro, RJ',
      date: '2024-03-01',
      time: '07:00',
      ageRange: '16-22 anos',
      positions: ['Todas as posições'],
      maxParticipants: 200,
      currentParticipants: 156,
      status: 'aberta',
      requirements: ['Documento com foto', 'Atestado médico', 'Comprovante de vacinação'],
      contact: 'peneiras@flamengo.com.br',
      fee: 'R$ 80,00',
      priority: 'alta'
    },
    {
      id: 6,
      club: 'Grêmio',
      logo: '🔵',
      title: 'Seleção Sub-17 - Tricolor',
      description: 'O Grêmio FBPA abre seleção para a categoria Sub-17 masculina.',
      location: 'CT Luiz Carvalho - Porto Alegre, RS',
      date: '2024-02-12',
      time: '14:00',
      ageRange: '15-17 anos',
      positions: ['Lateral', 'Meio-campo', 'Atacante'],
      maxParticipants: 90,
      currentParticipants: 90,
      status: 'encerrada',
      requirements: ['RG', 'Atestado médico', 'Comprovante de escolaridade'],
      contact: 'base@gremio.net',
      fee: 'Gratuita',
      priority: 'baixa'
    },
    {
      id: 7,
      club: 'Internacional',
      logo: '🔴',
      title: 'Peneira Feminina - Colorado',
      description: 'Sport Club Internacional busca atletas para o time feminino profissional.',
      location: 'CT Parque Gigante - Porto Alegre, RS',
      date: '2024-02-28',
      time: '16:00',
      ageRange: '17-24 anos',
      positions: ['Goleira', 'Zagueira', 'Meio-campo', 'Atacante'],
      maxParticipants: 70,
      currentParticipants: 31,
      status: 'aberta',
      requirements: ['Documento com foto', 'Atestado médico', 'Experiência em competições'],
      contact: 'feminino@internacional.com.br',
      fee: 'R$ 40,00',
      priority: 'media'
    },
    {
      id: 8,
      club: 'Botafogo',
      logo: '⚫',
      title: 'Captação de Talentos - General Severiano',
      description: 'Botafogo de Futebol e Regatas abre peneira para jovens talentos.',
      location: 'General Severiano - Rio de Janeiro, RJ',
      date: '2024-02-22',
      time: '13:00',
      ageRange: '16-20 anos',
      positions: ['Zagueiro', 'Volante', 'Ponta'],
      maxParticipants: 85,
      currentParticipants: 82,
      status: 'fechando',
      requirements: ['RG', 'CPF', 'Atestado médico', 'Foto 3x4'],
      contact: 'peneiras@botafogo.com.br',
      fee: 'R$ 60,00',
      priority: 'media'
    }
  ] : [];

  const filteredPeneiras = peneiras.filter(peneira => {
    const matchesFilter = selectedFilter === 'todas' || peneira.status === selectedFilter;
    const matchesSearch = peneira.club.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         peneira.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         peneira.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'aberta':
        return { backgroundColor: tokens.success + '20', color: tokens.success };
      case 'fechando':
        return { backgroundColor: tokens.warning + '20', color: tokens.warning };
      case 'encerrada':
        return { backgroundColor: tokens.error + '20', color: tokens.error };
      default:
        return { backgroundColor: tokens.surfaceAlt, color: tokens.textSecondary };
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'aberta': return 'Inscrições Abertas';
      case 'fechando': return 'Últimas Vagas';
      case 'encerrada': return 'Encerrada';
      default: return 'Status';
    }
  };

  const getPriorityBorderColor = (priority: string) => {
    switch (priority) {
      case 'alta': return tokens.error;
      case 'media': return tokens.warning;
      case 'baixa': return tokens.border;
      default: return tokens.border;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric' 
    });
  };

  if (!hasOpportunities) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span style={{ color: tokens.textPrimary }}>13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
            <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
          </button>
          <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Peneiras</h1>
          <div className="w-10"></div>
        </div>

        {/* Empty State */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <div className="w-24 h-24 rounded-full flex items-center justify-center mb-6" style={{ backgroundColor: tokens.surfaceAlt }}>
            <AlertCircle className="w-12 h-12" style={{ color: tokens.iconSecondary }} />
          </div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: tokens.textPrimary }}>
            Nenhuma peneira disponível no momento
          </h2>
          <p className="text-lg mb-8 max-w-sm" style={{ color: tokens.textSecondary }}>
            Não há oportunidades abertas agora, mas fique atento! Novas peneiras aparecem frequentemente.
          </p>
          <div className="rounded-2xl p-6 border max-w-sm" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
            <h3 className="font-semibold mb-2" style={{ color: tokens.textPrimary }}>💡 Dica</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>
              Continue treinando e melhorando sua pontuação. Clubes observam atletas com melhor desempenho no Vitrine Pro!
            </p>
          </div>
        </div>

        {/* Bottom Indicator */}
        <div className="h-1 mx-auto mb-2 rounded-full" style={{width: '134px', backgroundColor: tokens.border}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={{ color: tokens.textPrimary }}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Peneiras</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>Oportunidades Abertas</h2>
          <p style={{ color: tokens.textSecondary }}>Peneiras e seleções dos principais clubes do Brasil</p>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: tokens.iconSecondary }} />
          <input
            type="text"
            placeholder="Buscar por clube ou cidade..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border focus:outline-none focus:ring-2"
            style={{
              backgroundColor: tokens.surfaceAlt,
              borderColor: tokens.border,
              color: tokens.textPrimary
            }}
          />
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>Filtros</h3>
            <Filter className="w-5 h-5" style={{ color: tokens.iconSecondary }} />
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setSelectedFilter(filter.id)}
                className="flex items-center px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 border"
                style={{
                  backgroundColor: selectedFilter === filter.id ? tokens.accent : tokens.surfaceAlt,
                  color: selectedFilter === filter.id ? tokens.textInverse : tokens.textPrimary,
                  borderColor: selectedFilter === filter.id ? tokens.accent : tokens.border
                }}
              >
                {filter.label}
                <span
                  className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium"
                  style={{
                    backgroundColor: selectedFilter === filter.id ? 'rgba(255,255,255,0.2)' : tokens.surface,
                    color: selectedFilter === filter.id ? tokens.textInverse : tokens.textSecondary
                  }}
                >
                  {filter.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
          <h3 className="text-lg font-semibold mb-4" style={{ color: tokens.textPrimary }}>Estatísticas</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>5</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Abertas</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>805</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Inscritos</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>23</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Aprovados</div>
            </div>
          </div>
        </div>

        {/* Peneiras List */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>
              {selectedFilter === 'todas' ? 'Todas as Peneiras' : filters.find(f => f.id === selectedFilter)?.label}
            </h3>
            <span className="text-sm" style={{ color: tokens.textSecondary }}>{filteredPeneiras.length} oportunidades</span>
          </div>
          
          <div className="space-y-4">
            {filteredPeneiras.map((peneira) => (
              <div key={peneira.id} className="rounded-2xl shadow-sm border-l-4 overflow-hidden" style={{ backgroundColor: tokens.surfaceAlt, borderLeftColor: getPriorityBorderColor(peneira.priority) }}>
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{peneira.logo}</span>
                      <div>
                        <h4 className="font-semibold text-lg" style={{ color: tokens.textPrimary }}>{peneira.club}</h4>
                        <p className="text-sm" style={{ color: tokens.textSecondary }}>{peneira.title}</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-medium" style={getStatusStyle(peneira.status)}>
                      {getStatusLabel(peneira.status)}
                    </span>
                  </div>
                  
                  <p className="mb-4" style={{ color: tokens.textSecondary }}>{peneira.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{peneira.location}</span>
                    </div>
                    <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{formatDate(peneira.date)}</span>
                    </div>
                    <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                      <Clock className="w-4 h-4 mr-2" />
                      <span>{peneira.time}</span>
                    </div>
                    <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                      <Target className="w-4 h-4 mr-2" />
                      <span>{peneira.ageRange}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2" style={{ color: tokens.textPrimary }}>Posições:</p>
                    <div className="flex flex-wrap gap-2">
                      {peneira.positions.map((position, index) => (
                        <span key={index} className="px-2 py-1 text-xs rounded-full" style={{ backgroundColor: tokens.accent + '20', color: tokens.accent }}>
                          {position}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium" style={{ color: tokens.textPrimary }}>Vagas:</span>
                      <span className="text-sm" style={{ color: tokens.textSecondary }}>
                        {peneira.currentParticipants}/{peneira.maxParticipants}
                      </span>
                    </div>
                    <div className="w-full rounded-full h-2" style={{ backgroundColor: tokens.border }}>
                      <div
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ width: `${(peneira.currentParticipants / peneira.maxParticipants) * 100}%`, backgroundColor: tokens.accent }}
                      ></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium" style={{ color: tokens.textPrimary }}>Taxa: </span>
                      <span className="text-sm font-bold" style={{ color: peneira.fee === 'Gratuita' ? tokens.success : tokens.textPrimary }}>
                        {peneira.fee}
                      </span>
                    </div>
                    <button
                      disabled={peneira.status === 'encerrada'}
                      className="px-6 py-2 rounded-xl font-semibold text-sm transition-all duration-200 active:scale-95"
                      style={{
                        backgroundColor: peneira.status === 'encerrada' ? tokens.surfaceAlt : tokens.accent,
                        color: peneira.status === 'encerrada' ? tokens.textSecondary : tokens.textInverse,
                        cursor: peneira.status === 'encerrada' ? 'not-allowed' : 'pointer',
                        opacity: peneira.status === 'encerrada' ? 0.6 : 1
                      }}
                    >
                      {peneira.status === 'encerrada' ? 'Encerrada' : 'Inscrever-se'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Success Tips */}
        <div className="rounded-2xl p-6 mb-8" style={{ backgroundColor: tokens.success, color: tokens.textInverse }}>
          <h3 className="text-lg font-semibold mb-4">💡 Dicas para o Sucesso</h3>
          <div className="space-y-2" style={{ opacity: 0.9 }}>
            <p className="text-sm">• Mantenha sua pontuação alta no Vitrine Pro</p>
            <p className="text-sm">• Publique vídeos dos seus melhores treinos</p>
            <p className="text-sm">• Chegue cedo e leve todos os documentos</p>
            <p className="text-sm">• Demonstre dedicação e fair play</p>
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}