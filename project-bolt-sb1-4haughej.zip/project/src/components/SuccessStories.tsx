import React from 'react';
import { ChevronLeft, Star } from 'lucide-react';

interface SuccessStoriesProps {
  onNext: () => void;
  onBack: () => void;
}

export default function SuccessStories({ onNext, onBack }: SuccessStoriesProps) {
  const testimonials = [
    {
      id: 1,
      name: 'João Santos',
      photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      testimonial: 'Meus treinos da pré-temporada foram com vocês, máximo respeito!'
    },
    {
      id: 2,
      name: 'Maria Silva',
      photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      testimonial: 'Legal a ideia, meu filho usa a plataforma de vocês e melhorou muito nos jogos.'
    },
    {
      id: 3,
      name: 'Carlos Oliveira',
      photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      testimonial: 'Finalmente um lugar onde meu esforço está sendo visto. Vocês estão fazendo muito pelo futebol.'
    },
    {
      id: 4,
      name: 'Lucas Pereira',
      photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      testimonial: 'O Vitrine Pro me fez acreditar que ser profissional ainda é possível.'
    }
  ];

  const profilePhotos = [
    'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop',
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop',
    'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop'
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            Histórias de Sucesso
          </h1>
          
          {/* 5 Stars */}
          <div className="flex justify-center space-x-1 mb-6">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} className="w-8 h-8 text-yellow-400 fill-current" />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-8 leading-tight">
            Veja o que nossos usuários alcançaram
          </h2>

          {/* Profile Photos */}
          <div className="flex justify-center items-center mb-4">
            <div className="flex -space-x-3">
              {profilePhotos.map((photo, index) => (
                <img
                  key={index}
                  src={photo}
                  alt={`Usuário ${index + 1}`}
                  className="w-12 h-12 rounded-full border-3 border-white shadow-lg"
                />
              ))}
            </div>
          </div>

          <p className="text-gray-600 text-lg mb-8">
            +2K de usuários com o Vitrine Pro
          </p>
        </div>

        {/* Testimonials */}
        <div className="space-y-4 mb-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="flex items-start space-x-4">
                <img
                  src={testimonial.photo}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {testimonial.name}
                  </h3>
                  <div className="flex space-x-1 mb-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 leading-relaxed">
                    "{testimonial.testimonial}"
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}