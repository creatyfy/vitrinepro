import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';

interface BirthDateProps {
  selectedDay: number;
  selectedMonth: number;
  selectedYear: number;
  onDaySelect: (day: number) => void;
  onMonthSelect: (month: number) => void;
  onYearSelect: (year: number) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function BirthDate({ 
  selectedDay, 
  selectedMonth, 
  selectedYear,
  onDaySelect, 
  onMonthSelect, 
  onYearSelect,
  onNext, 
  onBack 
}: BirthDateProps) {
  const dayScrollRef = useRef<HTMLDivElement>(null);
  const monthScrollRef = useRef<HTMLDivElement>(null);
  const yearScrollRef = useRef<HTMLDivElement>(null);

  // Gerar valores de dia (1 a 31)
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  
  // Meses em português
  const months = [
    { value: 1, label: 'Janeiro' },
    { value: 2, label: 'Fevereiro' },
    { value: 3, label: 'Março' },
    { value: 4, label: 'Abril' },
    { value: 5, label: 'Maio' },
    { value: 6, label: 'Junho' },
    { value: 7, label: 'Julho' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Setembro' },
    { value: 10, label: 'Outubro' },
    { value: 11, label: 'Novembro' },
    { value: 12, label: 'Dezembro' }
  ];
  
  // Gerar valores de ano (1980 a 2010)
  const years = Array.from({ length: 31 }, (_, i) => 2010 - i);

  const scrollToValue = (containerRef: React.RefObject<HTMLDivElement>, value: number, values: number[]) => {
    if (containerRef.current) {
      const index = values.indexOf(value);
      const itemHeight = 60;
      const scrollTop = index * itemHeight;
      
      containerRef.current.scrollTo({
        top: scrollTop,
        behavior: 'auto'
      });
    }
  };

  useEffect(() => {
    if (selectedDay && dayScrollRef.current) {
      scrollToValue(dayScrollRef, selectedDay, days);
    }
  }, []);

  useEffect(() => {
    if (selectedMonth && monthScrollRef.current) {
      const monthValues = months.map(m => m.value);
      scrollToValue(monthScrollRef, selectedMonth, monthValues);
    }
  }, []);

  useEffect(() => {
    if (selectedYear && yearScrollRef.current) {
      scrollToValue(yearScrollRef, selectedYear, years);
    }
  }, []);

  const handleDayScroll = () => {
    if (dayScrollRef.current) {
      const scrollTop = dayScrollRef.current.scrollTop;
      const itemHeight = 60;
      const centerIndex = Math.round(scrollTop / itemHeight);
      const clampedIndex = Math.max(0, Math.min(centerIndex, days.length - 1));
      onDaySelect(days[clampedIndex]);
    }
  };

  const handleMonthScroll = () => {
    if (monthScrollRef.current) {
      const scrollTop = monthScrollRef.current.scrollTop;
      const itemHeight = 60;
      const centerIndex = Math.round(scrollTop / itemHeight);
      const clampedIndex = Math.max(0, Math.min(centerIndex, months.length - 1));
      onMonthSelect(months[clampedIndex].value);
    }
  };

  const handleYearScroll = () => {
    if (yearScrollRef.current) {
      const scrollTop = yearScrollRef.current.scrollTop;
      const itemHeight = 60;
      const centerIndex = Math.round(scrollTop / itemHeight);
      const clampedIndex = Math.max(0, Math.min(centerIndex, years.length - 1));
      onYearSelect(years[clampedIndex]);
    }
  };

  const getMonthLabel = (monthValue: number) => {
    const month = months.find(m => m.value === monthValue);
    return month ? month.label : 'Janeiro';
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Quando você nasceu?
          </h1>
          <p className="text-gray-600 text-lg">
            Isso será usado para calibrar seu plano personalizado
          </p>
        </div>

        {/* Date Selectors */}
        <div className="flex justify-between items-center mb-12">
          {/* Day Selector */}
          <div className="flex-1 mr-2">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Dia
            </h3>
            <div className="relative">
              <div 
                ref={dayScrollRef}
                onScroll={handleDayScroll}
                className="h-80 overflow-y-scroll scrollbar-hide snap-y snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div>
                  {days.map((day) => (
                    <div
                      key={day}
                      className={`h-15 flex items-center justify-center text-2xl font-medium transition-all duration-200 snap-start ${
                        selectedDay === day
                          ? 'text-gray-900 font-bold scale-110'
                          : 'text-gray-400'
                      }`}
                      style={{ height: '60px' }}
                    >
                      {day}
                    </div>
                  ))}
                </div>
              </div>
              {/* Selection line indicator */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500 pointer-events-none z-10"></div>
            </div>
          </div>

          {/* Month Selector */}
          <div className="flex-1 mx-2">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Mês
            </h3>
            <div className="relative">
              <div 
                ref={monthScrollRef}
                onScroll={handleMonthScroll}
                className="h-80 overflow-y-scroll scrollbar-hide snap-y snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div>
                  {months.map((month) => (
                    <div
                      key={month.value}
                      className={`h-15 flex items-center justify-center text-2xl font-medium transition-all duration-200 snap-start ${
                        selectedMonth === month.value
                          ? 'text-gray-900 font-bold scale-110'
                          : 'text-gray-400'
                      }`}
                      style={{ height: '60px' }}
                    >
                      {month.label}
                    </div>
                  ))}
                </div>
              </div>
              {/* Selection line indicator */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500 pointer-events-none z-10"></div>
            </div>
          </div>

          {/* Year Selector */}
          <div className="flex-1 ml-2">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Ano
            </h3>
            <div className="relative">
              <div 
                ref={yearScrollRef}
                onScroll={handleYearScroll}
                className="h-80 overflow-y-scroll scrollbar-hide snap-y snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div>
                  {years.map((year) => (
                    <div
                      key={year}
                      className={`h-15 flex items-center justify-center text-2xl font-medium transition-all duration-200 snap-start ${
                        selectedYear === year
                          ? 'text-gray-900 font-bold scale-110'
                          : 'text-gray-400'
                      }`}
                      style={{ height: '60px' }}
                    >
                      {year}
                    </div>
                  ))}
                </div>
              </div>
              {/* Selection line indicator */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500 pointer-events-none z-10"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedDay || !selectedMonth || !selectedYear}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedDay && selectedMonth && selectedYear
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}