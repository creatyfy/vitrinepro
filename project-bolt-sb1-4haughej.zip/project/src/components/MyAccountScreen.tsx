import React, { useState, useMemo } from 'react';
import { ChevronLeft, User, Settings, Bell, Shield, HelpCircle, LogOut, ChevronRight, Trophy, Camera, Mail, Phone, MapPin } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface MyAccountScreenProps {
  onBack: () => void;
  onNavigateToProfile: () => void;
  onNavigateToSettings: () => void;
  onNavigateToPrivacy?: () => void;
  onNavigateToSupport?: () => void;
}

export default function MyAccountScreen({ onBack, onNavigateToProfile, onNavigateToSettings, onNavigateToPrivacy, onNavigateToSupport }: MyAccountScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const styles = useMemo(() => ({
    container: {
      backgroundColor: theme.surface
    },
    card: {
      backgroundColor: theme.surfaceAlt,
      borderColor: theme.border
    },
    textPrimary: {
      color: theme.textPrimary
    },
    textSecondary: {
      color: theme.textSecondary
    },
    icon: {
      color: theme.icon
    },
    accent: {
      backgroundColor: theme.accent,
      color: theme.textInverse
    },
    accentText: {
      color: theme.accent
    },
    warning: {
      backgroundColor: theme.warning,
      color: theme.textInverse
    },
    success: {
      color: theme.success
    },
    error: {
      backgroundColor: theme.error,
      color: theme.textInverse
    }
  }), [themeVersion, theme]);

  const accountOptions = [
    {
      id: 'profile',
      title: 'Meu Perfil',
      description: 'Informações pessoais e dados do atleta',
      icon: User,
      action: 'navigate',
      onClick: onNavigateToProfile
    },
    {
      id: 'settings',
      title: 'Configurações',
      description: 'Tema, notificações e preferências',
      icon: Settings,
      action: 'navigate',
      onClick: onNavigateToSettings
    },
    {
      id: 'notifications',
      title: 'Notificações',
      description: 'Gerenciar alertas e lembretes',
      icon: Bell,
      action: 'toggle',
      value: notificationsEnabled
    },
    {
      id: 'privacy',
      title: 'Privacidade',
      description: 'Configurações de privacidade e dados',
      icon: Shield,
      action: 'navigate',
      onClick: onNavigateToPrivacy || (() => console.log('Navegando para Privacidade'))
    },
    {
      id: 'help',
      title: 'Ajuda e Suporte',
      description: 'Central de ajuda e contato',
      icon: HelpCircle,
      action: 'navigate',
      onClick: onNavigateToSupport
    }
  ];

  const userStats = {
    totalPoints: 2350,
    level: 'Intermediário',
    nextLevel: 'Avançado',
    progressToNext: 65,
    trainingsCompleted: 47,
    currentStreak: 12,
    achievements: 8
  };

  const recentAchievements = [
    { id: 1, title: 'Primeira Semana', icon: '🏆', earned: true },
    { id: 2, title: 'Sequência de Fogo', icon: '🔥', earned: true },
    { id: 3, title: 'Atleta Dedicado', icon: '⭐', earned: false }
  ];

  const handleToggle = (optionId: string) => {
    if (optionId === 'notifications') {
      setNotificationsEnabled(!notificationsEnabled);
    }
  };

  return (
    <div className="min-h-screen" style={styles.container}>
      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={styles.icon} />
        </button>
        <h1 className="text-xl font-bold" style={styles.textPrimary}>Minha Conta</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Profile Header */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={styles.card}>
          <div className="flex items-center mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full flex items-center justify-center mr-4" style={styles.accent}>
                <User className="w-10 h-10" style={{ color: theme.textInverse }} />
              </div>
              <button className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full flex items-center justify-center" style={styles.warning}>
                <Camera className="w-4 h-4" style={{ color: theme.textInverse }} />
              </button>
            </div>
            <div className="flex-1">
              <div className="flex items-center mb-2">
                <h2 className="text-2xl font-bold mr-2" style={styles.textPrimary}>João Silva</h2>
                <button className="p-1" style={styles.icon}>
                  <User className="w-4 h-4" />
                </button>
              </div>
              <p className="font-medium mb-1" style={styles.accentText}>Atacante</p>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-1" style={styles.icon} />
                <span className="text-sm" style={styles.textSecondary}>São Paulo, Brasil</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold" style={styles.textPrimary}>8.7</div>
              <div className="text-sm" style={styles.textSecondary}>Pontuação</div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-3">
            <div className="flex items-center">
              <Mail className="w-4 h-4 mr-3" style={styles.icon} />
              <span className="text-sm" style={styles.textPrimary}>joao.silva@email.com</span>
            </div>
            <div className="flex items-center">
              <Phone className="w-4 h-4 mr-3" style={styles.icon} />
              <span className="text-sm" style={styles.textPrimary}>(11) 99999-9999</span>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={styles.card}>
          <h3 className="text-lg font-semibold mb-4" style={styles.textPrimary}>Resumo da Conta</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold" style={styles.textPrimary}>{userStats.totalPoints}</div>
              <div className="text-sm" style={styles.textSecondary}>Pontos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold" style={styles.textPrimary}>{userStats.trainingsCompleted}</div>
              <div className="text-sm" style={styles.textSecondary}>Treinos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold" style={styles.textPrimary}>{userStats.achievements}</div>
              <div className="text-sm" style={styles.textSecondary}>Conquistas</div>
            </div>
          </div>
        </div>

        {/* Level Progress */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={styles.card}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style={styles.accent}>
                <Trophy className="w-6 h-6" style={{ color: theme.textInverse }} />
              </div>
              <div>
                <h3 className="text-lg font-semibold" style={styles.textPrimary}>Nível {userStats.level}</h3>
                <p style={styles.textSecondary}>Próximo: {userStats.nextLevel}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold" style={styles.textPrimary}>{userStats.progressToNext}%</div>
              <div className="text-sm" style={styles.textSecondary}>Progresso</div>
            </div>
          </div>
          <div className="w-full rounded-full h-3" style={{ backgroundColor: theme.border }}>
            <div
              className="h-3 rounded-full transition-all duration-300"
              style={{ width: `${userStats.progressToNext}%`, backgroundColor: theme.accent }}
            ></div>
          </div>
        </div>

        {/* Recent Achievements */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6" style={styles.textPrimary}>Conquistas Recentes</h3>
          <div className="flex space-x-4 overflow-x-auto pb-4">
            {recentAchievements.map((achievement) => (
              <div
                key={achievement.id}
                className="flex-shrink-0 w-32 rounded-2xl p-4 shadow-sm border text-center"
                style={{
                  ...styles.card,
                  opacity: achievement.earned ? 1 : 0.5
                }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3"
                  style={{ backgroundColor: achievement.earned ? theme.warning : theme.border }}
                >
                  <span className="text-2xl">{achievement.icon}</span>
                </div>
                <h4 className="font-semibold text-sm mb-1" style={styles.textPrimary}>{achievement.title}</h4>
                <span
                  className="text-xs"
                  style={achievement.earned ? styles.success : styles.textSecondary}
                >
                  {achievement.earned ? 'Conquistado' : 'Bloqueado'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Account Options */}
        <div className="space-y-4 mb-8">
          {accountOptions.map((option) => {
            const IconComponent = option.icon;
            return (
              <button
                key={option.id}
                onClick={option.action === 'toggle' ? () => handleToggle(option.id) : option.onClick}
                className="w-full rounded-2xl p-6 shadow-sm border hover:shadow-md transition-all duration-200 active:scale-95"
                style={styles.card}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center flex-1">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style={{ backgroundColor: theme.surface }}>
                      <IconComponent className="w-6 h-6" style={styles.icon} />
                    </div>
                    <div className="flex-1 text-left">
                      <h4 className="font-semibold mb-1" style={styles.textPrimary}>{option.title}</h4>
                      <p className="text-sm" style={styles.textSecondary}>{option.description}</p>
                    </div>
                  </div>

                  {option.action === 'toggle' ? (
                    <div
                      className="w-12 h-6 rounded-full transition-all duration-200"
                      style={{ backgroundColor: option.value ? theme.accent : theme.border }}
                    >
                      <div
                        className="w-5 h-5 rounded-full transition-all duration-200"
                        style={{
                          backgroundColor: theme.textInverse,
                          transform: option.value ? 'translateX(24px)' : 'translateX(2px)'
                        }}
                      ></div>
                    </div>
                  ) : (
                    <ChevronRight className="w-5 h-5" style={styles.icon} />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Logout Button */}
        <button
          className="w-full py-4 rounded-2xl font-semibold text-lg transition-colors duration-200 active:scale-95 flex items-center justify-center mb-8"
          style={styles.error}
        >
          <LogOut className="w-5 h-5 mr-2" />
          Sair da Conta
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 mx-auto mb-2 rounded-full" style={{ width: '134px', backgroundColor: theme.textPrimary, opacity: 0.3 }}></div>
    </div>
  );
}
