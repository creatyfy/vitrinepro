import React, { useState } from 'react';
import { ChevronLeft, MapPin, Calendar, Clock, Users, Star, Trophy, Target, Phone, MessageCircle, Share2, Heart, CheckCircle, AlertCircle, Crown, Award, Zap } from 'lucide-react';

interface PeladaDetailScreenProps {
  pelada: any;
  onBack: () => void;
  userType: 'atleta' | 'clube' | 'empresario';
  userName: string;
}

export default function PeladaDetailScreen({ pelada, onBack, userType, userName }: PeladaDetailScreenProps) {
  const [isParticipating, setIsParticipating] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);

  const handleParticipate = () => {
    setIsParticipating(true);
    // Aqui você implementaria a lógica real de participação
    console.log('Participando do evento:', pelada.id);
  };

  const handleCancelParticipation = () => {
    setIsParticipating(false);
    // Aqui você implementaria a lógica real de cancelamento
    console.log('Cancelando participação:', pelada.id);
  };

  const getBoostBadge = (boostLevel: string | null) => {
    if (!boostLevel) return null;
    
    switch (boostLevel) {
      case 'bronze':
        return <div className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center">
          <Zap className="w-4 h-4 mr-1" />
          BRONZE
        </div>;
      case 'prata':
        return <div className="bg-gray-400 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center">
          <Crown className="w-4 h-4 mr-1" />
          PRATA
        </div>;
      case 'ouro':
        return <div className="bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center">
          <Award className="w-4 h-4 mr-1" />
          OURO
        </div>;
      default:
        return null;
    }
  };

  const getOrganizerTypeLabel = (type: string) => {
    switch (type) {
      case 'atleta': return 'Atleta';
      case 'clube': return 'Clube';
      case 'empresario': return 'Empresário';
      default: return 'Organizador';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: 'long',
      weekday: 'long'
    });
  };

  const canParticipate = pelada.currentPlayers < pelada.maxPlayers && pelada.status === 'aberta';

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Detalhes do Evento</h1>
        <div className="flex items-center space-x-2">
          <Heart className="w-6 h-6 text-gray-600" />
          <Share2 className="w-6 h-6 text-gray-600" />
        </div>
      </div>

      <div className="px-6">
        {/* Boost Badge */}
        {pelada.boosted && (
          <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-2xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Zap className="w-5 h-5 text-white mr-2" />
                <span className="text-white font-bold">EVENTO TURBINADO</span>
              </div>
              {getBoostBadge(pelada.boostLevel)}
            </div>
          </div>
        )}

        {/* Event Image */}
        <div className="relative h-48 rounded-2xl overflow-hidden mb-6">
          <img 
            src={pelada.image} 
            alt={pelada.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-4 left-4 right-4">
            <h2 className="text-2xl font-bold text-white mb-2">{pelada.title}</h2>
            <div className="flex items-center space-x-4">
              <span className="text-white capitalize">{pelada.type}</span>
              <span className="text-gray-300">•</span>
              <span className="text-white">{pelada.level}</span>
            </div>
          </div>
        </div>

        {/* Organizer Info */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <img 
                src={pelada.organizerPhoto} 
                alt={pelada.organizer}
                className="w-12 h-12 rounded-full mr-3 object-cover"
              />
              <div>
                <h3 className="font-semibold text-gray-900">{pelada.organizer}</h3>
                <p className="text-sm text-gray-600">{getOrganizerTypeLabel(pelada.organizerType)}</p>
              </div>
            </div>
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
              <span className="text-sm font-medium text-gray-700">{pelada.rating}</span>
              <span className="text-sm text-gray-500 ml-1">({pelada.reviews})</span>
            </div>
          </div>
        </div>

        {/* Event Details */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Detalhes do Evento</h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <Calendar className="w-5 h-5 text-gray-400 mr-3" />
              <div>
                <div className="font-medium text-gray-900">{formatDate(pelada.date)}</div>
                <div className="text-sm text-gray-600">{pelada.time} • {pelada.duration}</div>
              </div>
            </div>
            
            <div className="flex items-start">
              <MapPin className="w-5 h-5 text-gray-400 mr-3 mt-0.5" />
              <div>
                <div className="font-medium text-gray-900">{pelada.location}</div>
                <div className="text-sm text-gray-600">{pelada.distance} de você</div>
              </div>
            </div>
            
            <div className="flex items-center">
              <Users className="w-5 h-5 text-gray-400 mr-3" />
              <div>
                <div className="font-medium text-gray-900">{pelada.currentPlayers}/{pelada.maxPlayers} participantes</div>
                <div className="text-sm text-gray-600">Campo: {pelada.field}</div>
              </div>
            </div>
            
            <div className="flex items-center">
              <Target className="w-5 h-5 text-gray-400 mr-3" />
              <div>
                <div className="font-medium text-gray-900">Nível: {pelada.level}</div>
                <div className="text-sm text-gray-600">Valor: {pelada.price}</div>
              </div>
            </div>

            {pelada.prize && (
              <div className="flex items-center">
                <Trophy className="w-5 h-5 text-yellow-500 mr-3" />
                <div>
                  <div className="font-medium text-gray-900">Premiação</div>
                  <div className="text-sm text-gray-600">{pelada.prize}</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Descrição</h3>
          <p className="text-gray-700 leading-relaxed">{pelada.description}</p>
        </div>

        {/* Amenities */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Comodidades</h3>
          <div className="flex flex-wrap gap-2">
            {pelada.amenities.map((amenity: string, index: number) => (
              <span key={index} className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                {amenity}
              </span>
            ))}
          </div>
        </div>

        {/* Participants */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">
              Participantes ({pelada.currentPlayers})
            </h3>
            <button 
              onClick={() => setShowParticipants(!showParticipants)}
              className="text-green-600 font-medium text-sm"
            >
              {showParticipants ? 'Ocultar' : 'Ver todos'}
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex -space-x-2">
              {pelada.participants.slice(0, 5).map((participant: any, index: number) => (
                <img
                  key={index}
                  src={participant.photo}
                  alt={participant.name}
                  className="w-10 h-10 rounded-full border-2 border-white"
                />
              ))}
              {pelada.currentPlayers > 5 && (
                <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center">
                  <span className="text-xs font-bold text-gray-600">+{pelada.currentPlayers - 5}</span>
                </div>
              )}
            </div>
            
            <div className="text-right">
              <div className="text-sm text-gray-600">
                {pelada.maxPlayers - pelada.currentPlayers} vagas restantes
              </div>
              <div className="w-24 bg-gray-200 rounded-full h-2 mt-1">
                <div 
                  className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${(pelada.currentPlayers / pelada.maxPlayers) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contato</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Phone className="w-5 h-5 text-gray-400 mr-3" />
                <span className="text-gray-700">{pelada.contact}</span>
              </div>
              <button className="bg-green-500 text-white px-4 py-2 rounded-xl font-medium hover:bg-green-600 transition-colors">
                Ligar
              </button>
            </div>
            
            {pelada.whatsapp && (
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <MessageCircle className="w-5 h-5 text-green-500 mr-3" />
                  <span className="text-gray-700">WhatsApp</span>
                </div>
                <button className="bg-green-500 text-white px-4 py-2 rounded-xl font-medium hover:bg-green-600 transition-colors">
                  Conversar
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fixed Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-6">
        {isParticipating ? (
          <div className="space-y-3">
            <div className="flex items-center justify-center text-green-600 mb-2">
              <CheckCircle className="w-5 h-5 mr-2" />
              <span className="font-semibold">Você está participando!</span>
            </div>
            <button
              onClick={handleCancelParticipation}
              className="w-full bg-red-500 text-white py-4 rounded-xl font-semibold text-lg hover:bg-red-600 transition-colors"
            >
              Cancelar Participação
            </button>
          </div>
        ) : canParticipate ? (
          <button
            onClick={handleParticipate}
            className="w-full bg-green-500 text-white py-4 rounded-xl font-semibold text-lg hover:bg-green-600 transition-colors"
          >
            {pelada.type === 'torneio' ? 'Inscrever Time' : 'Confirmar Participação'}
          </button>
        ) : (
          <div className="text-center">
            <div className="flex items-center justify-center text-red-600 mb-2">
              <AlertCircle className="w-5 h-5 mr-2" />
              <span className="font-semibold">
                {pelada.status === 'encerrada' ? 'Evento Encerrado' : 'Evento Lotado'}
              </span>
            </div>
            <button
              disabled
              className="w-full bg-gray-300 text-gray-500 py-4 rounded-xl font-semibold text-lg cursor-not-allowed"
            >
              Não é possível participar
            </button>
          </div>
        )}
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}