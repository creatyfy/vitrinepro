import React, { useState } from 'react';
import { ChevronLeft, HelpCircle, Mail, ChevronDown, ChevronUp, Instagram } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';

interface SupportScreenProps {
  onBack: () => void;
}

interface FAQItem {
  question: string;
  answer: string;
}

export default function SupportScreen({ onBack }: SupportScreenProps) {
  const { t } = useLanguage();
  const { isDarkMode } = useTheme();
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  const faqItems: FAQItem[] = [
    {
      question: "O que é o VITRINE PRO?",
      answer: "O VITRINE PRO é mais do que um aplicativo de treinos — é um sistema inteligente de oportunidades que conecta atletas, clubes, empresários, escolinhas e preparadores físicos em uma única plataforma. O objetivo é permitir que atletas sejam vistos e valorizados pelo seu desempenho real, enquanto clubes e empresários são recompensados por descobrirem e darem oportunidades a esses talentos. Tudo funciona com base em pontuação, mérito e desempenho comprovado por vídeos e treinos validados."
    },
    {
      question: "Como funcionam os treinos do VITRINE PRO?",
      answer: "Os treinos do VITRINE PRO são curtos, dinâmicos e totalmente focados em futebol. Eles são divididos em quatro modalidades:\n\n🏃‍♂️ Treino Livre (somente corpo) – Exercícios com o peso do corpo, voltados para resistência e mobilidade.\n\n🏋️‍♂️ Treino com Material Simples – Usando elástico, cones, degrau, escada ou garrafa.\n\n🏢 Treino na Academia – Foco em força, potência e explosão com uso de máquinas.\n\n🌴 Treino na Areia – Foco em equilíbrio e resistência, ideal para treinos funcionais.\n\nCada vídeo postado é analisado e valida o esforço real do atleta."
    },
    {
      question: "Como funciona o sistema de pontuação?",
      answer: "Cada treino postado passa pelo sistema antitrapassa, que valida se o exercício foi realmente executado. Os atletas que treinam e sobem vídeos ganham pontuações, e quanto mais pontos, mais o perfil é visto por empresários, clubes e escolinhas — aumentando as chances de serem contratados. A pontuação é baseada na qualidade da execução, constância e autenticidade dos treinos. Quanto mais esforço real, mais destaque o atleta recebe."
    },
    {
      question: "Como funciona o sistema antitrapassa?",
      answer: "O sistema antitrapassa é um recurso de validação automática que detecta tentativas de fraude. Ele identifica se o atleta realmente executou o treino, analisando postura, movimentos e autenticidade. Fotos e vídeos falsos são detectados — o sistema reconhece padrões de suor, movimento e contexto. Quanto mais real for o treino (exemplo: atleta suado, executando o exercício corretamente, no ambiente adequado), maior a pontuação e maior a visibilidade do perfil."
    },
    {
      question: "Como o progresso do atleta é salvo?",
      answer: "A cada treino concluído, o sistema atualiza automaticamente o perfil do atleta com as novas pontuações. Quanto mais pontos ele acumula, mais benefícios e níveis ele desbloqueia, ganhando notoriedade e mais chances de ser notado por clubes, empresários e escolinhas. O progresso é salvo de forma contínua e totalmente integrada ao sistema."
    },
    {
      question: "Como usar o VITRINE PRO da forma correta?",
      answer: "Para se destacar, o atleta deve postar com frequência, mostrando evolução, constância e qualidade. Quanto mais vídeos de treinos e conquistas ele sobe — e quanto mais autênticos forem — maior será sua visibilidade na plataforma. Vídeos bem executados, com boa iluminação, esforço real e consistência, aumentam as chances de ser descoberto."
    },
    {
      question: "Quem pode usar o VITRINE PRO?",
      answer: "O VITRINE PRO é aberto para todos os envolvidos com o futebol:\n\n⚽ Atletas – De qualquer nível, que queiram mostrar seu talento e serem descobertos.\n\n🏫 Clubes e Escolinhas – Podem divulgar projetos, monitorar atletas e ganhar notoriedade.\n\n💼 Empresários – Ganham visibilidade nacional ao gerenciar atletas e realizar contratos.\n\n🏋️ Preparadores Físicos e Personais – Podem subir treinos, monitorar progresso e ajudar atletas.\n\n👤 Pessoas comuns – Que apenas desejam treinar e melhorar o condicionamento físico também têm espaço na aba de treinos.\n\nTodos ganham recompensas, visibilidade e oportunidades reais dentro da plataforma."
    },
    {
      question: "Como funciona o sistema de recompensas?",
      answer: "O sistema de recompensas é um dos pilares do VITRINE PRO:\n\n🥇 Atletas ganham bônus de pontuação por completar desafios semanais, medalhas de desempenho e destaque em rankings regionais e nacionais.\n\n🏫 Clubes e Escolinhas ganham notoriedade, visibilidade e benefícios financeiros conforme descobrem novos talentos e divulgam seus projetos.\n\n💼 Empresários aumentam o alcance do próprio perfil e são reconhecidos por descobertas, contratações e bons resultados de atletas gerenciados.\n\nQuanto mais ativa for a participação, mais recompensas são desbloqueadas."
    },
    {
      question: "Como clubes, empresários e escolinhas se conectam com atletas?",
      answer: "A conexão é feita pela aba 'Vitrine'. Lá, clubes e empresários podem visualizar atletas com maior pontuação e desempenho validado. O sistema também envia notificações automáticas quando um atleta se destaca. Da mesma forma, quanto mais o empresário ou clube interage, contrata ou gerencia, mais visibilidade e benefícios ganha dentro da plataforma. Tudo é interligado — quanto mais todos participam, mais o ecossistema cresce."
    },
    {
      question: "Como o VITRINE PRO protege a integridade dos dados?",
      answer: "O sistema antitrapassa e de validação de imagem é 100% seguro. As fotos e vídeos enviados não são públicos — eles são usados apenas para comprovar a autenticidade do treino. O objetivo é validar o esforço real, e não expor o usuário. A privacidade e integridade dos dados são prioridade."
    },
    {
      question: "Quem está por trás do projeto?",
      answer: "O VITRINE PRO é idealizado por Thiago Espíndola, criador do conceito e responsável pela estrutura do sistema."
    }
  ];

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  return (
    <div className={`min-h-screen ${bgClass} pb-8`}>
      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>Ajuda e Suporte</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        <div className="text-center mb-8">
          <div className={`w-16 h-16 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <HelpCircle className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>Central de ajuda e contato</h2>
          <p className={secondaryTextClass}>Tire suas dúvidas sobre o VITRINE PRO</p>
        </div>

        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-6`}>
          <h3 className={`text-xl font-bold ${textClass} mb-6 text-center`}>FAQ – VITRINE PRO</h3>

          <div className="space-y-3">
            {faqItems.map((item, index) => (
              <div key={index} className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl overflow-hidden`}>
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-4 py-4 flex items-center justify-between hover:opacity-80 transition-opacity"
                >
                  <span className={`font-semibold ${textClass} text-left text-sm`}>
                    {index + 1}. {item.question}
                  </span>
                  {expandedFAQ === index ? (
                    <ChevronUp className={`w-5 h-5 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'} flex-shrink-0 ml-2`} />
                  ) : (
                    <ChevronDown className={`w-5 h-5 ${secondaryTextClass} flex-shrink-0 ml-2`} />
                  )}
                </button>

                {expandedFAQ === index && (
                  <div className={`px-4 pb-4 ${secondaryTextClass} text-sm whitespace-pre-line leading-relaxed`}>
                    {item.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-6`}>
          <h3 className={`text-lg font-bold ${textClass} mb-4 text-center`}>Entre em Contato</h3>

          <div className="space-y-4">
            <a
              href="mailto:vitrineprofutebol@gmail.com"
              className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4 flex items-center hover:opacity-80 transition-opacity`}
            >
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mr-4">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className={`font-semibold ${textClass} mb-1`}>Email</h4>
                <p className={`text-sm ${secondaryTextClass}`}>vitrineprofutebol@gmail.com</p>
              </div>
            </a>

            <a
              href="https://instagram.com/thiagoespindolaz"
              target="_blank"
              rel="noopener noreferrer"
              className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4 flex items-center hover:opacity-80 transition-opacity`}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-xl flex items-center justify-center mr-4">
                <Instagram className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className={`font-semibold ${textClass} mb-1`}>Instagram</h4>
                <p className={`text-sm ${secondaryTextClass}`}>@thiagoespindolaz</p>
              </div>
            </a>
          </div>

          <div className={`mt-6 pt-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
            <p className={`text-center ${secondaryTextClass} text-sm mb-2`}>
              Criado por
            </p>
            <p className={`text-center ${textClass} font-bold text-lg`}>
              Thiago Espíndola
            </p>
            <p className={`text-center ${secondaryTextClass} text-xs mt-2`}>
              Idealizador e responsável pela estrutura do VITRINE PRO
            </p>
          </div>
        </div>
      </div>

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}
