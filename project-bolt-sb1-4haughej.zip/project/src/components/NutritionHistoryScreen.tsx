import React, { useState, useEffect, useMemo } from 'react';
import { X, Calendar, TrendingUp, Award, Image as ImageIcon, BarChart3, Trophy, Flame } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface MealHistory {
  id: string;
  date: string;
  meal_type: string;
  points_earned: number;
  quality_score: number;
  notes: string;
  submission_id: string | null;
}

interface NutritionStats {
  current_level: number;
  total_nutrition_points: number;
  current_streak: number;
  longest_streak: number;
  meals_completed: number;
  quality_average: number;
}

interface Submission {
  photo_url: string;
  verification_status: string;
}

interface NutritionHistoryScreenProps {
  userId: string;
  onBack: () => void;
}

export default function NutritionHistoryScreen({ userId, onBack }: NutritionHistoryScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [loading, setLoading] = useState(true);
  const [history, setHistory] = useState<MealHistory[]>([]);
  const [stats, setStats] = useState<NutritionStats | null>(null);
  const [submissions, setSubmissions] = useState<Record<string, Submission>>({});
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month'>('week');

  const styles = useMemo(() => ({
    container: { backgroundColor: theme.surface },
    header: { backgroundColor: theme.surface, borderColor: theme.border },
    card: { backgroundColor: theme.surfaceAlt, borderColor: theme.border },
    textPrimary: { color: theme.textPrimary },
    textSecondary: { color: theme.textSecondary },
    textInverse: { color: theme.textInverse },
    icon: { color: theme.icon },
    accent: { backgroundColor: theme.accent, color: theme.textInverse },
    accentText: { color: theme.accent },
    border: { borderColor: theme.border }
  }), [themeVersion, theme]);

  useEffect(() => {
    loadData();
  }, [userId, selectedPeriod]);

  async function loadData() {
    try {
      setLoading(true);

      const daysAgo = selectedPeriod === 'week' ? 7 : 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      const { data: historyData, error: historyError } = await supabase
        .from('athlete_meal_history')
        .select('*')
        .eq('user_id', userId)
        .gte('date', startDate.toISOString().split('T')[0])
        .order('date', { ascending: false });

      if (historyError) throw historyError;

      const { data: statsData, error: statsError } = await supabase
        .from('athlete_nutrition_stats')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (statsError) throw statsError;

      setHistory(historyData || []);
      setStats(statsData || {
        current_level: 1,
        total_nutrition_points: 0,
        current_streak: 0,
        longest_streak: 0,
        meals_completed: 0,
        quality_average: 0
      });

      const submissionIds = historyData
        ?.filter(h => h.submission_id)
        .map(h => h.submission_id) || [];

      if (submissionIds.length > 0) {
        const { data: submissionsData } = await supabase
          .from('nutrition_submissions')
          .select('id, photo_url, verification_status')
          .in('id', submissionIds);

        const submissionsMap: Record<string, Submission> = {};
        submissionsData?.forEach(sub => {
          submissionsMap[sub.id] = sub;
        });
        setSubmissions(submissionsMap);
      }

    } catch (err) {
      console.error('Erro ao carregar histórico:', err);
    } finally {
      setLoading(false);
    }
  }

  function getQualityColor(score: number): string {
    if (score >= 80) return theme.success;
    if (score >= 60) return theme.warning;
    return theme.error;
  }

  function getProgressToNextLevel(): number {
    if (!stats) return 0;
    const pointsInCurrentLevel = stats.total_nutrition_points % 1000;
    return (pointsInCurrentLevel / 1000) * 100;
  }

  function formatDate(dateStr: string): string {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Histórico</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 p-6 space-y-4">
          <div className="h-40 rounded-2xl animate-pulse" style={{ backgroundColor: theme.border }} />
          <div className="h-32 rounded-2xl animate-pulse" style={{ backgroundColor: theme.border }} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      <div className="sticky top-0 z-20 border-b" style={{ ...styles.header, ...styles.border }}>
        <div className="flex items-center justify-between p-4">
          <button onClick={onBack} className="p-2 rounded-lg transition-all active:scale-95">
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>Histórico de Alimentação</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {stats && (
          <>
            <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-3xl font-bold mb-1" style={styles.textPrimary}>
                    Nível {stats.current_level}
                  </h2>
                  <p className="text-sm" style={styles.textSecondary}>
                    {stats.total_nutrition_points} pontos totais
                  </p>
                </div>
                <Trophy className="w-12 h-12" style={{ color: theme.warning }} />
              </div>
              <div className="relative w-full h-3 rounded-full overflow-hidden" style={{ backgroundColor: theme.border }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    backgroundColor: theme.accent,
                    width: `${getProgressToNextLevel()}%`
                  }}
                />
              </div>
              <p className="text-xs mt-2 text-center" style={styles.textSecondary}>
                {1000 - (stats.total_nutrition_points % 1000)} pontos para o próximo nível
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-xl p-4 border text-center" style={{ ...styles.card, ...styles.border }}>
                <Flame className="w-8 h-8 mx-auto mb-2" style={{ color: theme.warning }} />
                <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                  {stats.current_streak}
                </div>
                <div className="text-xs" style={styles.textSecondary}>Sequência atual</div>
              </div>
              <div className="rounded-xl p-4 border text-center" style={{ ...styles.card, ...styles.border }}>
                <Award className="w-8 h-8 mx-auto mb-2" style={styles.accentText} />
                <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                  {stats.longest_streak}
                </div>
                <div className="text-xs" style={styles.textSecondary}>Melhor sequência</div>
              </div>
            </div>

            <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold" style={styles.textPrimary}>Alimentação Saudável</h3>
                <div className="text-2xl font-bold" style={{ color: getQualityColor(stats.quality_average) }}>
                  {stats.quality_average.toFixed(0)}%
                </div>
              </div>
              <div className="relative w-full h-4 rounded-full overflow-hidden" style={{ backgroundColor: theme.border }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    backgroundColor: getQualityColor(stats.quality_average),
                    width: `${stats.quality_average}%`
                  }}
                />
              </div>
              <div className="flex justify-between text-xs mt-2" style={styles.textSecondary}>
                <span>Ruim</span>
                <span>Médio</span>
                <span>Excelente</span>
              </div>
            </div>

            <div className="rounded-xl p-4 border text-center" style={{ ...styles.card, ...styles.border }}>
              <BarChart3 className="w-8 h-8 mx-auto mb-2" style={styles.accentText} />
              <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                {stats.meals_completed}
              </div>
              <div className="text-sm" style={styles.textSecondary}>Refeições completadas</div>
            </div>
          </>
        )}

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold" style={styles.textPrimary}>Histórico Recente</h3>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedPeriod('week')}
                className="px-4 py-2 rounded-lg text-sm font-semibold transition-all active:scale-95"
                style={selectedPeriod === 'week' ? styles.accent : { backgroundColor: theme.border, color: theme.textSecondary }}
              >
                Semana
              </button>
              <button
                onClick={() => setSelectedPeriod('month')}
                className="px-4 py-2 rounded-lg text-sm font-semibold transition-all active:scale-95"
                style={selectedPeriod === 'month' ? styles.accent : { backgroundColor: theme.border, color: theme.textSecondary }}
              >
                Mês
              </button>
            </div>
          </div>

          {history.length === 0 ? (
            <div className="rounded-2xl p-8 text-center border" style={{ ...styles.card, ...styles.border }}>
              <Calendar className="w-16 h-16 mx-auto mb-4" style={styles.icon} />
              <p className="font-semibold mb-2" style={styles.textPrimary}>Nenhum registro ainda</p>
              <p className="text-sm" style={styles.textSecondary}>
                Complete desafios nutricionais para ver seu histórico aqui
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map((item) => {
                const submission = item.submission_id ? submissions[item.submission_id] : null;
                return (
                  <div key={item.id} className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Calendar className="w-4 h-4" style={styles.icon} />
                          <span className="text-sm font-medium" style={styles.textPrimary}>
                            {formatDate(item.date)}
                          </span>
                        </div>
                        <p className="text-lg font-bold mb-1" style={styles.textPrimary}>
                          {item.notes || 'Refeição registrada'}
                        </p>
                        {item.meal_type && (
                          <p className="text-sm" style={styles.textSecondary}>
                            Tipo: {item.meal_type.replace('_', ' ')}
                          </p>
                        )}
                      </div>
                      {submission && submission.photo_url && (
                        <button
                          onClick={() => window.open(submission.photo_url, '_blank')}
                          className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 transition-all active:scale-95"
                          style={{ backgroundColor: theme.border }}
                        >
                          <img
                            src={submission.photo_url}
                            alt="Foto da refeição"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg p-3 text-center" style={{ backgroundColor: theme.surface }}>
                        <Award className="w-5 h-5 mx-auto mb-1" style={styles.accentText} />
                        <div className="text-lg font-bold" style={styles.textPrimary}>
                          +{item.points_earned}
                        </div>
                        <div className="text-xs" style={styles.textSecondary}>Pontos</div>
                      </div>
                      <div className="rounded-lg p-3 text-center" style={{ backgroundColor: theme.surface }}>
                        <TrendingUp className="w-5 h-5 mx-auto mb-1" style={{ color: getQualityColor(item.quality_score) }} />
                        <div className="text-lg font-bold" style={styles.textPrimary}>
                          {item.quality_score}%
                        </div>
                        <div className="text-xs" style={styles.textSecondary}>Qualidade</div>
                      </div>
                    </div>

                    {submission && submission.verification_status && (
                      <div className="mt-4 pt-4 border-t" style={styles.border}>
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{
                              backgroundColor:
                                submission.verification_status === 'approved'
                                  ? theme.success
                                  : submission.verification_status === 'pending'
                                  ? theme.warning
                                  : theme.error
                            }}
                          />
                          <span className="text-xs font-medium" style={styles.textSecondary}>
                            {submission.verification_status === 'approved'
                              ? 'Aprovado'
                              : submission.verification_status === 'pending'
                              ? 'Em análise'
                              : 'Não aprovado'}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
