import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Upload, Play, Trash2, X } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { uploadVideo, deleteVideo, logTelemetry, VideoUploadProgress } from '../utils/videoUtils';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface Video {
  id: string;
  poster_url: string;
  hls_url: string;
  duration_seconds: number;
  created_at: string;
  title?: string;
  description?: string;
}

interface VideoGalleryScreenProps {
  userId: string;
  onBack: () => void;
}

export default function VideoGalleryScreen({ userId, onBack }: VideoGalleryScreenProps) {
  const { tokens } = useTheme();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<VideoUploadProgress | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const lastVideoRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    loadVideos();
    logTelemetry(userId, 'videos_tab_opened');
  }, []);

  useEffect(() => {
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore && !loading) {
        setPage((prev) => prev + 1);
      }
    });

    if (lastVideoRef.current) {
      observerRef.current.observe(lastVideoRef.current);
    }

    return () => observerRef.current?.disconnect();
  }, [hasMore, loading]);

  useEffect(() => {
    if (page > 0) {
      loadMoreVideos();
    }
  }, [page]);

  async function loadVideos() {
    try {
      const { data, error } = await supabase
        .from('player_videos')
        .select('*')
        .eq('user_id', userId)
        .is('deleted_at', null)
        .eq('status', 'ready')
        .order('created_at', { ascending: false })
        .range(0, 17);

      if (error) throw error;

      setVideos(data || []);
      setHasMore((data || []).length === 18);
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadMoreVideos() {
    try {
      const start = page * 18;
      const end = start + 17;

      const { data, error } = await supabase
        .from('player_videos')
        .select('*')
        .eq('user_id', userId)
        .is('deleted_at', null)
        .eq('status', 'ready')
        .order('created_at', { ascending: false })
        .range(start, end);

      if (error) throw error;

      setVideos((prev) => [...prev, ...(data || [])]);
      setHasMore((data || []).length === 18);
    } catch (error) {
      console.error('Error loading more videos:', error);
    }
  }

  async function handleFileSelect(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    await logTelemetry(userId, 'video_upload_started', { source: 'gallery' });

    const videoId = await uploadVideo(file, userId, 'gallery', (progress) => {
      setUploadProgress(progress);
    });

    if (videoId) {
      await loadVideos();
    }

    setUploading(false);
    setUploadProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  async function handleDeleteVideo(videoId: string) {
    if (!confirm('Deseja excluir este vídeo? Se foi enviado há menos de 24h, os pontos serão revertidos.')) {
      return;
    }

    const success = await deleteVideo(videoId, userId);
    if (success) {
      setVideos((prev) => prev.filter((v) => v.id !== videoId));
      setSelectedVideo(null);
    }
  }

  function formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: tokens.surface }}
    >
      <div
        className="sticky top-0 z-10 flex items-center p-4 border-b"
        style={{
          backgroundColor: tokens.surface,
          borderColor: tokens.border
        }}
      >
        <button
          onClick={onBack}
          className="p-2 rounded-lg transition-colors"
          style={{ color: tokens.icon }}
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1
          className="flex-1 text-xl font-bold text-center"
          style={{ color: tokens.textPrimary }}
        >
          Meus Vídeos
        </h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 p-4">
        <div className="mb-4 flex items-center justify-between">
          <p style={{ color: tokens.textSecondary }}>
            {videos.length} {videos.length === 1 ? 'vídeo' : 'vídeos'}
          </p>
          <p
            className="text-sm"
            style={{ color: tokens.textSecondary }}
          >
            Envie vídeos do seu treino/jogos para ganhar pontos
          </p>
        </div>

        {uploading && uploadProgress && (
          <div
            className="mb-4 p-4 rounded-lg"
            style={{ backgroundColor: tokens.surfaceAlt }}
          >
            <div className="flex items-center justify-between mb-2">
              <span style={{ color: tokens.textPrimary }}>
                {uploadProgress.status === 'queued' && 'Preparando...'}
                {uploadProgress.status === 'uploading' && 'Enviando...'}
                {uploadProgress.status === 'processing' && 'Processando...'}
                {uploadProgress.status === 'ready' && 'Pronto!'}
                {uploadProgress.status === 'failed' && 'Erro'}
              </span>
              <span style={{ color: tokens.textSecondary }}>
                {uploadProgress.progress}%
              </span>
            </div>
            <div
              className="w-full h-2 rounded-full overflow-hidden"
              style={{ backgroundColor: tokens.border }}
            >
              <div
                className="h-full transition-all duration-300"
                style={{
                  width: `${uploadProgress.progress}%`,
                  backgroundColor: tokens.accent
                }}
              />
            </div>
            {uploadProgress.error && (
              <p className="mt-2 text-sm text-red-500">
                {uploadProgress.error}
              </p>
            )}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-3 gap-2">
            {[...Array(9)].map((_, i) => (
              <div
                key={i}
                className="aspect-square rounded-lg animate-pulse"
                style={{ backgroundColor: tokens.surfaceAlt }}
              />
            ))}
          </div>
        ) : videos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
              style={{ backgroundColor: tokens.surfaceAlt }}
            >
              <Upload className="w-10 h-10" style={{ color: tokens.icon }} />
            </div>
            <p
              className="text-lg font-semibold mb-2"
              style={{ color: tokens.textPrimary }}
            >
              Nenhum vídeo ainda
            </p>
            <p
              className="text-center mb-6"
              style={{ color: tokens.textSecondary }}
            >
              Envie vídeos dos seus treinos e jogos para ganhar 20 pontos por vídeo
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {videos.map((video, index) => (
              <div
                key={video.id}
                ref={index === videos.length - 1 ? lastVideoRef : null}
                className="relative aspect-square rounded-lg overflow-hidden cursor-pointer"
                onClick={() => setSelectedVideo(video)}
                style={{ backgroundColor: tokens.surfaceAlt }}
              >
                <img
                  src={video.poster_url}
                  alt="Video thumbnail"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                  <Play
                    className="w-10 h-10 text-white"
                    fill="white"
                  />
                </div>
                <div
                  className="absolute bottom-2 right-2 px-2 py-1 rounded text-xs font-semibold"
                  style={{
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    color: 'white'
                  }}
                >
                  {formatDuration(video.duration_seconds)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={uploading}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-transform active:scale-95"
        style={{
          backgroundColor: tokens.accent,
          opacity: uploading ? 0.5 : 1
        }}
      >
        <Upload className="w-6 h-6" style={{ color: tokens.textInverse }} />
      </button>

      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/quicktime"
        onChange={handleFileSelect}
        className="hidden"
      />

      {selectedVideo && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.9)' }}
          onClick={() => setSelectedVideo(null)}
        >
          <div
            className="relative w-full max-w-2xl rounded-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            style={{ backgroundColor: tokens.surface }}
          >
            <button
              onClick={() => setSelectedVideo(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full"
              style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
            >
              <X className="w-6 h-6 text-white" />
            </button>

            <video
              src={selectedVideo.hls_url}
              controls
              autoPlay
              className="w-full"
              style={{ maxHeight: '70vh' }}
            />

            <div className="p-4">
              {selectedVideo.title && (
                <h3
                  className="text-lg font-semibold mb-2"
                  style={{ color: tokens.textPrimary }}
                >
                  {selectedVideo.title}
                </h3>
              )}
              {selectedVideo.description && (
                <p
                  className="mb-4"
                  style={{ color: tokens.textSecondary }}
                >
                  {selectedVideo.description}
                </p>
              )}
              <div className="flex items-center justify-between">
                <span
                  className="text-sm"
                  style={{ color: tokens.textSecondary }}
                >
                  {new Date(selectedVideo.created_at).toLocaleDateString('pt-BR')}
                </span>
                <button
                  onClick={() => handleDeleteVideo(selectedVideo.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors"
                  style={{
                    backgroundColor: tokens.surfaceAlt,
                    color: tokens.textPrimary
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                  Excluir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
