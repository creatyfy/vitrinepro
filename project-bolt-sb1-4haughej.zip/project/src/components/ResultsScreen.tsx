import React from 'react';
import { ChevronLeft, Trophy } from 'lucide-react';

interface ResultsScreenProps {
  onNext: () => void;
  onBack: () => void;
}

export default function ResultsScreen({ onNext, onBack }: ResultsScreenProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">
            Você tem um grande potencial para alcançar seu objetivo
          </h1>
        </div>

        {/* Chart Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
          <div className="relative h-64 mb-6">
            {/* Chart Background */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-50 to-yellow-100 rounded-lg"></div>
            
            {/* Chart Line */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 200">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="60" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 60 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="2,2"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
              
              {/* Progress line */}
              <path
                d="M 30 160 Q 90 140 150 120 Q 210 80 270 40"
                fill="none"
                stroke="#374151"
                strokeWidth="3"
                strokeLinecap="round"
              />
              
              {/* Data points */}
              <circle cx="30" cy="160" r="4" fill="white" stroke="#374151" strokeWidth="2"/>
              <circle cx="150" cy="120" r="4" fill="white" stroke="#374151" strokeWidth="2"/>
              <circle cx="270" cy="40" r="4" fill="white" stroke="#374151" strokeWidth="2"/>
              
              {/* Trophy icon at the end */}
              <g transform="translate(260, 25)">
                <circle cx="10" cy="15" r="15" fill="#f59e0b"/>
                <Trophy className="w-5 h-5 text-white" x="2.5" y="7.5"/>
              </g>
            </svg>
            
            {/* Time labels */}
            <div className="absolute bottom-2 left-6 text-sm font-medium text-gray-700">3 Dias</div>
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-sm font-medium text-gray-700">7 Dias</div>
            <div className="absolute bottom-2 right-6 text-sm font-medium text-gray-700">30 Dias</div>
          </div>
          
          <p className="text-gray-600 text-center leading-relaxed">
            Com base nos dados históricos do Vitrine Pro, você tem um padrão de atleta. 
            Em poucos dias você consegue se condicionar rapidamente!
          </p>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}