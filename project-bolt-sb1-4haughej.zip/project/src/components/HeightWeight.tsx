import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';

interface HeightWeightProps {
  selectedHeight: number;
  selectedWeight: number;
  onHeightSelect: (height: number) => void;
  onWeightSelect: (weight: number) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function HeightWeight({ 
  selectedHeight, 
  selectedWeight, 
  onHeightSelect, 
  onWeightSelect, 
  onNext, 
  onBack 
}: HeightWeightProps) {
  const heightScrollRef = useRef<HTMLDivElement>(null);
  const weightScrollRef = useRef<HTMLDivElement>(null);

  // Gerar valores de altura (150cm a 200cm)
  const heights = Array.from({ length: 51 }, (_, i) => 150 + i);
  
  // Gerar valores de peso (40kg a 120kg)
  const weights = Array.from({ length: 81 }, (_, i) => 40 + i);

  const scrollToValue = (containerRef: React.RefObject<HTMLDivElement>, value: number, values: number[]) => {
    if (containerRef.current) {
      const index = values.indexOf(value);
      const itemHeight = 60; // altura de cada item
      const containerHeight = containerRef.current.clientHeight;
      const scrollTop = index * itemHeight;
      
      containerRef.current.scrollTo({
        top: scrollTop,
        behavior: 'auto'
      });
    }
  };

  useEffect(() => {
    if (selectedHeight && heightScrollRef.current) {
      scrollToValue(heightScrollRef, selectedHeight, heights);
    }
  }, []);

  useEffect(() => {
    if (selectedWeight && weightScrollRef.current) {
      scrollToValue(weightScrollRef, selectedWeight, weights);
    }
  }, []);

  const handleHeightScroll = () => {
    if (heightScrollRef.current) {
      const scrollTop = heightScrollRef.current.scrollTop;
      const itemHeight = 60;
      const centerIndex = Math.round(scrollTop / itemHeight);
      const clampedIndex = Math.max(0, Math.min(centerIndex, heights.length - 1));
      onHeightSelect(heights[clampedIndex]);
    }
  };

  const handleWeightScroll = () => {
    if (weightScrollRef.current) {
      const scrollTop = weightScrollRef.current.scrollTop;
      const itemHeight = 60;
      const centerIndex = Math.round(scrollTop / itemHeight);
      const clampedIndex = Math.max(0, Math.min(centerIndex, weights.length - 1));
      onWeightSelect(weights[clampedIndex]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Altura & Peso
          </h1>
          <p className="text-gray-600 text-lg">
            Isso será usado para calibrar seu plano personalizado
          </p>
        </div>

        {/* Height and Weight Selectors */}
        <div className="flex justify-between items-center mb-12">
          {/* Height Selector */}
          <div className="flex-1 mr-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Altura (cm)
            </h3>
            <div className="relative">
              <div 
                ref={heightScrollRef}
                onScroll={handleHeightScroll}
                className="h-80 overflow-y-scroll scrollbar-hide snap-y snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div>
                  {heights.map((height) => (
                    <div
                      key={height}
                      className={`h-15 flex items-center justify-center text-2xl font-medium transition-all duration-200 snap-start ${
                        selectedHeight === height
                          ? 'text-gray-900 font-bold scale-110'
                          : 'text-gray-400'
                      }`}
                      style={{ height: '60px' }}
                    >
                      {height} cm
                    </div>
                  ))}
                </div>
              </div>
              {/* Selection line indicator */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500 pointer-events-none z-10"></div>
            </div>
          </div>

          {/* Weight Selector */}
          <div className="flex-1 ml-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Peso (kg)
            </h3>
            <div className="relative">
              <div 
                ref={weightScrollRef}
                onScroll={handleWeightScroll}
                className="h-80 overflow-y-scroll scrollbar-hide snap-y snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div>
                  {weights.map((weight) => (
                    <div
                      key={weight}
                      className={`h-15 flex items-center justify-center text-2xl font-medium transition-all duration-200 snap-start ${
                        selectedWeight === weight
                          ? 'text-gray-900 font-bold scale-110'
                          : 'text-gray-400'
                      }`}
                      style={{ height: '60px' }}
                    >
                      {weight} kg
                    </div>
                  ))}
                </div>
              </div>
              {/* Selection line indicator */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500 pointer-events-none z-10"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedHeight || !selectedWeight}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedHeight && selectedWeight
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}