import React, { useState, useEffect, useRef } from 'react';
import { X, Volume2, VolumeX, Maximize, ChevronDown, HelpCircle } from 'lucide-react';
import UniversalAntiCheatVerification from './UniversalAntiCheatVerification';
import type { Exercise, ExerciseVariant } from '../data/weeklyTrainingData';
import { saveTrainingProgress, getTrainingProgress, deleteTrainingProgress, TrainingProgress } from '../utils/trainingProgress';

interface ExerciseExecutionScreenProps {
  exercise: Exercise;
  variant: ExerciseVariant;
  isDarkMode: boolean;
  onComplete: () => void;
  onExit: () => void;
}

type Phase = 'prep' | 'active' | 'rest' | 'verification';

export default function ExerciseExecutionScreen({
  exercise,
  variant,
  isDarkMode,
  onComplete,
  onExit
}: ExerciseExecutionScreenProps) {
  const [phase, setPhase] = useState<Phase>('prep');
  const [prepTimer, setPrepTimer] = useState(10);
  const [restTimer, setRestTimer] = useState(10);
  const [currentSet, setCurrentSet] = useState(1);
  const [timerKey, setTimerKey] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [savedProgress, setSavedProgress] = useState<TrainingProgress | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const totalSets = parseInt(variant.sets);

  useEffect(() => {
    if (phase === 'prep' && prepTimer > 0) {
      const timer = setTimeout(() => {
        setPrepTimer(prepTimer - 1);
        setTimerKey(prev => prev + 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'prep' && prepTimer === 0) {
      handleStartExercise();
    }
  }, [phase, prepTimer]);

  useEffect(() => {
    if (phase === 'rest' && restTimer > 0) {
      const timer = setTimeout(() => {
        setRestTimer(restTimer - 1);
        setTimerKey(prev => prev + 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'rest' && restTimer === 0) {
      handleNextSet();
    }
  }, [phase, restTimer]);

  useEffect(() => {
    if (videoRef.current) {
      if (phase === 'prep' || phase === 'active') {
        videoRef.current.play().catch(err => console.log('Video play error:', err));
      } else if (phase === 'rest') {
        videoRef.current.pause();
      }
    }
  }, [phase]);

  useEffect(() => {
    const checkForSavedProgress = async () => {
      const progress = await getTrainingProgress('exercise', exercise.id);
      if (progress) {
        setSavedProgress(progress);
        setCurrentSet(progress.progress_data?.currentSet || 1);
        if (progress.is_resting) {
          setPhase('rest');
          setRestTimer(progress.rest_timer_remaining);
        }
      }
    };
    checkForSavedProgress();
  }, [exercise.id]);

  useEffect(() => {
    const interval = setInterval(async () => {
      if (phase !== 'verification') {
        await saveTrainingProgress({
          training_type: 'exercise',
          training_id: exercise.id,
          exercise_id: exercise.id,
          current_exercise_index: currentSet - 1,
          total_exercises: totalSets,
          timer_remaining: phase === 'prep' ? prepTimer : 0,
          is_resting: phase === 'rest',
          rest_timer_remaining: restTimer,
          progress_data: {
            currentSet,
            totalSets,
            exerciseName: exercise.name
          }
        });
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [exercise.id, exercise.name, currentSet, totalSets, phase, prepTimer, restTimer]);

  const handleStartExercise = () => {
    setPhase('active');
  };

  const handleSkipPrep = () => {
    setPrepTimer(0);
    setPhase('active');
  };

  const handleCompleteSet = () => {
    if (currentSet < totalSets) {
      setCurrentSet(prev => prev + 1);
      setPhase('rest');
      setRestTimer(10);
      setTimerKey(prev => prev + 1);
    } else {
      setPhase('verification');
    }
  };

  const handleNextSet = () => {
    setPhase('active');
    setPrepTimer(10);
  };

  const handleSkipRest = () => {
    setRestTimer(0);
    setPhase('active');
  };

  const handleExtendRest = () => {
    setRestTimer(prev => prev + 20);
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleExit = async () => {
    await saveTrainingProgress({
      training_type: 'exercise',
      training_id: exercise.id,
      exercise_id: exercise.id,
      current_exercise_index: currentSet - 1,
      total_exercises: totalSets,
      timer_remaining: phase === 'prep' ? prepTimer : 0,
      is_resting: phase === 'rest',
      rest_timer_remaining: restTimer,
      progress_data: {
        currentSet,
        totalSets,
        exerciseName: exercise.name
      }
    });
    onExit();
  };

  const handleVerificationComplete = async () => {
    if (savedProgress?.id) {
      await deleteTrainingProgress(savedProgress.id);
    }
    onComplete();
  };

  if (phase === 'verification') {
    return (
      <UniversalAntiCheatVerification
        sessionId={`exercise-${exercise.id}-${Date.now()}`}
        isDarkMode={isDarkMode}
        onComplete={(points) => {
          console.log('Exercise completed with points:', points);
          handleVerificationComplete();
        }}
        onSkip={() => {
          console.log('Exercise verification skipped');
          handleVerificationComplete();
        }}
      />
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden bg-black"
    >
      <video
        ref={videoRef}
        src={variant.video_url}
        className="absolute inset-0 w-full h-full object-cover"
        loop
        muted={isMuted}
        playsInline
        autoPlay
      />

      <div
        className="absolute inset-0 bg-black transition-opacity duration-300"
        style={{ opacity: phase === 'active' ? 0.3 : 0.45 }}
      />

      <div className="relative z-10 h-full flex flex-col">
        <div className="flex items-start justify-between p-4 pt-12">
          <button
            onClick={handleExit}
            className="w-12 h-12 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
            aria-label="Sair do treino"
          >
            <X className="w-6 h-6 text-white" />
          </button>

          <div className="flex items-center gap-2">
            {Array.from({ length: totalSets }).map((_, idx) => (
              <div
                key={idx}
                className={`h-1 rounded-full transition-all ${
                  idx < currentSet - 1 ? 'w-8 bg-white' :
                  idx === currentSet - 1 ? 'w-12 bg-white' :
                  'w-8 bg-white/30'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {currentSet < totalSets && (
              <div className="text-right mr-2">
                <div className="text-white font-semibold text-sm">Próximo</div>
                <div className="text-white/70 text-xs">Série {currentSet + 1}</div>
              </div>
            )}

            <button
              onClick={handleToggleFullscreen}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
              aria-label="Tela cheia"
            >
              <Maximize className="w-5 h-5 text-white" />
            </button>

            <button
              onClick={handleToggleMute}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
              aria-label={isMuted ? "Ativar som" : "Silenciar"}
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
            </button>

            <button
              onClick={() => setShowMenu(!showMenu)}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
              aria-label="Menu"
            >
              <ChevronDown className={`w-5 h-5 text-white transition-transform ${showMenu ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </div>

        {showMenu && (
          <div className="absolute top-20 right-4 bg-black/90 backdrop-blur-sm rounded-2xl p-4 min-w-[200px] z-20">
            <div className="text-white text-sm space-y-3">
              <div className="pb-2 border-b border-white/20">
                <p className="font-semibold mb-1">Instruções</p>
                <p className="text-white/70 text-xs">{variant.instructions}</p>
              </div>
              <div className="pb-2 border-b border-white/20">
                <p className="font-semibold mb-1">Dicas</p>
                <p className="text-white/70 text-xs">{variant.notes}</p>
              </div>
              <div>
                <p className="font-semibold mb-1">Detalhes</p>
                <p className="text-white/70 text-xs">Repetições: {variant.reps}</p>
                <p className="text-white/70 text-xs">Séries: {variant.sets}</p>
                <p className="text-white/70 text-xs">Descanso: {variant.rest}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col items-center justify-center px-6">
          {phase === 'prep' && (
            <>
              <h1 className="text-white text-2xl font-semibold tracking-wider mb-8 text-center">
                PREPARADO PARA COMEÇAR
              </h1>
              <div
                key={timerKey}
                className="text-white font-extrabold mb-8 leading-none animate-timer-explosion"
                style={{ fontSize: 'clamp(120px, 20vw, 180px)' }}
                aria-live="polite"
                aria-label={`${prepTimer} segundos para começar`}
              >
                {prepTimer}
              </div>
              <div className="text-white/90 text-lg font-medium mb-2">
                Exercício 1/1
              </div>
              <div className="flex items-center gap-2 text-white text-2xl font-bold mb-12 text-center">
                {exercise.name}
                <HelpCircle className="w-6 h-6 text-white/70" />
              </div>
              <button
                onClick={handleSkipPrep}
                className="bg-white/92 hover:bg-white text-gray-900 px-16 py-4 rounded-full text-xl font-bold shadow-lg transition-all active:scale-95"
                style={{ minHeight: '64px' }}
              >
                Início!
              </button>
            </>
          )}

          {phase === 'active' && (
            <>
              <div className="absolute bottom-32 left-6">
                <div className="bg-black/60 backdrop-blur-sm px-6 py-3 rounded-full">
                  <div className="text-white text-sm font-medium">
                    Série {currentSet}/{totalSets}
                  </div>
                </div>
              </div>

              <div className="absolute bottom-8 w-full px-6">
                <button
                  onClick={handleCompleteSet}
                  className="w-full bg-white/92 hover:bg-white text-gray-900 py-5 rounded-full text-xl font-bold shadow-lg transition-all active:scale-95"
                >
                  {currentSet === totalSets ? 'Finalizar!' : 'Próxima Série'}
                </button>
              </div>
            </>
          )}

          {phase === 'rest' && (
            <>
              <h1 className="text-white text-2xl font-semibold tracking-wider mb-8">
                DESCANSO
              </h1>
              <div
                key={timerKey}
                className="text-white font-extrabold mb-8 leading-none animate-timer-explosion"
                style={{ fontSize: 'clamp(120px, 20vw, 180px)' }}
                aria-live="polite"
                aria-label={`${restTimer} segundos de descanso`}
              >
                {restTimer}
              </div>
              <div className="text-white/90 text-lg font-medium mb-12">
                Próxima: Série {currentSet}/{totalSets}
              </div>
              <div className="flex gap-4">
                <button
                  onClick={handleExtendRest}
                  className="bg-white/20 hover:bg-white/30 text-white px-8 py-3 rounded-full font-semibold transition-all"
                >
                  +20s
                </button>
                <button
                  onClick={handleSkipRest}
                  className="bg-white/92 hover:bg-white text-gray-900 px-8 py-3 rounded-full font-semibold transition-all"
                >
                  Pular Descanso
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <style>{`
        @keyframes timer-explosion {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.1);
            opacity: 0.8;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }

        .animate-timer-explosion {
          animation: timer-explosion 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
