import React, { useState, useEffect, useMemo } from 'react';
import { X, Target, TrendingUp, Zap, Award, ChefHat, Clock, Flame, Crown } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface MealPlan {
  id: string;
  name: string;
  goal: string;
  description: string;
  is_pro: boolean;
  daily_calories: number;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
}

interface MealPlanItem {
  id: string;
  meal_type: string;
  meal_order: number;
  foods: string[];
  time_range: string;
  alternatives: string[];
  calories: number;
}

interface NutritionMealPlansScreenProps {
  userId: string;
  onBack: () => void;
}

const GOAL_INFO: Record<string, { icon: any; color: string; description: string }> = {
  ganho_massa: {
    icon: TrendingUp,
    color: 'bg-green-500',
    description: 'Maximize o ganho de massa muscular com alto teor proteico e calórico'
  },
  definicao: {
    icon: Target,
    color: 'bg-blue-500',
    description: 'Reduza gordura mantendo massa muscular com déficit calórico controlado'
  },
  resistencia: {
    icon: Zap,
    color: 'bg-yellow-500',
    description: 'Energia sustentada para performance em treinos de alta intensidade'
  },
  manutencao: {
    icon: Award,
    color: 'bg-gray-500',
    description: 'Mantenha seu peso ideal com alimentação balanceada e saudável'
  }
};

const MEAL_TYPE_NAMES: Record<string, string> = {
  cafe_manha: 'Café da Manhã',
  lanche_manha: 'Lanche da Manhã',
  almoco: 'Almoço',
  lanche_tarde: 'Lanche da Tarde',
  pre_treino: 'Pré-Treino',
  pos_treino: 'Pós-Treino',
  jantar: 'Jantar'
};

const MEAL_TYPE_ICONS: Record<string, string> = {
  cafe_manha: '🌅',
  lanche_manha: '🍎',
  almoco: '🍽️',
  lanche_tarde: '🥤',
  pre_treino: '⚡',
  pos_treino: '💪',
  jantar: '🌙'
};

export default function NutritionMealPlansScreen({ userId, onBack }: NutritionMealPlansScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [loading, setLoading] = useState(true);
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<MealPlan | null>(null);
  const [planItems, setPlanItems] = useState<MealPlanItem[]>([]);
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [recommendations, setRecommendations] = useState<any[]>([]);

  const styles = useMemo(() => ({
    container: { backgroundColor: theme.surface },
    header: { backgroundColor: theme.surface, borderColor: theme.border },
    card: { backgroundColor: theme.surfaceAlt, borderColor: theme.border },
    textPrimary: { color: theme.textPrimary },
    textSecondary: { color: theme.textSecondary },
    textInverse: { color: theme.textInverse },
    icon: { color: theme.icon },
    accent: { backgroundColor: theme.accent, color: theme.textInverse },
    accentText: { color: theme.accent },
    border: { borderColor: theme.border }
  }), [themeVersion, theme]);

  useEffect(() => {
    loadMealPlans();
    loadRecommendations();
  }, []);

  useEffect(() => {
    if (selectedPlan) {
      loadPlanItems(selectedPlan.id);
    }
  }, [selectedPlan]);

  async function loadMealPlans() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('nutrition_meal_plans')
        .select('*')
        .order('is_pro', { ascending: true });

      if (error) throw error;
      setMealPlans(data || []);
    } catch (err) {
      console.error('Erro ao carregar planos:', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadPlanItems(planId: string) {
    try {
      const { data, error } = await supabase
        .from('nutrition_meal_plan_items')
        .select('*')
        .eq('meal_plan_id', planId)
        .order('meal_order', { ascending: true });

      if (error) throw error;
      setPlanItems(data || []);
    } catch (err) {
      console.error('Erro ao carregar itens do plano:', err);
    }
  }

  async function loadRecommendations() {
    try {
      const { data, error } = await supabase
        .from('nutrition_smart_recommendations')
        .select('*')
        .eq('is_active', true)
        .limit(10);

      if (error) throw error;
      setRecommendations(data || []);
    } catch (err) {
      console.error('Erro ao carregar recomendações:', err);
    }
  }

  function handleGoalSelect(goal: string) {
    setSelectedGoal(goal);
    const plan = mealPlans.find(p => p.goal === goal && !p.is_pro);
    if (plan) {
      setSelectedPlan(plan);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Planos Alimentares</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 p-6 space-y-4">
          <div className="h-32 rounded-2xl animate-pulse" style={{ backgroundColor: theme.border }} />
          <div className="h-32 rounded-2xl animate-pulse" style={{ backgroundColor: theme.border }} />
          <div className="h-32 rounded-2xl animate-pulse" style={{ backgroundColor: theme.border }} />
        </div>
      </div>
    );
  }

  if (!selectedGoal) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between p-4">
            <button onClick={onBack} className="p-2 rounded-lg transition-all active:scale-95">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Planos Alimentares</h1>
            <div className="w-10" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="text-center mb-6">
            <ChefHat className="w-16 h-16 mx-auto mb-4" style={styles.accentText} />
            <h2 className="text-2xl font-bold mb-2" style={styles.textPrimary}>
              Escolha seu Objetivo
            </h2>
            <p style={styles.textSecondary}>
              Selecione o que você quer alcançar com sua alimentação
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {Object.entries(GOAL_INFO).map(([goal, info]) => {
              const IconComponent = info.icon;
              return (
                <button
                  key={goal}
                  onClick={() => handleGoalSelect(goal)}
                  className="rounded-2xl p-6 border transition-all active:scale-95 text-left"
                  style={{ ...styles.card, ...styles.border }}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 ${info.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold mb-2" style={styles.textPrimary}>
                        {mealPlans.find(p => p.goal === goal && !p.is_pro)?.name || 'Plano Personalizado'}
                      </h3>
                      <p className="text-sm leading-relaxed" style={styles.textSecondary}>
                        {info.description}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="rounded-2xl p-6 border bg-gradient-to-br from-yellow-500/10 to-orange-500/10" style={styles.border}>
            <div className="flex items-start gap-3 mb-3">
              <Crown className="w-6 h-6 text-yellow-500 flex-shrink-0" />
              <div>
                <h3 className="font-bold text-yellow-600 mb-2">Modo PRO Disponível</h3>
                <p className="text-sm" style={styles.textSecondary}>
                  Desbloqueie planos profissionais com receitas exclusivas, suplementação e acompanhamento personalizado.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      <div className="sticky top-0 z-20 border-b" style={{ ...styles.header, ...styles.border }}>
        <div className="flex items-center justify-between p-4">
          <button onClick={() => setSelectedGoal(null)} className="p-2 rounded-lg transition-all active:scale-95">
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>
            {selectedPlan?.name || 'Plano Alimentar'}
          </h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {selectedPlan && (
          <>
            <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
              <div className="flex items-center gap-4 mb-4">
                <div className={`w-14 h-14 ${GOAL_INFO[selectedPlan.goal]?.color} rounded-xl flex items-center justify-center`}>
                  {React.createElement(GOAL_INFO[selectedPlan.goal]?.icon, { className: 'w-7 h-7 text-white' })}
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold" style={styles.textPrimary}>{selectedPlan.name}</h2>
                  <p className="text-sm" style={styles.textSecondary}>{selectedPlan.description}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="rounded-xl p-4 text-center" style={{ backgroundColor: theme.surface }}>
                  <Flame className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                  <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                    {selectedPlan.daily_calories}
                  </div>
                  <div className="text-xs" style={styles.textSecondary}>Calorias/dia</div>
                </div>
                <div className="rounded-xl p-4 text-center" style={{ backgroundColor: theme.surface }}>
                  <Award className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                  <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                    {selectedPlan.macros.protein}g
                  </div>
                  <div className="text-xs" style={styles.textSecondary}>Proteínas/dia</div>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <div className="flex-1 text-center py-2 rounded-lg" style={{ backgroundColor: theme.surface }}>
                  <span className="text-sm font-semibold" style={styles.textSecondary}>
                    Carb: {selectedPlan.macros.carbs}g
                  </span>
                </div>
                <div className="flex-1 text-center py-2 rounded-lg" style={{ backgroundColor: theme.surface }}>
                  <span className="text-sm font-semibold" style={styles.textSecondary}>
                    Gord: {selectedPlan.macros.fats}g
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-4" style={styles.textPrimary}>Refeições Diárias</h3>
              <div className="space-y-4">
                {planItems.map((item) => (
                  <div key={item.id} className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{MEAL_TYPE_ICONS[item.meal_type]}</span>
                        <div>
                          <h4 className="text-lg font-semibold" style={styles.textPrimary}>
                            {MEAL_TYPE_NAMES[item.meal_type]}
                          </h4>
                          <div className="flex items-center gap-2 text-sm" style={styles.textSecondary}>
                            <Clock className="w-4 h-4" />
                            <span>{item.time_range}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold" style={styles.accentText}>{item.calories}</div>
                        <div className="text-xs" style={styles.textSecondary}>calorias</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="text-sm font-semibold mb-2" style={styles.textPrimary}>Alimentos:</div>
                      <div className="flex flex-wrap gap-2">
                        {item.foods.map((food, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 text-sm rounded-full font-medium"
                            style={{ backgroundColor: theme.surface, color: theme.textPrimary }}
                          >
                            {food}
                          </span>
                        ))}
                      </div>
                    </div>

                    {item.alternatives && item.alternatives.length > 0 && (
                      <div>
                        <div className="text-xs font-semibold mb-2" style={styles.textSecondary}>Substituições:</div>
                        <div className="flex flex-wrap gap-2">
                          {item.alternatives.map((alt, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-1 text-xs rounded-full"
                              style={{ backgroundColor: `${theme.accent}20`, color: theme.accent }}
                            >
                              {alt}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {recommendations.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold" style={styles.textPrimary}>Recomendações Inteligentes</h3>
                  <button
                    onClick={() => setShowRecommendations(!showRecommendations)}
                    className="text-sm font-semibold transition-all active:scale-95"
                    style={styles.accentText}
                  >
                    {showRecommendations ? 'Ocultar' : 'Ver todas'}
                  </button>
                </div>
                {showRecommendations && (
                  <div className="space-y-3">
                    {recommendations.map((rec) => (
                      <div key={rec.id} className="rounded-xl p-4 border" style={{ ...styles.card, ...styles.border }}>
                        <div className="flex items-start gap-3">
                          <span className="text-lg">💡</span>
                          <div className="flex-1">
                            <p className="text-sm font-medium mb-1" style={styles.textPrimary}>
                              Sem <strong>{rec.food_original}</strong>? Use <strong>{rec.food_alternative}</strong>
                            </p>
                            <p className="text-xs" style={styles.textSecondary}>{rec.reason}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
