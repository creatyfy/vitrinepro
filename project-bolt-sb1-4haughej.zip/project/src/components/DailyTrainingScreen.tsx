import React, { useState, useEffect } from 'react';
import { ChevronLeft, Clock, Star, Trophy, Target, Zap, ArrowLeft } from 'lucide-react';
import PauseOverlay from './PauseOverlay';
import { 
  exerciseCatalog, 
  weekTemplates, 
  getCurrentWeek, 
  getCurrentDayOfWeek, 
  generateDailySession,
  getExerciseById,
  calculateExercisePoints,
  getPillarColor,
  getPillarIcon,
  type Exercise,
  type DailySession,
  type DailyExercise,
  type ExerciseVariant
} from '../data/weeklyTrainingData';

interface DailyTrainingScreenProps {
  selectedPosition: string;
  isDarkMode: boolean;
  onBack: () => void;
  onStartExercise: (exercise: Exercise, variant: ExerciseVariant) => void;
}

export default function DailyTrainingScreen({ 
  selectedPosition, 
  isDarkMode, 
  onBack,
  onStartExercise 
}: DailyTrainingScreenProps) {
  const [dailySession, setDailySession] = useState<DailySession | null>(null);
  const [showPauseOverlay, setShowPauseOverlay] = useState(false);
  const [isTrainingActive, setIsTrainingActive] = useState(false);

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  useEffect(() => {
    const today = new Date();
    const session = generateDailySession(today);
    setDailySession(session);
  }, []);

  if (!dailySession) {
    return (
      <div className={`min-h-screen ${bgClass} flex items-center justify-center`}>
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-spin">
            <Target className="w-8 h-8 text-white" />
          </div>
          <p className={textClass}>Carregando treinos...</p>
        </div>
      </div>
    );
  }

  const currentWeekTemplate = weekTemplates.find(w => w.week === dailySession.week) || weekTemplates[0];
  const totalExercises = dailySession.exercises.length;

  const handleEnvironmentChange = (exerciseIndex: number, environment: 'ar_livre' | 'academia' | 'simples') => {
    if (!dailySession) return;
    
    const updatedExercises = [...dailySession.exercises];
    updatedExercises[exerciseIndex].chosen_env = environment;
    
    setDailySession({
      ...dailySession,
      exercises: updatedExercises
    });
  };

  const handlePauseTraining = () => {
    setShowPauseOverlay(true);
  };

  const handleResumeTraining = () => {
    setShowPauseOverlay(false);
  };

  const handleRestartExercise = () => {
    setShowPauseOverlay(false);
  };

  const handleExitFromPause = () => {
    setShowPauseOverlay(false);
    setIsTrainingActive(false);
    onBack();
  };

  const handleStartExercise = (exercise: Exercise, variant: ExerciseVariant) => {
    setIsTrainingActive(true);
    onStartExercise(exercise, variant);
  };

  const getEnvironmentLabel = (env: string) => {
    switch (env) {
      case 'ar_livre': return 'Ar Livre';
      case 'academia': return 'Academia';
      case 'simples': return 'Simples';
      default: return env;
    }
  };

  const getEnvironmentIcon = (env: string) => {
    switch (env) {
      case 'ar_livre': return '🌳';
      case 'academia': return '🏋️‍♂️';
      case 'simples': return '🏠';
      default: return '💪';
    }
  };

  const getDayName = (dayNumber: number) => {
    const days = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
    return days[dayNumber - 1] || 'Dia';
  };

  const getFocusPillars = () => {
    const pillars = dailySession.exercises
      .map(ex => {
        const exercise = getExerciseById(ex.exercise_id);
        return exercise?.pillar;
      })
      .filter(Boolean);
    
    const uniquePillars = [...new Set(pillars)];
    return uniquePillars.slice(0, 3).join(', ');
  };

  return (
    <div className={`min-h-screen ${bgClass}`}>
      {showPauseOverlay && (
        <PauseOverlay
          isDarkMode={isDarkMode}
          currentExercise={0}
          totalExercises={totalExercises}
          onResume={handleResumeTraining}
          onRestart={handleRestartExercise}
          onExit={handleExitFromPause}
        />
      )}

      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>Treinos do Dia</h1>
        {isTrainingActive ? (
          <button onClick={handlePauseTraining} className="p-2">
            <ArrowLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
        ) : (
          <div className="w-10"></div>
        )}
      </div>

      <div className="px-6">
        {/* Header do Dia */}
        <div className="text-center mb-8">
          <div className={`w-16 h-16 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <Target className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>
            {getDayName(dailySession.day_in_week)}
          </h2>
          <p className={`${secondaryTextClass} mb-2`}>
            Semana {dailySession.week} de 12 • Dia {dailySession.day_in_week} de 7
          </p>
          <div className={`${isDarkMode ? 'bg-blue-900' : 'bg-blue-50'} rounded-xl p-3 border ${isDarkMode ? 'border-blue-800' : 'border-blue-200'}`}>
            <p className={`text-sm ${isDarkMode ? 'text-blue-300' : 'text-blue-700'}`}>
              <strong>Hoje:</strong> foco em {getFocusPillars()}
            </p>
          </div>
        </div>

        {/* Informação da Sessão */}
        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <div className="text-center">
            <div className={`text-3xl font-bold ${textClass} mb-2`}>{totalExercises}</div>
            <div className={`text-sm ${secondaryTextClass}`}>Exercícios de Hoje</div>
          </div>
        </div>

        {/* Lista de Exercícios - Resumo */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className={`text-xl font-semibold ${textClass}`}>Exercícios ({totalExercises})</h3>
          </div>

          <div className="space-y-3">
            {dailySession.exercises.map((dailyExercise, index) => {
              const exercise = getExerciseById(dailyExercise.exercise_id);
              if (!exercise) return null;

              const variant = exercise.variants[dailyExercise.chosen_env];
              const points = calculateExercisePoints(exercise, 'normal');

              return (
                <div key={exercise.id} className={`${cardClass} rounded-xl shadow-sm border p-4`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center flex-1">
                      <div className={`text-lg font-bold ${secondaryTextClass} mr-3`}>
                        #{index + 1}
                      </div>
                      <img
                        src={variant.video_url}
                        alt={exercise.name}
                        className="w-12 h-12 object-cover rounded-lg mr-3"
                      />
                      <div className="flex-1">
                        <h4 className={`font-semibold ${textClass}`}>
                          {exercise.name}
                        </h4>
                        {variant.duration && (
                          <div className="flex items-center mt-1">
                            <Clock className={`w-3 h-3 ${secondaryTextClass} mr-1`} />
                            <span className={`text-xs ${secondaryTextClass}`}>{variant.duration}</span>
                          </div>
                        )}
                        {variant.reps && (
                          <div className="flex items-center mt-1">
                            <Zap className={`w-3 h-3 ${secondaryTextClass} mr-1`} />
                            <span className={`text-xs ${secondaryTextClass}`}>x {variant.reps}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                      <span className={`text-sm font-bold ${textClass}`}>+{points}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Session Footer */}
        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <div className="text-center">
            <h3 className={`text-lg font-semibold ${textClass} mb-2`}>
              Bons Treinos!
            </h3>
            <p className={secondaryTextClass}>
              Complete cada exercício para ganhar pontos e evoluir
            </p>
          </div>
        </div>

        {/* Week Info */}
        <div className={`${isDarkMode ? 'bg-gradient-to-r from-blue-600 to-blue-700' : 'bg-gradient-to-r from-blue-500 to-blue-600'} rounded-2xl p-6 text-white mb-8`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Trophy className="w-6 h-6 mr-2 text-yellow-300" />
              <h3 className="text-lg font-semibold">{currentWeekTemplate.title}</h3>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">Semana {dailySession.week}</div>
              <div className={`text-sm ${isDarkMode ? 'text-blue-200' : 'text-blue-100'}`}>de 12</div>
            </div>
          </div>
          <p className={`${isDarkMode ? 'text-blue-200' : 'text-blue-100'} mb-4`}>
            {currentWeekTemplate.subtitle}
          </p>
          <div className="flex justify-between items-center">
            <span className={`text-sm ${isDarkMode ? 'text-blue-200' : 'text-blue-100'}`}>
              Progressão aplicada: +{currentWeekTemplate.progression.sets_boost} série
            </span>
            <button className={`bg-white ${isDarkMode ? 'text-blue-700' : 'text-blue-600'} px-4 py-2 rounded-full font-semibold text-sm hover:bg-blue-50 transition-colors`}>
              Ver Semana
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}