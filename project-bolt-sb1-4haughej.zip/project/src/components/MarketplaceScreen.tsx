import React, { useState } from 'react';
import { ChevronLeft, ShoppingBag, Star, Heart, Filter, Search, ShoppingCart, Truck, Shield, Award, Tag, Flame, TrendingUp, Eye, Share2, ChevronDown, ChevronUp, MapPin } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import ProductDetailScreen from './ProductDetailScreen';
import CheckoutScreen from './CheckoutScreen';

interface MarketplaceScreenProps {
  onBack: () => void;
}

export default function MarketplaceScreen({ onBack }: MarketplaceScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [currentView, setCurrentView] = useState('categories'); // 'categories', 'products', 'product-detail', 'checkout'
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [favorites, setFavorites] = useState<number[]>([]);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [selectedGender, setSelectedGender] = useState('masculino');

  const categories = [
    {
      id: 'lancamentos',
      name: 'Lançamentos',
      image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-cyan-400 to-cyan-500'
    },
    {
      id: 'ofertas',
      name: 'Ofertas',
      image: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-cyan-400 to-cyan-500'
    },
    {
      id: 'suplementos',
      name: 'Suplementos',
      image: 'https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-green-400 to-green-500'
    },
    {
      id: 'calcados',
      name: 'Calçados',
      image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-cyan-400 to-cyan-500'
    },
    {
      id: 'roupas',
      name: 'Roupas',
      image: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-cyan-400 to-cyan-500'
    },
    {
      id: 'acessorios',
      name: 'Acessórios',
      image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      color: 'from-cyan-400 to-cyan-500'
    }
  ];

  const products = {
    calcados: [
      {
        id: 1,
        name: 'Chuteira Campo Nike Phantom High 6 Elite SE',
        category: 'Futebol',
        price: 2374.99,
        originalPrice: 2499.99,
        pixPrice: 2374.99,
        installments: '10x',
        discount: 5,
        image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.9,
        reviews: 156,
        brand: 'Nike',
        isNew: true,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'A chuteira de futsal de 2010 já está precisando de um relançamento há algum tempo. Bem, a espera acabou. A adorada Gato está de volta! Aperfeiçoada e preparada para enfrentar as ruas, esta edição elegante combina couro premium, camurça e tecido arejado para criar um look com camadas fácil de usar.',
        features: [
          'Cabedal em couro premium',
          'Solado de borracha antiderrapante',
          'Design clássico renovado',
          'Conforto durante todo o dia'
        ],
        colors: ['Preto', 'Branco', 'Azul'],
        sizes: ['38', '39', '40', '41', '42', '43', '44'],
        style: 'HQ6019-001',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 2,
        name: 'Chuteira Nike Street Gato Futsal',
        category: 'Futebol',
        price: 759.99,
        originalPrice: 899.99,
        pixPrice: 759.99,
        installments: '10x',
        discount: 15,
        image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.7,
        reviews: 89,
        brand: 'Nike',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Chuteira de futsal com design clássico e performance moderna.',
        features: [
          'Solado de borracha',
          'Cabedal sintético',
          'Amortecimento responsivo'
        ],
        colors: ['Azul', 'Preto'],
        sizes: ['38', '39', '40', '41', '42', '43'],
        style: 'ST7821-400',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 3,
        name: 'Chuteira Nike Air Zoom Mercurial Superfly 10 Academy Campo',
        category: 'Futebol',
        price: 683.99,
        originalPrice: 799.99,
        pixPrice: 683.99,
        installments: '10x',
        discount: 14,
        image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.8,
        reviews: 234,
        brand: 'Nike',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'Chuteira de campo com tecnologia Air Zoom para máxima velocidade.',
        features: [
          'Tecnologia Air Zoom',
          'Cabedal Flyknit',
          'Travas para campo'
        ],
        colors: ['Preto', 'Verde'],
        sizes: ['38', '39', '40', '41', '42', '43', '44'],
        style: 'DJ5627-040',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 4,
        name: 'Tênis Nike Vomero 18 Masculino',
        category: 'Corrida',
        price: 949.99,
        originalPrice: 999.99,
        pixPrice: 949.99,
        installments: '10x',
        discount: 5,
        image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.6,
        reviews: 78,
        brand: 'Nike',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'Tênis de corrida com máximo conforto e amortecimento.',
        features: [
          'Amortecimento ZoomX',
          'Cabedal respirável',
          'Solado durável'
        ],
        colors: ['Laranja', 'Cinza'],
        sizes: ['38', '39', '40', '41', '42', '43', '44'],
        style: 'DV4022-800',
        giftback: '5% Giftback',
        comingSoon: false
      },
      {
        id: 5,
        name: 'Tênis Nike Air Zoom Pegasus 41 Masculino',
        category: 'Corrida',
        price: 1044.99,
        originalPrice: 1099.99,
        pixPrice: 1044.99,
        installments: '10x',
        discount: 5,
        image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.8,
        reviews: 145,
        brand: 'Nike',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'O tênis de corrida mais versátil da Nike.',
        features: [
          'Air Zoom no antepé',
          'Espuma ReactX',
          'Cabedal engenheirado'
        ],
        colors: ['Cinza', 'Preto'],
        sizes: ['38', '39', '40', '41', '42', '43', '44'],
        style: 'FD2722-002',
        giftback: '5% Giftback',
        comingSoon: false
      }
    ],
    roupas: [
      {
        id: 6,
        name: 'Camiseta Nike Dri-FIT',
        category: 'Treino',
        price: 149.99,
        originalPrice: 179.99,
        pixPrice: 149.99,
        installments: '3x',
        discount: 17,
        image: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.5,
        reviews: 234,
        brand: 'Nike',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'Camiseta de treino com tecnologia Dri-FIT.',
        features: [
          'Tecnologia Dri-FIT',
          'Tecido respirável',
          'Ajuste confortável'
        ],
        colors: ['Branco', 'Preto', 'Azul'],
        sizes: ['P', 'M', 'G', 'GG'],
        style: 'BV6708-100',
        giftback: '5% Giftback',
        comingSoon: false
      }
    ],
    lancamentos: [
      {
        id: 7,
        name: 'Nike Air Max 270',
        category: 'Lifestyle',
        price: 899.99,
        originalPrice: 999.99,
        pixPrice: 899.99,
        installments: '10x',
        discount: 10,
        image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.9,
        reviews: 567,
        brand: 'Nike',
        isNew: true,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Tênis lifestyle com a maior unidade Air Max da Nike.',
        features: [
          'Unidade Air Max 270',
          'Cabedal mesh',
          'Design futurista'
        ],
        colors: ['Branco', 'Preto', 'Colorido'],
        sizes: ['38', '39', '40', '41', '42', '43', '44'],
        style: 'AH8050-100',
        giftback: '10% Giftback',
        comingSoon: false
      }
    ],
    ofertas: [
      {
        id: 8,
        name: 'Chuteira Nike Mercurial Vapor',
        category: 'Futebol',
        price: 599.99,
        originalPrice: 799.99,
        pixPrice: 599.99,
        installments: '8x',
        discount: 25,
        image: 'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.7,
        reviews: 123,
        brand: 'Nike',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Chuteira de campo com velocidade e precisão.',
        features: [
          'Cabedal sintético',
          'Travas FG',
          'Design aerodinâmico'
        ],
        colors: ['Vermelho', 'Azul'],
        sizes: ['38', '39', '40', '41', '42', '43'],
        style: 'AT5292-606',
        giftback: '15% Giftback',
        comingSoon: false
      }
    ],
    acessorios: [
      {
        id: 9,
        name: 'Mochila Nike Brasilia',
        category: 'Acessórios',
        price: 199.99,
        originalPrice: 249.99,
        pixPrice: 199.99,
        installments: '4x',
        discount: 20,
        image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.6,
        reviews: 89,
        brand: 'Nike',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'Mochila esportiva com compartimentos organizados.',
        features: [
          'Compartimento principal amplo',
          'Bolso frontal com zíper',
          'Alças acolchoadas'
        ],
        colors: ['Preto', 'Azul', 'Cinza'],
        sizes: ['Único'],
        style: 'BA5954-010',
        giftback: '5% Giftback',
        comingSoon: false
      }
    ],
    suplementos: [
      {
        id: 10,
        name: 'Whey Protein Concentrado 900g',
        category: 'Proteínas',
        price: 89.99,
        originalPrice: 129.99,
        pixPrice: 89.99,
        installments: '3x',
        discount: 31,
        image: 'https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.8,
        reviews: 567,
        brand: 'Growth Supplements',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Whey Protein Concentrado de alta qualidade, ideal para ganho de massa muscular e recuperação pós-treino. 24g de proteína por dose.',
        features: [
          '24g de proteína por dose',
          'Baixo teor de gordura',
          'Rápida absorção',
          'Sabor delicioso'
        ],
        colors: ['Chocolate', 'Baunilha', 'Morango'],
        sizes: ['900g'],
        style: 'WPC-900',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 11,
        name: 'Creatina Monohidratada 300g',
        category: 'Performance',
        price: 59.99,
        originalPrice: 79.99,
        pixPrice: 59.99,
        installments: '2x',
        discount: 25,
        image: 'https://images.pexels.com/photos/6550835/pexels-photo-6550835.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/6550835/pexels-photo-6550835.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.9,
        reviews: 892,
        brand: 'Max Titanium',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Creatina monohidratada pura, aumenta força, potência muscular e performance em treinos intensos.',
        features: [
          '100% creatina pura',
          'Aumenta força e potência',
          'Melhora performance',
          'Sem sabor'
        ],
        colors: ['Neutro'],
        sizes: ['300g'],
        style: 'CRT-300',
        giftback: '15% Giftback',
        comingSoon: false
      },
      {
        id: 12,
        name: 'BCAA 2:1:1 - 120 Cápsulas',
        category: 'Aminoácidos',
        price: 49.99,
        originalPrice: 69.99,
        pixPrice: 49.99,
        installments: '2x',
        discount: 29,
        image: 'https://images.pexels.com/photos/3873146/pexels-photo-3873146.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/3873146/pexels-photo-3873146.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.7,
        reviews: 234,
        brand: 'Integralmedica',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'BCAA com proporção 2:1:1 de aminoácidos essenciais. Previne catabolismo muscular e acelera recuperação.',
        features: [
          'Aminoácidos essenciais',
          'Previne catabolismo',
          'Acelera recuperação',
          'Fácil de consumir'
        ],
        colors: ['Cápsula'],
        sizes: ['120 cáps'],
        style: 'BCAA-120',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 13,
        name: 'Pré-Treino Horus 300g',
        category: 'Energia',
        price: 79.99,
        originalPrice: 99.99,
        pixPrice: 79.99,
        installments: '3x',
        discount: 20,
        image: 'https://images.pexels.com/photos/4061662/pexels-photo-4061662.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/4061662/pexels-photo-4061662.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.8,
        reviews: 445,
        brand: 'Max Titanium',
        isNew: true,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Pré-treino com cafeína, beta-alanina e arginina. Aumenta energia, foco e pump muscular.',
        features: [
          'Alta concentração de cafeína',
          'Beta-alanina e arginina',
          'Aumenta foco e energia',
          'Pump muscular intenso'
        ],
        colors: ['Frutas Vermelhas', 'Limão'],
        sizes: ['300g'],
        style: 'HORUS-300',
        giftback: '15% Giftback',
        comingSoon: false
      },
      {
        id: 14,
        name: 'Multivitamínico 60 Cápsulas',
        category: 'Vitaminas',
        price: 39.99,
        originalPrice: 54.99,
        pixPrice: 39.99,
        installments: '2x',
        discount: 27,
        image: 'https://images.pexels.com/photos/5938253/pexels-photo-5938253.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/5938253/pexels-photo-5938253.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.6,
        reviews: 178,
        brand: 'Integralmedica',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'Complexo multivitamínico completo com vitaminas e minerais essenciais para saúde e performance.',
        features: [
          '25 vitaminas e minerais',
          'Suporte imunológico',
          'Energia e disposição',
          '1 cápsula por dia'
        ],
        colors: ['Cápsula'],
        sizes: ['60 cáps'],
        style: 'MULTI-60',
        giftback: '5% Giftback',
        comingSoon: false
      },
      {
        id: 15,
        name: 'Whey Isolado 900g - Importado',
        category: 'Proteínas',
        price: 159.99,
        originalPrice: 199.99,
        pixPrice: 159.99,
        installments: '5x',
        discount: 20,
        image: 'https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.9,
        reviews: 723,
        brand: 'Optimum Nutrition',
        isNew: true,
        isTrending: true,
        inStock: true,
        fastShipping: false,
        description: 'Whey Protein Isolado importado, 90% de proteína pura, baixíssimo teor de carboidratos e gorduras.',
        features: [
          '27g de proteína por dose',
          '90% de proteína isolada',
          'Zero lactose',
          'Absorção ultra rápida'
        ],
        colors: ['Baunilha', 'Chocolate', 'Cookies'],
        sizes: ['900g'],
        style: 'WPI-900-ON',
        giftback: '20% Giftback',
        comingSoon: false
      },
      {
        id: 16,
        name: 'Glutamina 300g',
        category: 'Recuperação',
        price: 54.99,
        originalPrice: 74.99,
        pixPrice: 54.99,
        installments: '2x',
        discount: 27,
        image: 'https://images.pexels.com/photos/6550835/pexels-photo-6550835.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/6550835/pexels-photo-6550835.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.5,
        reviews: 156,
        brand: 'Growth Supplements',
        isNew: false,
        isTrending: false,
        inStock: true,
        fastShipping: true,
        description: 'L-Glutamina pura, aminoácido mais abundante no músculo. Acelera recuperação e fortalece sistema imunológico.',
        features: [
          '100% L-Glutamina',
          'Acelera recuperação',
          'Suporte imunológico',
          'Previne overtraining'
        ],
        colors: ['Neutro'],
        sizes: ['300g'],
        style: 'GLU-300',
        giftback: '10% Giftback',
        comingSoon: false
      },
      {
        id: 17,
        name: 'Termogênico Fire Black 60 Cáps',
        category: 'Emagrecimento',
        price: 69.99,
        originalPrice: 89.99,
        pixPrice: 69.99,
        installments: '3x',
        discount: 22,
        image: 'https://images.pexels.com/photos/3873146/pexels-photo-3873146.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
        images: [
          'https://images.pexels.com/photos/3873146/pexels-photo-3873146.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
        ],
        rating: 4.7,
        reviews: 289,
        brand: 'Max Titanium',
        isNew: false,
        isTrending: true,
        inStock: true,
        fastShipping: true,
        description: 'Termogênico potente com cafeína, chá verde e sinefrina. Acelera metabolismo e queima de gordura.',
        features: [
          'Acelera metabolismo',
          'Aumenta energia',
          'Queima gordura',
          'Foco e disposição'
        ],
        colors: ['Cápsula'],
        sizes: ['60 cáps'],
        style: 'FIRE-60',
        giftback: '15% Giftback',
        comingSoon: false
      }
    ]
  };

  const toggleFavorite = (productId: number) => {
    setFavorites(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const addToCart = (product: any, selectedSize?: string, selectedColor?: string) => {
    const cartItem = {
      ...product,
      selectedSize: selectedSize || product.sizes[0],
      selectedColor: selectedColor || product.colors[0],
      quantity: 1,
      cartId: Date.now()
    };
    setCartItems(prev => [...prev, cartItem]);
  };

  const buyNow = (product: any, selectedSize?: string, selectedColor?: string) => {
    const cartItem = {
      ...product,
      selectedSize: selectedSize || product.sizes[0],
      selectedColor: selectedColor || product.colors[0],
      quantity: 1,
      cartId: Date.now()
    };
    setCartItems([cartItem]);
    setCurrentView('checkout');
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentView('products');
  };

  const handleProductSelect = (product: any) => {
    setSelectedProduct(product);
    setCurrentView('product-detail');
  };

  const handleBackToCategories = () => {
    setCurrentView('categories');
    setSelectedCategory('');
  };

  const handleBackToProducts = () => {
    setCurrentView('products');
    setSelectedProduct(null);
  };

  const handleBackToProductDetail = () => {
    setCurrentView('product-detail');
  };

  // Checkout Screen
  if (currentView === 'checkout') {
    return (
      <CheckoutScreen
        cartItems={cartItems}
        onBack={handleBackToProductDetail}
        onUpdateCart={setCartItems}
      />
    );
  }

  // Product Detail Screen
  if (currentView === 'product-detail' && selectedProduct) {
    return (
      <ProductDetailScreen
        product={selectedProduct}
        onBack={handleBackToProducts}
        onAddToCart={addToCart}
        onBuyNow={buyNow}
        onToggleFavorite={toggleFavorite}
        isFavorite={favorites.includes(selectedProduct.id)}
      />
    );
  }

  // Products List Screen
  if (currentView === 'products') {
    const categoryProducts = products[selectedCategory as keyof typeof products] || [];
    const filteredProducts = categoryProducts.filter(product => 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
        {/* Status Bar - Spacer */}
        <div className="pt-12"></div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4">
          <button onClick={handleBackToCategories} className="p-2">
            <ChevronLeft className="w-6 h-6" style={{ color: tokens.icon }} />
          </button>
          <h1 className="text-xl font-bold capitalize" style={{ color: tokens.textPrimary }}>
            {selectedCategory === 'calcados' ? 'Calçados Masculinos' : 
             categories.find(c => c.id === selectedCategory)?.name}
          </h1>
          <div className="flex items-center space-x-3">
            <Filter className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
            <Search className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
          </div>
        </div>

        <div className="px-6">
          {/* Products Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {filteredProducts.map((product) => (
              <button
                key={product.id}
                onClick={() => handleProductSelect(product)}
                className="text-left" style={{ backgroundColor: tokens.surfaceAlt }}
              >
                <div className="relative mb-4">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  {product.comingSoon && (
                    <div className="absolute top-3 left-3 bg-orange-500 text-white px-2 py-1 rounded text-xs font-bold">
                      Em breve
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-bold text-lg leading-tight line-clamp-2" style={{ color: tokens.textPrimary }}>
                    {product.name}
                  </h3>
                  <p className="text-sm" style={{ color: tokens.textSecondary }}>{product.category}</p>
                  <div className="space-y-1">
                    <div className="text-xl font-bold" style={{ color: tokens.textPrimary }}>
                      R$ {product.pixPrice.toFixed(2).replace('.', ',')} no Pix
                    </div>
                    {product.originalPrice > product.price && (
                      <div className="flex items-center space-x-2">
                        <span className="line-through text-sm" style={{ color: tokens.textSecondary }}>
                          R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                        </span>
                        <span className="text-green-600 font-bold text-sm">
                          {product.discount}% off
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 border-t" style={{ backgroundColor: tokens.surface, borderColor: tokens.border }}>
          <div className="flex justify-around py-3">
            <button className="flex flex-col items-center">
              <div className="w-6 h-6 mb-1">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-white">
                  <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                </svg>
              </div>
              <span className="text-xs font-medium text-white">Destaques</span>
            </button>
            <button className="flex flex-col items-center">
              <Search className="w-6 h-6 mb-1 text-white" />
              <span className="text-xs text-white">Coleções</span>
            </button>
            <button className="flex flex-col items-center">
              <Heart className="w-6 h-6 mb-1 text-white" />
              <span className="text-xs text-white">Favoritos</span>
            </button>
            <button className="flex flex-col items-center relative">
              <ShoppingCart className="w-6 h-6 mb-1 text-white" />
              <span className="text-xs text-white">Carrinho</span>
              {cartItems.length > 0 && (
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white font-bold">{cartItems.length}</span>
                </div>
              )}
            </button>
            <button className="flex flex-col items-center">
              <div className="w-6 h-6 mb-1">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-white">
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
              </div>
              <span className="text-xs text-white">Perfil</span>
            </button>
          </div>

          {/* Bottom Indicator */}
          <div className="h-1 mx-auto mb-2 rounded-full bg-white" style={{ width: '134px' }}></div>
        </div>
      </div>
    );
  }

  // Categories Screen (Main)
  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {/* Status Bar - Spacer */}
      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.icon }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Coleções</h1>
        <Search className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
      </div>

      <div className="px-6 pb-24">
        {/* Gender Tabs */}
        <div className="flex space-x-8 mb-8">
          <button
            onClick={() => setSelectedGender('masculino')}
            className="pb-2 border-b-2 transition-colors"
            style={{
              borderColor: selectedGender === 'masculino' ? tokens.accent : 'transparent',
              color: selectedGender === 'masculino' ? tokens.textPrimary : tokens.textSecondary,
              fontWeight: selectedGender === 'masculino' ? '600' : '400'
            }}
          >
            Masculino
          </button>
          <button
            onClick={() => setSelectedGender('feminino')}
            className="pb-2 border-b-2 transition-colors"
            style={{
              borderColor: selectedGender === 'feminino' ? tokens.accent : 'transparent',
              color: selectedGender === 'feminino' ? tokens.textPrimary : tokens.textSecondary,
              fontWeight: selectedGender === 'feminino' ? '600' : '400'
            }}
          >
            Feminino
          </button>
          <button
            onClick={() => setSelectedGender('infantil')}
            className="pb-2 border-b-2 transition-colors"
            style={{
              borderColor: selectedGender === 'infantil' ? tokens.accent : 'transparent',
              color: selectedGender === 'infantil' ? tokens.textPrimary : tokens.textSecondary,
              fontWeight: selectedGender === 'infantil' ? '600' : '400'
            }}
          >
            Infantil
          </button>
        </div>

        {/* Category Cards - Main */}
        <div className="space-y-4 mb-8">
          {/* Lançamentos e Ofertas - Full Width */}
          {categories.slice(0, 2).map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategorySelect(category.id)}
              className="w-full h-32 relative overflow-hidden rounded-lg group"
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${category.color}`}></div>
              <img
                src={category.image}
                alt={category.name}
                className="absolute right-0 top-0 h-full w-1/2 object-cover opacity-80 group-hover:opacity-100 transition-opacity"
              />
              <div className="absolute inset-0 flex items-center">
                <h3 className="text-2xl font-bold text-white ml-6">
                  {category.name}
                </h3>
              </div>
            </button>
          ))}
        </div>

        {/* Navigate by Category Section - Grid 2x2 */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6" style={{ color: tokens.textPrimary }}>Navegue por categoria</h2>
          <div className="grid grid-cols-2 gap-4">
            {/* Suplementos */}
            <button
              onClick={() => handleCategorySelect('suplementos')}
              className="relative rounded-xl h-44 overflow-hidden group"
            >
              <img
                src="https://images.pexels.com/photos/4046719/pexels-photo-4046719.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Suplementos"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                <div className="text-left">
                  <h3 className="text-white font-bold text-lg">Suplementos</h3>
                  <p className="text-white/90 text-sm">Resultados reais</p>
                </div>
              </div>
            </button>

            {/* Calçados */}
            <button
              onClick={() => handleCategorySelect('calcados')}
              className="relative rounded-xl h-44 overflow-hidden group"
            >
              <img
                src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Calçados Esportivos"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                <div className="text-left">
                  <h3 className="text-white font-bold text-lg">Calçados</h3>
                  <p className="text-white/90 text-sm">Performance máxima</p>
                </div>
              </div>
            </button>

            {/* Roupas */}
            <button
              onClick={() => handleCategorySelect('roupas')}
              className="relative rounded-xl h-44 overflow-hidden group"
            >
              <img
                src="https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Roupas Esportivas"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                <div className="text-left">
                  <h3 className="text-white font-bold text-lg">Roupas</h3>
                  <p className="text-white/90 text-sm">Estilo e conforto</p>
                </div>
              </div>
            </button>

            {/* Acessórios */}
            <button
              onClick={() => handleCategorySelect('acessorios')}
              className="relative rounded-xl h-44 overflow-hidden group"
            >
              <img
                src="https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                alt="Acessórios"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                <div className="text-left">
                  <h3 className="text-white font-bold text-lg">Acessórios</h3>
                  <p className="text-white/90 text-sm">Complemente seu treino</p>
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 border-t" style={{ backgroundColor: tokens.surface, borderColor: tokens.border }}>
        <div className="flex justify-around py-3">
          <button className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-white">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
              </svg>
            </div>
            <span className="text-xs font-medium text-white">Destaques</span>
          </button>
          <button className="flex flex-col items-center">
            <Search className="w-6 h-6 mb-1 text-white" />
            <span className="text-xs font-medium text-white">Coleções</span>
          </button>
          <button className="flex flex-col items-center">
            <Heart className="w-6 h-6 mb-1 text-white" />
            <span className="text-xs text-white">Favoritos</span>
          </button>
          <button className="flex flex-col items-center relative">
            <ShoppingCart className="w-6 h-6 mb-1 text-white" />
            <span className="text-xs text-white">Carrinho</span>
            {cartItems.length > 0 && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">{cartItems.length}</span>
              </div>
            )}
          </button>
          <button className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-white">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
              </svg>
            </div>
            <span className="text-xs text-white">Perfil</span>
          </button>
        </div>

        {/* Bottom Indicator */}
        <div className="h-1 mx-auto mb-2 rounded-full bg-white" style={{ width: '134px' }}></div>
      </div>
    </div>
  );
}