import React, { useState } from 'react';
import { ChevronLeft, Users, Trophy, ShoppingBag, BarChart3, Settings, User, Plus, Search, Filter, MapPin, Calendar, Clock, Star, Eye, Heart, MessageCircle, Award, TrendingUp, Target, Bell, Shield, HelpCircle, LogOut, ChevronRight } from 'lucide-react';

interface ClubHubProps {
  clubName: string;
  onNavigateToCreatePeneira: () => void;
  onNavigateToScoutAthletes: () => void;
  onNavigateToMarketplace: () => void;
  onNavigateToPeladas: () => void;
  onNavigateToReports: () => void;
  onNavigateToSettings: () => void;
  onNavigateToTrainings: () => void;
  isDarkMode?: boolean;
  currentView?: string;
  onBackToMain?: () => void;
}

export default function ClubHub({
  clubName,
  onNavigateToCreatePeneira,
  onNavigateToScoutAthletes,
  onNavigateToMarketplace,
  onNavigateToPeladas,
  onNavigateToReports,
  onNavigateToSettings,
  onNavigateToTrainings,
  isDarkMode = false,
  currentView = 'main',
  onBackToMain = () => {}
}: ClubHubProps) {
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);

  // Create Peneira Screen
  if (currentView === 'create-peneira') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Criar Peneira</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Nova Peneira</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Título da Peneira</label>
                <input
                  type="text"
                  placeholder="Ex: Peneira Sub-20 - Categoria de Base"
                  className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Descrição</label>
                <textarea
                  placeholder="Descreva os objetivos e requisitos da peneira..."
                  rows={4}
                  className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Data</label>
                  <input
                    type="date"
                    min="2025-01-01"
                    max="2099-12-31"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Horário</label>
                  <input
                    type="time"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Local</label>
                <input
                  type="text"
                  placeholder="Endereço completo do local da peneira"
                  className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Idade Mínima</label>
                  <input
                    type="number"
                    placeholder="16"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Idade Máxima</label>
                  <input
                    type="number"
                    placeholder="20"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Posições Desejadas</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meio-campo', 'Meia-atacante', 'Ponta', 'Atacante'].map((position) => (
                    <label key={position} className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span className="text-gray-700">{position}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Vagas Disponíveis</label>
                  <input
                    type="number"
                    placeholder="100"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-lg font-semibold text-gray-900 mb-3">Taxa de Inscrição</label>
                  <input
                    type="text"
                    placeholder="Gratuita ou R$ 50,00"
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <button className="w-full bg-blue-500 text-white py-4 rounded-xl font-semibold text-lg hover:bg-blue-600 transition-colors">
                Publicar Peneira
              </button>
            </div>
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Scout Athletes Screen
  if (currentView === 'scout-athletes') {
    const athletes = [
      {
        id: 1,
        name: 'João Silva',
        age: 19,
        position: 'Atacante',
        location: 'São Paulo, SP',
        rating: 8.7,
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        stats: { goals: 23, assists: 12, matches: 45 },
        trending: true
      },
      {
        id: 2,
        name: 'Pedro Santos',
        age: 20,
        position: 'Meio-campo',
        location: 'Rio de Janeiro, RJ',
        rating: 8.4,
        photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        stats: { goals: 8, assists: 25, matches: 38 },
        trending: false
      }
    ];

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Buscar Atletas</h1>
          <Filter className="w-6 h-6 text-gray-600" />
        </div>

        <div className="px-6">
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar atletas por nome, posição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>

          {/* Filters */}
          <div className="flex space-x-3 mb-6 overflow-x-auto pb-2">
            {['Todos', 'Em Alta', 'Atacantes', 'Meio-campo', 'Defesa', 'Goleiros'].map((filter) => (
              <button
                key={filter}
                onClick={() => setSelectedCategory(filter.toLowerCase())}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  selectedCategory === filter.toLowerCase()
                    ? 'bg-green-500 text-white'
                    : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Athletes List */}
          <div className="space-y-4 mb-8">
            {athletes.map((athlete) => (
              <div key={athlete.id} className="bg-white rounded-2xl p-6 shadow-sm border">
                <div className="flex items-center mb-4">
                  <img 
                    src={athlete.photo} 
                    alt={athlete.name}
                    className="w-16 h-16 rounded-full mr-4 object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-xl font-bold text-gray-900">{athlete.name}</h3>
                      {athlete.trending && (
                        <div className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">
                          🔥 Em Alta
                        </div>
                      )}
                    </div>
                    <p className="text-blue-600 font-medium mb-1">{athlete.position} • {athlete.age} anos</p>
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span className="text-sm">{athlete.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">{athlete.rating}</div>
                    <div className="text-sm text-gray-600">Pontuação</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center bg-blue-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-blue-600">{athlete.stats.goals}</div>
                    <div className="text-sm text-gray-600">Gols</div>
                  </div>
                  <div className="text-center bg-green-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-green-600">{athlete.stats.assists}</div>
                    <div className="text-sm text-gray-600">Assistências</div>
                  </div>
                  <div className="text-center bg-purple-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-purple-600">{athlete.stats.matches}</div>
                    <div className="text-sm text-gray-600">Jogos</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-colors">
                    Convidar para Peneira
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <Heart className="w-5 h-5" />
                  </button>
                  <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                    <Eye className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Club Marketplace Screen
  if (currentView === 'club-marketplace') {
    const products = [
      {
        id: 1,
        name: 'Kit Completo de Cones',
        price: 299.90,
        image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
        category: 'Equipamentos de Treino'
      },
      {
        id: 2,
        name: 'Uniformes Personalizados',
        price: 89.90,
        image: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
        category: 'Uniformes'
      }
    ];

    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Marketplace Clube</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Equipamentos para Clubes</h2>
            <p className="text-gray-600">Tudo que seu clube precisa em um só lugar</p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            {products.map((product) => (
              <div key={product.id} className="bg-white rounded-2xl shadow-sm border overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-32 object-cover"
                />
                <div className="p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">{product.name}</h4>
                  <p className="text-xs text-gray-600 mb-3">{product.category}</p>
                  <div className="text-lg font-bold text-gray-900 mb-3">R$ {product.price.toFixed(2)}</div>
                  <button className="w-full bg-red-500 text-white py-2 rounded-xl font-semibold hover:bg-red-600 transition-colors">
                    Comprar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Reports Screen
  if (currentView === 'reports') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBackToMain} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Relatórios</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Análises do Clube</h2>
            <p className="text-gray-600">Métricas e performance detalhada</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">156</div>
                <div className="text-sm text-gray-600">Atletas Inscritos</div>
                <div className="text-xs text-green-600 mt-1">+23 esta semana</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">89%</div>
                <div className="text-sm text-gray-600">Taxa de Aprovação</div>
                <div className="text-xs text-green-600 mt-1">+5% vs mês anterior</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">12</div>
                <div className="text-sm text-gray-600">Contratos Fechados</div>
                <div className="text-xs text-green-600 mt-1">+3 este mês</div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">4.8</div>
                <div className="text-sm text-gray-600">Avaliação Média</div>
                <div className="text-xs text-green-600 mt-1">⭐⭐⭐⭐⭐</div>
              </div>
            </div>
          </div>

          {/* Top Performers */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performers do Mês</h3>
            <div className="space-y-3">
              {['João Silva - Atacante', 'Pedro Santos - Meio-campo', 'Carlos Lima - Zagueiro'].map((player, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-gray-700">{player}</span>
                  <span className="text-purple-600 font-bold">9.{2-index}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Main Club Hub
  return (
    <div className="min-h-screen bg-black">
      <div className="pt-12"></div>

      {/* Header */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">
              {clubName}
            </h1>
            <p className="text-gray-400 mt-1">Painel de Gestão do Clube</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center bg-blue-500 rounded-full px-3 py-1">
              <span className="text-white text-sm font-bold">156 atletas</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">Ações Rápidas</h2>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={onNavigateToTrainings}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Meus Treinos</h3>
            <p className="text-green-100 text-sm">Planos personalizados</p>
          </button>
          <button
            onClick={onNavigateToCreatePeneira}
            className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-6 text-left hover:from-blue-600 hover:to-blue-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Criar Peneira</h3>
            <p className="text-blue-100 text-sm">Publique nova seleção</p>
          </button>
          
          <button 
            onClick={onNavigateToScoutAthletes}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Buscar Atletas</h3>
            <p className="text-green-100 text-sm">Encontre novos talentos</p>
          </button>
          
          <button 
            onClick={onNavigateToMarketplace}
            className="bg-gradient-to-br from-red-500 to-red-700 rounded-2xl p-6 text-left hover:from-red-600 hover:to-red-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Marketplace</h3>
            <p className="text-red-100 text-sm">Equipamentos esportivos</p>
          </button>
          
          <button 
            onClick={onNavigateToPeladas}
            className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-6 text-left hover:from-green-600 hover:to-green-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Peladas</h3>
            <p className="text-green-100 text-sm">Organizar jogos</p>
          </button>
          
          <button 
            onClick={onNavigateToReports}
            className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl p-6 text-left hover:from-purple-600 hover:to-purple-800 transition-all duration-200 active:scale-95"
          >
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-4">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Relatórios</h3>
            <p className="text-purple-100 text-sm">Análises e métricas</p>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="px-6 mb-32">
        <h2 className="text-2xl font-bold text-white mb-6">Atividade Recente</h2>
        <div className="space-y-4">
          <div className="bg-gray-900 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-semibold">Nova inscrição na peneira Sub-20</h4>
                <p className="text-gray-400 text-sm">João Silva se inscreveu há 2 horas</p>
              </div>
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            </div>
          </div>
          <div className="bg-gray-900 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-semibold">Peneira Sub-17 finalizada</h4>
                <p className="text-gray-400 text-sm">23 atletas aprovados ontem</p>
              </div>
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800">
        <div className="flex justify-around py-3 px-4">
          <button
            onClick={onNavigateToCreatePeneira}
            className="p-2 rounded-full transition-all active:scale-90 text-blue-500"
          >
            <Plus className="w-6 h-6" />
          </button>

          <button
            onClick={onNavigateToScoutAthletes}
            className="p-2 rounded-full transition-all active:scale-90 text-gray-400"
          >
            <Search className="w-6 h-6" />
          </button>

          <button
            onClick={onNavigateToPeladas}
            className="p-2 rounded-full transition-all active:scale-90 text-gray-400"
          >
            <Users className="w-6 h-6" />
          </button>

          <button
            onClick={onNavigateToMarketplace}
            className="p-2 rounded-full transition-all active:scale-90 text-gray-400"
          >
            <Calendar className="w-6 h-6" />
          </button>

          <button
            onClick={onNavigateToSettings}
            className="p-2 rounded-full transition-all active:scale-90 text-gray-400"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>

        {/* Bottom Indicator */}
        <div className="h-1 bg-white mx-auto mt-3 rounded-full" style={{width: '134px'}}></div>
      </div>
    </div>
  );
}