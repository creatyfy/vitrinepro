import React, { useState } from 'react';
import { ChevronLeft, Play, Clock, Eye, BookOpen, Target, Brain, Trophy, Star, Filter } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface MindsetScreenProps {
  onBack: () => void;
}

export default function MindsetScreen({ onBack }: MindsetScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('todos');

  const categories = [
    { id: 'todos', label: 'Todos', icon: BookOpen },
    { id: 'tatica', label: 'Tática', icon: Target },
    { id: 'mental', label: 'Mental', icon: Brain },
    { id: 'tecnica', label: 'Técnica', icon: Star },
    { id: 'motivacao', label: 'Motivação', icon: Trophy }
  ];

  const videos = [
    {
      id: 1,
      title: 'Como Ler o Jogo: Visão Tática',
      description: 'Aprenda a antecipar jogadas e tomar decisões mais rápidas em campo',
      thumbnail: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '12:45',
      views: '2.3K',
      category: 'tatica',
      level: 'Intermediário',
      instructor: 'Prof. Carlos Silva'
    },
    {
      id: 2,
      title: 'Controle Emocional Sob Pressão',
      description: 'Técnicas para manter a calma em momentos decisivos do jogo',
      thumbnail: 'https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '8:30',
      views: '1.8K',
      category: 'mental',
      level: 'Avançado',
      instructor: 'Dra. Ana Costa'
    },
    {
      id: 3,
      title: 'Primeiro Toque Perfeito',
      description: 'Domine a técnica do primeiro toque para acelerar suas jogadas',
      thumbnail: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '15:20',
      views: '3.1K',
      category: 'tecnica',
      level: 'Iniciante',
      instructor: 'Ex-jogador João Santos'
    },
    {
      id: 4,
      title: 'Mentalidade de Campeão',
      description: 'Como desenvolver a mentalidade dos grandes jogadores profissionais',
      thumbnail: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '20:15',
      views: '4.2K',
      category: 'motivacao',
      level: 'Todos os níveis',
      instructor: 'Coach Roberto Lima'
    },
    {
      id: 5,
      title: 'Posicionamento Defensivo',
      description: 'Aprenda os fundamentos do posicionamento na defesa',
      thumbnail: 'https://images.pexels.com/photos/1171084/pexels-photo-1171084.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '18:45',
      views: '1.9K',
      category: 'tatica',
      level: 'Intermediário',
      instructor: 'Prof. Miguel Torres'
    },
    {
      id: 6,
      title: 'Superando Derrotas e Fracassos',
      description: 'Como transformar derrotas em aprendizado e motivação',
      thumbnail: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '14:30',
      views: '2.7K',
      category: 'mental',
      level: 'Todos os níveis',
      instructor: 'Psicólogo Esportivo Dr. Pedro'
    },
    {
      id: 7,
      title: 'Finalizações Certeiras',
      description: 'Técnicas avançadas para melhorar sua precisão no gol',
      thumbnail: 'https://images.pexels.com/photos/114296/pexels-photo-114296.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '22:10',
      views: '5.1K',
      category: 'tecnica',
      level: 'Avançado',
      instructor: 'Ex-atacante Luis Fernando'
    },
    {
      id: 8,
      title: 'Foco e Concentração em Campo',
      description: 'Exercícios mentais para manter o foco durante toda a partida',
      thumbnail: 'https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      duration: '11:25',
      views: '1.5K',
      category: 'mental',
      level: 'Intermediário',
      instructor: 'Mental Coach Maria'
    }
  ];

  const filteredVideos = selectedCategory === 'todos' 
    ? videos 
    : videos.filter(video => video.category === selectedCategory);

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Iniciante': return 'bg-green-100 text-green-800';
      case 'Intermediário': return 'bg-yellow-100 text-yellow-800';
      case 'Avançado': return 'bg-red-100 text-red-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'tatica': return 'bg-blue-500';
      case 'mental': return 'bg-purple-500';
      case 'tecnica': return 'bg-green-500';
      case 'motivacao': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={{ color: tokens.textPrimary }}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Mentalidade</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>Desenvolva sua Mente</h2>
          <p style={{ color: tokens.textSecondary }}>Vídeos exclusivos para elevar seu jogo ao próximo nível</p>
        </div>

        {/* Stats */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
          <h3 className="text-lg font-semibold mb-4" style={{ color: tokens.textPrimary }}>Seu Progresso</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Play className="w-6 h-6 text-purple-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>12</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Vídeos assistidos</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>4h</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Tempo de estudo</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Trophy className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>85%</div>
              <div className="text-sm" style={{ color: tokens.textSecondary }}>Progresso</div>
            </div>
          </div>
        </div>

        {/* Category Filter */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>Categorias</h3>
            <Filter className="w-5 h-5" style={{ color: tokens.iconSecondary }} />
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200"
                  style={{
                    backgroundColor: selectedCategory === category.id ? '#A855F7' : tokens.surfaceAlt,
                    color: selectedCategory === category.id ? '#FFFFFF' : tokens.textPrimary,
                    border: selectedCategory === category.id ? 'none' : `1px solid ${tokens.border}`
                  }}
                >
                  <IconComponent className="w-4 h-4 mr-2" />
                  {category.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Videos Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>
              {selectedCategory === 'todos' ? 'Todos os Vídeos' : categories.find(c => c.id === selectedCategory)?.label}
            </h3>
            <span className="text-sm" style={{ color: tokens.textSecondary }}>{filteredVideos.length} vídeos</span>
          </div>
          
          <div className="space-y-4">
            {filteredVideos.map((video) => (
              <div key={video.id} className="rounded-2xl shadow-sm border overflow-hidden hover:shadow-md transition-all duration-200" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
                <div className="flex">
                  <div className="relative w-32 h-24 flex-shrink-0">
                    <img 
                      src={video.thumbnail} 
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                      <div className="w-8 h-8 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                        <Play className="w-4 h-4 text-gray-800 ml-0.5" />
                      </div>
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 text-white text-xs px-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                  
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900 text-sm line-clamp-2 flex-1">
                        {video.title}
                      </h4>
                      <div className={`w-3 h-3 rounded-full ml-2 flex-shrink-0 ${getCategoryColor(video.category)}`}></div>
                    </div>
                    
                    <p className="text-xs text-gray-600 mb-3 line-clamp-2">
                      {video.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getLevelColor(video.level)}`}>
                          {video.level}
                        </span>
                        <div className="flex items-center text-gray-500">
                          <Eye className="w-3 h-3 mr-1" />
                          <span className="text-xs">{video.views}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-2">
                      <span className="text-xs text-gray-500">{video.instructor}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended Section */}
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl p-6 text-white mb-8">
          <div className="flex items-center mb-4">
            <Star className="w-6 h-6 mr-2 text-yellow-300" />
            <h3 className="text-lg font-semibold">Recomendado para Você</h3>
          </div>
          <p className="text-purple-100 mb-4">
            Com base no seu perfil de atacante, recomendamos focar em vídeos de finalização e mentalidade competitiva.
          </p>
          <button className="bg-white text-purple-600 px-4 py-2 rounded-full font-semibold text-sm hover:bg-purple-50 transition-colors">
            Ver Recomendações
          </button>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}