import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import BackgroundVideoLoop from './BackgroundVideoLoop';

interface TrainingPreRollScreenProps {
  categoryName: string;
  categoryIcon: string;
  videoUrl?: string;
  isDarkMode: boolean;
  onStart: () => void;
  onExit: () => void;
}

export default function TrainingPreRollScreen({
  categoryName,
  categoryIcon,
  videoUrl,
  isDarkMode,
  onStart,
  onExit
}: TrainingPreRollScreenProps) {
  const [countdown, setCountdown] = useState(20);
  const [isRunning, setIsRunning] = useState(true);

  useEffect(() => {
    console.log('preroll_started', { seconds: 20 });
  }, []);

  useEffect(() => {
    if (isRunning && countdown > 0) {
      const timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            console.log('preroll_completed_auto_start', { true: true });
            setTimeout(() => onStart(), 100);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isRunning, countdown, onStart]);

  const handleAddTime = () => {
    setCountdown(prev => prev + 20);
  };

  const bgClass = isDarkMode ? 'bg-black' : 'bg-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';
  const cardClass = isDarkMode ? 'bg-gray-900' : 'bg-gray-50';

  return (
    <div className={`min-h-screen ${bgClass} flex flex-col relative overflow-hidden`}>
      {videoUrl && (
        <BackgroundVideoLoop
          videoUrl={videoUrl}
          opacity={0.25}
          isPlaying={true}
          isMuted={true}
        />
      )}

      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70 pointer-events-none z-10" />

      <div className="pt-12 relative z-20"></div>

      <div className="flex items-center justify-between px-6 py-4 relative z-20">
        <button
          onClick={onExit}
          className={`p-2 ${isDarkMode ? 'bg-gray-800/80 backdrop-blur-sm' : 'bg-gray-100/80 backdrop-blur-sm'} rounded-full`}
        >
          <X className="w-6 h-6 text-white" />
        </button>

        <h1 className="text-lg font-bold text-white">Preparação</h1>

        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 relative z-20">
        <div className="text-center mb-12">
          <div className="text-8xl mb-6 drop-shadow-lg">{categoryIcon}</div>

          <h2 className="text-3xl font-bold text-white mb-4 drop-shadow-lg">
            Treino de {categoryName}
          </h2>

          <p className="text-gray-100 text-lg mb-8 max-w-md drop-shadow-md">
            Prepare seu espaço, mantenha-se hidratado e foque no seu objetivo
          </p>
        </div>

        <div className={`${cardClass} rounded-3xl p-8 w-full max-w-sm backdrop-blur-md bg-opacity-90`}>
          <div className="text-center mb-8">
            <div className={`text-8xl font-bold ${textClass} mb-2`}>
              {countdown}
            </div>
            <div className={`text-sm ${secondaryTextClass} uppercase tracking-wide`}>
              segundos para começar
            </div>
          </div>

          <div className="mb-6">
            <button
              onClick={handleAddTime}
              className="w-full py-3 rounded-xl font-bold transition-all bg-blue-500 text-white hover:bg-blue-600 active:scale-95"
            >
              +20s
            </button>
          </div>

          <div className={`${isDarkMode ? 'bg-blue-900/30' : 'bg-blue-50'} rounded-xl p-4 border ${isDarkMode ? 'border-blue-800' : 'border-blue-200'}`}>
            <p className={`text-sm ${isDarkMode ? 'text-blue-300' : 'text-blue-700'} text-center`}>
              💡 O treino iniciará automaticamente quando o contador chegar a zero
            </p>
          </div>
        </div>

        <button
          onClick={onStart}
          className="mt-8 bg-green-500 text-white px-12 py-4 rounded-2xl font-bold text-lg hover:bg-green-600 transition-colors active:scale-95 w-full max-w-sm"
        >
          Começar
        </button>
      </div>

      <div className="h-1 bg-white mx-auto mb-2 rounded-full relative z-20" style={{width: '134px'}}></div>
    </div>
  );
}
