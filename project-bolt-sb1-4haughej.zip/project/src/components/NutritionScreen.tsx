import React, { useState } from 'react';
import { ChevronLeft, Apple, Droplets, Clock, Zap, Award, Target, TrendingUp, Calendar, BookOpen, Crown } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface NutritionScreenProps {
  userId?: string;
  onBack: () => void;
  onNavigateToDailyChallenge?: () => void;
  onNavigateToMealPlans?: () => void;
  onNavigateToHistory?: () => void;
}

export default function NutritionScreen({ userId, onBack, onNavigateToDailyChallenge, onNavigateToMealPlans, onNavigateToHistory }: NutritionScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'tips'>('overview');
  const nutritionTips = [
    {
      id: 1,
      icon: Droplets,
      title: 'Hidratação é fundamental',
      description: 'Beba pelo menos 3L de água por dia. Durante treinos, hidrate-se a cada 15-20 minutos.',
      color: 'bg-blue-500'
    },
    {
      id: 2,
      icon: Clock,
      title: 'Timing das refeições',
      description: 'Coma carboidratos 2-3h antes do treino e proteínas até 30min após o exercício.',
      color: 'bg-green-500'
    },
    {
      id: 3,
      icon: Zap,
      title: 'Energia para performance',
      description: 'Carboidratos complexos fornecem energia sustentada. Evite açúcares simples.',
      color: 'bg-yellow-500'
    },
    {
      id: 4,
      icon: Award,
      title: 'Recuperação muscular',
      description: 'Proteínas magras ajudam na recuperação. Consuma 1.6-2.2g por kg de peso corporal.',
      color: 'bg-purple-500'
    }
  ];

  const mealPlan = {
    'Café da Manhã': {
      icon: '🌅',
      foods: ['Aveia com banana', 'Ovos mexidos', 'Suco de laranja natural', 'Pão integral'],
      time: '6:00 - 8:00',
      color: 'bg-orange-100'
    },
    'Lanche da Manhã': {
      icon: '🍎',
      foods: ['Frutas (maçã, banana)', 'Castanhas', 'Iogurte natural'],
      time: '9:30 - 10:30',
      color: 'bg-green-100'
    },
    'Almoço': {
      icon: '🍽️',
      foods: ['Arroz integral', 'Frango grelhado', 'Feijão', 'Salada verde', 'Legumes'],
      time: '12:00 - 13:30',
      color: 'bg-blue-100'
    },
    'Lanche da Tarde': {
      icon: '🥤',
      foods: ['Vitamina de frutas', 'Sanduíche natural', 'Água de coco'],
      time: '15:00 - 16:00',
      color: 'bg-purple-100'
    },
    'Jantar': {
      icon: '🌙',
      foods: ['Peixe assado', 'Batata doce', 'Brócolis', 'Salada colorida'],
      time: '19:00 - 20:30',
      color: 'bg-indigo-100'
    }
  };

  const performanceFoods = [
    {
      category: 'Energia Rápida',
      icon: '⚡',
      foods: ['Banana', 'Tâmaras', 'Mel', 'Água de coco'],
      description: 'Para consumir 30min antes do treino',
      color: 'bg-yellow-50 border-yellow-200'
    },
    {
      category: 'Resistência',
      icon: '🏃‍♂️',
      foods: ['Aveia', 'Batata doce', 'Quinoa', 'Arroz integral'],
      description: 'Carboidratos complexos para energia sustentada',
      color: 'bg-green-50 border-green-200'
    },
    {
      category: 'Recuperação',
      icon: '💪',
      foods: ['Frango', 'Peixe', 'Ovos', 'Whey protein'],
      description: 'Proteínas para reparação muscular',
      color: 'bg-blue-50 border-blue-200'
    },
    {
      category: 'Anti-inflamatório',
      icon: '🌿',
      foods: ['Salmão', 'Abacate', 'Nozes', 'Açaí'],
      description: 'Reduzem inflamação e aceleram recuperação',
      color: 'bg-purple-50 border-purple-200'
    }
  ];

  const hydrationPlan = [
    { time: 'Ao acordar', amount: '500ml', tip: 'Água morna com limão' },
    { time: 'Pré-treino', amount: '300ml', tip: '30min antes do exercício' },
    { time: 'Durante treino', amount: '150ml', tip: 'A cada 15-20 minutos' },
    { time: 'Pós-treino', amount: '500ml', tip: 'Reposição imediata' },
    { time: 'Ao longo do dia', amount: '2L+', tip: 'Pequenos goles constantes' }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={{ color: tokens.textPrimary }}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Nutrição Esportiva</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Apple className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>Alimente sua Performance</h2>
          <p style={{ color: tokens.textSecondary }}>Nutrição personalizada para atletas de alto rendimento</p>
        </div>

        {/* Daily Challenge Card */}
        {onNavigateToDailyChallenge && (
          <div className="mb-8">
            <button
              onClick={onNavigateToDailyChallenge}
              className="w-full rounded-2xl p-6 shadow-lg border-2 transition-transform active:scale-95"
              style={{
                backgroundColor: tokens.accent,
                borderColor: tokens.accent,
                backgroundImage: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 100%)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-white" />
                  <div className="text-left">
                    <h3 className="text-xl font-bold text-white">Desafio de Nutrição</h3>
                    <p className="text-sm text-white/90">Prato do Dia</p>
                  </div>
                </div>
                <Award className="w-8 h-8 text-white" />
              </div>
              <div className="text-left">
                <p className="text-white/90 text-sm mb-2">
                  Faça o prato do dia e envie uma foto para ganhar pontos!
                </p>
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-white" />
                  <span className="text-white font-bold">50 pontos disponíveis</span>
                </div>
              </div>
            </button>
          </div>
        )}

        {/* Quick Access Cards */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {onNavigateToMealPlans && (
            <button
              onClick={onNavigateToMealPlans}
              className="rounded-2xl p-6 shadow-sm border transition-transform active:scale-95 text-left"
              style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}
            >
              <BookOpen className="w-8 h-8 mb-3" style={{ color: tokens.accent }} />
              <h3 className="text-lg font-bold mb-1" style={{ color: tokens.textPrimary }}>
                Planos Alimentares
              </h3>
              <p className="text-sm" style={{ color: tokens.textSecondary }}>
                Personalizados por objetivo
              </p>
            </button>
          )}
          {onNavigateToHistory && (
            <button
              onClick={onNavigateToHistory}
              className="rounded-2xl p-6 shadow-sm border transition-transform active:scale-95 text-left"
              style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}
            >
              <Calendar className="w-8 h-8 mb-3" style={{ color: tokens.accent }} />
              <h3 className="text-lg font-bold mb-1" style={{ color: tokens.textPrimary }}>
                Histórico
              </h3>
              <p className="text-sm" style={{ color: tokens.textSecondary }}>
                Veja seu progresso
              </p>
            </button>
          )}
        </div>

        {/* Modo PRO Banner */}
        <div className="mb-8">
          <div
            className="rounded-2xl p-6 border-2 relative overflow-hidden"
            style={{
              backgroundColor: tokens.surfaceAlt,
              borderColor: '#fbbf24',
              backgroundImage: 'linear-gradient(135deg, rgba(251, 191, 36, 0.1) 0%, transparent 100%)'
            }}
          >
            <div className="flex items-start gap-4">
              <Crown className="w-10 h-10 text-yellow-500 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2" style={{ color: tokens.textPrimary }}>
                  Modo PRO
                </h3>
                <p className="text-sm mb-3 leading-relaxed" style={{ color: tokens.textSecondary }}>
                  Desbloqueie planos profissionais, receitas exclusivas, suplementação e dicas de nutricionistas especializados
                </p>
                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="px-3 py-1 rounded-full bg-yellow-500 text-white font-medium">
                    Receitas Exclusivas
                  </span>
                  <span className="px-3 py-1 rounded-full bg-yellow-500 text-white font-medium">
                    Suplementação
                  </span>
                  <span className="px-3 py-1 rounded-full bg-yellow-500 text-white font-medium">
                    Dicas PRO
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Nutrition Tips */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4" style={{ color: tokens.textPrimary }}>Dicas Fundamentais</h3>
          <div className="space-y-4">
            {nutritionTips.map((tip) => {
              const IconComponent = tip.icon;
              return (
                <div key={tip.id} className="rounded-2xl p-6 shadow-sm border" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
                  <div className="flex items-start">
                    <div className={`w-12 h-12 ${tip.color} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold mb-2" style={{ color: tokens.textPrimary }}>{tip.title}</h4>
                      <p style={{ color: tokens.textSecondary }}>{tip.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Meal Plan */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4" style={{ color: tokens.textPrimary }}>Plano Alimentar Diário</h3>
          <div className="space-y-4">
            {Object.entries(mealPlan).map(([mealName, meal]) => (
              <div key={mealName} className="rounded-2xl p-6 border" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">{meal.icon}</span>
                    <div>
                      <h4 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>{mealName}</h4>
                      <p className="text-sm" style={{ color: tokens.textSecondary }}>{meal.time}</p>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {meal.foods.map((food, index) => (
                    <span key={index} className="px-3 py-1 text-sm rounded-full font-medium" style={{ backgroundColor: tokens.surface, color: tokens.textPrimary }}>
                      {food}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Foods */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4" style={{ color: tokens.textPrimary }}>Alimentos para Performance</h3>
          <div className="grid grid-cols-1 gap-4">
            {performanceFoods.map((category, index) => (
              <div key={index} className="rounded-2xl p-6 border-2" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
                <div className="flex items-center mb-3">
                  <span className="text-2xl mr-3">{category.icon}</span>
                  <h4 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>{category.category}</h4>
                </div>
                <p className="text-sm mb-3" style={{ color: tokens.textSecondary }}>{category.description}</p>
                <div className="flex flex-wrap gap-2">
                  {category.foods.map((food, foodIndex) => (
                    <span key={foodIndex} className="px-3 py-1 text-sm rounded-full font-medium" style={{ backgroundColor: tokens.surface, color: tokens.textPrimary }}>
                      {food}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hydration Plan */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4" style={{ color: tokens.textPrimary }}>Plano de Hidratação</h3>
          <div className="rounded-2xl p-6 border-2" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
            <div className="flex items-center mb-4">
              <Droplets className="w-6 h-6 mr-3" style={{ color: tokens.accent }} />
              <h4 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>Meta Diária: 3+ Litros</h4>
            </div>
            <div className="space-y-3">
              {hydrationPlan.map((plan, index) => (
                <div key={index} className="flex items-center justify-between rounded-xl p-4" style={{ backgroundColor: tokens.surface }}>
                  <div className="flex-1">
                    <div className="font-semibold" style={{ color: tokens.textPrimary }}>{plan.time}</div>
                    <div className="text-sm" style={{ color: tokens.textSecondary }}>{plan.tip}</div>
                  </div>
                  <div className="font-bold text-lg" style={{ color: tokens.accent }}>{plan.amount}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Suas Metas Nutricionais</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Target className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">2800</div>
              <div className="text-sm text-gray-600">Calorias/dia</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">140g</div>
              <div className="text-sm text-gray-600">Proteínas/dia</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}