import React, { useState, useEffect } from 'react';
import { Trophy, Star, TrendingUp, CheckCircle2, Camera } from 'lucide-react';

interface TrainingPointsScreenProps {
  pointsEarned: number;
  maxPoints: number;
  hasProof: boolean;
  onComplete: () => void;
}

export default function TrainingPointsScreen({
  pointsEarned,
  maxPoints,
  hasProof,
  onComplete
}: TrainingPointsScreenProps) {
  const [animatedPoints, setAnimatedPoints] = useState(0);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    setTimeout(() => setShowContent(true), 300);

    const duration = 2000;
    const steps = 60;
    const increment = pointsEarned / steps;
    let current = 0;

    const interval = setInterval(() => {
      current += increment;
      if (current >= pointsEarned) {
        setAnimatedPoints(pointsEarned);
        clearInterval(interval);
      } else {
        setAnimatedPoints(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(interval);
  }, [pointsEarned]);

  const percentage = (pointsEarned / maxPoints) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-800 flex flex-col items-center justify-center px-6 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-white/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>
      </div>

      <div
        className={`relative z-10 w-full max-w-md transition-all duration-700 transform ${
          showContent ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}
      >
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mb-6 animate-bounce">
            <Trophy className="w-12 h-12 text-yellow-300" />
          </div>

          <h1 className="text-3xl font-extrabold text-white mb-3">
            Treino Concluído!
          </h1>

          <p className="text-purple-100 text-lg">
            {hasProof ? 'Você completou seu treino e enviou a comprovação!' : 'Você completou seu treino!'}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-6 border border-white/20 shadow-2xl">
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 mb-4">
              <Star className="w-6 h-6 text-yellow-300" />
              <span className="text-white/80 text-sm font-medium uppercase tracking-wider">
                Pontos Ganhos
              </span>
              <Star className="w-6 h-6 text-yellow-300" />
            </div>

            <div className="relative">
              <div
                className="text-7xl font-black text-white mb-2 transition-all duration-300"
                style={{
                  textShadow: '0 0 40px rgba(255, 255, 255, 0.5)',
                  transform: animatedPoints === pointsEarned ? 'scale(1.1)' : 'scale(1)'
                }}
              >
                {animatedPoints}
              </div>
              <div className="text-white/60 text-lg">
                de {maxPoints} pontos possíveis
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-yellow-400 to-yellow-300 rounded-full transition-all duration-2000 ease-out"
                style={{ width: `${percentage}%` }}
              ></div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                {hasProof ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-medium">Com comprovação</span>
                  </>
                ) : (
                  <>
                    <Camera className="w-5 h-5 text-yellow-400" />
                    <span className="text-yellow-300 font-medium">Sem comprovação</span>
                  </>
                )}
              </div>
              <div className="text-white font-bold">
                {percentage.toFixed(0)}%
              </div>
            </div>
          </div>
        </div>

        {!hasProof && (
          <div className="bg-yellow-500/20 backdrop-blur-sm border border-yellow-400/30 rounded-2xl p-4 mb-6">
            <p className="text-yellow-100 text-sm text-center">
              <span className="font-semibold">💡 Dica:</span> Envie uma foto na próxima vez para ganhar 100% dos pontos!
            </p>
          </div>
        )}

        <div className="space-y-3">
          <button
            onClick={onComplete}
            className="w-full bg-white text-purple-700 py-4 rounded-2xl font-bold text-lg hover:bg-purple-50 transition-all transform hover:scale-105 active:scale-95 shadow-xl"
          >
            Continuar
          </button>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500/30 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="text-white font-semibold">Próximo treino em</div>
                  <div className="text-purple-200 text-sm">24 horas</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white/60 text-xs">Bloqueado por</div>
                <div className="text-white font-bold">1 dia</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-0 right-0 flex justify-center">
        <div className="h-1 bg-white/30 rounded-full" style={{ width: '134px' }}></div>
      </div>
    </div>
  );
}
