import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, Plus, Building2, Calendar, TrendingUp, Target, Award, CreditCard as Edit, Trash2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry } from '../utils/videoUtils';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface CareerEntry {
  id: string;
  club_name: string;
  club_logo_url: string;
  position: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
  games_played: number;
  goals_scored: number;
  assists: number;
  achievements: string[];
  is_professional: boolean;
  display_order: number;
}

interface CareerOverviewScreenProps {
  userId: string;
  isOwnProfile: boolean;
  onBack: () => void;
}

export default function CareerOverviewScreen({ userId, isOwnProfile, onBack }: CareerOverviewScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [career, setCareer] = useState<CareerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  const styles = useMemo(() => ({
    container: {
      backgroundColor: theme.surface
    },
    header: {
      backgroundColor: theme.surface,
      borderColor: theme.border
    },
    card: {
      backgroundColor: theme.surfaceAlt,
      borderColor: theme.border
    },
    textPrimary: {
      color: theme.textPrimary
    },
    textSecondary: {
      color: theme.textSecondary
    },
    icon: {
      color: theme.icon
    },
    accent: {
      backgroundColor: theme.accent,
      color: theme.textInverse
    },
    accentText: {
      color: theme.accent
    },
    accentBorder: {
      borderColor: theme.accent
    }
  }), [themeVersion, theme]);

  useEffect(() => {
    loadCareer();
    logTelemetry(userId, 'career_overview_opened');
  }, [userId]);

  async function loadCareer() {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('athlete_career')
        .select('*')
        .eq('user_id', userId)
        .order('is_current', { ascending: false })
        .order('start_date', { ascending: false });

      setCareer(data || []);
    } catch (err) {
      console.error('Error loading career:', err);
    } finally {
      setLoading(false);
    }
  }

  function formatDate(date: string | null): string {
    if (!date) return 'Atual';
    return new Date(date).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
  }

  const totalGames = career.reduce((sum, entry) => sum + entry.games_played, 0);
  const totalGoals = career.reduce((sum, entry) => sum + entry.goals_scored, 0);
  const totalAssists = career.reduce((sum, entry) => sum + entry.assists, 0);
  const professionalClubs = career.filter(c => c.is_professional).length;

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center justify-between p-4 border-b" style={styles.header}>
        <button onClick={onBack} className="p-2 rounded-lg">
          <ChevronLeft className="w-6 h-6" style={styles.icon} />
        </button>
        <h1 className="text-xl font-bold" style={styles.textPrimary}>
          Visão Geral do Atleta
        </h1>
        <div className="w-10" />
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-6 space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 rounded-2xl animate-pulse" style={styles.card} />
            ))}
          </div>
        ) : (
          <>
            {/* Career Stats Summary */}
            <div className="p-6 space-y-4">
              <div className="rounded-2xl p-6 border" style={styles.card}>
                <h3 className="text-lg font-bold mb-4" style={styles.textPrimary}>
                  Estatísticas da Carreira
                </h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Building2 className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {career.length}
                    </p>
                    <p className="text-xs" style={styles.textSecondary}>
                      Clubes
                    </p>
                  </div>

                  <div className="text-center p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Calendar className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {totalGames}
                    </p>
                    <p className="text-xs" style={styles.textSecondary}>
                      Jogos
                    </p>
                  </div>

                  <div className="text-center p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Target className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {totalGoals}
                    </p>
                    <p className="text-xs" style={styles.textSecondary}>
                      Gols
                    </p>
                  </div>

                  <div className="text-center p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <TrendingUp className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {totalAssists}
                    </p>
                    <p className="text-xs" style={styles.textSecondary}>
                      Assistências
                    </p>
                  </div>
                </div>

                {professionalClubs > 0 && (
                  <div className="mt-4 p-3 rounded-xl text-center" style={styles.accent}>
                    <p className="text-sm font-semibold">
                      🏆 {professionalClubs} clube{professionalClubs > 1 ? 's' : ''} profissional{professionalClubs > 1 ? 'is' : ''}
                    </p>
                  </div>
                )}
              </div>

              {/* Career Timeline */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold" style={styles.textPrimary}>
                    Histórico de Clubes
                  </h3>
                  {isOwnProfile && (
                    <button
                      onClick={() => setShowAddForm(true)}
                      className="p-2 rounded-lg transition-transform active:scale-95"
                      style={styles.card}
                    >
                      <Plus className="w-5 h-5" style={styles.accentText} />
                    </button>
                  )}
                </div>

                {career.length === 0 ? (
                  <div className="rounded-2xl p-12 border text-center" style={styles.card}>
                    <Building2 className="w-12 h-12 mx-auto mb-3" style={styles.icon} />
                    <p className="text-sm mb-4" style={styles.textSecondary}>
                      {isOwnProfile
                        ? 'Adicione seu histórico de clubes para mostrar sua trajetória'
                        : 'Nenhum histórico de clubes disponível'}
                    </p>
                    {isOwnProfile && (
                      <button
                        onClick={() => setShowAddForm(true)}
                        className="px-6 py-3 rounded-xl font-semibold transition-transform active:scale-95"
                        style={styles.accent}
                      >
                        Adicionar Clube
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {career.map((entry, index) => (
                      <div key={entry.id} className="rounded-2xl p-6 border" style={styles.card}>
                        {/* Timeline Indicator */}
                        <div className="flex items-start gap-4">
                          {/* Logo or Icon */}
                          <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center border-2" style={{ borderColor: theme.border }}>
                            {entry.club_logo_url ? (
                              <img src={entry.club_logo_url} alt={entry.club_name} className="w-full h-full object-cover" />
                            ) : (
                              <Building2 className="w-8 h-8" style={styles.icon} />
                            )}
                          </div>

                          {/* Club Info */}
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h4 className="text-lg font-bold" style={styles.textPrimary}>
                                  {entry.club_name}
                                </h4>
                                {entry.is_professional && (
                                  <span className="inline-block px-2 py-0.5 rounded text-xs font-semibold mt-1" style={styles.accent}>
                                    Profissional
                                  </span>
                                )}
                              </div>
                              {entry.is_current && (
                                <span className="px-3 py-1 rounded-full text-xs font-semibold" style={styles.accent}>
                                  Atual
                                </span>
                              )}
                            </div>

                            {entry.position && (
                              <p className="text-sm mb-2" style={styles.textSecondary}>
                                {entry.position}
                              </p>
                            )}

                            <p className="text-xs mb-3" style={styles.textSecondary}>
                              {formatDate(entry.start_date)} - {entry.is_current ? 'Atual' : formatDate(entry.end_date)}
                            </p>

                            {/* Stats */}
                            {(entry.games_played > 0 || entry.goals_scored > 0 || entry.assists > 0) && (
                              <div className="flex gap-4 mb-3">
                                {entry.games_played > 0 && (
                                  <div className="text-center">
                                    <p className="text-xl font-bold" style={styles.textPrimary}>
                                      {entry.games_played}
                                    </p>
                                    <p className="text-xs" style={styles.textSecondary}>
                                      jogos
                                    </p>
                                  </div>
                                )}
                                {entry.goals_scored > 0 && (
                                  <div className="text-center">
                                    <p className="text-xl font-bold" style={styles.textPrimary}>
                                      {entry.goals_scored}
                                    </p>
                                    <p className="text-xs" style={styles.textSecondary}>
                                      gols
                                    </p>
                                  </div>
                                )}
                                {entry.assists > 0 && (
                                  <div className="text-center">
                                    <p className="text-xl font-bold" style={styles.textPrimary}>
                                      {entry.assists}
                                    </p>
                                    <p className="text-xs" style={styles.textSecondary}>
                                      assists
                                    </p>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Achievements */}
                            {entry.achievements && entry.achievements.length > 0 && (
                              <div className="space-y-1">
                                {entry.achievements.map((achievement, i) => (
                                  <div key={i} className="flex items-start gap-2">
                                    <Award className="w-4 h-4 mt-0.5 flex-shrink-0" style={styles.accentText} />
                                    <p className="text-xs" style={styles.textSecondary}>
                                      {achievement}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Add Form Placeholder */}
      {showAddForm && isOwnProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={styles.card}>
            <h3 className="text-lg font-bold mb-4" style={styles.textPrimary}>
              Adicionar Clube
            </h3>
            <p className="text-sm mb-4" style={styles.textSecondary}>
              Funcionalidade de adicionar clubes será implementada em breve.
            </p>
            <button
              onClick={() => setShowAddForm(false)}
              className="w-full py-3 rounded-xl font-semibold"
              style={styles.accent}
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
