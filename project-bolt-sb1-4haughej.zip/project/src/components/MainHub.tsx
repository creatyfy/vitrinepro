import React, { useMemo, useCallback, useState, useEffect } from 'react';
import { User, Target, Brain, Utensils, Trophy, ShoppingBag, Play, Star, TrendingUp, Calendar, Video, Award, ChevronRight, Siren as Fire, Medal, X, Bell, Search, Users, Clock, Image, Settings } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { OptimizedImage } from './OptimizedImage';
import { generateDailySession, getExerciseById, type DailySession } from '../data/weeklyTrainingData';

interface MainHubProps {
  athleteName: string;
  profile?: {
    full_name?: string;
    gender?: string;
    height?: number;
    weight?: number;
    player_position?: string;
  } | null;
  playerProfile?: {
    name?: string;
    position_1?: string;
  } | null;
  onThemeChange: (isDark: boolean) => void;
  onNavigateToTrainings: () => void;
  onNavigateToPeneiras: () => void;
  onNavigateToPeladas: () => void;
  onNavigateToNutrition: () => void;
  onNavigateToMindset: () => void;
  onNavigateToRanking: () => void;
  onNavigateToMarketplace: () => void;
  onNavigateToSettings: () => void;
  onNavigateToProfile: () => void;
  onNavigateToProofHistory: () => void;
  onNavigateToChallenge28: () => void;
  setCurrentStep: (step: string) => void;
}

const MainHub = React.memo(({ athleteName, profile, playerProfile, onThemeChange, onNavigateToTrainings, onNavigateToPeneiras, onNavigateToPeladas, onNavigateToNutrition, onNavigateToMindset, onNavigateToRanking, onNavigateToMarketplace, onNavigateToSettings, onNavigateToProfile, onNavigateToProofHistory, onNavigateToChallenge28, setCurrentStep }: MainHubProps) => {
  const { tokens, themeVersion, isDarkMode } = useTheme();

  // Check if user has already seen the notification modal
  const hasSeenNotificationModal = React.useMemo(() => {
    return localStorage.getItem('hasSeenNotificationModal') === 'true';
  }, []);

  const [showNotificationModal, setShowNotificationModal] = React.useState(!hasSeenNotificationModal);
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(false);
  const [dailySession, setDailySession] = useState<DailySession | null>(null);

  useEffect(() => {
    const today = new Date();
    const session = generateDailySession(today);
    setDailySession(session);
  }, []);

  const weeklyStats = {
    trainings: 4,
    points: 1250,
    videos: 2
  };

  const quickActions = [
    { id: 'trainings', label: 'Meus Treinos', icon: Target, color: 'bg-blue-500', description: 'Treinos personalizados' },
    { id: 'challenge28', label: 'Desafio 28 Dias', icon: Trophy, color: 'bg-red-600', description: 'Transforme seu corpo', onClick: onNavigateToChallenge28 },
    { id: 'proofs', label: 'Minhas Provas', icon: Image, color: 'bg-indigo-500', description: 'Histórico de verificações', onClick: onNavigateToProofHistory },
    { id: 'nutrition', label: 'Nutrição', icon: Utensils, color: 'bg-green-500', description: 'Plano alimentar', onClick: () => onNavigateToNutrition() },
    { id: 'mindset', label: 'Mentalidade', icon: Brain, color: 'bg-purple-500', description: 'Preparação mental', onClick: () => onNavigateToMindset() },
    { id: 'peneiras', label: 'Peneiras', icon: Trophy, color: 'bg-orange-500', description: 'Oportunidades em clubes' },
    { id: 'ranking', label: 'Ranking', icon: Trophy, color: 'bg-yellow-500', description: 'Classificação geral', onClick: () => onNavigateToRanking() },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag, color: 'bg-red-500', description: 'Produtos esportivos', onClick: onNavigateToMarketplace },
    { id: 'settings', label: 'Configurações', icon: () => <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 15.5A3.5 3.5 0 0 1 8.5 12A3.5 3.5 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5 3.5 3.5 0 0 1-3.5 3.5m7.43-2.53c.04-.32.07-.64.07-.97 0-.33-.03-.66-.07-1l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.31-.61-.22l-2.49 1c-.52-.39-1.06-.73-1.69-.98l-.37-2.65A.506.506 0 0 0 14 2h-4c-.25 0-.46.18-.5.42l-.37 2.65c-.63.25-1.17.59-1.69.98l-2.49-1c-.22-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.34-.07.67-.07 1 0 .33.03.65.07.97l-2.11 1.66c-.19.15-.25.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1.01c.52.4 1.06.74 1.69.99l.37 2.65c.04.24.25.42.5.42h4c.25 0 .46-.18.5-.42l.37-2.65c.63-.26 1.17-.59 1.69-.99l2.49 1.01c.22.08.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.66Z"/></svg>, color: 'bg-gray-500', description: 'Personalizar app', onClick: () => onNavigateToSettings() }
  ];

  const newsItems = [
    {
      id: 1,
      title: 'Novo treino de velocidade liberado',
      description: 'Melhore sua explosão com exercícios dos profissionais',
      image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      type: 'Treino'
    },
    {
      id: 2,
      title: 'João Silva em destaque',
      description: 'Atleta da semana conquistou vaga no time profissional',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      type: 'Destaque'
    },
    {
      id: 3,
      title: 'Oportunidade: Santos FC',
      description: 'Clube busca jovens talentos para categoria sub-20',
      image: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      type: 'Oportunidade'
    }
  ];

  const handleEnableNotifications = useCallback(() => {
    setNotificationsEnabled(true);
    setShowNotificationModal(false);
    localStorage.setItem('hasSeenNotificationModal', 'true');

    if ('Notification' in window) {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
          console.log('Notificações ativadas com sucesso!');
        }
      });
    }
  }, []);

  const handleCloseModal = useCallback(() => {
    setShowNotificationModal(false);
    localStorage.setItem('hasSeenNotificationModal', 'true');
  }, []);


  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      <div className="pt-12"></div>

      {/* Header */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: tokens.textPrimary }}>
              Vitrine Pro
            </h1>
            <p className="mt-1" style={{ color: tokens.textSecondary }}>Sua jornada rumo ao profissional</p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: tokens.textSecondary }} />
          <input
            type="text"
            placeholder="Buscar treinos, planos..."
            className="w-full pl-12 pr-4 py-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            style={{ backgroundColor: tokens.surfaceAlt, color: tokens.textPrimary, border: `1px solid ${tokens.border}` }}
          />
        </div>

        {/* Treino do Dia - Featured Button */}
        <button
          onClick={() => setCurrentStep('treino-do-dia')}
          className="w-full bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-4 mb-8 shadow-lg active:scale-95 transition-transform duration-200"
        >
          {dailySession ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-left">
                  <h3 className="text-white text-lg font-bold">Treino do Dia</h3>
                  <p className="text-white text-opacity-90 text-xs">{dailySession.exercises.length} exercícios • Semana {dailySession.week}</p>
                </div>
                <ChevronRight className="w-6 h-6 text-white" />
              </div>

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {dailySession.exercises.slice(0, 4).map((dailyExercise, index) => {
                  const exercise = getExerciseById(dailyExercise.exercise_id);
                  if (!exercise) return null;

                  const variant = exercise.variants[dailyExercise.chosen_env];

                  return (
                    <div key={exercise.id} className="flex items-center bg-white bg-opacity-10 rounded-xl p-2">
                      <div className="text-white text-opacity-80 text-xs font-bold mr-2 min-w-[20px]">
                        {index + 1}
                      </div>
                      <img
                        src={variant.video_url}
                        alt={exercise.name}
                        className="w-10 h-10 object-cover rounded-lg mr-2"
                      />
                      <div className="flex-1 text-left">
                        <p className="text-white text-sm font-semibold truncate">{exercise.name}</p>
                        <p className="text-white text-opacity-70 text-xs">{variant.reps}</p>
                      </div>
                    </div>
                  );
                })}

                {dailySession.exercises.length > 4 && (
                  <div className="text-center text-white text-opacity-80 text-xs font-semibold pt-1">
                    +{dailySession.exercises.length - 4} mais exercícios
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center py-4">
              <div className="text-white text-sm">Carregando treinos...</div>
            </div>
          )}
        </button>
      </div>



      {/* Quick Access Menu */}
      <div className="px-6 mb-8">
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={onNavigateToPeneiras}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center mb-4">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Peneiras</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Oportunidades em clubes</p>
          </button>
          
          <button
            onClick={onNavigateToPeladas}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Peladas/Torneios</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Jogos na sua região</p>
          </button>

          <button
            onClick={onNavigateToNutrition}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mb-4">
              <Utensils className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Nutrição</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Plano alimentar</p>
          </button>

          <button
            onClick={onNavigateToRanking}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-yellow-500 rounded-xl flex items-center justify-center mb-4">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Ranking</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Classificação geral</p>
          </button>

          <button
            onClick={onNavigateToMindset}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center mb-4">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Mentalidade</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Preparação mental</p>
          </button>

          <button
            onClick={onNavigateToMarketplace}
            className="rounded-2xl p-6 text-left transition-colors duration-200 active:scale-95"
            style={{ backgroundColor: tokens.surfaceAlt, border: `1px solid ${tokens.border}` }}
          >
            <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center mb-4">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-1" style={{ color: tokens.textPrimary }}>Marketplace</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Equipamentos esportivos</p>
          </button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 border-t" style={{ backgroundColor: tokens.surface, borderColor: tokens.border }}>
        <div className="flex justify-around py-3 px-4">
          <button
            onClick={() => setCurrentStep('daily-progress')}
            className="p-2 rounded-full transition-all active:scale-90"
            style={{ color: tokens.textPrimary }}
          >
            <Target className="w-6 h-6" />
          </button>
          <button
            onClick={onNavigateToTrainings}
            className="p-2 rounded-full transition-all active:scale-90"
            style={{ color: tokens.textPrimary }}
          >
            <Play className="w-6 h-6" />
          </button>
          <button
            onClick={onNavigateToProfile}
            className="p-2 rounded-full transition-all active:scale-90"
            style={{ color: tokens.textPrimary }}
          >
            <User className="w-6 h-6" />
          </button>
          <button
            onClick={onNavigateToRanking}
            className="p-2 rounded-full transition-all active:scale-90"
            style={{ color: tokens.textPrimary }}
          >
            <Calendar className="w-6 h-6" />
          </button>
          <button
            onClick={onNavigateToSettings}
            className="p-2 rounded-full transition-all active:scale-90"
            style={{ color: tokens.textPrimary }}
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>

      {/* Notification Modal */}
      {showNotificationModal && !notificationsEnabled && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-6 z-50">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full relative shadow-2xl">
            {/* Close Button */}
            <button 
              onClick={handleCloseModal}
              className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Phone Illustration */}
            <div className="flex justify-center mb-8">
              <div className="relative">
                {/* Phone */}
                <div className="w-32 h-56 bg-gray-900 rounded-3xl p-2 shadow-lg">
                  <div className="w-full h-full bg-orange-500 rounded-2xl relative overflow-hidden">
                    {/* Notch */}
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-16 h-4 bg-gray-900 rounded-full"></div>
                    
                    {/* Screen content */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <Bell className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Hand holding phone */}
                <div className="absolute -bottom-8 -left-4 w-20 h-16">
                  <svg viewBox="0 0 80 64" className="w-full h-full">
                    <path 
                      d="M20 40 C20 35, 25 30, 35 30 L45 30 C55 30, 60 35, 60 40 L60 50 C60 55, 55 60, 45 60 L35 60 C25 60, 20 55, 20 50 Z" 
                      fill="#D4A574" 
                    />
                    <path 
                      d="M15 45 C15 40, 18 35, 25 35 L30 35 L30 55 L25 55 C18 55, 15 50, 15 45 Z" 
                      fill="#D4A574" 
                    />
                  </svg>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
                As notificações do Vitrine Pro estão desabilitadas em seu dispositivo!
              </h2>
              
              <p className="text-gray-600 text-base leading-relaxed mb-8">
                Altere as permissões de notificação para poder receber as principais novidades sobre peneiras, 
                oportunidades em clubes, além de dicas e notícias para fazer os melhores treinos!
              </p>

              <button 
                onClick={handleEnableNotifications}
                className="w-full bg-orange-500 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-orange-600 transition-colors duration-200 active:scale-95 transform shadow-lg"
              >
                ACESSAR AS CONFIGURAÇÕES
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notification Modal */}
      {showNotificationModal && !notificationsEnabled && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-6 z-50">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full relative shadow-2xl">
            {/* Close Button */}
            <button 
              onClick={handleCloseModal}
              className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Phone Illustration */}
            <div className="flex justify-center mb-8">
              <div className="relative">
                {/* Phone */}
                <div className="w-32 h-56 bg-gray-900 rounded-3xl p-2 shadow-lg">
                  <div className="w-full h-full bg-orange-500 rounded-2xl relative overflow-hidden">
                    {/* Notch */}
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-16 h-4 bg-gray-900 rounded-full"></div>
                    
                    {/* Screen content */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <Bell className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Hand holding phone */}
                <div className="absolute -bottom-8 -left-4 w-20 h-16">
                  <svg viewBox="0 0 80 64" className="w-full h-full">
                    <path 
                      d="M20 40 C20 35, 25 30, 35 30 L45 30 C55 30, 60 35, 60 40 L60 50 C60 55, 55 60, 45 60 L35 60 C25 60, 20 55, 20 50 Z" 
                      fill="#D4A574" 
                    />
                    <path 
                      d="M15 45 C15 40, 18 35, 25 35 L30 35 L30 55 L25 55 C18 55, 15 50, 15 45 Z" 
                      fill="#D4A574" 
                    />
                  </svg>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
                As notificações do Vitrine Pro estão desabilitadas em seu dispositivo!
              </h2>
              
              <p className="text-gray-600 text-base leading-relaxed mb-8">
                Altere as permissões de notificação para poder receber as principais novidades sobre peneiras, 
                oportunidades em clubes, além de dicas e notícias para fazer os melhores treinos!
              </p>

              <button 
                onClick={handleEnableNotifications}
                className="w-full bg-orange-500 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-orange-600 transition-colors duration-200 active:scale-95 transform shadow-lg"
              >
                ACESSAR AS CONFIGURAÇÕES
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

MainHub.displayName = 'MainHub';

export default MainHub;