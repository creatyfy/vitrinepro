import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Shield,
  Eye,
  EyeOff,
  Lock,
  Users,
  Bell,
  Download,
  Trash2,
  ChevronRight,
  ChevronDown,
  AlertTriangle,
  CheckCircle,
  Monitor,
  Smartphone,
  MapPin,
  MessageSquare,
  History,
  FileText,
  UserX,
  Key,
  Mail,
  Globe,
  X,
  Check,
  Info
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';
import { supabase, type PrivacySettings, type NotificationPreferences, type LoginHistory, type BlockedUser } from '../lib/supabase';

interface PrivacyScreenProps {
  onBack: () => void;
}

type ExpandedSection = 'visibility' | 'data' | 'security' | 'notifications' | 'blocked' | null;
type ModalType = 'export' | 'delete' | 'change-password' | 'enable-2fa' | 'legal-docs' | null;

export default function PrivacyScreen({ onBack }: PrivacyScreenProps) {
  const { t } = useLanguage();
  const { isDarkMode } = useTheme();
  const [expandedSection, setExpandedSection] = useState<ExpandedSection>(null);
  const [loading, setLoading] = useState(true);
  const [privacySettings, setPrivacySettings] = useState<PrivacySettings | null>(null);
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences | null>(null);
  const [loginHistory, setLoginHistory] = useState<LoginHistory[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [selectedLegalDoc, setSelectedLegalDoc] = useState<'privacy' | 'terms' | 'lgpd' | null>(null);

  const [changePasswordForm, setChangePasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [twoFactorForm, setTwoFactorForm] = useState({
    method: 'app' as 'sms' | 'app' | 'email',
    phoneNumber: ''
  });

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';
  const accentBg = isDarkMode ? 'bg-green-600' : 'bg-green-500';
  const dangerBg = isDarkMode ? 'bg-red-600' : 'bg-red-500';
  const inputClass = isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-300 text-gray-900';

  useEffect(() => {
    loadPrivacyData();
  }, []);

  const loadPrivacyData = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setLoading(false);
      return;
    }

    const [privacyRes, notifRes, loginRes, blockedRes] = await Promise.all([
      supabase.from('user_privacy_settings').select('*').eq('user_id', user.id).maybeSingle(),
      supabase.from('notification_preferences').select('*').eq('user_id', user.id).maybeSingle(),
      supabase.from('login_history').select('*').eq('user_id', user.id).order('login_timestamp', { ascending: false }).limit(5),
      supabase.from('blocked_users').select('*').eq('blocker_id', user.id)
    ]);

    if (privacyRes.data) {
      setPrivacySettings(privacyRes.data);
    } else {
      const defaultSettings: Partial<PrivacySettings> = {
        user_id: user.id,
        profile_visibility: 'connections_only',
        video_visibility: 'connections_only',
        show_training_history: true,
        show_statistics: true,
        show_location: false,
        show_age: true,
        show_height_weight: true,
        allow_club_messages: true,
        allow_agent_messages: true,
        allow_athlete_messages: true,
        show_online_status: true
      };
      await supabase.from('user_privacy_settings').insert(defaultSettings);
      setPrivacySettings(defaultSettings as PrivacySettings);
    }

    if (notifRes.data) {
      setNotificationPrefs(notifRes.data);
    } else {
      const defaultNotifs: Partial<NotificationPreferences> = {
        user_id: user.id,
        training_reminders: true,
        peneira_alerts: true,
        message_notifications: true,
        achievement_notifications: true,
        club_interest_notifications: true,
        agent_interest_notifications: true,
        marketing_emails: false,
        newsletter: false,
        notification_frequency: 'realtime'
      };
      await supabase.from('notification_preferences').insert(defaultNotifs);
      setNotificationPrefs(defaultNotifs as NotificationPreferences);
    }

    if (loginRes.data) setLoginHistory(loginRes.data);
    if (blockedRes.data) setBlockedUsers(blockedRes.data);

    setLoading(false);
  };

  const updatePrivacySetting = async (key: keyof PrivacySettings, value: any) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('user_privacy_settings')
      .update({ [key]: value })
      .eq('user_id', user.id);

    setPrivacySettings(prev => prev ? { ...prev, [key]: value } : null);
  };

  const updateNotificationPref = async (key: keyof NotificationPreferences, value: any) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('notification_preferences')
      .update({ [key]: value })
      .eq('user_id', user.id);

    setNotificationPrefs(prev => prev ? { ...prev, [key]: value } : null);
  };

  const handleExportData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const exportData = {
      user_id: user.id,
      email: user.email,
      privacy_settings: privacySettings,
      notification_preferences: notificationPrefs,
      login_history: loginHistory,
      blocked_users: blockedUsers,
      export_date: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vitrine-pro-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setActiveModal(null);
  };

  const handleChangePassword = async () => {
    if (changePasswordForm.newPassword !== changePasswordForm.confirmPassword) {
      alert('As senhas não coincidem!');
      return;
    }

    if (changePasswordForm.newPassword.length < 6) {
      alert('A senha deve ter pelo menos 6 caracteres!');
      return;
    }

    const { error } = await supabase.auth.updateUser({
      password: changePasswordForm.newPassword
    });

    if (error) {
      alert('Erro ao alterar senha: ' + error.message);
    } else {
      alert('Senha alterada com sucesso!');
      setChangePasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setActiveModal(null);
    }
  };

  const handleEnable2FA = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const twoFactorData = {
      user_id: user.id,
      is_enabled: true,
      method: twoFactorForm.method,
      phone_number: twoFactorForm.method === 'sms' ? twoFactorForm.phoneNumber : null
    };

    const { error } = await supabase
      .from('two_factor_auth')
      .upsert(twoFactorData);

    if (error) {
      alert('Erro ao ativar 2FA: ' + error.message);
    } else {
      alert('Autenticação em duas etapas ativada com sucesso!');
      setActiveModal(null);
    }
  };

  const handleDeleteAccount = async () => {
    alert('Sua solicitação de exclusão de conta foi registrada. Entraremos em contato em até 48 horas.');
    setActiveModal(null);
  };

  const handleUnblockUser = async (blockedId: string) => {
    const { error } = await supabase
      .from('blocked_users')
      .delete()
      .eq('id', blockedId);

    if (error) {
      alert('Erro ao desbloquear usuário: ' + error.message);
    } else {
      setBlockedUsers(prev => prev.filter(b => b.id !== blockedId));
    }
  };

  const toggleSection = (section: ExpandedSection) => {
    console.log('🔄 Toggling section:', section);
    console.log('📍 Current expanded:', expandedSection);
    const newSection = expandedSection === section ? null : section;
    console.log('➡️ New section will be:', newSection);
    setExpandedSection(newSection);
  };

  const getPrivacyScore = () => {
    if (!privacySettings) return 0;
    let score = 0;
    if (privacySettings.profile_visibility === 'private') score += 20;
    if (privacySettings.profile_visibility === 'connections_only') score += 10;
    if (privacySettings.video_visibility === 'private') score += 20;
    if (privacySettings.video_visibility === 'connections_only') score += 10;
    if (!privacySettings.show_location) score += 15;
    if (!privacySettings.show_online_status) score += 10;
    if (!privacySettings.show_height_weight) score += 10;
    if (!privacySettings.allow_athlete_messages) score += 15;
    return Math.min(score, 100);
  };

  const privacyScore = getPrivacyScore();

  if (loading) {
    return (
      <div className={`min-h-screen ${bgClass} flex items-center justify-center`}>
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${bgClass}`}>
      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>Privacidade e Segurança</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6 pb-24">
        <div className="text-center mb-8">
          <div className={`w-16 h-16 ${accentBg} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>Centro de Privacidade</h2>
          <p className={secondaryTextClass}>Controle total sobre seus dados</p>
        </div>

        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-6`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className={`text-lg font-semibold ${textClass}`}>Nível de Privacidade</h3>
              <p className={`text-sm ${secondaryTextClass}`}>
                {privacyScore >= 70 ? 'Alto' : privacyScore >= 40 ? 'Médio' : 'Baixo'}
              </p>
            </div>
            <div className="text-right">
              <div className={`text-3xl font-bold ${textClass}`}>{privacyScore}</div>
              <div className={`text-xs ${secondaryTextClass}`}>de 100</div>
            </div>
          </div>
          <div className={`w-full h-3 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-full overflow-hidden`}>
            <div
              className={`h-full transition-all duration-500 ${
                privacyScore >= 70 ? 'bg-green-500' : privacyScore >= 40 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${privacyScore}%` }}
            ></div>
          </div>
        </div>

        <div className={`${cardClass} rounded-2xl shadow-sm border mb-4 overflow-hidden`}>
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('visibility');
            }}
            className="w-full p-6 flex items-center justify-between hover:bg-opacity-80 active:scale-98 transition-all cursor-pointer"
            type="button"
          >
            <div className="flex items-center flex-1">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-blue-50'} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                <Eye className={`w-6 h-6 ${isDarkMode ? 'text-blue-400' : 'text-blue-500'}`} />
              </div>
              <div className="text-left flex-1">
                <h3 className={`font-semibold ${textClass}`}>Visibilidade do Perfil</h3>
                <p className={`text-sm ${secondaryTextClass}`}>Controle quem vê suas informações</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              {expandedSection === 'visibility' ? (
                <ChevronDown className={`w-5 h-5 ${secondaryTextClass}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
              )}
            </div>
          </button>

          {expandedSection === 'visibility' && privacySettings ? (
            <div className={`px-6 pb-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} transition-all duration-300 ease-in-out`}>
              <div className="space-y-4 mt-4">
                <div>
                  <label className={`block text-sm font-medium ${textClass} mb-2`}>Perfil</label>
                  <select
                    value={privacySettings.profile_visibility}
                    onChange={(e) => updatePrivacySetting('profile_visibility', e.target.value)}
                    className={`w-full p-3 rounded-xl ${inputClass} border`}
                  >
                    <option value="public">Público - Todos podem ver</option>
                    <option value="connections_only">Apenas Conexões</option>
                    <option value="private">Privado - Só você</option>
                  </select>
                </div>

                <div>
                  <label className={`block text-sm font-medium ${textClass} mb-2`}>Vídeos</label>
                  <select
                    value={privacySettings.video_visibility}
                    onChange={(e) => updatePrivacySetting('video_visibility', e.target.value)}
                    className={`w-full p-3 rounded-xl ${inputClass} border`}
                  >
                    <option value="public">Público - Todos podem ver</option>
                    <option value="connections_only">Apenas Conexões</option>
                    <option value="private">Privado - Só você</option>
                  </select>
                </div>

                <ToggleOption
                  label="Mostrar Histórico de Treinos"
                  checked={privacySettings.show_training_history}
                  onChange={(val) => updatePrivacySetting('show_training_history', val)}
                  isDarkMode={isDarkMode}
                />
                <ToggleOption
                  label="Mostrar Estatísticas"
                  checked={privacySettings.show_statistics}
                  onChange={(val) => updatePrivacySetting('show_statistics', val)}
                  isDarkMode={isDarkMode}
                />
                <ToggleOption
                  label="Mostrar Localização"
                  checked={privacySettings.show_location}
                  onChange={(val) => updatePrivacySetting('show_location', val)}
                  isDarkMode={isDarkMode}
                />
                <ToggleOption
                  label="Mostrar Idade"
                  checked={privacySettings.show_age}
                  onChange={(val) => updatePrivacySetting('show_age', val)}
                  isDarkMode={isDarkMode}
                />
                <ToggleOption
                  label="Mostrar Altura e Peso"
                  checked={privacySettings.show_height_weight}
                  onChange={(val) => updatePrivacySetting('show_height_weight', val)}
                  isDarkMode={isDarkMode}
                />
                <ToggleOption
                  label="Mostrar Status Online"
                  checked={privacySettings.show_online_status}
                  onChange={(val) => updatePrivacySetting('show_online_status', val)}
                  isDarkMode={isDarkMode}
                />
              </div>
            </div>
          ) : null}
        </div>

        <div className={`${cardClass} rounded-2xl shadow-sm border mb-4 overflow-hidden`}>
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('notifications');
            }}
            className="w-full p-6 flex items-center justify-between hover:bg-opacity-80 active:scale-98 transition-all cursor-pointer"
            type="button"
          >
            <div className="flex items-center flex-1">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-purple-50'} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                <Bell className={`w-6 h-6 ${isDarkMode ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div className="text-left flex-1">
                <h3 className={`font-semibold ${textClass}`}>Notificações e Mensagens</h3>
                <p className={`text-sm ${secondaryTextClass}`}>Gerencie alertas e comunicações</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              {expandedSection === 'notifications' ? (
                <ChevronDown className={`w-5 h-5 ${secondaryTextClass}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
              )}
            </div>
          </button>

          {expandedSection === 'notifications' && notificationPrefs && privacySettings ? (
            <div className={`px-6 pb-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} transition-all duration-300 ease-in-out`}>
              <div className="space-y-4 mt-4">
                <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4 mb-4`}>
                  <h4 className={`font-semibold ${textClass} mb-3`}>Quem pode enviar mensagens</h4>
                  <ToggleOption
                    label="Clubes"
                    checked={privacySettings.allow_club_messages}
                    onChange={(val) => updatePrivacySetting('allow_club_messages', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Agentes"
                    checked={privacySettings.allow_agent_messages}
                    onChange={(val) => updatePrivacySetting('allow_agent_messages', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Outros Atletas"
                    checked={privacySettings.allow_athlete_messages}
                    onChange={(val) => updatePrivacySetting('allow_athlete_messages', val)}
                    isDarkMode={isDarkMode}
                  />
                </div>

                <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4`}>
                  <h4 className={`font-semibold ${textClass} mb-3`}>Notificações do App</h4>
                  <ToggleOption
                    label="Lembretes de Treino"
                    checked={notificationPrefs.training_reminders}
                    onChange={(val) => updateNotificationPref('training_reminders', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Alertas de Peneiras"
                    checked={notificationPrefs.peneira_alerts}
                    onChange={(val) => updateNotificationPref('peneira_alerts', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Notificações de Mensagens"
                    checked={notificationPrefs.message_notifications}
                    onChange={(val) => updateNotificationPref('message_notifications', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Conquistas"
                    checked={notificationPrefs.achievement_notifications}
                    onChange={(val) => updateNotificationPref('achievement_notifications', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Interesse de Clubes"
                    checked={notificationPrefs.club_interest_notifications}
                    onChange={(val) => updateNotificationPref('club_interest_notifications', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Interesse de Agentes"
                    checked={notificationPrefs.agent_interest_notifications}
                    onChange={(val) => updateNotificationPref('agent_interest_notifications', val)}
                    isDarkMode={isDarkMode}
                  />
                </div>

                <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4`}>
                  <h4 className={`font-semibold ${textClass} mb-3`}>E-mails e Marketing</h4>
                  <ToggleOption
                    label="E-mails de Marketing"
                    checked={notificationPrefs.marketing_emails}
                    onChange={(val) => updateNotificationPref('marketing_emails', val)}
                    isDarkMode={isDarkMode}
                  />
                  <ToggleOption
                    label="Newsletter"
                    checked={notificationPrefs.newsletter}
                    onChange={(val) => updateNotificationPref('newsletter', val)}
                    isDarkMode={isDarkMode}
                  />
                </div>
              </div>
            </div>
          ) : null}
        </div>

        <div className={`${cardClass} rounded-2xl shadow-sm border mb-4 overflow-hidden`}>
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('security');
            }}
            className="w-full p-6 flex items-center justify-between hover:bg-opacity-80 active:scale-98 transition-all cursor-pointer"
            type="button"
          >
            <div className="flex items-center flex-1">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-red-50'} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                <Lock className={`w-6 h-6 ${isDarkMode ? 'text-red-400' : 'text-red-500'}`} />
              </div>
              <div className="text-left flex-1">
                <h3 className={`font-semibold ${textClass}`}>Segurança da Conta</h3>
                <p className={`text-sm ${secondaryTextClass}`}>Histórico e proteção</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              {expandedSection === 'security' ? (
                <ChevronDown className={`w-5 h-5 ${secondaryTextClass}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
              )}
            </div>
          </button>

          {expandedSection === 'security' ? (
            <div className={`px-6 pb-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} transition-all duration-300 ease-in-out`}>
              <div className="space-y-4 mt-4">
                <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4`}>
                  <div className="flex items-center mb-3">
                    <History className={`w-5 h-5 ${secondaryTextClass} mr-2`} />
                    <h4 className={`font-semibold ${textClass}`}>Últimos Acessos</h4>
                  </div>
                  {loginHistory.length > 0 ? (
                    <div className="space-y-2">
                      {loginHistory.slice(0, 3).map((login) => (
                        <div key={login.id} className={`flex items-center justify-between py-2 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'} last:border-0`}>
                          <div className="flex items-center">
                            {login.device_type === 'mobile' ? (
                              <Smartphone className={`w-4 h-4 ${secondaryTextClass} mr-2`} />
                            ) : (
                              <Monitor className={`w-4 h-4 ${secondaryTextClass} mr-2`} />
                            )}
                            <div>
                              <p className={`text-sm font-medium ${textClass}`}>
                                {login.device_name || login.device_type}
                              </p>
                              <p className={`text-xs ${secondaryTextClass}`}>
                                {login.location_city ? `${login.location_city}, ${login.location_country}` : 'Localização desconhecida'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-xs ${secondaryTextClass}`}>
                              {new Date(login.login_timestamp).toLocaleDateString('pt-BR')}
                            </p>
                            <p className={`text-xs ${secondaryTextClass}`}>
                              {new Date(login.login_timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className={`text-sm ${secondaryTextClass}`}>Nenhum histórico disponível</p>
                  )}
                </div>

                <button
                  onClick={() => setActiveModal('change-password')}
                  className={`w-full ${cardClass} border rounded-xl p-4 flex items-center justify-between hover:bg-opacity-80 transition-all`}
                >
                  <div className="flex items-center">
                    <Key className={`w-5 h-5 ${secondaryTextClass} mr-3`} />
                    <span className={`font-medium ${textClass}`}>Alterar Senha</span>
                  </div>
                  <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
                </button>

                <button
                  onClick={() => setActiveModal('enable-2fa')}
                  className={`w-full ${cardClass} border rounded-xl p-4 flex items-center justify-between hover:bg-opacity-80 transition-all`}
                >
                  <div className="flex items-center">
                    <Shield className={`w-5 h-5 ${secondaryTextClass} mr-3`} />
                    <div className="text-left">
                      <p className={`font-medium ${textClass}`}>Autenticação em Duas Etapas</p>
                      <p className={`text-xs ${secondaryTextClass}`}>Adicionar camada extra de segurança</p>
                    </div>
                  </div>
                  <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
                </button>
              </div>
            </div>
          ) : null}
        </div>

        <div className={`${cardClass} rounded-2xl shadow-sm border mb-4 overflow-hidden`}>
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('data');
            }}
            className="w-full p-6 flex items-center justify-between hover:bg-opacity-80 active:scale-98 transition-all cursor-pointer"
            type="button"
          >
            <div className="flex items-center flex-1">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-yellow-50'} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                <FileText className={`w-6 h-6 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
              </div>
              <div className="text-left flex-1">
                <h3 className={`font-semibold ${textClass}`}>Meus Dados</h3>
                <p className={`text-sm ${secondaryTextClass}`}>Exportar e gerenciar dados</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              {expandedSection === 'data' ? (
                <ChevronDown className={`w-5 h-5 ${secondaryTextClass}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
              )}
            </div>
          </button>

          {expandedSection === 'data' ? (
            <div className={`px-6 pb-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} transition-all duration-300 ease-in-out`}>
              <div className="space-y-4 mt-4">
                <button
                  onClick={() => setActiveModal('export')}
                  className={`w-full ${isDarkMode ? 'bg-green-600 hover:bg-green-700' : 'bg-green-500 hover:bg-green-600'} text-white rounded-xl p-4 flex items-center justify-center transition-all`}
                >
                  <Download className="w-5 h-5 mr-2" />
                  Exportar Meus Dados
                </button>

                <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4`}>
                  <h4 className={`font-semibold ${textClass} mb-2`}>Seus Direitos (LGPD)</h4>
                  <ul className={`text-sm ${secondaryTextClass} space-y-1`}>
                    <li>• Acessar seus dados pessoais</li>
                    <li>• Corrigir dados incorretos</li>
                    <li>• Solicitar exclusão de dados</li>
                    <li>• Portabilidade de dados</li>
                    <li>• Revogar consentimento</li>
                  </ul>
                </div>

                <button
                  onClick={() => setActiveModal('delete')}
                  className={`w-full ${dangerBg} hover:opacity-90 text-white rounded-xl p-4 flex items-center justify-center transition-all`}
                >
                  <Trash2 className="w-5 h-5 mr-2" />
                  Excluir Minha Conta
                </button>
              </div>
            </div>
          ) : null}
        </div>

        <div className={`${cardClass} rounded-2xl shadow-sm border mb-4 overflow-hidden`}>
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('blocked');
            }}
            className="w-full p-6 flex items-center justify-between hover:bg-opacity-80 active:scale-98 transition-all cursor-pointer"
            type="button"
          >
            <div className="flex items-center flex-1">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-orange-50'} rounded-xl flex items-center justify-center mr-4 flex-shrink-0`}>
                <UserX className={`w-6 h-6 ${isDarkMode ? 'text-orange-400' : 'text-orange-600'}`} />
              </div>
              <div className="text-left flex-1">
                <h3 className={`font-semibold ${textClass}`}>Usuários Bloqueados</h3>
                <p className={`text-sm ${secondaryTextClass}`}>{blockedUsers.length} bloqueado(s)</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              {expandedSection === 'blocked' ? (
                <ChevronDown className={`w-5 h-5 ${secondaryTextClass}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
              )}
            </div>
          </button>

          {expandedSection === 'blocked' ? (
            <div className={`px-6 pb-6 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} transition-all duration-300 ease-in-out`}>
              <div className="space-y-3 mt-4">
                {blockedUsers.length > 0 ? (
                  blockedUsers.map((blocked) => (
                    <div key={blocked.id} className={`${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-xl p-4 flex items-center justify-between`}>
                      <div>
                        <p className={`font-medium ${textClass}`}>Usuário {blocked.blocked_type}</p>
                        <p className={`text-xs ${secondaryTextClass}`}>{blocked.reason || 'Sem motivo especificado'}</p>
                      </div>
                      <button
                        onClick={() => handleUnblockUser(blocked.id)}
                        className={`text-sm ${isDarkMode ? 'text-red-400' : 'text-red-500'} font-medium hover:underline`}
                      >
                        Desbloquear
                      </button>
                    </div>
                  ))
                ) : (
                  <p className={`text-sm ${secondaryTextClass} text-center py-4`}>Nenhum usuário bloqueado</p>
                )}
              </div>
            </div>
          ) : null}
        </div>

        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <h3 className={`text-lg font-semibold ${textClass} mb-4`}>Documentos Legais</h3>
          <div className="space-y-3">
            <button
              onClick={() => {
                setSelectedLegalDoc('privacy');
                setActiveModal('legal-docs');
              }}
              className="w-full flex items-center justify-between py-3 hover:bg-opacity-80 transition-all"
            >
              <div className="flex items-center">
                <FileText className={`w-5 h-5 ${secondaryTextClass} mr-3`} />
                <span className={textClass}>Política de Privacidade</span>
              </div>
              <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
            </button>
            <button
              onClick={() => {
                setSelectedLegalDoc('terms');
                setActiveModal('legal-docs');
              }}
              className="w-full flex items-center justify-between py-3 hover:bg-opacity-80 transition-all"
            >
              <div className="flex items-center">
                <FileText className={`w-5 h-5 ${secondaryTextClass} mr-3`} />
                <span className={textClass}>Termos de Uso</span>
              </div>
              <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
            </button>
            <button
              onClick={() => {
                setSelectedLegalDoc('lgpd');
                setActiveModal('legal-docs');
              }}
              className="w-full flex items-center justify-between py-3 hover:bg-opacity-80 transition-all"
            >
              <div className="flex items-center">
                <Globe className={`w-5 h-5 ${secondaryTextClass} mr-3`} />
                <span className={textClass}>Sobre LGPD</span>
              </div>
              <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
            </button>
          </div>
        </div>
      </div>

      {activeModal === 'export' && (
        <Modal
          title="Exportar Dados"
          description="Você receberá um arquivo JSON com todas as suas informações."
          icon={<Download className="w-8 h-8 text-white" />}
          iconBg={accentBg}
          onClose={() => setActiveModal(null)}
          onConfirm={handleExportData}
          confirmText="Exportar"
          confirmBg={accentBg}
          isDarkMode={isDarkMode}
          cardClass={cardClass}
          textClass={textClass}
          secondaryTextClass={secondaryTextClass}
        />
      )}

      {activeModal === 'delete' && (
        <Modal
          title="Excluir Conta?"
          description="Esta ação é irreversível. Todos os seus dados, vídeos e conquistas serão permanentemente excluídos."
          icon={<AlertTriangle className="w-8 h-8 text-white" />}
          iconBg={dangerBg}
          onClose={() => setActiveModal(null)}
          onConfirm={handleDeleteAccount}
          confirmText="Confirmar"
          confirmBg={dangerBg}
          isDarkMode={isDarkMode}
          cardClass={cardClass}
          textClass={textClass}
          secondaryTextClass={secondaryTextClass}
        />
      )}

      {activeModal === 'change-password' && (
        <ChangePasswordModal
          form={changePasswordForm}
          setForm={setChangePasswordForm}
          onClose={() => setActiveModal(null)}
          onConfirm={handleChangePassword}
          isDarkMode={isDarkMode}
          cardClass={cardClass}
          textClass={textClass}
          secondaryTextClass={secondaryTextClass}
          inputClass={inputClass}
          accentBg={accentBg}
        />
      )}

      {activeModal === 'enable-2fa' && (
        <Enable2FAModal
          form={twoFactorForm}
          setForm={setTwoFactorForm}
          onClose={() => setActiveModal(null)}
          onConfirm={handleEnable2FA}
          isDarkMode={isDarkMode}
          cardClass={cardClass}
          textClass={textClass}
          secondaryTextClass={secondaryTextClass}
          inputClass={inputClass}
          accentBg={accentBg}
        />
      )}

      {activeModal === 'legal-docs' && selectedLegalDoc && (
        <LegalDocsModal
          docType={selectedLegalDoc}
          onClose={() => {
            setActiveModal(null);
            setSelectedLegalDoc(null);
          }}
          isDarkMode={isDarkMode}
          cardClass={cardClass}
          textClass={textClass}
          secondaryTextClass={secondaryTextClass}
        />
      )}

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{ width: '134px' }}></div>
    </div>
  );
}

interface ToggleOptionProps {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  isDarkMode: boolean;
}

function ToggleOption({ label, checked, onChange, isDarkMode }: ToggleOptionProps) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>{label}</span>
      <button
        onClick={() => onChange(!checked)}
        className={`w-11 h-6 rounded-full transition-all duration-200 ${
          checked ? 'bg-green-500' : isDarkMode ? 'bg-gray-700' : 'bg-gray-300'
        }`}
      >
        <div
          className={`w-5 h-5 bg-white rounded-full transition-all duration-200 ${
            checked ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        ></div>
      </button>
    </div>
  );
}

interface ModalProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  iconBg: string;
  onClose: () => void;
  onConfirm: () => void;
  confirmText: string;
  confirmBg: string;
  isDarkMode: boolean;
  cardClass: string;
  textClass: string;
  secondaryTextClass: string;
}

function Modal({
  title,
  description,
  icon,
  iconBg,
  onClose,
  onConfirm,
  confirmText,
  confirmBg,
  isDarkMode,
  cardClass,
  textClass,
  secondaryTextClass
}: ModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-6">
      <div className={`${cardClass} rounded-2xl p-6 max-w-sm w-full`}>
        <div className="text-center mb-6">
          <div className={`w-16 h-16 ${iconBg} rounded-full flex items-center justify-center mx-auto mb-4`}>
            {icon}
          </div>
          <h3 className={`text-xl font-bold ${textClass} mb-2`}>{title}</h3>
          <p className={secondaryTextClass}>{description}</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={onClose}
            className={`flex-1 py-3 rounded-xl ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} ${textClass} font-medium hover:opacity-80 transition-all`}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 py-3 rounded-xl ${confirmBg} text-white font-medium hover:opacity-80 transition-all`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}

interface ChangePasswordModalProps {
  form: { currentPassword: string; newPassword: string; confirmPassword: string };
  setForm: React.Dispatch<React.SetStateAction<{ currentPassword: string; newPassword: string; confirmPassword: string }>>;
  onClose: () => void;
  onConfirm: () => void;
  isDarkMode: boolean;
  cardClass: string;
  textClass: string;
  secondaryTextClass: string;
  inputClass: string;
  accentBg: string;
}

function ChangePasswordModal({
  form,
  setForm,
  onClose,
  onConfirm,
  isDarkMode,
  cardClass,
  textClass,
  secondaryTextClass,
  inputClass,
  accentBg
}: ChangePasswordModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-6">
      <div className={`${cardClass} rounded-2xl p-6 max-w-md w-full`}>
        <div className="flex items-center justify-between mb-6">
          <h3 className={`text-xl font-bold ${textClass}`}>Alterar Senha</h3>
          <button onClick={onClose} className="p-1">
            <X className={`w-6 h-6 ${secondaryTextClass}`} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className={`block text-sm font-medium ${textClass} mb-2`}>Senha Atual</label>
            <input
              type="password"
              value={form.currentPassword}
              onChange={(e) => setForm({ ...form, currentPassword: e.target.value })}
              className={`w-full p-3 rounded-xl ${inputClass} border`}
              placeholder="Digite sua senha atual"
            />
          </div>
          <div>
            <label className={`block text-sm font-medium ${textClass} mb-2`}>Nova Senha</label>
            <input
              type="password"
              value={form.newPassword}
              onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
              className={`w-full p-3 rounded-xl ${inputClass} border`}
              placeholder="Digite a nova senha"
            />
          </div>
          <div>
            <label className={`block text-sm font-medium ${textClass} mb-2`}>Confirmar Nova Senha</label>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              className={`w-full p-3 rounded-xl ${inputClass} border`}
              placeholder="Confirme a nova senha"
            />
          </div>
          <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-blue-50'} rounded-xl p-3 flex items-start`}>
            <Info className={`w-5 h-5 ${secondaryTextClass} mr-2 mt-0.5 flex-shrink-0`} />
            <p className={`text-xs ${secondaryTextClass}`}>
              A senha deve ter no mínimo 6 caracteres
            </p>
          </div>
        </div>
        <div className="flex space-x-3 mt-6">
          <button
            onClick={onClose}
            className={`flex-1 py-3 rounded-xl ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} ${textClass} font-medium hover:opacity-80 transition-all`}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 py-3 rounded-xl ${accentBg} text-white font-medium hover:opacity-80 transition-all`}
          >
            Alterar Senha
          </button>
        </div>
      </div>
    </div>
  );
}

interface Enable2FAModalProps {
  form: { method: 'sms' | 'app' | 'email'; phoneNumber: string };
  setForm: React.Dispatch<React.SetStateAction<{ method: 'sms' | 'app' | 'email'; phoneNumber: string }>>;
  onClose: () => void;
  onConfirm: () => void;
  isDarkMode: boolean;
  cardClass: string;
  textClass: string;
  secondaryTextClass: string;
  inputClass: string;
  accentBg: string;
}

function Enable2FAModal({
  form,
  setForm,
  onClose,
  onConfirm,
  isDarkMode,
  cardClass,
  textClass,
  secondaryTextClass,
  inputClass,
  accentBg
}: Enable2FAModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-6">
      <div className={`${cardClass} rounded-2xl p-6 max-w-md w-full`}>
        <div className="flex items-center justify-between mb-6">
          <h3 className={`text-xl font-bold ${textClass}`}>Autenticação em Duas Etapas</h3>
          <button onClick={onClose} className="p-1">
            <X className={`w-6 h-6 ${secondaryTextClass}`} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className={`block text-sm font-medium ${textClass} mb-2`}>Método de Autenticação</label>
            <select
              value={form.method}
              onChange={(e) => setForm({ ...form, method: e.target.value as 'sms' | 'app' | 'email' })}
              className={`w-full p-3 rounded-xl ${inputClass} border`}
            >
              <option value="app">Aplicativo Autenticador</option>
              <option value="sms">SMS</option>
              <option value="email">E-mail</option>
            </select>
          </div>
          {form.method === 'sms' && (
            <div>
              <label className={`block text-sm font-medium ${textClass} mb-2`}>Número de Telefone</label>
              <input
                type="tel"
                value={form.phoneNumber}
                onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })}
                className={`w-full p-3 rounded-xl ${inputClass} border`}
                placeholder="+55 (11) 99999-9999"
              />
            </div>
          )}
          <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-blue-50'} rounded-xl p-3`}>
            <p className={`text-xs ${secondaryTextClass}`}>
              {form.method === 'app' && 'Você precisará de um aplicativo como Google Authenticator ou Authy.'}
              {form.method === 'sms' && 'Enviaremos um código por SMS sempre que você fizer login.'}
              {form.method === 'email' && 'Enviaremos um código por e-mail sempre que você fizer login.'}
            </p>
          </div>
        </div>
        <div className="flex space-x-3 mt-6">
          <button
            onClick={onClose}
            className={`flex-1 py-3 rounded-xl ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} ${textClass} font-medium hover:opacity-80 transition-all`}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 py-3 rounded-xl ${accentBg} text-white font-medium hover:opacity-80 transition-all`}
          >
            Ativar 2FA
          </button>
        </div>
      </div>
    </div>
  );
}

interface LegalDocsModalProps {
  docType: 'privacy' | 'terms' | 'lgpd';
  onClose: () => void;
  isDarkMode: boolean;
  cardClass: string;
  textClass: string;
  secondaryTextClass: string;
}

function LegalDocsModal({
  docType,
  onClose,
  isDarkMode,
  cardClass,
  textClass,
  secondaryTextClass
}: LegalDocsModalProps) {
  const docs = {
    privacy: {
      title: 'Política de Privacidade',
      content: `
**1. Introdução**

O Vitrine Pro se compromete a proteger sua privacidade e dados pessoais. Esta política descreve como coletamos, usamos e protegemos suas informações.

**2. Dados Coletados**

- Informações de perfil (nome, idade, posição)
- Histórico de treinos e desempenho
- Fotos e vídeos enviados
- Localização para encontrar peneiras próximas
- Dados de navegação e uso do aplicativo

**3. Uso dos Dados**

Seus dados são utilizados para:
- Personalizar treinos e recomendações
- Conectar você com clubes e agentes
- Melhorar nossos serviços
- Análise de desempenho
- Enviar notificações relevantes

**4. Compartilhamento de Dados**

Não vendemos seus dados. Compartilhamos apenas quando:
- Você autoriza explicitamente
- Necessário para prestação de serviços
- Exigido por lei

**5. Seus Direitos**

Você tem direito a:
- Acessar seus dados
- Corrigir informações incorretas
- Solicitar exclusão de dados
- Portabilidade de dados
- Revogar consentimento
      `
    },
    terms: {
      title: 'Termos de Uso',
      content: `
**1. Aceitação dos Termos**

Ao utilizar o Vitrine Pro, você concorda com estes termos de uso.

**2. Uso do Serviço**

Você pode:
- Criar e manter um perfil de atleta
- Publicar vídeos e fotos de treinos
- Conectar-se com clubes e agentes
- Participar de desafios e competições

**3. Responsabilidades do Usuário**

Você concorda em:
- Fornecer informações verdadeiras
- Não publicar conteúdo ofensivo
- Respeitar outros usuários
- Não violar direitos autorais

**4. Conteúdo do Usuário**

- Você mantém direitos sobre seu conteúdo
- Concede licença ao Vitrine Pro para exibir seu conteúdo
- Conteúdo inadequado será removido

**5. Suspensão e Cancelamento**

Podemos suspender ou cancelar contas que violem estes termos.

**6. Limitação de Responsabilidade**

O Vitrine Pro não se responsabiliza por:
- Conteúdo de terceiros
- Negociações entre usuários
- Resultados de peneiras ou seleções
      `
    },
    lgpd: {
      title: 'Sobre a LGPD',
      content: `
**Lei Geral de Proteção de Dados (LGPD)**

A LGPD é a lei brasileira que regula o tratamento de dados pessoais.

**Seus Direitos sob a LGPD:**

1. **Acesso aos Dados**
   - Você pode solicitar acesso a todos os seus dados

2. **Correção**
   - Você pode corrigir dados incorretos ou desatualizados

3. **Exclusão**
   - Você pode solicitar a exclusão de seus dados

4. **Portabilidade**
   - Você pode transferir seus dados para outro serviço

5. **Revogação de Consentimento**
   - Você pode revogar consentimentos a qualquer momento

6. **Informação sobre Compartilhamento**
   - Você tem direito de saber com quem compartilhamos seus dados

**Como Exercer seus Direitos:**

- Acesse as configurações de privacidade no app
- Entre em contato através do suporte
- Envie e-mail para: privacidade@vitrinepro.com.br

**Encarregado de Dados:**

Para questões sobre privacidade:
E-mail: dpo@vitrinepro.com.br
Telefone: (11) 0000-0000
      `
    }
  };

  const doc = docs[docType];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-6">
      <div className={`${cardClass} rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto`}>
        <div className="flex items-center justify-between mb-6 sticky top-0 pb-4" style={{ backgroundColor: isDarkMode ? '#111827' : 'white' }}>
          <h3 className={`text-xl font-bold ${textClass}`}>{doc.title}</h3>
          <button onClick={onClose} className="p-1">
            <X className={`w-6 h-6 ${secondaryTextClass}`} />
          </button>
        </div>
        <div className={`prose ${isDarkMode ? 'prose-invert' : ''} max-w-none`}>
          {doc.content.split('\n').map((paragraph, index) => {
            if (paragraph.trim().startsWith('**') && paragraph.trim().endsWith('**')) {
              return (
                <h4 key={index} className={`text-lg font-semibold ${textClass} mt-6 mb-3`}>
                  {paragraph.trim().replace(/\*\*/g, '')}
                </h4>
              );
            } else if (paragraph.trim().startsWith('-')) {
              return (
                <li key={index} className={`${secondaryTextClass} ml-4`}>
                  {paragraph.trim().substring(1).trim()}
                </li>
              );
            } else if (paragraph.trim()) {
              return (
                <p key={index} className={`${secondaryTextClass} mb-3`}>
                  {paragraph.trim()}
                </p>
              );
            }
            return null;
          })}
        </div>
        <button
          onClick={onClose}
          className={`w-full py-3 rounded-xl ${accentBg} text-white font-medium hover:opacity-80 transition-all mt-6`}
        >
          Entendi
        </button>
      </div>
    </div>
  );
}

const accentBg = 'bg-green-500';
