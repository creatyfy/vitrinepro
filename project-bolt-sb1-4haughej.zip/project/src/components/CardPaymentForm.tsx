import React, { useState } from 'react';
import { CreditCard, Lock } from 'lucide-react';

interface CardPaymentFormProps {
  onCardDataChange: (cardData: CardData) => void;
  isValid: boolean;
}

export interface CardData {
  cardNumber: string;
  cardHolder: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  cpf: string;
}

export default function CardPaymentForm({ onCardDataChange, isValid }: CardPaymentFormProps) {
  const [cardData, setCardData] = useState<CardData>({
    cardNumber: '',
    cardHolder: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    cpf: ''
  });

  const [errors, setErrors] = useState({
    cardNumber: '',
    cardHolder: '',
    expiry: '',
    cvv: '',
    cpf: ''
  });

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    const formatted = numbers.match(/.{1,4}/g)?.join(' ') || numbers;
    return formatted.substring(0, 19);
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
      .substring(0, 14);
  };

  const validateCardNumber = (number: string): boolean => {
    const cleaned = number.replace(/\s/g, '');
    if (cleaned.length !== 16) return false;

    let sum = 0;
    let isEven = false;

    for (let i = cleaned.length - 1; i >= 0; i--) {
      let digit = parseInt(cleaned[i]);

      if (isEven) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }

      sum += digit;
      isEven = !isEven;
    }

    return sum % 10 === 0;
  };

  const validateCPF = (cpf: string): boolean => {
    const numbers = cpf.replace(/\D/g, '');
    if (numbers.length !== 11) return false;

    if (/^(\d)\1+$/.test(numbers)) return false;

    let sum = 0;
    let remainder;

    for (let i = 1; i <= 9; i++) {
      sum += parseInt(numbers[i - 1]) * (11 - i);
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(numbers[9])) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) {
      sum += parseInt(numbers[i - 1]) * (12 - i);
    }

    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(numbers[10])) return false;

    return true;
  };

  const getCardBrand = (number: string): string => {
    const cleaned = number.replace(/\s/g, '');

    if (/^4/.test(cleaned)) return 'Visa';
    if (/^5[1-5]/.test(cleaned)) return 'Mastercard';
    if (/^3[47]/.test(cleaned)) return 'American Express';
    if (/^6(?:011|5)/.test(cleaned)) return 'Discover';
    if (/^35/.test(cleaned)) return 'JCB';
    if (/^(?:5[0678]|6304|6390|67)/.test(cleaned)) return 'Maestro';
    if (/^3(?:0[0-5]|[68])/.test(cleaned)) return 'Diners Club';
    if (/^(?:2131|1800|636)/.test(cleaned)) return 'Elo';

    return '';
  };

  const handleCardNumberChange = (value: string) => {
    const formatted = formatCardNumber(value);
    const newCardData = { ...cardData, cardNumber: formatted };
    setCardData(newCardData);

    const cleaned = formatted.replace(/\s/g, '');
    if (cleaned.length === 16) {
      if (!validateCardNumber(formatted)) {
        setErrors(prev => ({ ...prev, cardNumber: 'Número de cartão inválido' }));
      } else {
        setErrors(prev => ({ ...prev, cardNumber: '' }));
      }
    } else if (cleaned.length > 0 && cleaned.length < 16) {
      setErrors(prev => ({ ...prev, cardNumber: 'Número incompleto' }));
    } else {
      setErrors(prev => ({ ...prev, cardNumber: '' }));
    }

    validateAndNotify(newCardData);
  };

  const handleCardHolderChange = (value: string) => {
    const formatted = value.toUpperCase().replace(/[^A-Z\s]/g, '');
    const newCardData = { ...cardData, cardHolder: formatted };
    setCardData(newCardData);

    if (formatted.length > 0 && formatted.length < 3) {
      setErrors(prev => ({ ...prev, cardHolder: 'Nome muito curto' }));
    } else {
      setErrors(prev => ({ ...prev, cardHolder: '' }));
    }

    validateAndNotify(newCardData);
  };

  const handleExpiryMonthChange = (value: string) => {
    const numbers = value.replace(/\D/g, '').substring(0, 2);
    const month = parseInt(numbers);

    if (numbers.length === 2 && (month < 1 || month > 12)) {
      setErrors(prev => ({ ...prev, expiry: 'Mês inválido' }));
    } else if (cardData.expiryYear && numbers.length === 2) {
      validateExpiry(numbers, cardData.expiryYear);
    } else {
      setErrors(prev => ({ ...prev, expiry: '' }));
    }

    const newCardData = { ...cardData, expiryMonth: numbers };
    setCardData(newCardData);
    validateAndNotify(newCardData);
  };

  const handleExpiryYearChange = (value: string) => {
    const numbers = value.replace(/\D/g, '').substring(0, 2);

    if (cardData.expiryMonth && numbers.length === 2) {
      validateExpiry(cardData.expiryMonth, numbers);
    }

    const newCardData = { ...cardData, expiryYear: numbers };
    setCardData(newCardData);
    validateAndNotify(newCardData);
  };

  const validateExpiry = (month: string, year: string) => {
    if (month.length !== 2 || year.length !== 2) {
      setErrors(prev => ({ ...prev, expiry: 'Data incompleta' }));
      return;
    }

    const currentDate = new Date();
    const currentYear = currentDate.getFullYear() % 100;
    const currentMonth = currentDate.getMonth() + 1;

    const expYear = parseInt(year);
    const expMonth = parseInt(month);

    if (expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) {
      setErrors(prev => ({ ...prev, expiry: 'Cartão vencido' }));
    } else {
      setErrors(prev => ({ ...prev, expiry: '' }));
    }
  };

  const handleCVVChange = (value: string) => {
    const numbers = value.replace(/\D/g, '').substring(0, 4);
    const newCardData = { ...cardData, cvv: numbers };
    setCardData(newCardData);

    const brand = getCardBrand(cardData.cardNumber);
    const requiredLength = brand === 'American Express' ? 4 : 3;

    if (numbers.length > 0 && numbers.length < requiredLength) {
      setErrors(prev => ({ ...prev, cvv: 'CVV incompleto' }));
    } else {
      setErrors(prev => ({ ...prev, cvv: '' }));
    }

    validateAndNotify(newCardData);
  };

  const handleCPFChange = (value: string) => {
    const formatted = formatCPF(value);
    const newCardData = { ...cardData, cpf: formatted };
    setCardData(newCardData);

    const numbers = formatted.replace(/\D/g, '');
    if (numbers.length === 11) {
      if (!validateCPF(formatted)) {
        setErrors(prev => ({ ...prev, cpf: 'CPF inválido' }));
      } else {
        setErrors(prev => ({ ...prev, cpf: '' }));
      }
    } else if (numbers.length > 0) {
      setErrors(prev => ({ ...prev, cpf: 'CPF incompleto' }));
    } else {
      setErrors(prev => ({ ...prev, cpf: '' }));
    }

    validateAndNotify(newCardData);
  };

  const validateAndNotify = (data: CardData) => {
    const isCardNumberValid = validateCardNumber(data.cardNumber);
    const isCardHolderValid = data.cardHolder.length >= 3;
    const isExpiryValid = data.expiryMonth.length === 2 && data.expiryYear.length === 2;
    const isCVVValid = data.cvv.length >= 3;
    const isCPFValid = validateCPF(data.cpf);

    onCardDataChange({
      ...data,
      isValid: isCardNumberValid && isCardHolderValid && isExpiryValid && isCVVValid && isCPFValid
    } as any);
  };

  const cardBrand = getCardBrand(cardData.cardNumber);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Dados do Cartão</h3>
        <div className="flex items-center text-sm text-gray-600">
          <Lock className="w-4 h-4 mr-1" />
          <span>Pagamento seguro</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Número do Cartão
        </label>
        <div className="relative">
          <input
            type="text"
            placeholder="0000 0000 0000 0000"
            value={cardData.cardNumber}
            onChange={(e) => handleCardNumberChange(e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 pr-12 ${
              errors.cardNumber
                ? 'border-red-500 focus:ring-red-500'
                : 'border-gray-300 focus:ring-gray-900'
            }`}
            maxLength={19}
          />
          {cardBrand && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 rounded">
                {cardBrand}
              </span>
            </div>
          )}
        </div>
        {errors.cardNumber && (
          <p className="text-red-500 text-sm mt-1">{errors.cardNumber}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Nome no Cartão
        </label>
        <input
          type="text"
          placeholder="NOME COMO ESTÁ NO CARTÃO"
          value={cardData.cardHolder}
          onChange={(e) => handleCardHolderChange(e.target.value)}
          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
            errors.cardHolder
              ? 'border-red-500 focus:ring-red-500'
              : 'border-gray-300 focus:ring-gray-900'
          }`}
        />
        {errors.cardHolder && (
          <p className="text-red-500 text-sm mt-1">{errors.cardHolder}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Validade
          </label>
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="MM"
              value={cardData.expiryMonth}
              onChange={(e) => handleExpiryMonthChange(e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 text-center ${
                errors.expiry
                  ? 'border-red-500 focus:ring-red-500'
                  : 'border-gray-300 focus:ring-gray-900'
              }`}
              maxLength={2}
            />
            <input
              type="text"
              placeholder="AA"
              value={cardData.expiryYear}
              onChange={(e) => handleExpiryYearChange(e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 text-center ${
                errors.expiry
                  ? 'border-red-500 focus:ring-red-500'
                  : 'border-gray-300 focus:ring-gray-900'
              }`}
              maxLength={2}
            />
          </div>
          {errors.expiry && (
            <p className="text-red-500 text-sm mt-1">{errors.expiry}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            CVV
          </label>
          <input
            type="text"
            placeholder="000"
            value={cardData.cvv}
            onChange={(e) => handleCVVChange(e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 text-center ${
              errors.cvv
                ? 'border-red-500 focus:ring-red-500'
                : 'border-gray-300 focus:ring-gray-900'
            }`}
            maxLength={4}
          />
          {errors.cvv && (
            <p className="text-red-500 text-sm mt-1">{errors.cvv}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          CPF do Titular
        </label>
        <input
          type="text"
          placeholder="000.000.000-00"
          value={cardData.cpf}
          onChange={(e) => handleCPFChange(e.target.value)}
          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
            errors.cpf
              ? 'border-red-500 focus:ring-red-500'
              : 'border-gray-300 focus:ring-gray-900'
          }`}
          maxLength={14}
        />
        {errors.cpf && (
          <p className="text-red-500 text-sm mt-1">{errors.cpf}</p>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
        <div className="flex items-start">
          <CreditCard className="w-5 h-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">Seus dados estão protegidos</p>
            <p className="text-blue-600">
              Utilizamos criptografia de ponta para garantir a segurança das suas informações.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
