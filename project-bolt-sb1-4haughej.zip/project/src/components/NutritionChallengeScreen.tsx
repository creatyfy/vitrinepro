import React, { useState, useEffect, useMemo } from 'react';
import { X, Camera, Check, AlertCircle, Clock, RefreshCw, Image as ImageIcon, ChefHat, Timer, Award } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry } from '../utils/videoUtils';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const POINTS_NUTRITION_VALID = 200;

const GESTURES = [
  { id: 'joinha', label: 'Joinha', icon: '👍' },
  { id: 'mao-queixo', label: 'Mão no queixo', icon: '🤔' },
  { id: 'lingua-fora', label: 'Língua para fora', icon: '😛' },
  { id: 'sorriso', label: 'Sorriso', icon: '😊' },
  { id: 'numero-3', label: 'Número 3 com dedos', icon: '✌️' },
  { id: 'punho-fechado', label: 'Punho fechado', icon: '✊' },
  { id: 'paz', label: 'Sinal de paz (V)', icon: '✌️' },
  { id: 'ok', label: 'Sinal de OK', icon: '👌' },
  { id: 'rock', label: 'Rock', icon: '🤘' },
  { id: 'aceno', label: 'Aceno com mão', icon: '👋' }
];

interface RecipeData {
  ingredients: { item: string; quantity: string }[];
  preparation_steps: string[];
  cooking_time: number;
  difficulty: string;
  nutritional_info: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
    fiber: number;
  };
  tips: string;
}

interface WeeklyChallengeData {
  period: string;
  cadence: string;
  startAt: string;
  endAt: string;
  dish: {
    name: string;
    description: string;
    imageUrl: string;
    pointsFull: number;
    pointsPartial: number;
  };
  recipe?: RecipeData;
  gestureCode: string;
  challengeId: string;
  user: {
    submitted: boolean;
    status: string | null;
    provisionalPoints: number;
    photoUrl?: string;
    submittedAt?: string;
  };
  timeRemaining?: string;
}

interface NutritionChallengeScreenProps {
  userId: string;
  onBack: () => void;
}

export default function NutritionChallengeScreen({ userId, onBack }: NutritionChallengeScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [loading, setLoading] = useState(true);
  const [challengeData, setChallengeData] = useState<WeeklyChallengeData | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showRulesSheet, setShowRulesSheet] = useState(false);
  const [gestureTimer, setGestureTimer] = useState(60);
  const [selectedGesture, setSelectedGesture] = useState<any>(null);
  const [generatedCode, setGeneratedCode] = useState('');
  const [imageError, setImageError] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  const styles = useMemo(() => ({
    container: { backgroundColor: theme.surface },
    header: { backgroundColor: theme.surface, borderColor: theme.border },
    card: { backgroundColor: theme.surfaceAlt, borderColor: theme.border },
    textPrimary: { color: theme.textPrimary },
    textSecondary: { color: theme.textSecondary },
    textInverse: { color: theme.textInverse },
    icon: { color: theme.icon },
    accent: { backgroundColor: theme.accent, color: theme.textInverse },
    accentText: { color: theme.accent },
    success: { color: theme.success, backgroundColor: `${theme.success}15` },
    warning: { color: theme.warning, backgroundColor: `${theme.warning}15` },
    error: { color: theme.error, backgroundColor: `${theme.error}15` },
    disabled: { backgroundColor: theme.border, color: theme.textSecondary, cursor: 'not-allowed' },
    border: { borderColor: theme.border }
  }), [themeVersion, theme]);

  useEffect(() => {
    loadChallenge();
  }, [userId]);

  useEffect(() => {
    if (showSubmitModal && gestureTimer > 0) {
      const timer = setTimeout(() => setGestureTimer(gestureTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
    if (gestureTimer === 0) {
      setShowSubmitModal(false);
      setGestureTimer(60);
      setError('O código expirou. Tente novamente.');
    }
  }, [showSubmitModal, gestureTimer]);

  useEffect(() => {
    if (challengeData && challengeData.endAt) {
      const interval = setInterval(() => {
        const remaining = calculateTimeRemaining(challengeData.endAt);
        setTimeRemaining(remaining);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [challengeData]);

  function calculateTimeRemaining(endDate: string): string {
    const now = new Date().getTime();
    const end = new Date(endDate).getTime();
    const diff = end - now;

    if (diff <= 0) return 'Expirado';

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  async function loadChallenge() {
    try {
      setLoading(true);
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Não autenticado');
      }

      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-weekly-nutrition-challenge`;
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Falha ao carregar desafio');
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      const { data: recipeData } = await supabase
        .from('nutrition_recipes')
        .select('ingredients, preparation_steps, cooking_time, difficulty, nutritional_info, tips')
        .eq('dish_id', data.dish.id)
        .maybeSingle();

      setChallengeData({
        ...data,
        recipe: recipeData
      });

      logTelemetry(userId, 'nutrition_challenge_viewed', {
        periodId: data.period,
        dishName: data.dish.name,
        theme: themeVersion
      });

    } catch (err: any) {
      console.error('Erro ao carregar desafio:', err);
      setError(err.message || 'Erro ao carregar desafio');
      logTelemetry(userId, 'nutrition_challenge_error_boundary', {
        stackPresent: !!err.stack
      });
    } finally {
      setLoading(false);
    }
  }

  function openSubmitModal() {
    if (!challengeData) return;

    if (challengeData.user.submitted) {
      setError('Você já enviou sua foto nesta semana.');
      return;
    }

    const gesture = GESTURES[Math.floor(Math.random() * GESTURES.length)];
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 4; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    setSelectedGesture(gesture);
    setGeneratedCode(code);
    setGestureTimer(60);
    setShowSubmitModal(true);

    logTelemetry(userId, 'nutrition_challenge_generate_code', {
      gesture: gesture.id,
      codeTTL: 60
    });
  }

  async function handlePhotoUpload(file: File) {
    if (!challengeData || !selectedGesture || !generatedCode) return;

    try {
      setUploading(true);
      setError(null);
      logTelemetry(userId, 'nutrition_challenge_submit_started', {});

      if (file.size > 10 * 1024 * 1024) {
        setError('Arquivo muito grande. Máximo 10MB.');
        return;
      }

      if (!file.type.startsWith('image/')) {
        setError('Apenas imagens são permitidas.');
        return;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${userId}_${Date.now()}.${fileExt}`;
      const filePath = `nutrition/${challengeData.period}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('nutrition-photos')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('nutrition-photos')
        .getPublicUrl(filePath);

      const photoHash = await calculateHash(file);

      const { data: isDuplicate } = await supabase
        .rpc('check_duplicate_photo_hash', {
          p_user_id: userId,
          p_photo_hash: photoHash
        });

      if (isDuplicate) {
        setError('Esta foto já foi usada. Use uma foto nova.');
        logTelemetry(userId, 'nutrition_challenge_submit_failed', {
          reason: 'duplicate_photo'
        });
        return;
      }

      const points = POINTS_NUTRITION_VALID;
      const qualityScore = 85;

      const { error: subError } = await supabase
        .from('nutrition_submissions')
        .insert({
          user_id: userId,
          challenge_id: challengeData.challengeId,
          photo_url: publicUrl,
          photo_hash: photoHash,
          gesture_code_provided: generatedCode,
          gesture_correct: true,
          points_awarded: points,
          verification_status: 'pending',
          metadata: {
            file_size: file.size,
            file_type: file.type,
            period: challengeData.period,
            gesture: selectedGesture.id,
            ttl_remaining: gestureTimer
          }
        });

      if (subError) throw subError;

      await supabase
        .from('athlete_meal_history')
        .insert({
          user_id: userId,
          meal_type: 'desafio_semanal',
          date: new Date().toISOString().split('T')[0],
          points_earned: points,
          quality_score: qualityScore,
          notes: `Desafio: ${challengeData.dish.name}`
        });

      setSuccess(`Foto enviada! +${points} pontos (provisórios)`);
      setShowSubmitModal(false);

      logTelemetry(userId, 'nutrition_challenge_submit_succeeded', {
        provisionalPoints: points
      });

      setTimeout(() => {
        loadChallenge();
      }, 1500);

    } catch (err: any) {
      console.error('Erro ao enviar:', err);
      setError('Erro ao enviar foto. Tente novamente.');
      logTelemetry(userId, 'nutrition_challenge_submit_failed', {
        reason: err.message
      });
    } finally {
      setUploading(false);
    }
  }

  async function calculateHash(file: File): Promise<string> {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  function handleFileSelect(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) {
      handlePhotoUpload(file);
    }
  }

  function isExpired(): boolean {
    if (!challengeData) return true;
    return new Date() > new Date(challengeData.endAt);
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <div className="h-6 w-48 rounded animate-pulse" style={{ backgroundColor: theme.border }} />
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 p-6 space-y-4">
          <div className="rounded-2xl overflow-hidden animate-pulse" style={{ ...styles.card, height: '240px' }} />
          <div className="space-y-3">
            <div className="h-8 w-3/4 rounded animate-pulse" style={{ backgroundColor: theme.border }} />
            <div className="h-4 w-full rounded animate-pulse" style={{ backgroundColor: theme.border }} />
            <div className="h-4 w-2/3 rounded animate-pulse" style={{ backgroundColor: theme.border }} />
          </div>
        </div>
      </div>
    );
  }

  if (error && !challengeData) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Prato da Semana</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="rounded-2xl p-8 text-center max-w-md border" style={{ ...styles.card, ...styles.border }}>
            <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: theme.error }} />
            <h2 className="text-2xl font-bold mb-2" style={styles.textPrimary}>
              Ops! Algo deu errado.
            </h2>
            <p className="mb-6" style={styles.textSecondary}>
              Tente novamente.
            </p>
            <button
              onClick={loadChallenge}
              className="w-full py-3 rounded-xl font-semibold transition-all duration-150 active:scale-95 flex items-center justify-center gap-2"
              style={styles.accent}
            >
              <RefreshCw className="w-5 h-5" />
              Tentar novamente
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!challengeData) return null;

  const expired = isExpired();
  const submitted = challengeData.user.submitted;
  const status = challengeData.user.status;
  const recipe = challengeData.recipe;

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      <div className="sticky top-0 z-20 border-b" style={{ ...styles.header, ...styles.border }}>
        <div className="flex items-center justify-between p-4">
          <button onClick={onBack} className="p-2 rounded-lg transition-all active:scale-95">
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>Prato da Semana</h1>
          <div className="w-10" />
        </div>
      </div>

      {error && challengeData && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.error, ...styles.border }}>
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium flex-1">{error}</p>
          <button onClick={() => setError(null)} className="p-1 rounded transition-all active:scale-95">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.success, ...styles.border }}>
          <Check className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">{success}</p>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="rounded-2xl border overflow-hidden" style={{ ...styles.card, ...styles.border }}>
          <div className="relative w-full aspect-video" style={{ backgroundColor: theme.border }}>
            {!imageError ? (
              <img
                src={challengeData.dish.imageUrl}
                alt={challengeData.dish.name}
                className="w-full h-full object-cover"
                onError={() => setImageError(true)}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <ImageIcon className="w-16 h-16" style={styles.icon} />
              </div>
            )}
            {timeRemaining && !expired && (
              <div className="absolute top-4 right-4 bg-black bg-opacity-70 px-3 py-2 rounded-lg flex items-center gap-2">
                <Clock className="w-4 h-4 text-white" />
                <span className="text-white text-sm font-bold">{timeRemaining}</span>
              </div>
            )}
          </div>

          <div className="p-6 space-y-4">
            <div>
              <h2 className="text-3xl font-bold mb-2" style={styles.textPrimary}>
                {challengeData.dish.name}
              </h2>
              <p className="text-sm leading-relaxed" style={styles.textSecondary}>
                {challengeData.dish.description}
              </p>
            </div>

            <div className="flex items-center justify-between p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
              <span className="font-semibold" style={styles.textSecondary}>
                Pontos disponíveis
              </span>
              <span className="text-2xl font-bold" style={styles.accentText}>
                {challengeData.dish.pointsFull}
              </span>
            </div>

            {submitted && status === 'pending' && (
              <div className="p-4 rounded-xl border" style={{ ...styles.warning, ...styles.border }}>
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5" />
                  <span className="font-bold">Em análise</span>
                </div>
                <p className="text-sm mb-2">
                  +{challengeData.user.provisionalPoints} pontos (provisórios)
                </p>
                <button
                  onClick={() => window.open(challengeData.user.photoUrl, '_blank')}
                  className="text-sm underline mt-2"
                  style={styles.textSecondary}
                >
                  Ver minha foto
                </button>
              </div>
            )}

            {submitted && status === 'approved' && (
              <div className="p-4 rounded-xl border" style={{ ...styles.success, ...styles.border }}>
                <div className="flex items-center gap-2 mb-2">
                  <Check className="w-5 h-5" />
                  <span className="font-bold">Aprovado</span>
                </div>
                <p className="text-sm mb-2">
                  Seus pontos foram confirmados.
                </p>
                <button
                  onClick={() => window.open(challengeData.user.photoUrl, '_blank')}
                  className="text-sm underline mt-2"
                  style={styles.textSecondary}
                >
                  Ver minha foto
                </button>
              </div>
            )}

            {submitted && status === 'rejected' && (
              <div className="p-4 rounded-xl border" style={{ ...styles.error, ...styles.border }}>
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-bold">Não aprovado</span>
                </div>
                <p className="text-sm mb-2">
                  Os pontos provisórios foram removidos.
                </p>
                <button
                  onClick={() => setShowRulesSheet(true)}
                  className="text-sm underline mt-2"
                  style={styles.textSecondary}
                >
                  Ver regras para enviar corretamente
                </button>
              </div>
            )}

            {!submitted && !expired && (
              <button
                onClick={openSubmitModal}
                className="w-full py-4 rounded-xl font-bold text-lg transition-all duration-150 active:scale-95 flex items-center justify-center gap-2"
                style={styles.accent}
              >
                <Camera className="w-6 h-6" />
                Enviar Imagem
              </button>
            )}

            {!submitted && expired && (
              <div className="w-full py-4 rounded-xl font-semibold text-center" style={styles.disabled}>
                Desafio encerrado – volte na próxima semana.
              </div>
            )}
          </div>
        </div>

        {recipe && (
          <>
            <div className="rounded-2xl border p-6" style={{ ...styles.card, ...styles.border }}>
              <div className="flex items-center gap-3 mb-4">
                <ChefHat className="w-6 h-6" style={styles.accentText} />
                <h3 className="text-xl font-bold" style={styles.textPrimary}>Ingredientes</h3>
              </div>
              <ul className="space-y-2">
                {recipe.ingredients.map((ingredient, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span style={styles.accentText}>•</span>
                    <span style={styles.textSecondary}>
                      <strong>{ingredient.quantity}</strong> {ingredient.item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border p-6" style={{ ...styles.card, ...styles.border }}>
              <div className="flex items-center gap-3 mb-4">
                <Check className="w-6 h-6" style={styles.accentText} />
                <h3 className="text-xl font-bold" style={styles.textPrimary}>Modo de Preparo</h3>
              </div>
              <ol className="space-y-3">
                {recipe.preparation_steps.map((step, idx) => (
                  <li key={idx} className="flex gap-3">
                    <span className="font-bold flex-shrink-0" style={styles.accentText}>{idx + 1}.</span>
                    <span style={styles.textSecondary}>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-xl border p-4 text-center" style={{ ...styles.card, ...styles.border }}>
                <Timer className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                  {recipe.cooking_time}min
                </div>
                <div className="text-xs" style={styles.textSecondary}>Tempo de preparo</div>
              </div>
              <div className="rounded-xl border p-4 text-center" style={{ ...styles.card, ...styles.border }}>
                <Award className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                  {recipe.nutritional_info.calories}
                </div>
                <div className="text-xs" style={styles.textSecondary}>Calorias</div>
              </div>
            </div>

            {recipe.tips && (
              <div className="rounded-2xl border p-6 bg-gradient-to-r" style={{ ...styles.card, ...styles.border, backgroundImage: `linear-gradient(135deg, ${theme.accent}10, transparent)` }}>
                <p className="text-sm font-medium" style={styles.textPrimary}>
                  <span className="text-base" style={styles.accentText}>💡 Dica: </span>
                  {recipe.tips}
                </p>
              </div>
            )}
          </>
        )}

        <button
          onClick={() => {
            setShowRulesSheet(true);
            logTelemetry(userId, 'nutrition_challenge_open_rules', {});
          }}
          className="w-full text-center text-sm py-2 transition-all active:scale-95"
          style={styles.accentText}
        >
          Ver regras do desafio
        </button>
      </div>

      {showSubmitModal && (
        <div className="fixed inset-0 z-50 bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
          <div className="flex-1 flex flex-col">
            <div className="pt-6 pb-4 text-center px-4">
              <div className="w-16 h-16 bg-purple-500 bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Verificação Anti-Trapaça</h1>
              <p className="text-sm text-purple-100">Complete o desafio para comprovar sua refeição</p>
            </div>

            <div className="px-4 mb-4">
              <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-3 border border-white border-opacity-20 flex items-center justify-between">
                <div className="flex items-center">
                  <Clock className="w-4 h-4 text-white mr-2" />
                  <span className="text-white text-sm font-medium">Tempo: {gestureTimer}s</span>
                </div>
                <div className="bg-green-500 px-3 py-1 rounded-full">
                  <span className="text-white font-bold text-xs">OK</span>
                </div>
              </div>
            </div>

            <div className="px-4 space-y-3 mb-4">
              <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
                <p className="text-purple-100 text-center text-xs mb-2">Código do Desafio</p>
                <div className="text-white text-center text-4xl font-bold tracking-wider">{generatedCode}</div>
              </div>
              <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
                <p className="text-purple-100 text-center text-xs mb-2">Faça o Gesto</p>
                <div className="text-white text-center text-2xl font-bold">{selectedGesture?.label}</div>
              </div>
            </div>

            <div className="flex-1 px-4 mb-4">
              <div className="relative w-full h-full rounded-2xl overflow-hidden bg-purple-500 bg-opacity-30 backdrop-blur-sm border border-white border-opacity-20 flex items-center justify-center min-h-[200px]">
                <div className="text-center">
                  <div className="text-6xl mb-4">{selectedGesture?.icon}</div>
                  <p className="text-white text-sm">Apareça segurando o prato</p>
                  <p className="text-purple-100 text-xs mt-2">e mostre o gesto acima</p>
                </div>
              </div>
            </div>

            <div className="px-4 pb-6">
              <label className="w-full bg-white text-purple-600 py-4 rounded-2xl font-bold text-base mb-3 hover:bg-gray-100 transition-colors flex items-center justify-center cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileSelect}
                  disabled={uploading}
                  className="hidden"
                  onClick={() => logTelemetry(userId, 'nutrition_challenge_camera_opened', {})}
                />
                <Camera className="w-5 h-5 mr-2" />
                {uploading ? 'Enviando...' : 'Capturar Prova'}
              </label>
              <button
                onClick={() => setShowSubmitModal(false)}
                className="w-full py-3 text-center text-purple-200 hover:text-white transition-colors text-sm font-medium"
              >
                Cancelar
              </button>
            </div>
          </div>
          <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
        </div>
      )}

      {showRulesSheet && (
        <div className="fixed inset-0 z-50 flex items-end" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full rounded-t-3xl p-6 space-y-4 max-h-[70vh] overflow-y-auto" style={styles.card}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold" style={styles.textPrimary}>
                Regras do desafio
              </h3>
              <button onClick={() => setShowRulesSheet(false)} className="p-2 rounded-lg transition-all active:scale-95">
                <X className="w-6 h-6" style={styles.icon} />
              </button>
            </div>

            <div className="space-y-4">
              {[
                'Envie uma foto sua segurando o prato do "Prato da Semana".',
                'Mostre o gesto e o código exibidos no app (validade de 60s).',
                '1 envio por semana.',
                'Envios fora do prazo não são aceitos.',
                'Se a foto não seguir as regras, os pontos provisórios serão removidos.'
              ].map((rule, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ backgroundColor: theme.accent }}>
                    <Check className="w-4 h-4" style={styles.textInverse} />
                  </div>
                  <p className="text-sm leading-relaxed" style={styles.textPrimary}>
                    {rule}
                  </p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowRulesSheet(false)}
              className="w-full py-3 rounded-xl font-semibold transition-all duration-150 active:scale-95"
              style={styles.accent}
            >
              Entendi
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
