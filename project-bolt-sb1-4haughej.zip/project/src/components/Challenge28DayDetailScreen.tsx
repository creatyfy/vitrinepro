import React, { useState } from 'react';
import { ChevronLeft, Play, Check, Clock, Trophy, Target, Zap, Star, Heart, Info, Settings, ArrowLeft } from 'lucide-react';
import PauseOverlay from './PauseOverlay';
import { useTheme } from '../contexts/ThemeContext';
import { allChallenges } from '../data/challenge28Data';

interface Challenge28DayDetailScreenProps {
  challengeId: string;
  day: number;
  onBack: () => void;
  onStart: () => void;
  onSettings: () => void;
}

export default function Challenge28DayDetailScreen({
  challengeId,
  day,
  onBack,
  onStart,
  onSettings
}: Challenge28DayDetailScreenProps) {
  const { tokens, isDarkMode } = useTheme();
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);
  const [showPauseOverlay, setShowPauseOverlay] = useState(false);
  const [isTrainingActive, setIsTrainingActive] = useState(false);

  const challenge = allChallenges[challengeId as keyof typeof allChallenges];
  const dayData = challenge?.days.find(d => d.day === day);

  if (!dayData) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: tokens.surface }}>
        <p style={{ color: tokens.textPrimary }}>Dia não encontrado</p>
      </div>
    );
  }

  const completedCount = completedExercises.length;
  const totalExercises = dayData.exercises.length;
  const progressPercentage = (completedCount / totalExercises) * 100;

  const handleToggleExercise = (exerciseId: string) => {
    setCompletedExercises(prev =>
      prev.includes(exerciseId)
        ? prev.filter(id => id !== exerciseId)
        : [...prev, exerciseId]
    );
  };

  const handlePauseTraining = () => {
    setShowPauseOverlay(true);
  };

  const handleResumeTraining = () => {
    setShowPauseOverlay(false);
  };

  const handleRestartExercise = () => {
    if (completedExercises.length > 0) {
      const lastCompleted = completedExercises[completedExercises.length - 1];
      setCompletedExercises(prev => prev.filter(id => id !== lastCompleted));
    }
    setShowPauseOverlay(false);
  };

  const handleExitFromPause = () => {
    setShowPauseOverlay(false);
    setIsTrainingActive(false);
    onBack();
  };

  const handleStartTraining = () => {
    setIsTrainingActive(true);
    onStart();
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {showPauseOverlay && (
        <PauseOverlay
          isDarkMode={isDarkMode}
          currentExercise={completedCount}
          totalExercises={totalExercises}
          onResume={handleResumeTraining}
          onRestart={handleRestartExercise}
          onExit={handleExitFromPause}
        />
      )}

      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.textPrimary }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>
          {dayData.title}
        </h1>
        {isTrainingActive ? (
          <button onClick={handlePauseTraining} className="p-2">
            <ArrowLeft className="w-6 h-6" style={{ color: tokens.textPrimary }} />
          </button>
        ) : (
          <div className="w-10"></div>
        )}
      </div>

      {/* Day Info Card */}
      <div className="px-6 mb-6">
        <div className="rounded-3xl p-6" style={{ backgroundColor: tokens.surfaceAlt }}>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>
                Dia {dayData.day} de {challenge.totalDays}
              </h2>
              <p className="text-sm mb-4" style={{ color: tokens.textSecondary }}>
                {dayData.description}
              </p>
            </div>
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
              <Trophy className="w-8 h-8 text-white" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-xl" style={{ backgroundColor: tokens.surface }}>
              <Clock className="w-5 h-5 mx-auto mb-1 text-blue-500" />
              <div className="text-sm font-bold" style={{ color: tokens.textPrimary }}>
                {dayData.duration}
              </div>
              <div className="text-xs" style={{ color: tokens.textSecondary }}>Duração</div>
            </div>
            <div className="text-center p-3 rounded-xl" style={{ backgroundColor: tokens.surface }}>
              <Target className="w-5 h-5 mx-auto mb-1 text-green-500" />
              <div className="text-sm font-bold" style={{ color: tokens.textPrimary }}>
                {dayData.focusArea}
              </div>
              <div className="text-xs" style={{ color: tokens.textSecondary }}>Foco</div>
            </div>
            <div className="text-center p-3 rounded-xl" style={{ backgroundColor: tokens.surface }}>
              <Zap className="w-5 h-5 mx-auto mb-1 text-yellow-500" />
              <div className="text-sm font-bold" style={{ color: tokens.textPrimary }}>
                {dayData.level}
              </div>
              <div className="text-xs" style={{ color: tokens.textSecondary }}>Nível</div>
            </div>
          </div>

          {dayData.equipment.length > 0 && (
            <div className="mt-4 p-3 rounded-xl" style={{ backgroundColor: tokens.surface }}>
              <div className="flex items-center mb-2">
                <Info className="w-4 h-4 mr-2 text-blue-500" />
                <span className="text-sm font-semibold" style={{ color: tokens.textPrimary }}>
                  Equipamento necessário:
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {dayData.equipment.map((eq, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: isDarkMode ? '#1e3a5f' : '#dbeafe',
                      color: isDarkMode ? '#93c5fd' : '#1e40af'
                    }}
                  >
                    {eq}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Progress */}
      <div className="px-6 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold" style={{ color: tokens.textPrimary }}>
            Progresso do Treino
          </span>
          <span className="text-sm" style={{ color: tokens.textSecondary }}>
            {completedCount}/{totalExercises}
          </span>
        </div>
        <div className="w-full h-2 rounded-full" style={{ backgroundColor: tokens.surfaceAlt }}>
          <div
            className="h-2 rounded-full bg-green-500 transition-all duration-300"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Start Button */}
      <div className="px-6 mb-6">
        <div className="flex items-center space-x-4">
          <button
            onClick={onSettings}
            className="p-4 rounded-2xl"
            style={{ backgroundColor: tokens.surfaceAlt }}
          >
            <Settings className="w-6 h-6" style={{ color: tokens.textPrimary }} />
          </button>
          <button
            onClick={handleStartTraining}
            className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white py-4 rounded-2xl font-bold text-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 active:scale-95 shadow-lg flex items-center justify-center"
          >
            <Play className="w-6 h-6 mr-2" />
            Começar Treino
          </button>
        </div>
      </div>

      {/* Exercises List */}
      <div className="px-6 pb-24">
        <h3 className="text-lg font-bold mb-4" style={{ color: tokens.textPrimary }}>
          Exercícios ({totalExercises})
        </h3>
        <div className="space-y-3">
          {dayData.exercises.map((exercise, index) => {
            const isCompleted = completedExercises.includes(exercise.id);

            return (
              <div
                key={exercise.id}
                className="rounded-2xl p-4 shadow-sm border transition-all duration-200"
                style={{
                  backgroundColor: tokens.surfaceAlt,
                  borderColor: tokens.border
                }}
              >
                <div className="flex items-center">
                  <button
                    onClick={() => handleToggleExercise(exercise.id)}
                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center mr-4 transition-all duration-200 ${
                      isCompleted
                        ? 'bg-green-500 border-green-500'
                        : 'border-gray-400'
                    }`}
                  >
                    {isCompleted && <Check className="w-5 h-5 text-white" />}
                  </button>

                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <span className="text-sm font-bold mr-3" style={{ color: tokens.textSecondary }}>
                          #{index + 1}
                        </span>
                        <h4
                          className={`font-semibold ${isCompleted ? 'line-through opacity-60' : ''}`}
                          style={{ color: tokens.textPrimary }}
                        >
                          {exercise.name}
                        </h4>
                      </div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                        <span className="text-sm font-semibold text-yellow-600">+10</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      {exercise.duration && (
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1 text-blue-500" />
                          <span className="text-sm" style={{ color: tokens.textSecondary }}>
                            {exercise.duration}
                          </span>
                        </div>
                      )}
                      {exercise.reps && (
                        <div className="flex items-center">
                          <Zap className="w-4 h-4 mr-1 text-green-500" />
                          <span className="text-sm" style={{ color: tokens.textSecondary }}>
                            {exercise.reps}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="ml-4 w-16 h-16 rounded-xl overflow-hidden">
                    <img
                      src={exercise.imageUrl}
                      alt={exercise.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
