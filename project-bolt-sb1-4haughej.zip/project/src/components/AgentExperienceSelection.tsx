import React from 'react';
import { ChevronLeft, Users, Clock } from 'lucide-react';

interface AgentExperienceSelectionProps {
  athletesRepresented: string;
  yearsExperience: string;
  onAthletesChange: (athletes: string) => void;
  onYearsChange: (years: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function AgentExperienceSelection({ 
  athletesRepresented,
  yearsExperience,
  onAthletesChange,
  onYearsChange,
  onNext, 
  onBack 
}: AgentExperienceSelectionProps) {
  const athleteOptions = [
    { id: 'nenhum', label: 'Nenhum', description: 'Ainda não representei atletas' },
    { id: '1-10', label: '1–10', description: 'Poucos atletas representados' },
    { id: '11-50', label: '11–50', description: 'Experiência moderada' },
    { id: '50+', label: '50+', description: 'Muita experiência' }
  ];

  const yearOptions = [
    { id: '0-1', label: '0–1 ano', description: 'Iniciante na área' },
    { id: '2-5', label: '2–5 anos', description: 'Experiência intermediária' },
    { id: '5+', label: '5+ anos', description: 'Profissional experiente' }
  ];

  const canContinue = athletesRepresented && yearsExperience;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '77%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">
            Sua experiência
          </h1>
          <p className="text-gray-600 text-lg">
            Conte-nos sobre sua trajetória profissional
          </p>
        </div>

        {/* Athletes Represented */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Users className="w-6 h-6 text-gray-600 mr-3" />
            <h2 className="text-xl font-semibold text-gray-900">
              Quantos atletas já representou?
            </h2>
          </div>
          <div className="space-y-3">
            {athleteOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => onAthletesChange(option.id)}
                className={`w-full p-4 rounded-2xl text-left transition-all duration-200 ${
                  athletesRepresented === option.id
                    ? 'bg-green-100 border-2 border-green-500'
                    : 'bg-white border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex flex-col">
                  <span className="text-lg font-medium text-gray-900 mb-1">
                    {option.label}
                  </span>
                  <span className="text-sm text-gray-600">
                    {option.description}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Years Experience */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Clock className="w-6 h-6 text-gray-600 mr-3" />
            <h2 className="text-xl font-semibold text-gray-900">
              Há quanto tempo atua como empresário/olheiro?
            </h2>
          </div>
          <div className="space-y-3">
            {yearOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => onYearsChange(option.id)}
                className={`w-full p-4 rounded-2xl text-left transition-all duration-200 ${
                  yearsExperience === option.id
                    ? 'bg-green-100 border-2 border-green-500'
                    : 'bg-white border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex flex-col">
                  <span className="text-lg font-medium text-gray-900 mb-1">
                    {option.label}
                  </span>
                  <span className="text-sm text-gray-600">
                    {option.description}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!canContinue}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            canContinue
              ? 'bg-orange-500 text-white hover:bg-orange-600 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}