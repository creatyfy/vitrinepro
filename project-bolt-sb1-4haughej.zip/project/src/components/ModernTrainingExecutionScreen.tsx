import React, { useState, useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import {
  createTrainingSession,
  updateTrainingSession,
  completeTrainingSession,
  abandonTrainingSession,
  getUserPreferences,
  type TrainingPreferences
} from '../services/trainingPersistenceService';

export interface TrainingExercise {
  id: string;
  name: string;
  videoUrl: string;
  sets?: number;
  reps?: string;
  duration?: number;
  restTime?: number;
}

export interface ModernTrainingExecutionProps {
  trainingType: 'classic' | 'daily' | 'preparation' | 'strengthening' | 'challenge28';
  trainingId: string;
  exercises: TrainingExercise[];
  currentExerciseIndex?: number;
  onComplete: () => void;
  onExit: () => void;
}

type Phase = 'prep' | 'active' | 'completed';

export default function ModernTrainingExecutionScreen({
  trainingType,
  trainingId,
  exercises,
  currentExerciseIndex = 0,
  onComplete,
  onExit
}: ModernTrainingExecutionProps) {
  const [phase, setPhase] = useState<Phase>('prep');
  const [prepTimer, setPrepTimer] = useState(9);
  const [exerciseIndex, setExerciseIndex] = useState(currentExerciseIndex);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [preferences, setPreferences] = useState<TrainingPreferences | null>(null);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  const currentExercise = exercises[exerciseIndex];
  const totalExercises = exercises.length;

  useEffect(() => {
    const init = async () => {
      try {
        const prefs = await getUserPreferences();
        setPreferences(prefs);

        const newSessionId = await createTrainingSession({
          training_type: trainingType,
          training_id: trainingId,
          status: 'active',
          total_exercises: exercises.length,
          completed_exercises: 0
        });
        setSessionId(newSessionId);
      } catch (error) {
        console.error('Error initializing session:', error);
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (phase === 'prep' && prepTimer > 0) {
      const timer = setTimeout(() => {
        setPrepTimer(prepTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'prep' && prepTimer === 0) {
      handleStartExercise();
    }
  }, [phase, prepTimer]);

  const handleStartExercise = () => {
    setPhase('active');
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  const handleSkipPrep = () => {
    setPrepTimer(0);
    handleStartExercise();
  };

  const handleCompleteExercise = async () => {
    if (exerciseIndex < totalExercises - 1) {
      setExerciseIndex(exerciseIndex + 1);
      setPhase('prep');
      setPrepTimer(9);

      if (sessionId) {
        await updateTrainingSession(sessionId, {
          completed_exercises: exerciseIndex + 1
        });
      }
    } else {
      if (sessionId) {
        await completeTrainingSession(sessionId);
      }
      onComplete();
    }
  };

  const handleExit = () => {
    setShowExitConfirm(true);
  };

  const confirmExit = async () => {
    if (sessionId) {
      await abandonTrainingSession(sessionId);
    }
    onExit();
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      <video
        ref={videoRef}
        src={currentExercise.videoUrl}
        className="absolute inset-0 w-full h-full object-cover"
        loop
        muted
        playsInline
      />

      <div
        className="absolute inset-0 bg-black transition-opacity duration-300"
        style={{ opacity: phase === 'prep' ? 0.7 : 0.4 }}
      />

      <div className="relative z-10 h-full flex flex-col">
        <div className="absolute top-0 left-0 right-0 z-20">
          <div className="flex items-center justify-center gap-1 px-4 pt-16">
            {Array.from({ length: totalExercises }).map((_, idx) => (
              <div
                key={idx}
                className={`h-1 flex-1 rounded-full transition-all ${
                  idx < exerciseIndex ? 'bg-white' :
                  idx === exerciseIndex ? 'bg-white' :
                  'bg-white/30'
                }`}
                style={{ maxWidth: '60px' }}
              />
            ))}
          </div>
        </div>

        <div className="absolute top-4 left-4 z-20">
          <button
            onClick={handleExit}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
            aria-label="Sair do treino"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6 pt-24">
          {phase === 'prep' && (
            <div className="flex flex-col items-center justify-center w-full max-w-md space-y-6 sm:space-y-8">
              <h1 className="text-white text-xl sm:text-2xl font-bold tracking-wider text-center uppercase">
                Preparado para começar
              </h1>

              <div className="relative">
                <div
                  className="text-white font-extrabold leading-none transition-all duration-300"
                  style={{
                    fontSize: 'clamp(120px, 25vw, 200px)',
                    textShadow: '0 0 60px rgba(255, 255, 255, 0.5), 0 0 120px rgba(255, 255, 255, 0.3)'
                  }}
                  aria-live="polite"
                  aria-label={`${prepTimer} segundos para começar`}
                >
                  {prepTimer}
                </div>
                <div
                  className="absolute inset-0 blur-3xl opacity-50"
                  style={{
                    background: 'radial-gradient(circle, rgba(255,255,255,0.4) 0%, transparent 70%)'
                  }}
                />
              </div>

              <div className="text-center space-y-2">
                <div className="text-white/80 text-base sm:text-lg font-medium">
                  Exercício {exerciseIndex + 1}/{totalExercises}
                </div>
                <div className="text-white text-lg sm:text-xl font-bold">
                  {currentExercise.name}
                </div>
              </div>

              <button
                onClick={handleSkipPrep}
                className="bg-white hover:bg-gray-100 text-black px-12 sm:px-16 py-4 sm:py-5 rounded-full text-lg sm:text-xl font-bold shadow-[0_0_30px_rgba(255,255,255,0.5)] transition-all active:scale-95 mt-4"
                style={{ minHeight: '60px', minWidth: '180px' }}
              >
                Início!
              </button>
            </div>
          )}

          {phase === 'active' && (
            <div className="flex flex-col items-center justify-center w-full h-full">
              <div className="absolute top-20 sm:top-24 left-1/2 -translate-x-1/2 max-w-[90%]">
                <div className="bg-black/60 backdrop-blur-md px-6 sm:px-8 py-3 sm:py-4 rounded-full">
                  <div className="text-white text-base sm:text-xl font-bold text-center">
                    {currentExercise.name}
                  </div>
                </div>
              </div>

              <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
                <button
                  onClick={handleCompleteExercise}
                  className="bg-white/90 hover:bg-white text-black px-8 sm:px-12 py-3 sm:py-4 rounded-full text-base sm:text-lg font-bold shadow-lg transition-all active:scale-95"
                >
                  Concluir Exercício
                </button>
              </div>

              {currentExercise.reps && (
                <div className="absolute bottom-6 sm:bottom-8 left-4 sm:left-6">
                  <div className="bg-black/60 backdrop-blur-md px-4 sm:px-6 py-2 sm:py-3 rounded-full">
                    <div className="text-white text-xs sm:text-sm font-medium">
                      {currentExercise.reps}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {showExitConfirm && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 sm:p-8 max-w-md w-full border border-white/20">
            <h3 className="text-white text-xl sm:text-2xl font-bold mb-4 text-center">
              Sair do treino?
            </h3>
            <p className="text-white/80 text-sm sm:text-base mb-6 sm:mb-8 text-center">
              Seu progresso será perdido se você sair agora.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 bg-white/20 hover:bg-white/30 text-white px-6 py-3 sm:py-4 rounded-full font-bold transition-all text-sm sm:text-base"
              >
                Continuar
              </button>
              <button
                onClick={confirmExit}
                className="flex-1 bg-red-500/90 hover:bg-red-500 text-white px-6 py-3 sm:py-4 rounded-full font-bold transition-all text-sm sm:text-base"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
