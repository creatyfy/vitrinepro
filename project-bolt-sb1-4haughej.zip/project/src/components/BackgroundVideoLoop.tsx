import React, { useEffect, useRef, useState } from 'react';
import { convertDriveUrlToEmbed } from '../utils/driveVideoUtils';

interface BackgroundVideoLoopProps {
  videoUrl: string;
  opacity?: number;
  isPlaying?: boolean;
  isMuted?: boolean;
  className?: string;
}

export default function BackgroundVideoLoop({
  videoUrl,
  opacity = 0.3,
  isPlaying = true,
  isMuted = true,
  className = ''
}: BackgroundVideoLoopProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [embedUrl, setEmbedUrl] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (videoUrl) {
      const converted = convertDriveUrlToEmbed(videoUrl);
      setEmbedUrl(converted);
      setIsLoading(true);
      setHasError(false);
    }
  }, [videoUrl]);

  const handleLoad = () => {
    setIsLoading(false);
  };

  const handleError = () => {
    setIsLoading(false);
    setHasError(true);
    console.error('Error loading video:', videoUrl);
  };

  if (!videoUrl || hasError) {
    return null;
  }

  return (
    <div
      className={`absolute inset-0 overflow-hidden ${className}`}
      style={{
        opacity,
        pointerEvents: 'none',
        zIndex: 0
      }}
    >
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/10">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      <iframe
        ref={iframeRef}
        src={`${embedUrl}?autoplay=1&loop=1&mute=${isMuted ? 1 : 0}&controls=0&modestbranding=1&showinfo=0&rel=0`}
        className="absolute inset-0 w-full h-full object-cover"
        style={{
          border: 'none',
          transform: 'scale(1.1)',
        }}
        allow="autoplay; encrypted-media"
        allowFullScreen={false}
        onLoad={handleLoad}
        onError={handleError}
        title="Exercise Background Video"
      />

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20" />
    </div>
  );
}
