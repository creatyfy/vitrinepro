import React, { useState } from 'react';
import { ChevronLeft, Mail } from 'lucide-react';

interface ForgotPasswordScreenProps {
  onBack: () => void;
  onSendCode: (email: string) => void;
}

export default function ForgotPasswordScreen({ onBack, onSendCode }: ForgotPasswordScreenProps) {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [codeSent, setCodeSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && isValidEmail(email)) {
      setIsLoading(true);
      
      // Simular envio do código
      setTimeout(() => {
        setIsLoading(false);
        setCodeSent(true);
        onSendCode(email);
      }, 2000);
    }
  };

  const isValidEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const isFormValid = email.trim() && isValidEmail(email);

  if (codeSent) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-gray-900">13:03</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
            <span className="ml-2 text-gray-800">5G</span>
            <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div className="flex items-center space-x-2">
            <span className="text-gray-400 text-sm">Vitrine Pro</span>
          </div>
          <div className="w-10"></div>
        </div>

        {/* Content - Success Message */}
        <div className="flex-1 px-6 flex flex-col justify-center">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Mail className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
              Código enviado!
            </h1>
            <p className="text-gray-600 text-xl mb-4">
              Enviamos um código de verificação para:
            </p>
            <p className="text-gray-900 font-semibold text-lg mb-8">
              {email}
            </p>
            <p className="text-gray-500 text-base">
              Verifique sua caixa de entrada e spam. O código expira em 10 minutos.
            </p>
          </div>
        </div>

        {/* Back to Login Button */}
        <div className="px-6 pb-8">
          <button
            onClick={onBack}
            className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
          >
            Voltar ao Login
          </button>
        </div>

        {/* Bottom Indicator */}
        <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Esqueceu sua senha?
          </h1>
          <p className="text-gray-600 text-xl">
            Digite seu email para receber um código de verificação
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <label htmlFor="email" className="block text-lg font-semibold text-gray-900 mb-4">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Digite seu email"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
              autoFocus
              disabled={isLoading}
            />
          </div>
        </form>
      </div>

      {/* Send Code Button */}
      <div className="px-6 pb-8">
        <button
          onClick={handleSubmit}
          disabled={!isFormValid || isLoading}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            isFormValid && !isLoading
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          {isLoading ? 'Enviando código...' : 'Enviar código'}
        </button>
        
        {/* Back to login link */}
        <p className="text-center text-gray-600 mt-6">
          Lembrou da senha? 
          <button 
            onClick={onBack}
            className="text-orange-500 font-medium ml-1 hover:text-orange-600 transition-colors"
            disabled={isLoading}
          >
            Voltar ao login
          </button>
        </p>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}