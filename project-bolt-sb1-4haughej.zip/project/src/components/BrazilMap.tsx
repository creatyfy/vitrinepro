import React, { useState } from 'react';
import { MapPin, Users, X } from 'lucide-react';

interface State {
  id: string;
  name: string;
  athletes: number;
  clubs: number;
  topAthletes: Array<{
    name: string;
    position: string;
    points: number;
  }>;
}

interface BrazilMapProps {
  isDarkMode: boolean;
}

export default function BrazilMap({ isDarkMode }: BrazilMapProps) {
  const [selectedState, setSelectedState] = useState<State | null>(null);

  const statesData: Record<string, State> = {
    SP: {
      id: 'SP',
      name: 'São Paulo',
      athletes: 485,
      clubs: 12,
      topAthletes: [
        { name: 'Carlos Silva', position: 'Atacante', points: 2450 },
        { name: 'João Santos', position: 'Zagueiro', points: 2380 },
        { name: 'Pedro Lima', position: 'Meia', points: 2300 }
      ]
    },
    RJ: {
      id: 'RJ',
      name: 'Rio de Janeiro',
      athletes: 392,
      clubs: 9,
      topAthletes: [
        { name: 'Bruno Henrique', position: 'Ponta', points: 2480 },
        { name: 'Gabriel Costa', position: 'Lateral', points: 2210 },
        { name: 'Lucas Moura', position: 'Volante', points: 2150 }
      ]
    },
    MG: {
      id: 'MG',
      name: 'Minas Gerais',
      athletes: 278,
      clubs: 7,
      topAthletes: [
        { name: 'Rafael Oliveira', position: 'Goleiro', points: 2320 },
        { name: 'Diego Santos', position: 'Zagueiro', points: 2180 },
        { name: 'Mateus Rocha', position: 'Atacante', points: 2100 }
      ]
    },
    RS: {
      id: 'RS',
      name: 'Rio Grande do Sul',
      athletes: 245,
      clubs: 6,
      topAthletes: [
        { name: 'Gabriel Ferreira', position: 'Volante', points: 2420 },
        { name: 'André Silva', position: 'Lateral', points: 2190 },
        { name: 'Rodrigo Lima', position: 'Meia', points: 2080 }
      ]
    },
    PR: {
      id: 'PR',
      name: 'Paraná',
      athletes: 198,
      clubs: 5,
      topAthletes: [
        { name: 'Neymar Silva', position: 'Ponta', points: 2470 },
        { name: 'Felipe Costa', position: 'Zagueiro', points: 2150 },
        { name: 'Júlio Cesar', position: 'Goleiro', points: 2050 }
      ]
    },
    BA: {
      id: 'BA',
      name: 'Bahia',
      athletes: 167,
      clubs: 4,
      topAthletes: [
        { name: 'Vitor Hugo', position: 'Atacante', points: 2280 },
        { name: 'Leonardo Dias', position: 'Meia', points: 2120 },
        { name: 'Thiago Santos', position: 'Lateral', points: 2000 }
      ]
    },
    PE: {
      id: 'PE',
      name: 'Pernambuco',
      athletes: 153,
      clubs: 4,
      topAthletes: [
        { name: 'Marcelo Souza', position: 'Ponta', points: 2250 },
        { name: 'Ricardo Lima', position: 'Volante', points: 2110 },
        { name: 'Fernando Costa', position: 'Zagueiro', points: 1980 }
      ]
    },
    CE: {
      id: 'CE',
      name: 'Ceará',
      athletes: 142,
      clubs: 3,
      topAthletes: [
        { name: 'Anderson Silva', position: 'Atacante', points: 2200 },
        { name: 'Gustavo Rocha', position: 'Meia', points: 2090 },
        { name: 'Paulo Henrique', position: 'Goleiro', points: 1970 }
      ]
    },
    SC: {
      id: 'SC',
      name: 'Santa Catarina',
      athletes: 128,
      clubs: 3,
      topAthletes: [
        { name: 'Marcos Paulo', position: 'Lateral', points: 2180 },
        { name: 'Rafael Santos', position: 'Zagueiro', points: 2070 },
        { name: 'Vinícius Lima', position: 'Meia', points: 1950 }
      ]
    },
    GO: {
      id: 'GO',
      name: 'Goiás',
      athletes: 95,
      clubs: 2,
      topAthletes: [
        { name: 'Diego Alves', position: 'Meia-atacante', points: 2360 },
        { name: 'Bruno Costa', position: 'Volante', points: 2050 },
        { name: 'Lucas Rocha', position: 'Atacante', points: 1940 }
      ]
    }
  };

  const getAthleteColor = (count: number) => {
    if (count > 400) return '#FF9500';
    if (count > 300) return '#FFB84D';
    if (count > 200) return '#FFC266';
    if (count > 100) return '#FFD699';
    return '#FFE5CC';
  };

  return (
    <div className="relative">
      <svg
        viewBox="0 0 400 500"
        className="w-full h-auto"
        style={{ maxHeight: '500px' }}
      >
        {/* Simplified Brazil Map with main states */}

        {/* São Paulo - SP */}
        <g onClick={() => setSelectedState(statesData.SP)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 200 280 L 220 280 L 230 290 L 230 310 L 210 320 L 190 310 Z"
            fill={getAthleteColor(statesData.SP.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="210" cy="300" r="8" fill="#FF6B00" className="animate-pulse" />
          <text x="210" y="340" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">SP</text>
        </g>

        {/* Rio de Janeiro - RJ */}
        <g onClick={() => setSelectedState(statesData.RJ)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 230 290 L 250 285 L 255 295 L 250 305 L 230 310 Z"
            fill={getAthleteColor(statesData.RJ.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="242" cy="297" r="7" fill="#FF6B00" className="animate-pulse" />
          <text x="242" y="325" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">RJ</text>
        </g>

        {/* Minas Gerais - MG */}
        <g onClick={() => setSelectedState(statesData.MG)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 200 250 L 230 250 L 240 270 L 230 290 L 200 280 Z"
            fill={getAthleteColor(statesData.MG.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="220" cy="270" r="6" fill="#FF6B00" className="animate-pulse" />
          <text x="220" y="245" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">MG</text>
        </g>

        {/* Rio Grande do Sul - RS */}
        <g onClick={() => setSelectedState(statesData.RS)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 170 370 L 200 370 L 210 390 L 200 410 L 170 410 L 160 390 Z"
            fill={getAthleteColor(statesData.RS.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="185" cy="390" r="6" fill="#FF6B00" className="animate-pulse" />
          <text x="185" y="430" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">RS</text>
        </g>

        {/* Paraná - PR */}
        <g onClick={() => setSelectedState(statesData.PR)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 180 320 L 210 320 L 220 340 L 200 350 L 180 340 Z"
            fill={getAthleteColor(statesData.PR.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="200" cy="335" r="5" fill="#FF6B00" className="animate-pulse" />
          <text x="200" y="365" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">PR</text>
        </g>

        {/* Santa Catarina - SC */}
        <g onClick={() => setSelectedState(statesData.SC)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 180 350 L 210 350 L 215 365 L 200 370 L 180 365 Z"
            fill={getAthleteColor(statesData.SC.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="197" cy="360" r="4" fill="#FF6B00" className="animate-pulse" />
          <text x="197" y="345" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">SC</text>
        </g>

        {/* Bahia - BA */}
        <g onClick={() => setSelectedState(statesData.BA)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 220 180 L 260 180 L 270 210 L 250 230 L 220 220 Z"
            fill={getAthleteColor(statesData.BA.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="240" cy="205" r="5" fill="#FF6B00" className="animate-pulse" />
          <text x="240" y="170" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">BA</text>
        </g>

        {/* Pernambuco - PE */}
        <g onClick={() => setSelectedState(statesData.PE)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 260 140 L 280 140 L 285 155 L 275 165 L 260 160 Z"
            fill={getAthleteColor(statesData.PE.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="272" cy="152" r="5" fill="#FF6B00" className="animate-pulse" />
          <text x="272" y="132" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">PE</text>
        </g>

        {/* Ceará - CE */}
        <g onClick={() => setSelectedState(statesData.CE)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 250 100 L 275 100 L 280 120 L 270 130 L 250 125 Z"
            fill={getAthleteColor(statesData.CE.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="265" cy="115" r="4" fill="#FF6B00" className="animate-pulse" />
          <text x="265" y="92" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">CE</text>
        </g>

        {/* Goiás - GO */}
        <g onClick={() => setSelectedState(statesData.GO)} className="cursor-pointer hover:opacity-80 transition-opacity">
          <path
            d="M 180 220 L 210 220 L 215 245 L 200 250 L 180 240 Z"
            fill={getAthleteColor(statesData.GO.athletes)}
            stroke="#1B3C87"
            strokeWidth="1.5"
          />
          <circle cx="197" cy="235" r="4" fill="#FF6B00" className="animate-pulse" />
          <text x="197" y="212" textAnchor="middle" className="text-xs font-bold" fill="#1B3C87">GO</text>
        </g>

        {/* Title */}
        <text x="200" y="40" textAnchor="middle" className="text-lg font-bold" fill="#1B3C87">
          Atletas por Estado
        </text>
        <text x="200" y="60" textAnchor="middle" className="text-sm" fill="#666">
          Clique em um estado para ver detalhes
        </text>
      </svg>

      {/* State Details Modal */}
      {selectedState && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 max-w-md w-full`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {selectedState.name}
              </h3>
              <button
                onClick={() => setSelectedState(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className={`w-5 h-5 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-600">{selectedState.athletes}</div>
                <div className="text-sm text-gray-600">Atletas</div>
              </div>
              <div className="bg-green-50 rounded-xl p-4 text-center">
                <MapPin className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-600">{selectedState.clubs}</div>
                <div className="text-sm text-gray-600">Clubes</div>
              </div>
            </div>

            <div>
              <h4 className={`font-semibold mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Top 3 Atletas
              </h4>
              <div className="space-y-3">
                {selectedState.topAthletes.map((athlete, index) => (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-xl ${
                      isDarkMode ? 'bg-gray-800' : 'bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' :
                        index === 1 ? 'bg-gray-400' :
                        'bg-orange-600'
                      }`}>
                        {index + 1}
                      </div>
                      <div>
                        <div className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {athlete.name}
                        </div>
                        <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {athlete.position}
                        </div>
                      </div>
                    </div>
                    <div className="text-lg font-bold text-blue-600">
                      {athlete.points}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
