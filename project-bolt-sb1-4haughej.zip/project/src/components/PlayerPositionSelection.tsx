import React from 'react';
import { ChevronLeft, Target, Shield, Users, Zap, Crown } from 'lucide-react';

interface PlayerPositionSelectionProps {
  selectedPosition: string;
  onPositionSelect: (position: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function PlayerPositionSelection({ selectedPosition, onPositionSelect, onNext, onBack }: PlayerPositionSelectionProps) {
  const positions = [
    { 
      id: 'goleiro', 
      label: 'Goleiro',
      icon: Shield,
      description: 'Defende o gol da equipe'
    },
    { 
      id: 'zagueiro', 
      label: 'Zagueiro',
      icon: Shield,
      description: 'Defesa central'
    },
    { 
      id: 'lateral', 
      label: 'Lateral',
      icon: Users,
      description: 'Lateral direito ou esquerdo'
    },
    { 
      id: 'volante', 
      label: 'Volante',
      icon: Target,
      description: 'Meio-campo defensivo'
    },
    { 
      id: 'meio-campo', 
      label: 'Meio-campo',
      icon: Users,
      description: 'Centro do campo'
    },
    { 
      id: 'meia-atacante', 
      label: 'Meia-atacante',
      icon: Zap,
      description: 'Meio-campo ofensivo'
    },
    { 
      id: 'ponta', 
      label: 'Ponta',
      icon: Zap,
      description: 'Extremo direito ou esquerdo'
    },
    { 
      id: 'atacante', 
      label: 'Atacante',
      icon: Crown,
      description: 'Centro-avante'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">
            Qual é a sua posição em campo?
          </h1>
          <p className="text-gray-600 text-lg mb-2">
            Selecione sua posição principal
          </p>
          <p className="text-gray-500 text-sm">
            💡 Você poderá alterar sua posição a qualquer momento no seu perfil
          </p>
        </div>

        {/* Position Options */}
        <div className="space-y-3 mb-12">
          {positions.map((position) => {
            const IconComponent = position.icon;
            const selected = selectedPosition === position.id;
            return (
              <button
                key={position.id}
                onClick={() => onPositionSelect(position.id)}
                className={`w-full p-4 rounded-2xl text-left transition-all duration-200 flex items-center ${
                  selected
                    ? 'bg-gray-900 text-white'
                    : 'bg-white border border-gray-200 hover:bg-gray-50 text-gray-800'
                }`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
                  selected ? 'bg-white/20' : 'bg-gray-100'
                }`}>
                  <IconComponent className={`w-5 h-5 ${selected ? 'text-white' : 'text-gray-600'}`} />
                </div>
                <div className="flex-1">
                  <span className="text-lg font-medium block">
                    {position.label}
                  </span>
                  <span className={`text-sm ${selected ? 'text-gray-300' : 'text-gray-500'}`}>
                    {position.description}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedPosition}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedPosition
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}