import React, { useState, useEffect, useRef } from 'react';
import { X, Volume2, VolumeX, Maximize, ChevronDown, SkipForward, RotateCcw, Play, Pause } from 'lucide-react';
import UniversalAntiCheatVerification from './UniversalAntiCheatVerification';
import {
  createTrainingSession,
  updateTrainingSession,
  saveExerciseProgress,
  getUserPreferences,
  saveUserPreferences,
  completeTrainingSession,
  abandonTrainingSession,
  getActiveTrainingSession,
  type TrainingPreferences
} from '../services/trainingPersistenceService';

export interface TrainingExercise {
  id: string;
  name: string;
  videoUrl: string;
  sets?: number;
  reps?: string;
  duration?: number;
  restTime?: number;
}

export interface UniversalTrainingExecutionProps {
  trainingType: 'classic' | 'daily' | 'preparation' | 'strengthening' | 'challenge28';
  trainingId: string;
  exercises: TrainingExercise[];
  currentExerciseIndex: number;
  onComplete: () => void;
  onExit: () => void;
  isDarkMode?: boolean;
}

type Phase = 'prep' | 'active' | 'rest' | 'paused' | 'verification';

export default function UniversalTrainingExecutionScreen({
  trainingType,
  trainingId,
  exercises,
  currentExerciseIndex,
  onComplete,
  onExit,
  isDarkMode = false
}: UniversalTrainingExecutionProps) {
  const [phase, setPhase] = useState<Phase>('prep');
  const [prepTimer, setPrepTimer] = useState(10);
  const [restTimer, setRestTimer] = useState(10);
  const [currentSet, setCurrentSet] = useState(1);
  const [timerKey, setTimerKey] = useState(0);
  const [exerciseIndex, setExerciseIndex] = useState(currentExerciseIndex);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [preferences, setPreferences] = useState<TrainingPreferences | null>(null);
  const [videoSpeed, setVideoSpeed] = useState(1.0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentExercise = exercises[exerciseIndex];
  const totalExercises = exercises.length;
  const nextExercise = exerciseIndex < totalExercises - 1 ? exercises[exerciseIndex + 1] : null;
  const totalSets = currentExercise?.sets || 1;

  useEffect(() => {
    const init = async () => {
      try {
        await initializeSession();
        await loadPreferences();
      } catch (error) {
        console.error('Error initializing session:', error);
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (phase === 'prep' && prepTimer > 0) {
      const timer = setTimeout(() => {
        setPrepTimer(prepTimer - 1);
        setTimerKey(prev => prev + 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'prep' && prepTimer === 0) {
      handleStartExercise();
    }
  }, [phase, prepTimer]);

  useEffect(() => {
    if (phase === 'rest' && restTimer > 0) {
      const timer = setTimeout(() => {
        setRestTimer(restTimer - 1);
        setTimerKey(prev => prev + 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'rest' && restTimer === 0) {
      handleNextSet();
    }
  }, [phase, restTimer]);

  useEffect(() => {
    if (sessionId) {
      const persist = async () => {
        try {
          await persistState();
        } catch (error) {
          console.error('Error persisting state:', error);
        }
      };
      persist();
    }
  }, [phase, exerciseIndex, currentSet, prepTimer, restTimer]);

  useEffect(() => {
    if (preferences) {
      setIsMuted(!preferences.music_enabled);
      setIsFullscreen(preferences.fullscreen_enabled);
      setPrepTimer(preferences.default_prep_time);
      setRestTimer(preferences.default_rest_time);
      setVideoSpeed(preferences.video_speed);
    }
  }, [preferences]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = videoSpeed;
    }
  }, [videoSpeed]);

  useEffect(() => {
    if (videoRef.current) {
      if (phase === 'prep' || phase === 'active') {
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(err => {
            console.error('Video play error:', err);
            videoRef.current?.load();
            setTimeout(() => {
              videoRef.current?.play().catch(e => console.error('Retry play error:', e));
            }, 500);
          });
        }
      } else if (phase === 'rest' || phase === 'paused') {
        videoRef.current.pause();
      }
    }
  }, [phase, exerciseIndex]);

  const initializeSession = async () => {
    const existing = await getActiveTrainingSession(trainingType, trainingId);

    if (existing) {
      setSessionId(existing.id || null);
      setExerciseIndex(existing.session_data?.currentExerciseIndex || 0);
      setCurrentSet(existing.session_data?.currentSet || 1);
      setPhase(existing.session_data?.phase || 'prep');
    } else {
      const newSessionId = await createTrainingSession({
        training_type: trainingType,
        training_id: trainingId,
        total_exercises: totalExercises,
        completed_exercises: 0,
        status: 'active',
        session_data: {
          currentExerciseIndex: exerciseIndex,
          currentSet: 1,
          phase: 'prep'
        }
      });
      setSessionId(newSessionId);
    }
  };

  const loadPreferences = async () => {
    const prefs = await getUserPreferences();
    setPreferences(prefs);
  };

  const persistState = async () => {
    if (!sessionId) return;

    await updateTrainingSession(sessionId, {
      session_data: {
        currentExerciseIndex: exerciseIndex,
        currentSet,
        phase,
        prepTimer,
        restTimer
      }
    });

    await saveExerciseProgress({
      session_id: sessionId,
      exercise_id: currentExercise.id,
      exercise_name: currentExercise.name,
      exercise_index: exerciseIndex,
      phase: phase === 'verification' ? 'completed' : phase,
      current_set: currentSet,
      total_sets: totalSets,
      remaining_time: phase === 'prep' ? prepTimer : restTimer,
      exercise_data: {
        videoUrl: currentExercise.videoUrl,
        reps: currentExercise.reps
      }
    });
  };

  const handleStartExercise = () => {
    setPhase('active');
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  const handleSkipPrep = () => {
    setPrepTimer(0);
    handleStartExercise();
  };

  const handleNextSet = () => {
    if (currentSet < totalSets) {
      setCurrentSet(currentSet + 1);
      setPhase('prep');
      setPrepTimer(preferences?.default_prep_time || 10);
    } else {
      handleCompleteExercise();
    }
  };

  const handleCompleteExercise = () => {
    if (exerciseIndex < totalExercises - 1) {
      setExerciseIndex(exerciseIndex + 1);
      setCurrentSet(1);
      setPhase('prep');
      setPrepTimer(preferences?.default_prep_time || 10);

      if (sessionId) {
        updateTrainingSession(sessionId, {
          completed_exercises: exerciseIndex + 1
        });
      }
    } else {
      setPhase('verification');
    }
  };

  const handleVerificationComplete = async () => {
    if (sessionId) {
      await completeTrainingSession(sessionId);
    }
    onComplete();
  };

  const handlePause = () => {
    setPhase('paused');
    if (videoRef.current) {
      videoRef.current.pause();
    }
  };

  const handleResume = () => {
    setPhase('active');
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  const handleExit = async () => {
    setShowExitConfirm(true);
  };

  const confirmExit = async (save: boolean) => {
    if (save && sessionId) {
      await updateTrainingSession(sessionId, {
        status: 'paused'
      });
    } else if (sessionId) {
      await abandonTrainingSession(sessionId);
    }
    onExit();
  };

  const handleToggleMute = async () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    if (preferences) {
      await saveUserPreferences({ ...preferences, music_enabled: !newMuted });
    }
  };

  const handleToggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
      if (preferences) {
        await saveUserPreferences({ ...preferences, fullscreen_enabled: true });
      }
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
      if (preferences) {
        await saveUserPreferences({ ...preferences, fullscreen_enabled: false });
      }
    }
  };

  const handleExtendRest = () => {
    setRestTimer(restTimer + 20);
  };

  const handleSkipRest = () => {
    setRestTimer(0);
    handleNextSet();
  };

  const handleChangeSpeed = async (speed: number) => {
    setVideoSpeed(speed);
    if (preferences) {
      await saveUserPreferences({ ...preferences, video_speed: speed });
    }
  };

  const overlayOpacity = isDarkMode ? 0.45 : 0.35;
  const activeOverlayOpacity = isDarkMode ? 0.15 : 0.2;

  if (phase === 'verification') {
    return (
      <UniversalAntiCheatVerification
        onSuccess={handleVerificationComplete}
        onFailure={() => setPhase('active')}
        isDarkMode={isDarkMode}
      />
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden bg-black"
    >
      <video
        ref={videoRef}
        src={currentExercise.videoUrl}
        className="absolute inset-0 w-full h-full object-cover"
        autoPlay
        loop
        muted={isMuted}
        playsInline
        preload="auto"
        onError={(e) => {
          console.error('Video loading error:', e);
          console.log('Video URL:', currentExercise.videoUrl);
        }}
        onLoadedData={() => {
          console.log('Video loaded successfully');
          if (videoRef.current && (phase === 'prep' || phase === 'active')) {
            videoRef.current.play().catch(e => console.error('Auto-play failed:', e));
          }
        }}
      />

      <div
        className="absolute inset-0 bg-black transition-opacity duration-300"
        style={{ opacity: phase === 'prep' ? 0.3 : phase === 'active' ? activeOverlayOpacity : overlayOpacity }}
      />

      <div className="relative z-10 h-full flex flex-col">
        <div className="absolute top-0 left-0 right-0 z-20">
          <div className="flex items-center justify-center gap-1 px-4 pt-16">
            {Array.from({ length: totalExercises }).map((_, idx) => (
              <div
                key={idx}
                className={`h-1 flex-1 rounded-full transition-all ${
                  idx < exerciseIndex ? 'bg-white' :
                  idx === exerciseIndex ? 'bg-white' :
                  'bg-white/30'
                }`}
                style={{ maxWidth: '60px' }}
              />
            ))}
          </div>
        </div>

        <div className="absolute top-4 left-4 z-20">
          <button
            onClick={handleExit}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
            aria-label="Sair do treino"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
            <button
              onClick={handleToggleFullscreen}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
              aria-label="Tela cheia"
            >
              <Maximize className="w-5 h-5 text-white" />
            </button>

            <button
              onClick={handleToggleMute}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
              aria-label={isMuted ? "Ativar som" : "Silenciar"}
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
            </button>

          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
            aria-label="Menu"
          >
            <ChevronDown className={`w-5 h-5 text-white transition-transform ${showMenu ? 'rotate-180' : ''}`} />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 py-4 pb-32 overflow-y-auto pt-24">
          {phase === 'prep' && (
            <div className="flex flex-col items-center justify-center w-full max-w-md">
              <h1 className="text-white text-2xl font-semibold tracking-wider mb-6 text-center">
                PREPARADO PARA COMEÇAR
              </h1>
              <div
                key={timerKey}
                className="text-white font-extrabold mb-6 leading-none animate-timer-explosion"
                style={{ fontSize: 'clamp(100px, 18vw, 160px)' }}
                aria-live="polite"
                aria-label={`${prepTimer} segundos para começar`}
              >
                {prepTimer}
              </div>
              <div className="text-white/90 text-lg font-medium mb-2">
                Exercício {exerciseIndex + 1}/{totalExercises}
              </div>
              <div className="text-white text-xl font-bold mb-8 text-center px-4">
                {currentExercise.name}
              </div>
              <button
                onClick={handleSkipPrep}
                className="bg-white hover:bg-gray-100 text-gray-900 px-16 py-5 rounded-full text-xl font-bold shadow-[0_0_30px_rgba(255,255,255,0.5)] transition-all active:scale-95 mt-4"
                style={{ minHeight: '68px', minWidth: '200px' }}
              >
                Início!
              </button>
            </div>
          )}

          {phase === 'active' && (
            <>
              <div className="absolute top-24 left-1/2 -translate-x-1/2">
                <div className="bg-black/60 backdrop-blur-sm px-8 py-3 rounded-full">
                  <div className="text-white text-xl font-bold text-center">
                    {currentExercise.name}
                  </div>
                </div>
              </div>
              <div className="absolute bottom-32 left-6">
                <div className="bg-black/60 backdrop-blur-sm px-6 py-3 rounded-full">
                  <div className="text-white text-sm font-medium">
                    Série {currentSet}/{totalSets}
                  </div>
                </div>
              </div>
              <div className="absolute bottom-32 right-6">
                <div className="bg-black/60 backdrop-blur-sm px-6 py-3 rounded-full">
                  <div className="text-white text-sm font-medium">
                    {currentExercise.reps}
                  </div>
                </div>
              </div>
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
                <button
                  onClick={handlePause}
                  className="bg-white/90 hover:bg-white text-gray-900 px-8 py-4 rounded-full font-bold shadow-lg transition-all active:scale-95 flex items-center gap-2"
                >
                  <Pause className="w-5 h-5" />
                  Pausar
                </button>
                <button
                  onClick={handleCompleteExercise}
                  className="bg-green-500/90 hover:bg-green-500 text-white px-8 py-4 rounded-full font-bold shadow-lg transition-all active:scale-95"
                >
                  Concluir
                </button>
              </div>
            </>
          )}

          {phase === 'rest' && (
            <div className="flex flex-col items-center justify-center w-full max-w-md">
              <h1 className="text-white text-2xl font-semibold tracking-wider mb-6 text-center">
                DESCANSO
              </h1>
              <div
                key={timerKey}
                className="text-white font-extrabold mb-8 leading-none animate-timer-explosion"
                style={{ fontSize: 'clamp(100px, 18vw, 160px)' }}
                aria-live="polite"
                aria-label={`${restTimer} segundos de descanso`}
              >
                {restTimer}
              </div>
              <div className="flex flex-col sm:flex-row gap-3 w-full px-4">
                <button
                  onClick={handleExtendRest}
                  className="bg-white/20 hover:bg-white/30 text-white px-8 py-4 rounded-full font-bold transition-all shadow-lg text-lg flex-1"
                  style={{ minHeight: '60px' }}
                >
                  +20s
                </button>
                <button
                  onClick={handleSkipRest}
                  className="bg-white hover:bg-gray-100 text-gray-900 px-8 py-4 rounded-full font-bold transition-all shadow-[0_0_30px_rgba(255,255,255,0.5)] text-lg flex-1"
                  style={{ minHeight: '60px' }}
                >
                  Pular Descanso
                </button>
              </div>
            </div>
          )}

          {phase === 'paused' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center">
              <div className="bg-black/90 rounded-3xl p-8 max-w-md w-full mx-6">
                <h2 className="text-white text-2xl font-bold mb-6 text-center">Treino Pausado</h2>
                <div className="space-y-3">
                  <button
                    onClick={handleResume}
                    className="w-full bg-white text-gray-900 py-4 rounded-full font-bold text-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2"
                  >
                    <Play className="w-5 h-5" />
                    Retomar
                  </button>
                  <button
                    onClick={() => {
                      setPhase('prep');
                      setCurrentSet(1);
                      setPrepTimer(preferences?.default_prep_time || 10);
                    }}
                    className="w-full bg-white/10 text-white py-4 rounded-full font-semibold hover:bg-white/20 transition-colors flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-5 h-5" />
                    Recomeçar Exercício
                  </button>
                  <button
                    onClick={handleExit}
                    className="w-full bg-red-500/20 text-red-400 py-4 rounded-full font-semibold hover:bg-red-500/30 transition-colors"
                  >
                    Encerrar Treino
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {showMenu && phase === 'active' && (
          <div className="absolute bottom-0 left-0 right-0 bg-black/95 backdrop-blur-lg rounded-t-3xl p-6 pb-8 transform transition-transform max-h-[80vh] overflow-y-auto">
            <div className="w-12 h-1 bg-white/30 rounded-full mx-auto mb-6" />

            <h3 className="text-white text-lg font-bold mb-4">Controles</h3>

            <div className="space-y-3 mb-6">
              <button
                onClick={() => {
                  if (exerciseIndex < totalExercises - 1) {
                    setExerciseIndex(exerciseIndex + 1);
                    setCurrentSet(1);
                    setPhase('prep');
                    setPrepTimer(preferences?.default_prep_time || 10);
                  } else {
                    setPhase('verification');
                  }
                  setShowMenu(false);
                }}
                className="w-full bg-white/10 text-white py-3 rounded-xl font-medium hover:bg-white/20 transition-colors flex items-center justify-center gap-2"
              >
                <SkipForward className="w-5 h-5" />
                {exerciseIndex < totalExercises - 1 ? 'Pular Exercício' : 'Finalizar Treino'}
              </button>

              <button
                onClick={handlePause}
                className="w-full bg-white/10 text-white py-3 rounded-xl font-medium hover:bg-white/20 transition-colors flex items-center justify-center gap-2"
              >
                <Pause className="w-5 h-5" />
                Pausar
              </button>
            </div>

            <div className="mb-6">
              <h4 className="text-white text-sm font-semibold mb-3">Velocidade do Vídeo</h4>
              <div className="flex gap-2">
                {[0.75, 1.0, 1.25].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => handleChangeSpeed(speed)}
                    className={`flex-1 py-2 rounded-lg font-medium transition-colors ${
                      videoSpeed === speed
                        ? 'bg-white text-gray-900'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                  >
                    {speed}×
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowMenu(false)}
              className="w-full bg-white text-gray-900 py-3 rounded-xl font-bold hover:bg-gray-100 transition-colors"
            >
              Fechar
            </button>
          </div>
        )}

        {showExitConfirm && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-black/90 rounded-3xl p-8 max-w-md w-full mx-6">
              <h2 className="text-white text-2xl font-bold mb-4 text-center">Sair do treino?</h2>
              <p className="text-white/70 text-center mb-6">
                Seu progresso atual será salvo e você poderá continuar depois.
              </p>
              <div className="space-y-3">
                <button
                  onClick={() => confirmExit(true)}
                  className="w-full bg-white text-gray-900 py-4 rounded-full font-bold hover:bg-gray-100 transition-colors"
                >
                  Salvar e Sair
                </button>
                <button
                  onClick={() => setShowExitConfirm(false)}
                  className="w-full bg-white/10 text-white py-4 rounded-full font-semibold hover:bg-white/20 transition-colors"
                >
                  Continuar Treinando
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-4 left-0 right-0 flex justify-center">
        <div className="w-32 h-1 bg-white/50 rounded-full" />
      </div>
    </div>
  );
}
