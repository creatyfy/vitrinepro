import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, CreditCard as Edit, Camera, Trophy, TrendingUp, Target, Calendar, ChevronRight, Building2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry, PLAYER_POSITIONS } from '../utils/videoUtils';
import { getMedalAsset } from '../utils/medalAssets';
import EditProfileScreen from './EditProfileScreen';
import VideoGalleryScreen from './VideoGalleryScreen';
import MedalsDetailScreen from './MedalsDetailScreen';
import ProgressDetailScreen from './ProgressDetailScreen';
import CareerOverviewScreen from './CareerOverviewScreen';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface PlayerProfile {
  id: string;
  user_id: string;
  name: string;
  birth_date: string;
  city: string;
  state: string;
  country: string;
  gender: string;
  height_cm: number;
  weight_kg: number;
  position_1: string;
  position_2: string;
  bio: string;
  avatar_url: string;
  total_points: number;
  quiz_completed: boolean;
}

interface Medal {
  id: string;
  medal_name: string;
  medal_description: string;
  medal_icon: string;
  progress: number;
  target: number;
  is_unlocked: boolean;
}

interface Progress {
  days_trained_7d: number;
  days_trained_30d: number;
  total_minutes: number;
  total_trainings: number;
  streak_current: number;
  streak_best: number;
}

interface TrainingHistory {
  id: string;
  training_name: string;
  training_type: string;
  date: string;
  completed: boolean;
  points_earned: number;
}

interface CareerEntry {
  id: string;
  club_name: string;
  games_played: number;
  goals_scored: number;
}

interface PlayerProfileScreenProps {
  userId: string;
  isOwnProfile: boolean;
  onBack: () => void;
}

export default function PlayerProfileScreen({ userId, isOwnProfile, onBack }: PlayerProfileScreenProps) {
  const { tokens, themeVersion } = useTheme();
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [medals, setMedals] = useState<Medal[]>([]);
  const [progress, setProgress] = useState<Progress | null>(null);
  const [history, setHistory] = useState<TrainingHistory[]>([]);
  const [career, setCareer] = useState<CareerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'resumo' | 'videos'>('resumo');
  const [videoCount, setVideoCount] = useState(0);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showMedalsDetail, setShowMedalsDetail] = useState(false);
  const [showProgressDetail, setShowProgressDetail] = useState(false);
  const [showCareerOverview, setShowCareerOverview] = useState(false);

  const styles = useMemo(() => ({
    container: {
      backgroundColor: tokens.surface
    },
    header: {
      backgroundColor: tokens.surface,
      borderColor: tokens.border
    },
    card: {
      backgroundColor: tokens.surfaceAlt,
      borderColor: tokens.border
    },
    textPrimary: {
      color: tokens.textPrimary
    },
    textSecondary: {
      color: tokens.textSecondary
    },
    icon: {
      color: tokens.icon
    },
    accent: {
      backgroundColor: tokens.accent,
      color: tokens.textInverse
    },
    accentText: {
      color: tokens.accent
    },
    accentBorder: {
      borderColor: tokens.accent
    }
  }), [themeVersion, tokens]);

  useEffect(() => {
    loadAllData();
    logTelemetry(userId, 'profile_screen_mounted', {});
  }, [userId]);

  async function loadAllData() {
    try {
      setLoading(true);
      setError(null);

      await Promise.all([
        loadProfile(),
        loadMedals(),
        loadProgress(),
        loadHistory(),
        loadCareer(),
        loadVideoCount()
      ]);
    } catch (err) {
      console.error('Error loading profile data:', err);
      setError('Erro ao carregar dados');
      await logTelemetry(userId, 'error_boundary_hit', {
        component: 'ProfileScreen',
        error: String(err)
      });
    } finally {
      setLoading(false);
    }
  }

  async function loadProfile() {
    const { data, error: fetchError } = await supabase
      .from('player_profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (fetchError) throw fetchError;
    setProfile(data);

    if (data?.quiz_completed) {
      await logTelemetry(userId, 'profile_prefilled_from_quiz', {
        fields: Object.keys(data).filter(k => data[k] !== null)
      });
    }
  }

  async function loadMedals() {
    try {
      await supabase.rpc('initialize_player_medals', { p_user_id: userId });
      const { data } = await supabase
        .from('player_medals')
        .select('*')
        .eq('user_id', userId)
        .order('is_unlocked', { ascending: false })
        .order('created_at', { ascending: true })
        .limit(5);

      setMedals(data || []);
      await logTelemetry(userId, 'medals_loaded', { count: data?.length || 0 });
    } catch (err) {
      console.error('Error loading medals:', err);
    }
  }

  async function loadProgress() {
    try {
      await supabase.rpc('update_player_progress', { p_user_id: userId });
      const { data } = await supabase
        .from('player_progress')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      setProgress(data);
      await logTelemetry(userId, 'progress_loaded', { period: '30d' });
    } catch (err) {
      console.error('Error loading progress:', err);
    }
  }

  async function loadHistory() {
    try {
      const { data } = await supabase
        .from('training_history')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: false })
        .limit(3);

      setHistory(data || []);
    } catch (err) {
      console.error('Error loading history:', err);
    }
  }

  async function loadCareer() {
    try {
      const { data } = await supabase
        .from('athlete_career')
        .select('id, club_name, games_played, goals_scored')
        .eq('user_id', userId)
        .order('is_current', { ascending: false })
        .order('start_date', { ascending: false })
        .limit(3);

      setCareer(data || []);
    } catch (err) {
      console.error('Error loading career:', err);
    }
  }

  async function loadVideoCount() {
    try {
      const { count } = await supabase
        .from('player_videos')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .is('deleted_at', null)
        .eq('status', 'ready');

      setVideoCount(count || 0);
    } catch (err) {
      console.error('Error loading video count:', err);
    }
  }

  function calculateAge(birthDate: string): number {
    if (!birthDate) return 0;
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  }

  function getPositionLabel(value: string): string {
    if (!value) return '';
    return PLAYER_POSITIONS.find((p) => p.value === value)?.label || value;
  }

  if (showEditProfile) {
    return (
      <EditProfileScreen
        userId={userId}
        onBack={() => setShowEditProfile(false)}
        onSave={async () => {
          setShowEditProfile(false);
          await loadAllData();
        }}
      />
    );
  }

  if (showMedalsDetail) {
    return (
      <MedalsDetailScreen
        userId={userId}
        onBack={() => setShowMedalsDetail(false)}
      />
    );
  }

  if (showProgressDetail) {
    return (
      <ProgressDetailScreen
        userId={userId}
        onBack={() => setShowProgressDetail(false)}
      />
    );
  }

  if (showCareerOverview) {
    return (
      <CareerOverviewScreen
        userId={userId}
        isOwnProfile={isOwnProfile}
        onBack={() => setShowCareerOverview(false)}
      />
    );
  }

  if (activeTab === 'videos') {
    return (
      <VideoGalleryScreen
        userId={userId}
        onBack={() => setActiveTab('resumo')}
      />
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-10 flex items-center justify-between p-4 border-b" style={styles.header}>
          <button onClick={onBack} className="p-2 rounded-lg">
            <ChevronLeft className="w-6 h-6" style={styles.icon} />
          </button>
          <div className="h-6 w-24 rounded animate-pulse" style={styles.card} />
          <div className="w-10" />
        </div>

        <div className="flex border-b" style={{ borderColor: tokens.border }}>
          <div className="flex-1 py-4 text-center">
            <div className="h-4 w-20 mx-auto rounded animate-pulse" style={styles.card} />
          </div>
          <div className="flex-1 py-4 text-center">
            <div className="h-4 w-20 mx-auto rounded animate-pulse" style={styles.card} />
          </div>
        </div>

        <div className="flex-1 p-6 space-y-6">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 rounded-full animate-pulse mb-4" style={styles.card} />
            <div className="h-6 w-40 rounded animate-pulse mb-2" style={styles.card} />
          </div>
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 rounded-2xl animate-pulse" style={styles.card} />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-10 flex items-center p-4 border-b" style={styles.header}>
          <button onClick={onBack} className="p-2 rounded-lg">
            <ChevronLeft className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="flex-1 text-xl font-bold text-center" style={styles.textPrimary}>
            Perfil
          </h1>
          <div className="w-10" />
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <p className="text-lg font-semibold mb-2" style={styles.textPrimary}>
            {error}
          </p>
          <button
            onClick={loadAllData}
            className="px-6 py-3 rounded-full font-semibold transition-transform active:scale-95"
            style={styles.accent}
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  const nextMedal = medals.find(m => !m.is_unlocked);
  const unlockedMedals = medals.filter(m => m.is_unlocked);

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      {/* Header */}
      <div className="sticky top-0 z-10" style={styles.header}>
        <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: tokens.border }}>
          <button onClick={onBack} className="p-2 rounded-lg">
            <ChevronLeft className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>
            Perfil
          </h1>
          <div className="w-10" />
        </div>

        {/* Tabs */}
        <div className="flex" style={{ borderBottomWidth: '1px', borderColor: tokens.border }}>
          <button
            onClick={() => setActiveTab('resumo')}
            className="flex-1 py-4 text-center font-semibold transition-colors relative"
            style={activeTab === 'resumo' ? styles.accentText : styles.textSecondary}
          >
            Resumo
            {activeTab === 'resumo' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: tokens.accent }} />
            )}
          </button>
          <button
            onClick={() => {
              setActiveTab('videos');
              logTelemetry(userId, 'videos_tab_opened');
            }}
            className="flex-1 py-4 text-center font-semibold transition-colors relative"
            style={activeTab === 'videos' ? styles.accentText : styles.textSecondary}
          >
            Vídeos ({videoCount})
            {activeTab === 'videos' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: tokens.accent }} />
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Profile Header - Centered */}
        <div className="flex flex-col items-center py-8 px-6">
          {/* Avatar with Camera Icon */}
          <div className="relative mb-4">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4" style={{ borderColor: tokens.border }}>
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center" style={styles.card}>
                  <Camera className="w-10 h-10" style={styles.icon} />
                </div>
              )}
            </div>
            {isOwnProfile && (
              <button
                onClick={() => setShowEditProfile(true)}
                className="absolute bottom-0 right-0 w-8 h-8 rounded-full flex items-center justify-center border-2"
                style={{ ...styles.card, borderColor: tokens.border }}
              >
                <Camera className="w-4 h-4" style={styles.icon} />
              </button>
            )}
          </div>

          {/* Name */}
          <h2 className="text-2xl font-bold mb-1" style={styles.textPrimary}>
            {profile?.name || 'Atleta'}
          </h2>

          {/* Subtitle */}
          <div className="text-center mb-4" style={styles.textSecondary}>
            <span>Atleta</span>
            {profile?.birth_date && (
              <span> • Idade {calculateAge(profile.birth_date)}</span>
            )}
            {(profile?.city || profile?.state) && (
              <span> • {[profile.city, profile.state].filter(Boolean).join(', ')}</span>
            )}
          </div>

          {/* Position Chips */}
          {(profile?.position_1 || profile?.position_2) && (
            <div className="flex gap-2 mb-6">
              {profile.position_1 && (
                <div className="px-4 py-2 rounded-lg text-sm font-bold" style={styles.accent}>
                  {getPositionLabel(profile.position_1)}
                </div>
              )}
              {profile.position_2 && (
                <div className="px-4 py-2 rounded-lg text-sm font-bold" style={styles.accent}>
                  {getPositionLabel(profile.position_2)}
                </div>
              )}
            </div>
          )}

          {/* Compact Metrics */}
          <div className="flex items-center gap-8">
            <div className="text-center">
              <p className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                {profile?.total_points?.toLocaleString() || 0}
              </p>
              <p className="text-sm" style={styles.textSecondary}>
                Pontos
              </p>
            </div>
            <div className="w-px h-12" style={{ backgroundColor: tokens.border }} />
            <div className="text-center">
              <p className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                {videoCount}
              </p>
              <p className="text-sm" style={styles.textSecondary}>
                Vídeos
              </p>
            </div>
          </div>
        </div>

        {/* Sections */}
        <div className="px-6 pb-8 space-y-4">
          {/* Medals & Achievements */}
          <button
            onClick={() => {
              logTelemetry(userId, 'medals_card_clicked');
              setShowMedalsDetail(true);
            }}
            className="w-full rounded-2xl p-6 border transition-transform active:scale-[0.98] text-left"
            style={styles.card}
          >
            <h3 className="text-lg font-bold mb-4" style={styles.textPrimary}>
              Medalhas & Conquistas
            </h3>

            <div className="flex items-center justify-between mb-4">
              <div className="flex gap-2">
                {medals.slice(0, 5).map((medal) => (
                  <div
                    key={medal.id}
                    className="w-10 h-10 flex items-center justify-center"
                  >
                    <img
                      src={medal.medal_icon}
                      alt={medal.medal_name}
                      className="w-full h-full object-contain"
                      style={{
                        filter: medal.is_unlocked ? 'none' : 'grayscale(100%) opacity(0.3)'
                      }}
                    />
                  </div>
                ))}
              </div>

              {/* Mini Progress Bar */}
              <div className="flex gap-1">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="w-1.5 rounded-full"
                    style={{
                      height: `${(i + 1) * 8}px`,
                      backgroundColor: i < unlockedMedals.length ? tokens.accent : tokens.border
                    }}
                  />
                ))}
              </div>
              <ChevronRight className="w-5 h-5" style={styles.icon} />
            </div>

            {nextMedal && (
              <p className="text-sm" style={styles.textSecondary}>
                Próxima: {nextMedal.medal_name} ({nextMedal.progress}/{nextMedal.target})
              </p>
            )}
          </button>

          {/* Progress & Career Split */}
          <div className="grid grid-cols-2 gap-4">
            {/* Progress - Last 30 days */}
            <button
              onClick={() => {
                logTelemetry(userId, 'progress_card_clicked');
                setShowProgressDetail(true);
              }}
              className="rounded-2xl p-4 border transition-transform active:scale-[0.98] text-left"
              style={styles.card}
            >
              <h3 className="text-sm font-bold mb-3" style={styles.textPrimary}>
                Progresso (Últimos 30 dias)
              </h3>

              <div className="space-y-3">
                <div>
                  <p className="text-3xl font-bold" style={styles.textPrimary}>
                    {progress?.total_trainings || 0}
                  </p>
                  <p className="text-xs" style={styles.textSecondary}>
                    treinos
                  </p>
                </div>

                <div>
                  <p className="text-3xl font-bold" style={styles.textPrimary}>
                    {progress?.total_minutes || 0}
                  </p>
                  <p className="text-xs" style={styles.textSecondary}>
                    min
                  </p>
                </div>
              </div>
            </button>

            {/* Career Overview */}
            <button
              onClick={() => {
                logTelemetry(userId, 'career_overview_clicked');
                setShowCareerOverview(true);
              }}
              className="rounded-2xl p-4 border transition-transform active:scale-[0.98] text-left"
              style={styles.card}
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold" style={styles.textPrimary}>
                  Visão Geral
                </h3>
                <Building2 className="w-4 h-4" style={styles.icon} />
              </div>

              <div className="space-y-2">
                {career.length > 0 ? (
                  <>
                    <div>
                      <p className="text-2xl font-bold" style={styles.textPrimary}>
                        {career.length}
                      </p>
                      <p className="text-xs" style={styles.textSecondary}>
                        clubes
                      </p>
                    </div>
                    <div className="flex gap-3 text-xs">
                      <div>
                        <span className="font-bold" style={styles.textPrimary}>
                          {career.reduce((sum, c) => sum + c.goals_scored, 0)}
                        </span>
                        <span style={styles.textSecondary}> gols</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-xs" style={styles.textSecondary}>
                    Adicione seu histórico
                  </p>
                )}
              </div>
            </button>
          </div>

          {/* Recent History */}
          {history.length > 0 && (
            <div className="rounded-2xl p-6 border" style={styles.card}>
              <h3 className="text-lg font-bold mb-4" style={styles.textPrimary}>
                Histórico recente
              </h3>

              <div className="space-y-2">
                {history.map((item) => (
                  <div key={item.id} className="text-sm" style={styles.textSecondary}>
                    {item.training_name} – {item.completed ? 'Concluído' : 'Em andamento'}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Edit Profile Button */}
          {isOwnProfile && (
            <button
              onClick={() => {
                logTelemetry(userId, 'profile_edit_opened');
                setShowEditProfile(true);
              }}
              className="w-full py-3 rounded-xl font-semibold border-2 transition-transform active:scale-[0.98]"
              style={{ ...styles.textPrimary, ...styles.accentBorder }}
            >
              Editar Perfil
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
