import React, { useMemo } from 'react';
import { ChevronLeft, User, Calendar, Ruler, Weight, Target, TrendingUp, Award, Star, Trophy, MapPin, Phone, Mail } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface ProfileScreenProps {
  athleteName: string;
  selectedGender: string;
  selectedHeight: number;
  selectedWeight: number;
  selectedDay: number;
  selectedMonth: number;
  selectedYear: number;
  selectedPosition: string;
  email: string;
  phone: string;
  profile?: {
    full_name?: string;
    gender?: string;
    height?: number;
    weight?: number;
    player_position?: string;
    phone?: string;
    email?: string;
    birth_date?: string;
  } | null;
  playerProfile?: {
    name?: string;
    position_1?: string;
    height_cm?: number;
    weight_kg?: number;
    birth_date?: string;
  } | null;
  onBack: () => void;
}

export default function ProfileScreen({
  athleteName,
  selectedGender,
  selectedHeight,
  selectedWeight,
  selectedDay,
  selectedMonth,
  selectedYear,
  selectedPosition,
  email,
  phone,
  profile,
  playerProfile,
  onBack
}: ProfileScreenProps) {
  const displayName = profile?.full_name || playerProfile?.name || athleteName;
  const displayGender = profile?.gender || selectedGender;
  const displayHeight = profile?.height || playerProfile?.height_cm || selectedHeight;
  const displayWeight = profile?.weight || playerProfile?.weight_kg || selectedWeight;
  const displayPosition = profile?.player_position || playerProfile?.position_1 || selectedPosition;
  const displayEmail = profile?.email || email;
  const displayPhone = profile?.phone || phone;

  let displayDay = selectedDay;
  let displayMonth = selectedMonth;
  let displayYear = selectedYear;

  if (profile?.birth_date) {
    const date = new Date(profile.birth_date);
    displayDay = date.getDate();
    displayMonth = date.getMonth() + 1;
    displayYear = date.getFullYear();
  } else if (playerProfile?.birth_date) {
    const date = new Date(playerProfile.birth_date);
    displayDay = date.getDate();
    displayMonth = date.getMonth() + 1;
    displayYear = date.getFullYear();
  }
  const { tokens, themeVersion } = useTheme();

  const styles = useMemo(() => ({
    container: {
      backgroundColor: tokens.surface
    },
    card: {
      backgroundColor: tokens.surfaceAlt,
      borderColor: tokens.border
    },
    textPrimary: {
      color: tokens.textPrimary
    },
    textSecondary: {
      color: tokens.textSecondary
    },
    icon: {
      color: tokens.icon
    },
    accent: {
      backgroundColor: tokens.accent,
      color: tokens.textInverse
    },
    accentText: {
      color: tokens.accent
    },
    success: {
      backgroundColor: `${tokens.success}20`,
      color: tokens.success
    },
    warning: {
      backgroundColor: `${tokens.warning}20`,
      color: tokens.warning
    }
  }), [themeVersion, tokens]);

  const getPositionName = (position: string) => {
    const positions: { [key: string]: string } = {
      'goleiro': 'Goleiro',
      'zagueiro': 'Zagueiro',
      'lateral': 'Lateral',
      'volante': 'Volante',
      'meio-campo': 'Meio-campo',
      'meia-atacante': 'Meia-atacante',
      'ponta': 'Ponta',
      'atacante': 'Atacante'
    };
    return positions[position] || 'Não definido';
  };

  const getAge = () => {
    const today = new Date();
    const birthDate = new Date(displayYear, displayMonth - 1, displayDay);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const evolutionData = [
    { metric: 'Treinos Concluídos', value: 47, change: '+12', period: 'este mês', positive: true },
    { metric: 'Pontuação Geral', value: 8.7, change: '+0.8', period: 'este mês', positive: true },
    { metric: 'Vídeos Postados', value: 23, change: '+5', period: 'este mês', positive: true },
    { metric: 'Visualizações', value: 1240, change: '+340', period: 'esta semana', positive: true }
  ];

  const achievements = [
    { id: 1, title: 'Primeira Semana', description: 'Complete 5 treinos em uma semana', earned: true },
    { id: 2, title: 'Consistência', description: 'Treine por 30 dias seguidos', earned: true },
    { id: 3, title: 'Destaque', description: 'Seja atleta da semana', earned: false },
    { id: 4, title: 'Profissional', description: 'Receba proposta de clube', earned: false }
  ];

  return (
    <div className="min-h-screen" style={styles.container}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={styles.textPrimary}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={styles.textPrimary}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={styles.icon} />
        </button>
        <h1 className="text-xl font-bold" style={styles.textPrimary}>Meu Perfil</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Profile Header */}
        <div className="rounded-2xl p-6 shadow-sm border mb-6" style={styles.card}>
          <div className="flex items-center mb-6">
            <div className="w-20 h-20 rounded-full flex items-center justify-center mr-4" style={styles.accent}>
              <User className="w-10 h-10" style={{ color: tokens.textInverse }} />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-1" style={styles.textPrimary}>{displayName}</h2>
              <p className="font-medium mb-1" style={styles.accentText}>{getPositionName(displayPosition)}</p>
              <div className="flex items-center" style={styles.textSecondary}>
                <MapPin className="w-4 h-4 mr-1" />
                <span className="text-sm">São Paulo, Brasil</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold" style={styles.textPrimary}>8.7</div>
              <div className="text-sm" style={styles.textSecondary}>Pontuação</div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center">
              <Calendar className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Idade</div>
                <div className="font-semibold" style={styles.textPrimary}>{getAge()} anos</div>
              </div>
            </div>
            <div className="flex items-center">
              <Target className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Gênero</div>
                <div className="font-semibold capitalize" style={styles.textPrimary}>{displayGender}</div>
              </div>
            </div>
            <div className="flex items-center">
              <Ruler className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Altura</div>
                <div className="font-semibold" style={styles.textPrimary}>{displayHeight} cm</div>
              </div>
            </div>
            <div className="flex items-center">
              <Weight className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Peso</div>
                <div className="font-semibold" style={styles.textPrimary}>{displayWeight} kg</div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="rounded-2xl p-6 shadow-sm border mb-6" style={styles.card}>
          <h3 className="text-lg font-semibold mb-4" style={styles.textPrimary}>Informações de Contato</h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <Mail className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Email</div>
                <div className="font-medium" style={styles.textPrimary}>{email || 'Não informado'}</div>
              </div>
            </div>
            <div className="flex items-center">
              <Phone className="w-5 h-5 mr-3" style={styles.icon} />
              <div>
                <div className="text-sm" style={styles.textSecondary}>Telefone</div>
                <div className="font-medium" style={styles.textPrimary}>{phone || 'Não informado'}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Evolution Data */}
        <div className="rounded-2xl p-6 shadow-sm border mb-6" style={styles.card}>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold" style={styles.textPrimary}>Dados de Evolução</h3>
            <TrendingUp className="w-6 h-6" style={{ color: tokens.success }} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {evolutionData.map((data, index) => (
              <div key={index} className="rounded-xl p-4" style={{ backgroundColor: tokens.surface }}>
                <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
                  {typeof data.value === 'number' && data.value > 100 ? data.value.toLocaleString() : data.value}
                </div>
                <div className="text-sm mb-2" style={styles.textSecondary}>{data.metric}</div>
                <div className="flex items-center">
                  <span className="text-sm font-medium" style={{ color: data.positive ? tokens.success : tokens.warning }}>
                    {data.change}
                  </span>
                  <span className="text-xs ml-1" style={styles.textSecondary}>{data.period}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="rounded-2xl p-6 shadow-sm border mb-8" style={styles.card}>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold" style={styles.textPrimary}>Conquistas</h3>
            <Award className="w-6 h-6" style={{ color: tokens.warning }} />
          </div>

          <div className="space-y-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className="flex items-center p-4 rounded-xl border"
                style={achievement.earned ? styles.success : { ...styles.card, borderColor: tokens.border }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mr-4"
                  style={achievement.earned ? { backgroundColor: tokens.success } : { backgroundColor: tokens.border }}
                >
                  {achievement.earned ? (
                    <Trophy className="w-6 h-6" style={{ color: tokens.textInverse }} />
                  ) : (
                    <Star className="w-6 h-6" style={styles.icon} />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold" style={achievement.earned ? { color: tokens.success } : styles.textPrimary}>
                    {achievement.title}
                  </h4>
                  <p className="text-sm" style={styles.textSecondary}>
                    {achievement.description}
                  </p>
                </div>
                {achievement.earned && (
                  <div className="font-medium text-sm" style={{ color: tokens.success }}>
                    Conquistado!
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 mx-auto mb-2 rounded-full" style={{ width: '134px', backgroundColor: tokens.textPrimary, opacity: 0.3 }}></div>
    </div>
  );
}
