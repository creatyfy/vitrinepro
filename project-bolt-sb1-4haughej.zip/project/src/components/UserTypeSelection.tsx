import React, { useMemo, useCallback } from 'react';
import { ChevronLeft, User, Building, Eye } from 'lucide-react';

interface UserTypeSelectionProps {
  selectedUserType: string;
  onUserTypeSelect: (userType: string) => void;
  onNext: () => void;
  onBack: () => void;
}

const UserTypeSelection = React.memo(({ selectedUserType, onUserTypeSelect, onNext, onBack }: UserTypeSelectionProps) => {
  const userTypes = useMemo(() => [
    { 
      id: 'atleta', 
      label: 'Atleta',
      icon: User,
      description: 'Jogador em busca de oportunidades'
    },
    { 
      id: 'clube', 
      label: 'Clube/Escolinha',
      icon: Building,
      description: 'Clube ou escola de futebol'
    },
    { 
      id: 'empresario', 
      label: 'Empresário/Olheiro',
      icon: Eye,
      description: 'Agente ou descobridor de talentos'
    }
  ], []);

  const handleUserTypeSelect = useCallback((userTypeId: string) => {
    onUserTypeSelect(userTypeId);
  }, [onUserTypeSelect]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '12.5%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            O que você é?
          </h1>
          <p className="text-gray-600 text-lg">
            Isso será usado para calibrar sua experiência personalizada
          </p>
        </div>

        {/* User Type Options */}
        <div className="space-y-4 mb-12">
          {userTypes.map((userType) => {
            const IconComponent = userType.icon;
            return (
              <button
                key={userType.id}
                onClick={() => handleUserTypeSelect(userType.id)}
                className={`w-full p-6 rounded-2xl text-left button-press flex items-center ${
                  selectedUserType === userType.id
                    ? 'bg-green-100 border-2 border-green-500'
                    : 'bg-white border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                  selectedUserType === userType.id ? 'bg-green-500' : 'bg-gray-100'
                }`}>
                  <IconComponent className={`w-6 h-6 ${
                    selectedUserType === userType.id ? 'text-white' : 'text-gray-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <span className="text-lg font-medium text-gray-800 block">
                    {userType.label}
                  </span>
                  <span className="text-sm text-gray-500">
                    {userType.description}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedUserType}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedUserType
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
});

UserTypeSelection.displayName = 'UserTypeSelection';

export default UserTypeSelection;