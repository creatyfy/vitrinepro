import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, TrendingUp, Calendar, Clock, Flame, Target, Award } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry } from '../utils/videoUtils';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface Progress {
  days_trained_7d: number;
  days_trained_30d: number;
  total_minutes: number;
  total_trainings: number;
  streak_current: number;
  streak_best: number;
}

interface TrainingHistory {
  id: string;
  training_name: string;
  training_type: string;
  date: string;
  completed: boolean;
  points_earned: number;
  duration_minutes: number;
}

interface ProgressDetailScreenProps {
  userId: string;
  onBack: () => void;
}

export default function ProgressDetailScreen({ userId, onBack }: ProgressDetailScreenProps) {
  const { theme, themeVersion } = useTheme();
  const [progress, setProgress] = useState<Progress | null>(null);
  const [history, setHistory] = useState<TrainingHistory[]>([]);
  const [loading, setLoading] = useState(true);

  const styles = useMemo(() => ({
    container: {
      backgroundColor: theme.surface
    },
    header: {
      backgroundColor: theme.surface,
      borderColor: theme.border
    },
    card: {
      backgroundColor: theme.surfaceAlt,
      borderColor: theme.border
    },
    textPrimary: {
      color: theme.textPrimary
    },
    textSecondary: {
      color: theme.textSecondary
    },
    icon: {
      color: theme.icon
    },
    accent: {
      backgroundColor: theme.accent,
      color: theme.textInverse
    },
    accentText: {
      color: theme.accent
    }
  }), [themeVersion, theme]);

  useEffect(() => {
    loadData();
    logTelemetry(userId, 'progress_detail_opened');
  }, [userId]);

  async function loadData() {
    try {
      setLoading(true);
      await Promise.all([
        loadProgress(),
        loadHistory()
      ]);
    } catch (err) {
      console.error('Error loading progress data:', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadProgress() {
    const { data } = await supabase
      .from('player_progress')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    setProgress(data);
  }

  async function loadHistory() {
    const { data } = await supabase
      .from('training_history')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false })
      .limit(20);

    setHistory(data || []);
  }

  const totalHours = Math.floor((progress?.total_minutes || 0) / 60);

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center justify-between px-3 py-4 border-b" style={styles.header}>
        <button onClick={onBack} className="p-2 rounded-lg -ml-2">
          <ChevronLeft className="w-6 h-6" style={styles.icon} />
        </button>
        <h1 className="text-lg sm:text-xl font-bold text-center flex-1 px-2" style={styles.textPrimary}>
          Progresso & Estatísticas
        </h1>
        <div className="w-10" />
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-3 sm:p-6 space-y-3 sm:space-y-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-32 rounded-2xl animate-pulse" style={styles.card} />
            ))}
          </div>
        ) : (
          <>
            {/* Stats Grid */}
            <div className="p-3 sm:p-6 space-y-3 sm:space-y-4 max-w-4xl mx-auto">
              {/* Overall Stats */}
              <div className="rounded-2xl p-4 sm:p-6 border" style={styles.card}>
                <h3 className="text-base sm:text-lg font-bold mb-4 text-center" style={styles.textPrimary}>
                  Estatísticas Gerais
                </h3>

                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div className="text-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Target className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-2xl sm:text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {progress?.total_trainings || 0}
                    </p>
                    <p className="text-xs leading-tight" style={styles.textSecondary}>
                      Total de treinos
                    </p>
                  </div>

                  <div className="text-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Clock className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-2xl sm:text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {totalHours}h
                    </p>
                    <p className="text-xs leading-tight" style={styles.textSecondary}>
                      Tempo total
                    </p>
                  </div>

                  <div className="text-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Flame className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-2xl sm:text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {progress?.streak_current || 0}
                    </p>
                    <p className="text-xs leading-tight" style={styles.textSecondary}>
                      Sequência atual
                    </p>
                  </div>

                  <div className="text-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
                    <Award className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" style={styles.accentText} />
                    <p className="text-2xl sm:text-3xl font-bold mb-1" style={styles.textPrimary}>
                      {progress?.streak_best || 0}
                    </p>
                    <p className="text-xs leading-tight" style={styles.textSecondary}>
                      Melhor sequência
                    </p>
                  </div>
                </div>
              </div>

              {/* Last 30 Days */}
              <div className="rounded-2xl p-4 sm:p-6 border" style={styles.card}>
                <div className="flex items-center gap-2 mb-4 justify-center sm:justify-start">
                  <Calendar className="w-4 h-4 sm:w-5 sm:h-5" style={styles.icon} />
                  <h3 className="text-base sm:text-lg font-bold" style={styles.textPrimary}>
                    Últimos 30 dias
                  </h3>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm" style={styles.textSecondary}>Dias treinados</span>
                    <span className="font-bold text-sm sm:text-base" style={styles.textPrimary}>
                      {progress?.days_trained_30d || 0} dias
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm" style={styles.textSecondary}>Média por semana</span>
                    <span className="font-bold text-sm sm:text-base" style={styles.textPrimary}>
                      {Math.round(((progress?.days_trained_30d || 0) / 30) * 7)} dias
                    </span>
                  </div>
                </div>
              </div>

              {/* Last 7 Days */}
              <div className="rounded-2xl p-4 sm:p-6 border" style={styles.card}>
                <div className="flex items-center gap-2 mb-4 justify-center sm:justify-start">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" style={styles.icon} />
                  <h3 className="text-base sm:text-lg font-bold" style={styles.textPrimary}>
                    Últimos 7 dias
                  </h3>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm" style={styles.textSecondary}>Dias treinados</span>
                    <span className="font-bold text-sm sm:text-base" style={styles.textPrimary}>
                      {progress?.days_trained_7d || 0} dias
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm" style={styles.textSecondary}>Consistência</span>
                    <span className="font-bold text-sm sm:text-base" style={styles.accentText}>
                      {Math.round(((progress?.days_trained_7d || 0) / 7) * 100)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Training History */}
              {history.length > 0 && (
                <div className="rounded-2xl p-4 sm:p-6 border" style={styles.card}>
                  <h3 className="text-base sm:text-lg font-bold mb-4 text-center sm:text-left" style={styles.textPrimary}>
                    Histórico Completo
                  </h3>

                  <div className="space-y-2 sm:space-y-3">
                    {history.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-3 rounded-xl gap-2"
                        style={{ backgroundColor: theme.surface }}
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-xs sm:text-sm mb-1 truncate" style={styles.textPrimary}>
                            {item.training_name}
                          </p>
                          <p className="text-xs truncate" style={styles.textSecondary}>
                            {new Date(item.date).toLocaleDateString('pt-BR')} • {item.duration_minutes}min
                          </p>
                        </div>
                        {item.completed && (
                          <div className="px-2 sm:px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap flex-shrink-0" style={styles.accent}>
                            +{item.points_earned}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
