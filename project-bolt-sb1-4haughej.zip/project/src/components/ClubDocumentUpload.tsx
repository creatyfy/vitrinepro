import React, { useState } from 'react';
import { ChevronLeft, Upload, FileText } from 'lucide-react';

interface ClubDocumentUploadProps {
  clubDocument: string;
  onDocumentChange: (document: string) => void;
  onNext: () => void;
  onSkip: () => void;
  onBack: () => void;
}

export default function ClubDocumentUpload({ 
  clubDocument, 
  onDocumentChange, 
  onNext, 
  onSkip,
  onBack 
}: ClubDocumentUploadProps) {
  const [dragOver, setDragOver] = useState(false);

  const handleFileSelect = (file: File) => {
    if (file && (file.type === 'application/pdf' || file.type.startsWith('image/'))) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        onDocumentChange(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '87.5%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Documento do clube
          </h1>
          <p className="text-gray-600 text-xl mb-2">
            Adicione o registro ou documento oficial
          </p>
          <p className="text-gray-500 text-lg">
            Opcional - apenas para clubes maiores
          </p>
        </div>

        {/* Upload Area */}
        <div className="mb-8">
          {clubDocument ? (
            <div className="text-center">
              <div className="w-32 h-32 mx-auto mb-6 rounded-2xl bg-blue-50 border-2 border-blue-200 flex items-center justify-center">
                <FileText className="w-16 h-16 text-blue-500" />
              </div>
              <p className="text-gray-700 font-medium mb-4">Documento enviado com sucesso!</p>
              <button
                onClick={() => onDocumentChange('')}
                className="text-orange-500 font-medium hover:text-orange-600 transition-colors"
              >
                Remover documento
              </button>
            </div>
          ) : (
            <div
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-200 ${
                dragOver 
                  ? 'border-orange-500 bg-orange-50' 
                  : 'border-gray-300 hover:border-orange-400'
              }`}
              onDrop={handleDrop}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
            >
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Arraste o documento aqui
              </h3>
              <p className="text-gray-600 mb-4">
                ou clique para selecionar (PDF ou imagem)
              </p>
              <input
                type="file"
                accept=".pdf,image/*"
                onChange={handleFileInput}
                className="hidden"
                id="document-upload"
              />
              <label
                htmlFor="document-upload"
                className="inline-flex items-center px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition-colors cursor-pointer"
              >
                <FileText className="w-5 h-5 mr-2" />
                Selecionar Arquivo
              </label>
            </div>
          )}
        </div>
      </div>

      {/* Buttons */}
      <div className="px-6 pb-8 space-y-4">
        <button
          onClick={onNext}
          disabled={!clubDocument}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            clubDocument
              ? 'bg-orange-500 text-white hover:bg-orange-600 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
        
        <button
          onClick={onSkip}
          className="w-full text-gray-600 py-2 font-medium text-lg hover:text-gray-800 transition-colors duration-200"
        >
          Pular esta etapa
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}