import React, { useState, useEffect, useRef } from 'react';

interface OptimizedImageProps {
  src: string;
  alt: string;
  className?: string;
  placeholder?: string;
  onLoad?: () => void;
  lazy?: boolean;
}

export const OptimizedImage = React.memo(({
  src,
  alt,
  className = '',
  placeholder,
  onLoad,
  lazy = true
}: OptimizedImageProps) => {
  const [imageSrc, setImageSrc] = useState<string | undefined>(placeholder);
  const [imageLoaded, setImageLoaded] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    if (!lazy) {
      setImageSrc(src);
      return;
    }

    const imgElement = imgRef.current;
    if (!imgElement) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setImageSrc(src);
            observer.disconnect();
          }
        });
      },
      {
        rootMargin: '50px',
        threshold: 0.01,
      }
    );

    observer.observe(imgElement);

    return () => {
      observer.disconnect();
    };
  }, [src, lazy]);

  const handleLoad = () => {
    setImageLoaded(true);
    onLoad?.();
  };

  return (
    <img
      ref={imgRef}
      src={imageSrc}
      alt={alt}
      className={`${className} ${imageLoaded ? '' : 'img-loading'} gpu-accelerated`}
      onLoad={handleLoad}
      loading={lazy ? 'lazy' : 'eager'}
      decoding="async"
    />
  );
});

OptimizedImage.displayName = 'OptimizedImage';
