import React from 'react';
import { X } from 'lucide-react';

interface PauseOverlayProps {
  isDarkMode: boolean;
  currentExercise: number;
  totalExercises: number;
  onResume: () => void;
  onRestart: () => void;
  onExit: () => void;
}

export default function PauseOverlay({
  isDarkMode,
  currentExercise,
  totalExercises,
  onResume,
  onRestart,
  onExit
}: PauseOverlayProps) {
  const progressPercentage = Math.round((currentExercise / totalExercises) * 100);
  const remainingExercises = totalExercises - currentExercise;

  const bgClass = isDarkMode ? 'bg-black' : 'bg-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80 backdrop-blur-sm">
      <div className={`${bgClass} rounded-3xl p-8 mx-6 max-w-md w-full shadow-2xl`}>
        <div className="flex items-center justify-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
            <X className="w-10 h-10 text-white" />
          </div>
        </div>

        <h2 className={`text-3xl font-bold ${textClass} text-center mb-4`}>
          Tela Pausada
        </h2>

        <p className={`text-xl font-semibold ${textClass} text-center mb-8`}>
          Não desista Jogador, você está bem!
        </p>

        <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'} rounded-2xl p-6 mb-8`}>
          <div className="text-center mb-4">
            <div className={`text-5xl font-bold ${textClass} mb-2`}>
              {progressPercentage}%
            </div>
            <div className={`text-sm ${secondaryTextClass}`}>
              Você concluiu {progressPercentage}% do treino
            </div>
          </div>

          <div className={`w-full ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-full h-3 mb-4`}>
            <div
              className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>

          <div className="flex items-center justify-center space-x-6">
            <div className="text-center">
              <div className={`text-2xl font-bold ${textClass}`}>{currentExercise}</div>
              <div className={`text-xs ${secondaryTextClass}`}>Concluídos</div>
            </div>
            <div className={`h-8 w-px ${isDarkMode ? 'bg-gray-700' : 'bg-gray-300'}`}></div>
            <div className="text-center">
              <div className={`text-2xl font-bold text-blue-500`}>{remainingExercises}</div>
              <div className={`text-xs ${secondaryTextClass}`}>Falta{remainingExercises !== 1 ? 'm' : ''}</div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={onResume}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-4 rounded-2xl font-bold text-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 active:scale-95 shadow-lg"
          >
            Retomar
          </button>

          <button
            onClick={onRestart}
            className={`w-full ${isDarkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-200 hover:bg-gray-300'} ${textClass} py-4 rounded-2xl font-semibold text-base transition-all duration-200 active:scale-95 border-2 ${isDarkMode ? 'border-gray-700' : 'border-gray-300'}`}
          >
            Recomeçar este exercício
          </button>

          <button
            onClick={onExit}
            className={`w-full ${secondaryTextClass} py-4 rounded-2xl font-medium text-base hover:opacity-60 transition-all duration-200 active:scale-95`}
          >
            Sair
          </button>
        </div>
      </div>
    </div>
  );
}
