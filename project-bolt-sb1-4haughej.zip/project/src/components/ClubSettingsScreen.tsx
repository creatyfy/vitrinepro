import React, { useState } from 'react';
import { ChevronLeft, User, Palette, Shield, HelpCircle, Video, ChevronRight, Sun, Moon, Monitor, Trophy, FileText, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';

interface ClubSettingsScreenProps {
  onBack: () => void;
  onNavigateToClubProfile: () => void;
  onNavigateToPrivacy: () => void;
  onNavigateToSupport: () => void;
  onNavigateToVerification: () => void;
}

export default function ClubSettingsScreen({
  onBack,
  onNavigateToClubProfile,
  onNavigateToPrivacy,
  onNavigateToSupport,
  onNavigateToVerification
}: ClubSettingsScreenProps) {
  const { t } = useLanguage();
  const { theme, setTheme, isDarkMode } = useTheme();
  const [showThemeSelector, setShowThemeSelector] = useState(false);

  const settingsOptions = [
    {
      id: 'profile',
      title: 'Perfil do Clube',
      description: 'Alterar informações e categorias do clube',
      icon: Trophy,
      action: onNavigateToClubProfile
    },
    {
      id: 'theme',
      title: t('changeTheme'),
      description: 'Escolher tema claro, escuro ou seguir sistema',
      icon: Palette,
      action: () => setShowThemeSelector(!showThemeSelector)
    },
    {
      id: 'privacy',
      title: t('privacy'),
      description: 'Configurações de privacidade e dados',
      icon: Shield,
      action: onNavigateToPrivacy
    },
    {
      id: 'support',
      title: t('helpSupport'),
      description: 'Central de ajuda e contato',
      icon: HelpCircle,
      action: onNavigateToSupport
    },
    {
      id: 'verification',
      title: 'Verificação do Clube',
      description: 'Validar documentação e credenciais',
      icon: FileText,
      action: onNavigateToVerification
    }
  ];

  const themeOptions = [
    { value: 'light' as const, label: t('light'), icon: Sun },
    { value: 'dark' as const, label: t('dark'), icon: Moon },
    { value: 'system' as const, label: t('followSystem'), icon: Monitor }
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="text-xl font-bold text-white">Configurações</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Palette className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Configurações</h2>
          <p className="text-gray-400">Configure o perfil do clube</p>
        </div>

        <div className="space-y-4 mb-8">
          {settingsOptions.map((option) => {
            const IconComponent = option.icon;
            return (
              <div key={option.id}>
                <button
                  onClick={option.action}
                  className="w-full bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-800 hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center flex-1">
                      <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mr-4">
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-left">
                        <h3 className="font-semibold text-white text-lg mb-1">
                          {option.title}
                        </h3>
                        <p className="text-sm text-gray-400">
                          {option.description}
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </button>

                {option.id === 'theme' && showThemeSelector && (
                  <div className="mt-4 bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-800">
                    <h4 className="text-sm font-medium text-white mb-4">Selecione o tema</h4>
                    <div className="space-y-3">
                      {themeOptions.map((themeOption) => {
                        const ThemeIcon = themeOption.icon;
                        return (
                          <button
                            key={themeOption.value}
                            onClick={() => setTheme(themeOption.value)}
                            className={`w-full p-4 rounded-xl flex items-center transition-colors ${
                              theme === themeOption.value
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                            }`}
                          >
                            <ThemeIcon className="w-5 h-5 mr-3" />
                            <span className="font-medium">{themeOption.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
