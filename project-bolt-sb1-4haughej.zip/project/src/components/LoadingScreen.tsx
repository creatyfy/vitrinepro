import React, { useState, useEffect } from 'react';
import { Check } from 'lucide-react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    'Analisando seus dados',
    'Criando o treino ideal para você',
    'Organizando seu perfil',
    'Revisando tudo'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + 2;
        
        // Update current step based on progress
        if (newProgress >= 25 && currentStep < 1) {
          setCurrentStep(1);
        } else if (newProgress >= 50 && currentStep < 2) {
          setCurrentStep(2);
        } else if (newProgress >= 75 && currentStep < 3) {
          setCurrentStep(3);
        } else if (newProgress >= 100 && currentStep < 4) {
          setCurrentStep(4);
        }

        if (newProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 1000);
          return 100;
        }
        
        return newProgress;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [currentStep, onComplete]);

  const circumference = 2 * Math.PI * 90; // radius = 90
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        {/* Progress Circle */}
        <div className="relative mb-16">
          <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 200 200">
            {/* Background circle */}
            <circle
              cx="100"
              cy="100"
              r="90"
              stroke="#e5e7eb"
              strokeWidth="8"
              fill="none"
            />
            {/* Progress circle */}
            <circle
              cx="100"
              cy="100"
              r="90"
              stroke="#10b981"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-300 ease-out"
            />
          </svg>
          {/* Percentage text */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-4xl font-bold text-gray-900">
              {Math.round(progress)}%
            </span>
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold text-gray-900 mb-16 text-center leading-tight">
          Quase lá jogador...
        </h1>

        {/* Progress Steps */}
        <div className="w-full max-w-sm space-y-6">
          {steps.map((step, index) => {
            const isCompleted = index < currentStep;
            const isActive = index === currentStep && progress < 100;
            
            return (
              <div key={index} className="flex items-center space-x-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 ${
                  isCompleted 
                    ? 'bg-green-500' 
                    : isActive 
                      ? 'bg-gray-300 animate-pulse' 
                      : 'bg-gray-200'
                }`}>
                  {isCompleted ? (
                    <Check className="w-5 h-5 text-white" />
                  ) : (
                    <div className={`w-3 h-3 rounded-full ${
                      isActive ? 'bg-gray-500' : 'bg-gray-400'
                    }`}></div>
                  )}
                </div>
                <span className={`text-lg transition-all duration-500 ${
                  isCompleted 
                    ? 'text-green-600 font-medium line-through' 
                    : isActive 
                      ? 'text-gray-900 font-medium' 
                      : 'text-gray-500'
                }`}>
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}