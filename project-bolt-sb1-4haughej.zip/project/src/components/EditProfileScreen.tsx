import React, { useState, useEffect, useMemo } from 'react';
import {
  X, Camera, Check, AlertCircle, Instagram, Youtube, Mail, Phone, Shield, Lock, Trophy, Plus
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry, PLAYER_POSITIONS } from '../utils/videoUtils';
import {
  formatDateInput,
  calculateBMI,
  PLAY_STYLE_OPTIONS,
  DOMINANT_FOOT_OPTIONS,
  GENDER_OPTIONS
} from '../utils/profileHelpers';
import AchievementSubmissionScreen from './AchievementSubmissionScreen';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

type TabType = 'basico' | 'fisico' | 'jogo' | 'sobre';

interface EditProfileScreenProps {
  userId: string;
  onBack: () => void;
  onSave?: () => void;
}

export default function EditProfileScreen({ userId, onBack, onSave }: EditProfileScreenProps) {
  const { tokens, themeVersion } = useTheme();
  const [activeTab, setActiveTab] = useState<TabType>('basico');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [originalData, setOriginalData] = useState<any>({});
  const [formData, setFormData] = useState<any>({});
  const [selectedPositions, setSelectedPositions] = useState<string[]>([]);
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);
  const [isFreeAgent, setIsFreeAgent] = useState(false);
  const [showAchievementScreen, setShowAchievementScreen] = useState(false);

  const styles = useMemo(() => ({
    container: { backgroundColor: tokens.surface },
    header: { backgroundColor: tokens.surface, borderColor: tokens.border },
    card: { backgroundColor: tokens.surfaceAlt, borderColor: tokens.border },
    textPrimary: { color: tokens.textPrimary },
    textSecondary: { color: tokens.textSecondary },
    icon: { color: tokens.icon },
    accent: { backgroundColor: tokens.accent, color: tokens.textInverse },
    accentText: { color: tokens.accent },
    accentBorder: { borderColor: tokens.accent },
    input: { backgroundColor: tokens.surfaceAlt, borderColor: tokens.border, color: tokens.textPrimary },
    inputDisabled: { backgroundColor: tokens.border, borderColor: tokens.border, color: tokens.textSecondary, cursor: 'not-allowed' },
    error: { color: tokens.error, backgroundColor: `${tokens.error}15` },
    success: { color: tokens.success, backgroundColor: `${tokens.success}15` },
    chipDefault: { backgroundColor: tokens.surfaceAlt, color: tokens.textPrimary, borderColor: tokens.border },
    chipSelected: { backgroundColor: tokens.accent, color: tokens.textInverse }
  }), [themeVersion, tokens]);

  useEffect(() => {
    loadProfile();
    logTelemetry(userId, 'edit_profile_opened', { tab: activeTab });
  }, [userId]);

  async function loadProfile() {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('player_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (fetchError) throw fetchError;
      if (data) {
        setOriginalData(data);
        setFormData(data);
        setSelectedPositions([data.position_1, data.position_2].filter(Boolean));
        setSelectedStyles(data.play_style_tags || []);
        setIsFreeAgent(data.free_agent || false);
      }
    } catch (err) {
      console.error('Error loading profile:', err);
      setError('Erro ao carregar perfil');
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    try {
      setSaving(true);
      setError(null);

      const changes: any = {};

      changes.position_1 = selectedPositions[0] || null;
      changes.position_2 = selectedPositions[1] || null;
      changes.play_style_tags = selectedStyles;
      changes.free_agent = isFreeAgent;

      if (isFreeAgent) {
        changes.current_club = null;
      }

      if (formData.dominant_foot !== originalData.dominant_foot) {
        changes.dominant_foot = formData.dominant_foot;
      }
      if (formData.shirt_number !== originalData.shirt_number) {
        changes.shirt_number = formData.shirt_number;
      }
      if (!isFreeAgent && formData.current_club !== originalData.current_club) {
        changes.current_club = formData.current_club;
      }
      if (formData.bio !== originalData.bio) {
        changes.bio = formData.bio;
      }
      if (formData.instagram_url !== originalData.instagram_url) {
        changes.instagram_url = formData.instagram_url;
      }
      if (formData.youtube_url !== originalData.youtube_url) {
        changes.youtube_url = formData.youtube_url;
      }
      if (formData.commercial_email !== originalData.commercial_email) {
        changes.commercial_email = formData.commercial_email;
      }
      if (formData.commercial_phone !== originalData.commercial_phone) {
        changes.commercial_phone = formData.commercial_phone;
      }
      if (formData.hide_contact_public !== originalData.hide_contact_public) {
        changes.hide_contact_public = formData.hide_contact_public;
      }
      if (formData.show_age_public !== originalData.show_age_public) {
        changes.show_age_public = formData.show_age_public;
      }
      if (formData.show_city_public !== originalData.show_city_public) {
        changes.show_city_public = formData.show_city_public;
      }
      if (formData.allow_club_messages !== originalData.allow_club_messages) {
        changes.allow_club_messages = formData.allow_club_messages;
      }

      if (Object.keys(changes).length > 0) {
        await saveWithRetry(changes);
        logTelemetry(userId, 'profile_patch_succeeded', { fields: Object.keys(changes) });
      }

      setSuccess(true);
      logTelemetry(userId, 'profile_patch_submitted', { fields: Object.keys(changes), tab: activeTab });

      setTimeout(() => {
        if (onSave) onSave();
        else onBack();
      }, 1000);

    } catch (err) {
      console.error('Error saving:', err);
      setError('Erro ao salvar. Tente novamente.');
      logTelemetry(userId, 'profile_patch_failed', { code: (err as any)?.code });
    } finally {
      setSaving(false);
    }
  }

  async function saveWithRetry(changes: any, retries = 2): Promise<void> {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const { error: updateError } = await supabase
          .from('player_profiles')
          .update(changes)
          .eq('user_id', userId);

        if (updateError) throw updateError;
        return;
      } catch (err: any) {
        if (attempt === retries || (err?.code && !err.code.startsWith('5'))) throw err;
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }
  }

  function updateField(field: string, value: any) {
    setFormData((prev: any) => ({ ...prev, [field]: value }));
  }

  function handleTabChange(tab: TabType) {
    setActiveTab(tab);
    logTelemetry(userId, 'edit_tab_changed', { tab });
  }

  function togglePosition(position: string) {
    setSelectedPositions(prev => {
      if (prev.includes(position)) {
        logTelemetry(userId, 'position_toggled', { pos: position, selected: false });
        return prev.filter(p => p !== position);
      }
      if (prev.length >= 2) {
        setError('Selecione no máximo 2 posições');
        setTimeout(() => setError(null), 3000);
        return prev;
      }
      logTelemetry(userId, 'position_toggled', { pos: position, selected: true });
      return [...prev, position];
    });
  }

  function toggleStyle(style: string) {
    setSelectedStyles(prev => {
      if (prev.includes(style)) return prev.filter(s => s !== style);
      if (prev.length >= 5) {
        setError('Selecione no máximo 5 características');
        setTimeout(() => setError(null), 3000);
        return prev;
      }
      return [...prev, style];
    });
  }

  function handleDominantFootChange(foot: string) {
    updateField('dominant_foot', foot);
    logTelemetry(userId, 'dominant_foot_selected', { value: foot });
  }

  function handleFreeAgentToggle(checked: boolean) {
    setIsFreeAgent(checked);
    if (checked) {
      updateField('current_club', null);
    }
    logTelemetry(userId, 'free_agent_toggled', { value: checked });
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="p-6 space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-20 rounded-xl animate-pulse" style={styles.card} />
          ))}
        </div>
      </div>
    );
  }

  if (showAchievementScreen) {
    try {
      return (
        <AchievementSubmissionScreen
          onBack={() => setShowAchievementScreen(false)}
          userId={userId}
          isDarkMode={tokens.surface === '#000000'}
        />
      );
    } catch (error) {
      console.error('Error rendering AchievementSubmissionScreen:', error);
      setShowAchievementScreen(false);
      setError('Erro ao carregar tela de conquistas');
    }
  }

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      {/* Header */}
      <div className="sticky top-0 z-20" style={styles.header}>
        <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: tokens.border }}>
          <button onClick={onBack} className="p-2 rounded-lg" disabled={saving}>
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>Editar Perfil</h1>
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 rounded-lg font-semibold transition-transform active:scale-95"
            style={saving ? { ...styles.card, opacity: 0.6 } : styles.accent}
          >
            {saving ? 'Salvando...' : 'Salvar'}
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b" style={{ borderColor: tokens.border }}>
          {[
            { id: 'basico', label: 'Básico' },
            { id: 'fisico', label: 'Físico' },
            { id: 'jogo', label: 'Jogo' },
            { id: 'sobre', label: 'Sobre' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id as TabType)}
              className="flex-1 py-4 text-sm font-semibold relative transition-all"
              style={activeTab === tab.id ? styles.accentText : styles.textSecondary}
            >
              {tab.label}
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 transition-all duration-200" style={{ backgroundColor: tokens.accent }} />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      {error && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-2" style={styles.error}>
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {success && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-2" style={styles.success}>
          <Check className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">Perfil atualizado!</p>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* BÁSICO TAB */}
        {activeTab === 'basico' && (
          <>
            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>Foto do Perfil</label>
              <div className="flex items-center gap-4">
                <div className="w-24 h-24 rounded-full overflow-hidden border-4 flex items-center justify-center" style={{ borderColor: tokens.border }}>
                  {formData.avatar_url ? (
                    <img src={formData.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-10 h-10" style={styles.icon} />
                  )}
                </div>
                <button className="px-4 py-2 rounded-lg font-semibold border" style={{ ...styles.textPrimary, borderColor: tokens.accent }}>
                  Alterar foto
                </button>
              </div>
            </div>

            {/* LOCKED FIELDS FROM QUIZ */}
            <div className="p-4 rounded-xl border-2 border-dashed" style={{ borderColor: tokens.border, backgroundColor: `${tokens.border}10` }}>
              <div className="flex items-center gap-2 mb-3">
                <Lock className="w-4 h-4" style={styles.textSecondary} />
                <p className="text-sm font-medium" style={styles.textSecondary}>
                  Essas informações vêm do seu Quiz inicial
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold mb-1" style={styles.textSecondary}>Nome Completo</label>
                  <input
                    type="text"
                    value={formData.name || ''}
                    disabled
                    className="w-full px-4 py-3 rounded-xl border outline-none"
                    style={styles.inputDisabled}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1" style={styles.textSecondary}>Data de Nascimento</label>
                    <input
                      type="text"
                      value={formatDateInput(formData.birth_date || '')}
                      disabled
                      className="w-full px-4 py-3 rounded-xl border outline-none"
                      style={styles.inputDisabled}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1" style={styles.textSecondary}>Gênero</label>
                    <input
                      type="text"
                      value={GENDER_OPTIONS.find(g => g.value === formData.gender)?.label || ''}
                      disabled
                      className="w-full px-4 py-3 rounded-xl border outline-none"
                      style={styles.inputDisabled}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1" style={styles.textSecondary}>Altura (cm)</label>
                    <input
                      type="text"
                      value={formData.height_cm || ''}
                      disabled
                      className="w-full px-4 py-3 rounded-xl border outline-none"
                      style={styles.inputDisabled}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1" style={styles.textSecondary}>Peso (kg)</label>
                    <input
                      type="text"
                      value={formData.weight_kg || ''}
                      disabled
                      className="w-full px-4 py-3 rounded-xl border outline-none"
                      style={styles.inputDisabled}
                    />
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* FÍSICO TAB */}
        {activeTab === 'fisico' && (
          <>
            <div className="p-4 rounded-xl" style={styles.card}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold" style={styles.textSecondary}>Altura (cm)</span>
                <span className="text-2xl font-bold" style={styles.textPrimary}>
                  {formData.height_cm || '--'}
                </span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold" style={styles.textSecondary}>Peso (kg)</span>
                <span className="text-2xl font-bold" style={styles.textPrimary}>
                  {formData.weight_kg || '--'}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: tokens.border }}>
                <span className="text-sm font-semibold" style={styles.textSecondary}>IMC</span>
                <span className="text-2xl font-bold" style={styles.textPrimary}>
                  {calculateBMI(formData.height_cm, formData.weight_kg)}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl" style={{ backgroundColor: `${tokens.success}10`, borderWidth: '1px', borderStyle: 'solid', borderColor: tokens.success }}>
              <p className="text-sm" style={{ color: tokens.success }}>
                Dados físicos do Quiz. Sem campos adicionais nesta versão.
              </p>
            </div>
          </>
        )}

        {/* JOGO TAB */}
        {activeTab === 'jogo' && (
          <>
            <div>
              <button
                onClick={() => setShowAchievementScreen(true)}
                className="w-full p-6 rounded-2xl flex items-center justify-between transition-all active:scale-95 mb-6"
                style={{
                  ...styles.card,
                  borderWidth: '2px',
                  borderStyle: 'dashed',
                  borderColor: tokens.accent
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${tokens.accent}20` }}>
                    <Trophy className="w-6 h-6" style={{ color: tokens.accent }} />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg" style={styles.textPrimary}>
                      Adicionar Conquista
                    </h3>
                    <p className="text-sm" style={styles.textSecondary}>
                      Títulos, gols, clubes e momentos
                    </p>
                  </div>
                </div>
                <Plus className="w-6 h-6" style={{ color: tokens.accent }} />
              </button>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>
                Posições (escolha até 2)
              </label>
              <div className="grid grid-cols-3 gap-3">
                {PLAYER_POSITIONS.map(pos => {
                  const isSelected = selectedPositions.includes(pos.value);
                  return (
                    <button
                      key={pos.value}
                      onClick={() => togglePosition(pos.value)}
                      className="px-4 py-3 rounded-lg text-sm font-bold transition-all duration-200 active:scale-95"
                      style={{
                        ...(isSelected ? styles.chipSelected : { ...styles.chipDefault, borderWidth: '1px', borderStyle: 'solid' }),
                        transform: isSelected ? 'scale(1)' : 'scale(1)'
                      }}
                    >
                      {pos.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>Pé Dominante</label>
              <div className="grid grid-cols-3 gap-3">
                {DOMINANT_FOOT_OPTIONS.map(foot => {
                  const isSelected = formData.dominant_foot === foot.value;
                  return (
                    <button
                      key={foot.value}
                      onClick={() => handleDominantFootChange(foot.value)}
                      className="px-4 py-3 rounded-lg text-sm font-semibold transition-all duration-200 active:scale-95"
                      style={{
                        ...(isSelected ? styles.chipSelected : { ...styles.chipDefault, borderWidth: '1px', borderStyle: 'solid' })
                      }}
                    >
                      {foot.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 mb-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isFreeAgent}
                  onChange={(e) => handleFreeAgentToggle(e.target.checked)}
                  className="w-5 h-5 rounded"
                  style={{ accentColor: tokens.accent }}
                />
                <span className="text-sm font-semibold" style={styles.textPrimary}>
                  Livre no mercado
                </span>
              </label>

              {!isFreeAgent && (
                <input
                  type="text"
                  value={formData.current_club || ''}
                  onChange={(e) => updateField('current_club', e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border outline-none transition-all"
                  style={styles.input}
                  placeholder="Nome do clube"
                />
              )}

              {isFreeAgent && (
                <div className="p-4 rounded-xl" style={{ backgroundColor: `${tokens.accent}10`, borderWidth: '1px', borderStyle: 'solid', borderColor: tokens.accent }}>
                  <p className="text-sm" style={styles.accentText}>
                    Perfil marcado como disponível no mercado
                  </p>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2" style={styles.textPrimary}>
                Número da Camisa <span style={styles.textSecondary}>- opcional</span>
              </label>
              <input
                type="number"
                value={formData.shirt_number || ''}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  if (e.target.value === '' || (!isNaN(val) && val >= 1 && val <= 99)) {
                    updateField('shirt_number', val || null);
                  }
                }}
                className="w-full px-4 py-3 rounded-xl border outline-none"
                style={styles.input}
                placeholder="10"
                min={1}
                max={99}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>
                Estilo de Jogo (escolha até 5)
              </label>
              <div className="flex flex-wrap gap-2">
                {PLAY_STYLE_OPTIONS.map(style => {
                  const isSelected = selectedStyles.includes(style);
                  return (
                    <button
                      key={style}
                      onClick={() => toggleStyle(style)}
                      className="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 active:scale-95"
                      style={{
                        ...(isSelected ? styles.chipSelected : { ...styles.chipDefault, borderWidth: '1px', borderStyle: 'solid' })
                      }}
                    >
                      {style}
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* SOBRE TAB */}
        {activeTab === 'sobre' && (
          <>
            <div>
              <label className="block text-sm font-semibold mb-2" style={styles.textPrimary}>
                Bio (160-240 caracteres)
              </label>
              <textarea
                value={formData.bio || ''}
                onChange={(e) => {
                  if (e.target.value.length <= 240) updateField('bio', e.target.value);
                }}
                className="w-full px-4 py-3 rounded-xl border outline-none resize-none"
                style={styles.input}
                placeholder="Conte um pouco sobre você..."
                rows={4}
                maxLength={240}
              />
              <p className="text-xs mt-1 text-right" style={styles.textSecondary}>
                {(formData.bio || '').length}/240 caracteres
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>
                Redes Sociais <span style={styles.textSecondary}>- opcional</span>
              </label>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Instagram className="w-5 h-5 flex-shrink-0" style={styles.icon} />
                  <input
                    type="url"
                    value={formData.instagram_url || ''}
                    onChange={(e) => updateField('instagram_url', e.target.value)}
                    className="flex-1 px-4 py-3 rounded-xl border outline-none"
                    style={styles.input}
                    placeholder="https://instagram.com/seu_perfil"
                  />
                </div>
                <div className="flex items-center gap-3">
                  <Youtube className="w-5 h-5 flex-shrink-0" style={styles.icon} />
                  <input
                    type="url"
                    value={formData.youtube_url || ''}
                    onChange={(e) => updateField('youtube_url', e.target.value)}
                    className="flex-1 px-4 py-3 rounded-xl border outline-none"
                    style={styles.input}
                    placeholder="https://youtube.com/@seu_canal"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={styles.textPrimary}>
                Contato Comercial <span style={styles.textSecondary}>- opcional</span>
              </label>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 flex-shrink-0" style={styles.icon} />
                  <input
                    type="email"
                    value={formData.commercial_email || ''}
                    onChange={(e) => updateField('commercial_email', e.target.value)}
                    className="flex-1 px-4 py-3 rounded-xl border outline-none"
                    style={styles.input}
                    placeholder="contato@email.com"
                  />
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 flex-shrink-0" style={styles.icon} />
                  <input
                    type="tel"
                    value={formData.commercial_phone || ''}
                    onChange={(e) => updateField('commercial_phone', e.target.value)}
                    className="flex-1 px-4 py-3 rounded-xl border outline-none"
                    style={styles.input}
                    placeholder="+55 11 99999-9999"
                  />
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.hide_contact_public || false}
                    onChange={(e) => updateField('hide_contact_public', e.target.checked)}
                    className="w-5 h-5 rounded"
                    style={{ accentColor: tokens.accent }}
                  />
                  <span className="text-sm" style={styles.textSecondary}>Ocultar contato do público</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3 flex items-center gap-2" style={styles.textPrimary}>
                <Shield className="w-5 h-5" />
                Configurações de Privacidade
              </label>
              <div className="space-y-3">
                <label className="flex items-center justify-between p-4 rounded-xl cursor-pointer" style={styles.card}>
                  <span className="text-sm" style={styles.textPrimary}>Mostrar idade pública</span>
                  <input
                    type="checkbox"
                    checked={formData.show_age_public ?? true}
                    onChange={(e) => updateField('show_age_public', e.target.checked)}
                    className="w-5 h-5 rounded"
                    style={{ accentColor: tokens.accent }}
                  />
                </label>
                <label className="flex items-center justify-between p-4 rounded-xl cursor-pointer" style={styles.card}>
                  <span className="text-sm" style={styles.textPrimary}>Mostrar cidade/UF pública</span>
                  <input
                    type="checkbox"
                    checked={formData.show_city_public ?? true}
                    onChange={(e) => updateField('show_city_public', e.target.checked)}
                    className="w-5 h-5 rounded"
                    style={{ accentColor: tokens.accent }}
                  />
                </label>
                <label className="flex items-center justify-between p-4 rounded-xl cursor-pointer" style={styles.card}>
                  <span className="text-sm" style={styles.textPrimary}>Permitir mensagens de clubes</span>
                  <input
                    type="checkbox"
                    checked={formData.allow_club_messages ?? true}
                    onChange={(e) => updateField('allow_club_messages', e.target.checked)}
                    className="w-5 h-5 rounded"
                    style={{ accentColor: tokens.accent }}
                  />
                </label>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Bottom Save Button */}
      <div className="sticky bottom-0 p-4 border-t" style={{ ...styles.header, borderColor: tokens.border }}>
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full py-4 rounded-xl font-bold text-lg transition-transform active:scale-95"
          style={saving ? { ...styles.card, opacity: 0.6 } : styles.accent}
        >
          {saving ? 'Salvando...' : 'Salvar Alterações'}
        </button>
      </div>
    </div>
  );
}
