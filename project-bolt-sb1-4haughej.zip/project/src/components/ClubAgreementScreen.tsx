import React, { useState } from 'react';
import { ChevronLeft, Check } from 'lucide-react';

interface ClubAgreementScreenProps {
  onNext: () => void;
  onBack: () => void;
}

export default function ClubAgreementScreen({ onNext, onBack }: ClubAgreementScreenProps) {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Quase terminando!
          </h1>
          <p className="text-gray-600 text-xl">
            Confirme que você é o responsável autorizado
          </p>
        </div>

        {/* Agreement Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Declaração de Responsabilidade
          </h2>
          <p className="text-gray-700 leading-relaxed mb-6">
            Ao marcar esta opção, declaro que sou o responsável autorizado pelo clube/escolinha 
            mencionado e tenho permissão para cadastrá-lo na plataforma Vitrine Pro. 
            Assumo total responsabilidade pelas informações fornecidas e pelo uso da conta.
          </p>
          
          <button
            onClick={() => setAgreed(!agreed)}
            className="flex items-center space-x-3 w-full p-4 rounded-xl border-2 border-gray-200 hover:border-orange-300 transition-all duration-200"
          >
            <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all duration-200 ${
              agreed 
                ? 'bg-orange-500 border-orange-500' 
                : 'border-gray-300 hover:border-orange-400'
            }`}>
              {agreed && <Check className="w-4 h-4 text-white" />}
            </div>
            <span className="text-gray-900 font-medium text-left flex-1">
              Concordo que sou o responsável autorizado pelo clube
            </span>
          </button>
        </div>

        {/* Terms */}
        <div className="text-center text-sm text-gray-500 mb-8">
          <p>
            Ao continuar, você concorda com nossos{' '}
            <button className="text-orange-500 hover:text-orange-600 font-medium">
              Termos de Uso
            </button>
            {' '}e{' '}
            <button className="text-orange-500 hover:text-orange-600 font-medium">
              Política de Privacidade
            </button>
          </p>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!agreed}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            agreed
              ? 'bg-orange-500 text-white hover:bg-orange-600 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Finalizar Cadastro
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}