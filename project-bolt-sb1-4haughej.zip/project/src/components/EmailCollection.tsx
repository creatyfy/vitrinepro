import React, { useState } from 'react';
import { ChevronLeft, Eye, EyeOff, AlertTriangle } from 'lucide-react';

interface EmailCollectionProps {
  email: string;
  password: string;
  confirmPassword: string;
  onEmailChange: (email: string) => void;
  onPasswordChange: (password: string) => void;
  onConfirmPasswordChange: (confirmPassword: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function EmailCollection({ 
  email, 
  password = '',
  confirmPassword = '',
  onEmailChange, 
  onPasswordChange = () => {},
  onConfirmPasswordChange = () => {},
  onNext, 
  onBack 
}: EmailCollectionProps) {
  const [inputValue, setInputValue] = useState(email);
  const [passwordValue, setPasswordValue] = useState(password);
  const [confirmPasswordValue, setConfirmPasswordValue] = useState(confirmPassword);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    onEmailChange(value);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPasswordValue(value);
    onPasswordChange(value);
  };

  const handleConfirmPasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setConfirmPasswordValue(value);
    onConfirmPasswordChange(value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && passwordValue.trim() && confirmPasswordValue.trim() && isValidEmail(inputValue) && passwordValue === confirmPasswordValue && passwordValue.length >= 6) {
      onNext();
    }
  };

  const isValidEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const isWeakPassword = (password: string) => {
    if (!password || typeof password !== 'string') {
      return true; // Consider undefined/null/non-string as weak
    }
    const hasLowerCase = /[a-z]/.test(password);
    const hasUpperCase = /[A-Z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSymbol = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return (password || '').length >= 6 && (!hasLowerCase || !hasUpperCase || !hasNumber || !hasSymbol);
  };

  const isFormValid = () => {
    return inputValue.trim() && 
           passwordValue.trim() && 
           confirmPasswordValue.trim() && 
           isValidEmail(inputValue) && 
           passwordValue.length >= 6 && 
           passwordValue === confirmPasswordValue;
  };

  const passwordsMatch = passwordValue === confirmPasswordValue;
  const showPasswordError = confirmPasswordValue.length > 0 && !passwordsMatch;
  const showWeakPasswordWarning = passwordValue.length >= 6 && isWeakPassword(passwordValue);
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Crie sua conta
          </h1>
          <p className="text-gray-600 text-xl">
            Digite seu email e crie uma senha segura
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-lg font-semibold text-gray-900 mb-4">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Digite seu email"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
              autoFocus
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-lg font-semibold text-gray-900 mb-4">
              Senha
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                value={passwordValue}
                onChange={handlePasswordChange}
                placeholder="Digite sua senha (mín. 6 caracteres)"
                className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200 pr-14"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? (
                  <EyeOff className="w-6 h-6" />
                ) : (
                  <Eye className="w-6 h-6" />
                )}
              </button>
            </div>
            
            {showWeakPasswordWarning && (
              <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-xl mb-2">
                <p className="text-blue-800 text-sm">
                  <strong>Sua senha deve conter:</strong>
                </p>
                <ul className="text-blue-700 text-sm mt-1 space-y-1">
                  <li>• Letras maiúsculas e minúsculas</li>
                  <li>• Pelo menos um número</li>
                  <li>• Pelo menos um símbolo (!@#$%^&*)</li>
                  <li>• Mínimo de 6 caracteres</li>
                </ul>
              </div>
            )}
            
            {showWeakPasswordWarning && (
              <div className="flex items-center mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-xl">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2 flex-shrink-0" />
                <p className="text-yellow-800 text-sm">
                  <strong>Senha fraca!</strong> Sua senha deve ter letras maiúsculas, minúsculas, números e símbolos.
                </p>
              </div>
            )}
          </div>

          <div>
            <label htmlFor="confirmPassword" className="block text-lg font-semibold text-gray-900 mb-4">
              Repetir Senha
            </label>
            <div className="relative">
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                id="confirmPassword"
                value={confirmPasswordValue}
                onChange={handleConfirmPasswordChange}
                placeholder="Digite sua senha novamente"
                className={`w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:bg-white transition-all duration-200 pr-14 ${
                  showPasswordError ? 'focus:ring-red-500 ring-2 ring-red-500' : 'focus:ring-orange-500'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showConfirmPassword ? (
                  <EyeOff className="w-6 h-6" />
                ) : (
                  <Eye className="w-6 h-6" />
                )}
              </button>
            </div>
            {showPasswordError && (
              <p className="text-red-500 text-sm mt-2">As senhas não coincidem</p>
            )}
          </div>
        </form>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={handleSubmit}
          disabled={!isFormValid()}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            isFormValid()
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}