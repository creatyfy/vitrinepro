import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, Trophy, Lock } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import { logTelemetry } from '../utils/videoUtils';
import { MEDALS, MEDAL_CATEGORIES, Medal as MedalData } from '../data/medalsData';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface UserMedal {
  id: string;
  medal_id: string;
  progress: number;
  is_unlocked: boolean;
  unlocked_at: string;
}

interface MedalWithProgress extends MedalData {
  progress: number;
  is_unlocked: boolean;
  unlocked_at?: string;
}

interface MedalsDetailScreenProps {
  userId: string;
  onBack: () => void;
}

export default function MedalsDetailScreen({ userId, onBack }: MedalsDetailScreenProps) {
  const { tokens, themeVersion } = useTheme();
  const [medals, setMedals] = useState<MedalWithProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMedal, setSelectedMedal] = useState<MedalWithProgress | null>(null);

  const styles = useMemo(() => ({
    container: {
      backgroundColor: tokens.surface
    },
    header: {
      backgroundColor: tokens.surface,
      borderColor: tokens.border
    },
    card: {
      backgroundColor: tokens.surfaceAlt,
      borderColor: tokens.border
    },
    textPrimary: {
      color: tokens.textPrimary
    },
    textSecondary: {
      color: tokens.textSecondary
    },
    icon: {
      color: tokens.icon
    },
    accent: {
      backgroundColor: tokens.accent,
      color: tokens.textInverse
    },
    accentText: {
      color: tokens.accent
    }
  }), [themeVersion, tokens]);

  useEffect(() => {
    loadMedals();
    logTelemetry(userId, 'medals_detail_opened');
  }, [userId]);

  async function loadMedals() {
    try {
      setLoading(true);
      const { data: userMedals } = await supabase
        .from('user_medals')
        .select('*')
        .eq('user_id', userId);

      const medalsWithProgress: MedalWithProgress[] = MEDALS.map(medal => {
        const userMedal = userMedals?.find(um => um.medal_id === medal.id);
        return {
          ...medal,
          progress: userMedal?.progress || 0,
          is_unlocked: userMedal?.is_unlocked || false,
          unlocked_at: userMedal?.unlocked_at
        };
      });

      medalsWithProgress.sort((a, b) => {
        if (a.is_unlocked !== b.is_unlocked) return a.is_unlocked ? -1 : 1;
        return a.order - b.order;
      });

      setMedals(medalsWithProgress);
    } catch (err) {
      console.error('Error loading medals:', err);
    } finally {
      setLoading(false);
    }
  }

  const unlockedCount = medals.filter(m => m.is_unlocked).length;
  const totalCount = 80; // Total fixo de medalhas do sistema

  const filteredMedals = selectedCategory === 'all'
    ? medals
    : medals.filter(m => m.category === selectedCategory);

  const getRarityColor = (rarity: string) => {
    switch(rarity) {
      case 'lendario': return '#FFD700';
      case 'epico': return '#9945FF';
      case 'raro': return '#1E90FF';
      default: return tokens.textSecondary;
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center justify-between p-4 border-b" style={styles.header}>
        <button onClick={onBack} className="p-2 rounded-lg">
          <ChevronLeft className="w-6 h-6" style={styles.icon} />
        </button>
        <h1 className="text-xl font-bold" style={styles.textPrimary}>
          Medalhas & Conquistas
        </h1>
        <div className="w-10" />
      </div>

      {/* Summary */}
      <div className="p-6">
        <div className="rounded-2xl p-6 border text-center" style={styles.card}>
          <div className="flex items-center justify-center gap-2 mb-2">
            <Trophy className="w-8 h-8" style={styles.accentText} />
            <span className="text-4xl font-bold" style={styles.textPrimary}>
              {unlockedCount}
            </span>
            <span className="text-2xl" style={styles.textSecondary}>
              / {totalCount}
            </span>
          </div>
          <p className="text-sm" style={styles.textSecondary}>
            de 80 medalhas conquistadas
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="px-6 pb-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setSelectedCategory('all')}
            className="px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors"
            style={{
              backgroundColor: selectedCategory === 'all' ? tokens.accent : tokens.surfaceAlt,
              color: selectedCategory === 'all' ? tokens.textInverse : tokens.textSecondary
            }}
          >
            Todas ({totalCount})
          </button>
          {MEDAL_CATEGORIES.map(cat => {
            const count = medals.filter(m => m.category === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className="px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors"
                style={{
                  backgroundColor: selectedCategory === cat.id ? tokens.accent : tokens.surfaceAlt,
                  color: selectedCategory === cat.id ? tokens.textInverse : tokens.textSecondary
                }}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Medals Grid */}
      <div className="flex-1 px-6 pb-8">
        <div className="space-y-4">
          {loading ? (
            [1, 2, 3, 4, 5].map(i => (
              <div key={i} className="h-24 rounded-2xl animate-pulse" style={styles.card} />
            ))
          ) : (
            filteredMedals.map((medal) => (
              <button
                key={medal.id}
                onClick={() => setSelectedMedal(medal)}
                className="w-full rounded-2xl p-6 border text-left transition-transform active:scale-[0.98]"
                style={{
                  ...styles.card,
                  opacity: medal.is_unlocked ? 1 : 0.6
                }}
              >
                <div className="flex items-start gap-4">
                  {/* Medal Icon */}
                  <div className="flex-shrink-0 w-20 h-20 flex items-center justify-center">
                    <img
                      src={medal.icon}
                      alt={medal.name}
                      className="w-full h-full object-contain"
                      style={{
                        filter: medal.is_unlocked ? 'none' : 'grayscale(100%) opacity(0.3)'
                      }}
                    />
                  </div>

                  {/* Medal Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className="text-xs font-bold px-2 py-1 rounded"
                            style={{
                              backgroundColor: tokens.border,
                              color: tokens.textSecondary
                            }}
                          >
                            #{medal.order}
                          </span>
                          <h3 className="text-lg font-bold" style={styles.textPrimary}>
                            {medal.name}
                          </h3>
                        </div>
                        <span
                          className="text-xs font-bold uppercase ml-12"
                          style={{ color: getRarityColor(medal.rarity) }}
                        >
                          {medal.rarity}
                        </span>
                      </div>
                      {medal.is_unlocked ? (
                        <div className="text-center">
                          <Trophy className="w-5 h-5 mx-auto" style={styles.accentText} />
                          <span className="text-xs font-bold" style={styles.accentText}>
                            +{medal.points}
                          </span>
                        </div>
                      ) : (
                        <Lock className="w-5 h-5" style={styles.icon} />
                      )}
                    </div>

                    <p className="text-sm mb-3" style={styles.textSecondary}>
                      {medal.description}
                    </p>

                    {/* Progress */}
                    {!medal.is_unlocked && medal.requirement.type !== 'special' && (
                      <div>
                        <div className="flex justify-between text-xs mb-2" style={styles.textSecondary}>
                          <span>Progresso</span>
                          <span>{medal.progress} / {medal.requirement.target}</span>
                        </div>
                        <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: tokens.border }}>
                          <div
                            className="h-full transition-all duration-300"
                            style={{
                              width: `${Math.min((medal.progress / medal.requirement.target) * 100, 100)}%`,
                              backgroundColor: tokens.accent
                            }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Earned Date */}
                    {medal.is_unlocked && medal.unlocked_at && (
                      <p className="text-xs" style={styles.accentText}>
                        Conquistada em {new Date(medal.unlocked_at).toLocaleDateString('pt-BR')}
                      </p>
                    )}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Medal Detail Modal */}
      {selectedMedal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
          onClick={() => setSelectedMedal(null)}
        >
          <div
            className="w-full max-w-md rounded-3xl p-8 border"
            style={styles.card}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Medal Icon Large */}
            <div className="flex justify-center mb-6">
              <div className="w-32 h-32 flex items-center justify-center">
                <img
                  src={selectedMedal.icon}
                  alt={selectedMedal.name}
                  className="w-full h-full object-contain"
                  style={{
                    filter: selectedMedal.is_unlocked ? 'none' : 'grayscale(100%) opacity(0.5)'
                  }}
                />
              </div>
            </div>

            {/* Medal Info */}
            <div className="text-center mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span
                  className="text-xs font-bold px-3 py-1 rounded-full"
                  style={{
                    backgroundColor: tokens.border,
                    color: tokens.textSecondary
                  }}
                >
                  #{selectedMedal.order}
                </span>
                <span
                  className="text-xs font-bold uppercase px-3 py-1 rounded-full"
                  style={{
                    backgroundColor: getRarityColor(selectedMedal.rarity) + '20',
                    color: getRarityColor(selectedMedal.rarity)
                  }}
                >
                  {selectedMedal.rarity}
                </span>
              </div>

              <h2 className="text-2xl font-bold mb-3" style={styles.textPrimary}>
                {selectedMedal.name}
              </h2>

              <p className="text-base mb-4" style={styles.textSecondary}>
                {selectedMedal.description}
              </p>

              {/* Status */}
              {selectedMedal.is_unlocked ? (
                <div className="rounded-xl p-4 mb-4" style={{ backgroundColor: tokens.accent + '20' }}>
                  <Trophy className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
                  <p className="font-bold" style={styles.accentText}>
                    Conquistada!
                  </p>
                  {selectedMedal.unlocked_at && (
                    <p className="text-sm mt-1" style={styles.textSecondary}>
                      {new Date(selectedMedal.unlocked_at).toLocaleDateString('pt-BR', {
                        day: '2-digit',
                        month: 'long',
                        year: 'numeric'
                      })}
                    </p>
                  )}
                  <p className="text-lg font-bold mt-2" style={styles.accentText}>
                    +{selectedMedal.points} pontos
                  </p>
                </div>
              ) : (
                <div className="rounded-xl p-4 mb-4" style={{ backgroundColor: tokens.border + '40' }}>
                  <Lock className="w-6 h-6 mx-auto mb-2" style={styles.icon} />
                  <p className="font-bold mb-2" style={styles.textSecondary}>
                    Ainda não conquistada
                  </p>
                  {selectedMedal.requirement.type !== 'special' && (
                    <>
                      <p className="text-sm mb-3" style={styles.textSecondary}>
                        Progresso: {selectedMedal.progress} / {selectedMedal.requirement.target}
                      </p>
                      <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: tokens.border }}>
                        <div
                          className="h-full transition-all duration-300"
                          style={{
                            width: `${Math.min((selectedMedal.progress / selectedMedal.requirement.target) * 100, 100)}%`,
                            backgroundColor: tokens.accent
                          }}
                        />
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Close Button */}
            <button
              onClick={() => setSelectedMedal(null)}
              className="w-full py-4 rounded-xl font-bold transition-opacity active:opacity-70"
              style={styles.accent}
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
