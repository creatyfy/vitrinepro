import React from 'react';
import { ChevronLeft, Check, Heart, Target, User, Utensils } from 'lucide-react';

interface CongratulationsScreenProps {
  onNext: () => void;
  onBack: () => void;
}

export default function CongratulationsScreen({ onNext, onBack }: CongratulationsScreenProps) {
  const tips = [
    {
      id: 1,
      icon: Target,
      title: 'Treine todos os dias, constância é o segredo',
      description: 'Mantenha uma rotina de treinos regular'
    },
    {
      id: 2,
      icon: Heart,
      title: 'Publique seus treinos, sua pontuação irá subir',
      description: 'Compartilhe seu progresso e ganhe visibilidade'
    },
    {
      id: 3,
      icon: User,
      title: 'Sempre atualize seu perfil, os clubes estão de olho...',
      description: 'Mantenha suas informações sempre atualizadas'
    },
    {
      id: 4,
      icon: Utensils,
      title: 'Siga as recomendações alimentares se quiser jogar bem',
      description: 'Nutrição adequada é fundamental para performance'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        {/* Success Icon and Title */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-black rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Parabéns!
          </h1>
          <p className="text-gray-600 text-xl">
            Sua jornada rumo ao pro começa aqui
          </p>
        </div>

        {/* Health Score Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mr-4">
                <Heart className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Health Score</h3>
              </div>
            </div>
            <span className="text-2xl font-bold text-gray-900">10/10</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div className="bg-green-500 h-3 rounded-full" style={{ width: '100%' }}></div>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Como alcançar seus objetivos
          </h2>
          
          <div className="space-y-4">
            {tips.map((tip) => {
              const IconComponent = tip.icon;
              return (
                <div key={tip.id} className="bg-white rounded-2xl p-6 shadow-sm border">
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                      <IconComponent className="w-6 h-6 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {tip.title}
                      </h3>
                      <p className="text-gray-600">
                        {tip.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
        >
          Começar minha jornada
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}