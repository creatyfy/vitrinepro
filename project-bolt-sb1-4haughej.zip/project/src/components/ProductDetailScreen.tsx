import React, { useState } from 'react';
import { ChevronLeft, Heart, Search, Star, Share2, ChevronDown, ChevronUp, MapPin, Truck, Shield, Award, ShoppingCart } from 'lucide-react';

interface ProductDetailScreenProps {
  product: any;
  onBack: () => void;
  onAddToCart: (product: any, selectedSize?: string, selectedColor?: string) => void;
  onBuyNow: (product: any, selectedSize?: string, selectedColor?: string) => void;
  onToggleFavorite: (productId: number) => void;
  isFavorite: boolean;
}

export default function ProductDetailScreen({ 
  product, 
  onBack, 
  onAddToCart, 
  onBuyNow, 
  onToggleFavorite, 
  isFavorite 
}: ProductDetailScreenProps) {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [showSizeGuide, setShowSizeGuide] = useState(false);
  const [showShippingInfo, setShowShippingInfo] = useState(false);
  const [showReviews, setShowReviews] = useState(false);
  const [cep, setCep] = useState('');

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, selectedColor);
  };

  const handleBuyNow = () => {
    onBuyNow(product, selectedSize, selectedColor);
  };

  const canPurchase = selectedSize && selectedColor;

  return (
    <div className="min-h-screen bg-white">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">18:10</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">4G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
        <h1 className="text-lg font-bold text-gray-900 flex-1 text-center line-clamp-1 px-4">
          {product.name}
        </h1>
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => onToggleFavorite(product.id)}
            className="p-2"
          >
            <Heart className={`w-6 h-6 ${isFavorite ? 'text-red-500 fill-current' : 'text-gray-600'}`} />
          </button>
          <Search className="w-6 h-6 text-gray-600" />
        </div>
      </div>

      <div className="px-6">
        {/* Product Images */}
        <div className="mb-8">
          <div className="relative h-80 bg-gray-50 rounded-lg overflow-hidden mb-4">
            <img 
              src={product.images[selectedImageIndex]} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.comingSoon && (
              <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                Em breve
              </div>
            )}
          </div>
          
          {/* Image Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex space-x-2">
              {product.images.map((image: string, index: number) => (
                <button
                  key={index}
                  onClick={() => setSelectedImageIndex(index)}
                  className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${
                    selectedImageIndex === index ? 'border-gray-900' : 'border-gray-200'
                  }`}
                >
                  <img 
                    src={image} 
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="mb-8">
          {product.comingSoon && (
            <div className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold inline-block mb-4">
              Em breve
            </div>
          )}
          <p className="text-gray-900 font-medium mb-2">{product.category}</p>
          <h1 className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
            {product.name}
          </h1>
          
          <div className="space-y-2 mb-6">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-gray-900">
                R$ {product.pixPrice.toFixed(2).replace('.', ',')} no Pix
              </span>
              {product.discount > 0 && (
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm font-bold">
                  {product.discount}% off
                </span>
              )}
            </div>
            {product.originalPrice > product.price && (
              <p className="text-gray-500 line-through">
                R$ {product.originalPrice.toFixed(2).replace('.', ',')} em até {product.installments}
              </p>
            )}
          </div>

          {/* Giftback */}
          {product.giftback && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <p className="text-green-800 font-medium">
                Ganhe <strong>{product.giftback}</strong> com o cupom{' '}
                <strong>PRIMEIRACOMPRA</strong>, na primeira compra feita no app
              </p>
            </div>
          )}
        </div>

        {/* Color Selection */}
        {product.colors && product.colors.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Cor: {selectedColor || product.colors[0]}</h3>
            <div className="flex space-x-3">
              {product.colors.map((color: string) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`px-4 py-2 rounded-lg border-2 transition-all ${
                    selectedColor === color || (!selectedColor && color === product.colors[0])
                      ? 'border-gray-900 bg-gray-900 text-white'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Size Selection */}
        {product.sizes && product.sizes.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold text-gray-900">
                Tamanho: {selectedSize || 'Selecione'}
              </h3>
              <button 
                onClick={() => setShowSizeGuide(!showSizeGuide)}
                className="text-gray-600 text-sm underline"
              >
                Guia de tamanhos
              </button>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {product.sizes.map((size: string) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-3 rounded-lg border-2 transition-all ${
                    selectedSize === size
                      ? 'border-gray-900 bg-gray-900 text-white'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Add to Cart Button */}
        <div className="mb-8">
          <button
            onClick={handleAddToCart}
            disabled={!canPurchase}
            className={`w-full py-4 rounded-full font-bold text-lg transition-all duration-200 ${
              canPurchase
                ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Adicionar ao carrinho
          </button>
        </div>

        {/* Product Description */}
        <div className="mb-8">
          <p className="text-gray-700 leading-relaxed mb-4">
            {product.description}
          </p>
          <button className="text-gray-900 font-medium underline">
            Ver mais
          </button>
          
          <div className="mt-6 space-y-2">
            <div className="flex items-center">
              <span className="text-gray-700">• <strong>Cor:</strong> {selectedColor || product.colors[0]}</span>
            </div>
            <div className="flex items-center">
              <span className="text-gray-700">• <strong>Estilo:</strong> {product.style}</span>
            </div>
          </div>

          <button className="flex items-center text-gray-900 font-medium mt-4">
            <Share2 className="w-5 h-5 mr-2" />
            Compartilhar
          </button>
        </div>

        {/* Shipping Calculator */}
        <div className="mb-8">
          <button 
            onClick={() => setShowShippingInfo(!showShippingInfo)}
            className="w-full flex items-center justify-between py-4 border-t border-gray-200"
          >
            <h3 className="text-lg font-semibold text-gray-900">Calcular frete de entrega</h3>
            {showShippingInfo ? (
              <ChevronUp className="w-5 h-5 text-gray-600" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-600" />
            )}
          </button>
          
          {showShippingInfo && (
            <div className="py-4 space-y-4">
              <p className="text-gray-600">
                Calcule o frete e o prazo de entrega estimados para sua região.
              </p>
              <div className="flex space-x-3">
                <input
                  type="text"
                  placeholder="Digite seu CEP"
                  value={cep}
                  onChange={(e) => setCep(e.target.value)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                />
                <button className="bg-gray-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800 transition-colors">
                  Calcular
                </button>
              </div>
              <button className="text-gray-600 text-sm underline">
                Não sei meu CEP
              </button>
              <button className="w-full border border-gray-300 text-gray-900 py-3 rounded-full font-medium hover:bg-gray-50 transition-colors">
                Usar minha localização
              </button>
            </div>
          )}
        </div>

        {/* Reviews Section */}
        <div className="mb-8">
          <button 
            onClick={() => setShowReviews(!showReviews)}
            className="w-full flex items-center justify-between py-4 border-t border-gray-200"
          >
            <h3 className="text-lg font-semibold text-gray-900">Avaliações ({product.reviews})</h3>
            {showReviews ? (
              <ChevronUp className="w-5 h-5 text-gray-600" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-600" />
            )}
          </button>
          
          {showReviews && (
            <div className="py-4">
              <div className="flex items-center mb-4">
                <div className="flex items-center mr-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star 
                      key={star} 
                      className={`w-5 h-5 ${star <= Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                    />
                  ))}
                </div>
                <span className="text-lg font-bold text-gray-900">{product.rating}</span>
                <span className="text-gray-600 ml-2">({product.reviews} avaliações)</span>
              </div>
              <p className="text-gray-600">
                Seja o primeiro a avaliar este produto e ajude outros compradores!
              </p>
            </div>
          )}
        </div>

        {/* You Might Also Like */}
        <div className="mb-8 border-t border-gray-200 pt-8">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Você também pode gostar</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <img 
                src="https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop" 
                alt="Produto relacionado"
                className="w-full h-32 object-cover rounded-lg"
              />
              <div>
                <h4 className="font-bold text-gray-900 text-sm line-clamp-2">
                  Chuteira Nike Street Gato Futsal
                </h4>
                <p className="text-gray-600 text-xs">Futebol</p>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-lg font-bold text-gray-900">
                    R$ 759,99 no Pix
                  </span>
                </div>
                <span className="text-green-600 text-xs font-medium">10% Giftback</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <img 
                src="https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop" 
                alt="Produto relacionado"
                className="w-full h-32 object-cover rounded-lg"
              />
              <div>
                <h4 className="font-bold text-gray-900 text-sm line-clamp-2">
                  Chuteira Nike Air Zoom Mercurial Superfly 10 Academy Campo
                </h4>
                <p className="text-gray-600 text-xs">Futebol</p>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-lg font-bold text-gray-900">
                    R$ 683,99 no Pix
                  </span>
                </div>
                <span className="text-green-600 text-xs font-medium">10% Giftback</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-6">
        <div className="flex space-x-3">
          <button
            onClick={handleAddToCart}
            disabled={!canPurchase}
            className={`flex-1 py-4 rounded-full font-bold text-lg transition-all duration-200 ${
              canPurchase
                ? 'bg-gray-200 text-gray-900 hover:bg-gray-300 active:scale-95'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            Adicionar ao Carrinho
          </button>
          <button
            onClick={handleBuyNow}
            disabled={!canPurchase}
            className={`flex-1 py-4 rounded-full font-bold text-lg transition-all duration-200 ${
              canPurchase
                ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Comprar
          </button>
        </div>
        
        {!canPurchase && (
          <p className="text-center text-gray-500 text-sm mt-3">
            Selecione tamanho e cor para continuar
          </p>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-20 left-0 right-0 bg-white border-t border-gray-200">
        <div className="flex justify-around py-3">
          <button className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-gray-400">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
              </svg>
            </div>
            <span className="text-xs text-gray-400">Destaques</span>
          </button>
          <button className="flex flex-col items-center">
            <Search className="w-6 h-6 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Coleções</span>
          </button>
          <button className="flex flex-col items-center">
            <Heart className="w-6 h-6 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Favoritos</span>
          </button>
          <button className="flex flex-col items-center">
            <ShoppingCart className="w-6 h-6 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Carrinho</span>
          </button>
          <button className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-gray-400">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
              </svg>
            </div>
            <span className="text-xs text-gray-400">Perfil</span>
          </button>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}