import React, { useState, useEffect } from 'react';
import { Calendar, Trophy, Zap, Clock, Target, Flame, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import UniversalTrainingExecutionScreen, { TrainingExercise } from './UniversalTrainingExecutionScreen';
import UniversalAntiCheatVerification from './UniversalAntiCheatVerification';
import TrainingPointsScreen from './TrainingPointsScreen';
import { trainingTopics } from '../data/trainingData';
import {
  checkDailyTrainingStatus,
  completeTraining,
  getRecentTrainingHistory,
  formatTimeUntilNext,
  getStreakMessage,
  type DailyTrainingStatus,
  type TrainingHistory
} from '../services/dailyTrainingService';

interface TreinoDoDiaScreenProps {
  onComplete: () => void;
  onBack: () => void;
  isDarkMode?: boolean;
}

interface DailyTraining {
  id: string;
  training_date: string;
  exercises: any[];
  total_exercises: number;
  intensity_level: 'low' | 'medium' | 'high';
  prep_time: number;
  rest_time: number;
  status: string;
  proof_gesture: string;
}

export default function TreinoDoDiaScreen({ onComplete, onBack, isDarkMode = false }: TreinoDoDiaScreenProps) {
  const [loading, setLoading] = useState(true);
  const [dailyTraining, setDailyTraining] = useState<DailyTraining | null>(null);
  const [exercises, setExercises] = useState<TrainingExercise[]>([]);
  const [hasStarted, setHasStarted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [trainingStatus, setTrainingStatus] = useState<DailyTrainingStatus | null>(null);
  const [history, setHistory] = useState<TrainingHistory[]>([]);
  const [timeUntilNext, setTimeUntilNext] = useState<number>(0);
  const [showVerification, setShowVerification] = useState(false);
  const [showPointsScreen, setShowPointsScreen] = useState(false);
  const [earnedPoints, setEarnedPoints] = useState(0);
  const [hasProof, setHasProof] = useState(false);

  useEffect(() => {
    loadOrGenerateDailyTraining();
  }, []);

  useEffect(() => {
    if (!trainingStatus) return;

    if (trainingStatus.timeUntilNext > 0) {
      setTimeUntilNext(trainingStatus.timeUntilNext);

      const interval = setInterval(() => {
        setTimeUntilNext((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [trainingStatus]);

  const loadOrGenerateDailyTraining = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();

      const today = new Date().toISOString().split('T')[0];

      if (!user) {
        const mockTraining = generateMockDailyTraining(today);
        setDailyTraining(mockTraining);
        const generatedExercises = generateExercisesFromData(mockTraining);
        setExercises(generatedExercises);
        setLoading(false);
        return;
      }

      let { data: existingTraining, error: fetchError } = await supabase
        .from('daily_trainings')
        .select('*')
        .eq('user_id', user.id)
        .eq('training_date', today)
        .neq('status', 'expired')
        .maybeSingle();

      if (fetchError) {
        console.error('Error fetching daily training:', fetchError);
        const mockTraining = generateMockDailyTraining(today);
        setDailyTraining(mockTraining);
        const generatedExercises = generateExercisesFromData(mockTraining);
        setExercises(generatedExercises);
        setLoading(false);
        return;
      }

      const status = await checkDailyTrainingStatus(user.id);
      setTrainingStatus(status);

      const trainingHistory = await getRecentTrainingHistory(user.id);
      setHistory(trainingHistory);

      if (existingTraining && existingTraining.status === 'completed') {
        setError('Você já completou o treino de hoje! Volte amanhã para um novo desafio.');
        setLoading(false);
        return;
      }

      if (!existingTraining) {
        existingTraining = await generateNewDailyTraining(user.id, today);
      }

      if (existingTraining) {
        setDailyTraining(existingTraining);
        const generatedExercises = generateExercisesFromData(existingTraining);
        setExercises(generatedExercises);
      }
    } catch (err) {
      console.error('Error in loadOrGenerateDailyTraining:', err);
      const today = new Date().toISOString().split('T')[0];
      const mockTraining = generateMockDailyTraining(today);
      setDailyTraining(mockTraining);
      const generatedExercises = generateExercisesFromData(mockTraining);
      setExercises(generatedExercises);
    } finally {
      setLoading(false);
    }
  };

  const generateMockDailyTraining = (date: string): DailyTraining => {
    const intensityLevels: Array<'low' | 'medium' | 'high'> = ['low', 'medium', 'high'];
    const randomIntensity = intensityLevels[Math.floor(Math.random() * intensityLevels.length)];

    const totalExercises = Math.floor(Math.random() * 11) + 10;

    const prepTimeByIntensity = { low: 15, medium: 10, high: 8 };
    const restTimeByIntensity = { low: 20, medium: 15, high: 10 };

    const allExercises: any[] = [];
    trainingTopics.forEach(topic => {
      Object.values(topic.trainings).forEach(envTrainings => {
        allExercises.push(...envTrainings.map(t => ({
          ...t,
          category: topic.name
        })));
      });
    });

    const shuffled = [...allExercises].sort(() => Math.random() - 0.5);
    const selectedExercises = shuffled.slice(0, totalExercises).map((ex, idx) => ({
      id: ex.id,
      name: ex.title,
      category: ex.category,
      videoUrl: ex.videoUrl,
      sets: 1,
      reps: ex.instructions?.repetitions || '10 repetições',
      index: idx
    }));

    const gestures = [
      'Mão no queixo',
      'Braço cruzado',
      'Polegar para cima',
      'Sinal de joia',
      'Mão na testa',
      'Punho fechado ao lado da cabeça',
      'Dois dedos em V',
      'Mão espalmada na câmera',
      'Apontando para cima',
      'Mão na cintura'
    ];
    const randomGesture = gestures[Math.floor(Math.random() * gestures.length)];

    return {
      id: 'mock-' + Date.now(),
      training_date: date,
      exercises: selectedExercises,
      total_exercises: totalExercises,
      intensity_level: randomIntensity,
      prep_time: prepTimeByIntensity[randomIntensity],
      rest_time: restTimeByIntensity[randomIntensity],
      status: 'generated',
      proof_gesture: randomGesture
    };
  };

  const generateNewDailyTraining = async (userId: string, date: string): Promise<DailyTraining | null> => {
    const intensityLevels: Array<'low' | 'medium' | 'high'> = ['low', 'medium', 'high'];
    const randomIntensity = intensityLevels[Math.floor(Math.random() * intensityLevels.length)];

    const totalExercises = Math.floor(Math.random() * 11) + 10;

    const prepTimeByIntensity = { low: 15, medium: 10, high: 8 };
    const restTimeByIntensity = { low: 20, medium: 15, high: 10 };

    const allExercises: any[] = [];
    trainingTopics.forEach(topic => {
      Object.values(topic.trainings).forEach(envTrainings => {
        allExercises.push(...envTrainings.map(t => ({
          ...t,
          category: topic.name
        })));
      });
    });

    const shuffled = [...allExercises].sort(() => Math.random() - 0.5);
    const selectedExercises = shuffled.slice(0, totalExercises).map((ex, idx) => ({
      id: ex.id,
      name: ex.title,
      category: ex.category,
      videoUrl: ex.videoUrl,
      sets: 1,
      reps: ex.instructions?.repetitions || '10 repetições',
      index: idx
    }));

    const gestures = [
      'Mão no queixo',
      'Braço cruzado',
      'Polegar para cima',
      'Sinal de joia',
      'Mão na testa',
      'Punho fechado ao lado da cabeça',
      'Dois dedos em V',
      'Mão espalmada na câmera',
      'Apontando para cima',
      'Mão na cintura'
    ];
    const randomGesture = gestures[Math.floor(Math.random() * gestures.length)];

    const { data, error } = await supabase
      .from('daily_trainings')
      .insert({
        user_id: userId,
        training_date: date,
        exercises: selectedExercises,
        total_exercises: totalExercises,
        intensity_level: randomIntensity,
        prep_time: prepTimeByIntensity[randomIntensity],
        rest_time: restTimeByIntensity[randomIntensity],
        status: 'generated',
        proof_gesture: randomGesture
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating daily training:', error);
      return null;
    }

    return data;
  };

  const generateExercisesFromData = (training: DailyTraining): TrainingExercise[] => {
    return training.exercises.map((ex: any) => ({
      id: ex.id,
      name: ex.name,
      videoUrl: ex.videoUrl,
      sets: ex.sets || 1,
      reps: ex.reps,
      duration: 60,
      restTime: training.rest_time
    }));
  };

  const handleStartTraining = async () => {
    if (!dailyTraining) return;

    if (!dailyTraining.id.startsWith('mock-')) {
      await supabase
        .from('daily_trainings')
        .update({ status: 'in_progress' })
        .eq('id', dailyTraining.id);
    }

    setHasStarted(true);
  };

  const handleTrainingComplete = async () => {
    if (!dailyTraining) return;

    setHasStarted(false);
    setShowVerification(true);
  };

  const handleVerificationComplete = async (points: number) => {
    const maxPoints = 100;
    setEarnedPoints(points);
    setHasProof(points === maxPoints);
    setShowVerification(false);

    if (dailyTraining && !dailyTraining.id.startsWith('mock-')) {
      await completeTraining(dailyTraining.id);

      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from('player_profiles')
          .select('total_points')
          .eq('user_id', user.id)
          .maybeSingle();

        if (profile) {
          await supabase
            .from('player_profiles')
            .update({ total_points: (profile.total_points || 0) + points })
            .eq('user_id', user.id);
        }
      }
    }

    setShowPointsScreen(true);
  };

  const handlePointsScreenComplete = () => {
    setShowPointsScreen(false);
    onComplete();
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'high': return 'bg-red-500';
      default: return 'bg-blue-500';
    }
  };

  const getIntensityLabel = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'Leve';
      case 'medium': return 'Moderada';
      case 'high': return 'Intensa';
      default: return 'Moderada';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: isDarkMode ? '#1a1a1a' : '#ffffff' }}>
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>Preparando seu treino do dia...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: isDarkMode ? '#1a1a1a' : '#ffffff' }}>
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-orange-500" />
          </div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>
            {error.includes('completou') ? 'Treino Concluído!' : 'Ops!'}
          </h2>
          <p className="mb-6" style={{ color: isDarkMode ? '#9ca3af' : '#6b7280' }}>
            {error}
          </p>

          {trainingStatus && trainingStatus.streak > 0 && (
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-6 mb-6 text-white">
              <div className="flex items-center justify-center gap-3 mb-2">
                <Flame className="w-8 h-8" />
                <div className="text-3xl font-bold">{trainingStatus.streak}</div>
              </div>
              <p className="text-sm opacity-90">{getStreakMessage(trainingStatus.streak)}</p>
            </div>
          )}

          {timeUntilNext > 0 && (
            <div className="bg-gray-100 rounded-2xl p-4 mb-6" style={{ backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6' }}>
              <p className="text-sm font-semibold mb-2" style={{ color: isDarkMode ? '#9ca3af' : '#6b7280' }}>
                Próximo treino disponível em:
              </p>
              <div className="text-2xl font-bold" style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>
                {formatTimeUntilNext(timeUntilNext)}
              </div>
            </div>
          )}

          {history.length > 0 && (
            <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm" style={{ backgroundColor: isDarkMode ? '#2a2a2a' : '#ffffff' }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>
                Últimos 7 dias
              </h3>
              <div className="flex gap-2 justify-center">
                {history.map((day, idx) => (
                  <div
                    key={idx}
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      day.status === 'completed' ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                    title={new Date(day.training_date).toLocaleDateString()}
                  >
                    {day.status === 'completed' ? (
                      <CheckCircle className="w-5 h-5 text-white" />
                    ) : (
                      <span className="text-xs text-gray-500">-</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={onBack}
            className="bg-orange-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-orange-600 transition-colors w-full"
          >
            Voltar ao Início
          </button>
        </div>
      </div>
    );
  }

  if (showPointsScreen) {
    return (
      <TrainingPointsScreen
        pointsEarned={earnedPoints}
        maxPoints={100}
        hasProof={hasProof}
        onComplete={handlePointsScreenComplete}
      />
    );
  }

  if (showVerification && dailyTraining) {
    return (
      <UniversalAntiCheatVerification
        sessionId={dailyTraining.id}
        isDarkMode={isDarkMode}
        onComplete={handleVerificationComplete}
      />
    );
  }

  if (hasStarted && exercises.length > 0 && dailyTraining) {
    return (
      <UniversalTrainingExecutionScreen
        trainingType="daily"
        trainingId={dailyTraining.id}
        exercises={exercises}
        currentExerciseIndex={0}
        onComplete={handleTrainingComplete}
        onExit={onBack}
        isDarkMode={isDarkMode}
      />
    );
  }

  if (!dailyTraining) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: isDarkMode ? '#1a1a1a' : '#ffffff' }}>
        <div className="text-center">
          <p style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>Erro ao carregar treino</p>
          <button
            onClick={onBack}
            className="mt-4 bg-orange-500 text-white px-6 py-2 rounded-full"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  const today = new Date();
  const formattedDate = `${today.getDate().toString().padStart(2, '0')}/${(today.getMonth() + 1).toString().padStart(2, '0')}`;

  return (
    <div className="min-h-screen" style={{ backgroundColor: isDarkMode ? '#1a1a1a' : '#f5f5f5' }}>
      <div className="pt-12 pb-24 px-6">
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-orange-500 font-semibold hover:text-orange-600 transition-colors"
        >
          ← Voltar
        </button>

        <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl p-8 mb-6 text-white shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Calendar className="w-8 h-8" />
              <div>
                <h1 className="text-3xl font-bold">Treino do Dia</h1>
                <p className="text-white text-opacity-90">{formattedDate}</p>
              </div>
            </div>
            {trainingStatus && trainingStatus.streak > 0 && (
              <div className="flex items-center gap-2 bg-white bg-opacity-20 px-4 py-2 rounded-full">
                <Flame className="w-5 h-5" />
                <span className="font-bold text-lg">{trainingStatus.streak}</span>
              </div>
            )}
          </div>

          <div className="bg-white bg-opacity-20 rounded-2xl p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                <span className="font-semibold">Intensidade:</span>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-bold ${getIntensityColor(dailyTraining.intensity_level)} text-white`}>
                {getIntensityLabel(dailyTraining.intensity_level)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                <span>{dailyTraining.total_exercises} exercícios</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>~{Math.ceil(dailyTraining.total_exercises * 1.5)} min</span>
              </div>
            </div>
          </div>
        </div>

        {trainingStatus && trainingStatus.streak > 0 && (
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-6 mb-6 text-white shadow-lg">
            <div className="flex items-center gap-3">
              <Flame className="w-8 h-8" />
              <div>
                <h3 className="font-bold text-lg">Sequência Ativa!</h3>
                <p className="text-sm opacity-90">{getStreakMessage(trainingStatus.streak)}</p>
              </div>
            </div>
          </div>
        )}

        {history.length > 0 && (
          <div className="bg-white rounded-2xl p-4 mb-6 shadow-lg" style={{ backgroundColor: isDarkMode ? '#2a2a2a' : '#ffffff' }}>
            <h3 className="text-sm font-bold mb-3" style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>
              Seus últimos 7 dias
            </h3>
            <div className="flex gap-2">
              {history.map((day, idx) => (
                <div key={idx} className="flex-1">
                  <div
                    className={`w-full h-12 rounded-lg flex items-center justify-center ${
                      day.status === 'completed' ? 'bg-green-500' : 'bg-gray-200'
                    }`}
                  >
                    {day.status === 'completed' ? (
                      <CheckCircle className="w-6 h-6 text-white" />
                    ) : (
                      <span className="text-xs text-gray-400">-</span>
                    )}
                  </div>
                  <p className="text-xs text-center mt-1" style={{ color: isDarkMode ? '#9ca3af' : '#6b7280' }}>
                    {new Date(day.training_date).getDate()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-3xl p-6 shadow-lg mb-6" style={{ backgroundColor: isDarkMode ? '#2a2a2a' : '#ffffff' }}>
          <h3 className="text-xl font-bold mb-4" style={{ color: isDarkMode ? '#ffffff' : '#000000' }}>
            Sobre o Treino
          </h3>
          <div className="space-y-3 text-sm" style={{ color: isDarkMode ? '#9ca3af' : '#6b7280' }}>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-orange-500 font-bold text-xs">1</span>
              </div>
              <p>Treino personalizado gerado automaticamente com exercícios de todas as categorias</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-orange-500 font-bold text-xs">2</span>
              </div>
              <p>Você pode fazer este treino apenas uma vez por dia</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-orange-500 font-bold text-xs">3</span>
              </div>
              <p>Ao concluir, será necessário enviar uma foto de comprovação</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-orange-500 font-bold text-xs">4</span>
              </div>
              <p>Volte amanhã para um novo treino exclusivo!</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg mb-6">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-6 h-6" />
            <h4 className="font-bold text-lg">Comprovação Necessária</h4>
          </div>
          <p className="text-white text-opacity-90 text-sm">
            Ao finalizar o treino, tire uma foto fazendo o gesto: <span className="font-bold">"{dailyTraining.proof_gesture}"</span>
          </p>
        </div>

        <button
          onClick={handleStartTraining}
          className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-5 rounded-2xl font-bold text-xl shadow-xl hover:shadow-2xl transition-all active:scale-95"
        >
          Começar Treino
        </button>
      </div>
    </div>
  );
}
