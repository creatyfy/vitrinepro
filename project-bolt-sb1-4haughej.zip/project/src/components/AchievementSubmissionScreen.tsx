import React, { useState, useEffect } from 'react';
import { ChevronLeft, Trophy, Target, Award, Shield, Star, Upload, X, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AchievementSubmissionScreenProps {
  onBack: () => void;
  userId: string;
  isDarkMode: boolean;
}

type AchievementType = {
  id: string;
  code: string;
  label: string;
  default_points: number;
  icon: string;
};

export default function AchievementSubmissionScreen({ onBack, userId, isDarkMode }: AchievementSubmissionScreenProps) {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [achievementTypes, setAchievementTypes] = useState<AchievementType[]>([]);
  const [selectedType, setSelectedType] = useState<AchievementType | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    loadAchievementTypes();
  }, []);

  const loadAchievementTypes = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('achievement_types')
        .select('*')
        .order('default_points', { ascending: false });

      if (error) {
        console.error('Error loading types:', error);
        setLoadError('Erro ao carregar tipos de conquista');
        return;
      }

      if (data && data.length > 0) {
        setAchievementTypes(data);
        setLoadError('');
      } else {
        setLoadError('Nenhum tipo de conquista encontrado');
      }
    } catch (error: any) {
      console.error('Error:', error);
      setLoadError('Erro ao carregar dados');
    } finally {
      setIsLoading(false);
    }
  };

  const getIconComponent = (iconName: string) => {
    const icons: Record<string, any> = {
      trophy: Trophy,
      target: Target,
      award: Award,
      shield: Shield,
      star: Star
    };
    return icons[iconName] || Star;
  };

  const handleTypeSelect = (type: AchievementType) => {
    setSelectedType(type);
    setStep(2);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;

    const newFiles = Array.from(e.target.files);
    const validFiles = newFiles.filter(file => {
      const isValidType = ['image/jpeg', 'image/png', 'image/jpg', 'video/mp4'].includes(file.type);
      const isValidSize = file.size <= 20 * 1024 * 1024;
      return isValidType && isValidSize;
    });

    if (mediaFiles.length + validFiles.length > 5) {
      alert('Máximo de 5 arquivos por submissão');
      return;
    }

    setMediaFiles([...mediaFiles, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setMediaFiles(mediaFiles.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!agreedToTerms || !selectedType) {
      alert('Você precisa concordar com os termos');
      return;
    }

    if (mediaFiles.length === 0) {
      alert('Adicione pelo menos 1 arquivo de comprovação');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const { data: achievement, error: achievementError } = await supabase
        .from('achievements')
        .insert({
          user_id: userId,
          type_id: selectedType.id,
          title: title,
          description: description,
          level: 'amador',
          status: 'pending',
          provisional_points: selectedType.default_points
        })
        .select()
        .single();

      if (achievementError) throw achievementError;

      for (const file of mediaFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/${achievement.id}/${Date.now()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('achievement-media')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('achievement-media')
          .getPublicUrl(fileName);

        await supabase
          .from('achievement_media')
          .insert({
            achievement_id: achievement.id,
            user_id: userId,
            media_url: publicUrl,
            media_type: file.type.startsWith('image/') ? 'image' : 'video',
            file_size: file.size,
            mime_type: file.type
          });
      }

      setSubmitSuccess(true);
      setStep(4);
    } catch (error: any) {
      console.error('Error submitting:', error);
      setSubmitError(error.message || 'Erro ao submeter conquista');
    } finally {
      setIsSubmitting(false);
    }
  };

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  if (isLoading) {
    return (
      <div className={`min-h-screen ${bgClass} flex items-center justify-center`}>
        <div className="text-center">
          <Loader className={`w-12 h-12 ${textClass} animate-spin mx-auto mb-4`} />
          <p className={textClass}>Carregando...</p>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className={`min-h-screen ${bgClass} flex items-center justify-center p-6`}>
        <div className="text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className={`text-xl font-bold ${textClass} mb-2`}>Erro ao Carregar</h2>
          <p className={`${secondaryTextClass} mb-6`}>{loadError}</p>
          <button
            onClick={onBack}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className={`min-h-screen ${bgClass} pb-20`}>
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className={textClass}>13:04</span>
          <div className="flex items-center space-x-1">
            <span className={`ml-2 ${textClass}`}>5G</span>
            <div className={`w-6 h-3 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-sm ml-2`} />
          </div>
        </div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
          <h1 className={`text-xl font-bold ${textClass}`}>Adicionar Conquista</h1>
          <div className="w-10" />
        </div>

        <div className="px-6">
          <div className="mb-6">
            <h2 className={`text-2xl font-bold ${textClass} mb-2`}>O que você quer adicionar?</h2>
            <p className={secondaryTextClass}>Escolha o tipo de conquista</p>
          </div>

          <div className="space-y-4">
            {achievementTypes.map((type) => {
              const Icon = getIconComponent(type.icon);
              return (
                <button
                  key={type.id}
                  onClick={() => handleTypeSelect(type)}
                  className={`w-full ${cardClass} rounded-2xl p-6 border flex items-center justify-between hover:border-blue-500 transition-all active:scale-95`}
                >
                  <div className="flex items-center">
                    <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-xl flex items-center justify-center mr-4`}>
                      <Icon className="w-6 h-6 text-blue-500" />
                    </div>
                    <div className="text-left">
                      <h3 className={`font-semibold ${textClass}`}>{type.label}</h3>
                      <p className={`text-sm ${secondaryTextClass}`}>+{type.default_points} pontos</p>
                    </div>
                  </div>
                  <ChevronLeft className={`w-5 h-5 ${secondaryTextClass} rotate-180`} />
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className={`min-h-screen ${bgClass} pb-20`}>
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className={textClass}>13:04</span>
          <div className="flex items-center space-x-1">
            <span className={`ml-2 ${textClass}`}>5G</span>
            <div className={`w-6 h-3 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-sm ml-2`} />
          </div>
        </div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={() => setStep(1)} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
          <h1 className={`text-xl font-bold ${textClass}`}>{selectedType?.label}</h1>
          <div className="w-10" />
        </div>

        <div className="px-6">
          <div className={`${cardClass} rounded-2xl p-6 border space-y-4 mb-6`}>
            <div>
              <label className={`block text-sm font-medium ${textClass} mb-2`}>Título *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Campeão Copa Municipal 2023"
                className={`w-full p-3 rounded-xl ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-gray-100'} border-0`}
              />
            </div>

            <div>
              <label className={`block text-sm font-medium ${textClass} mb-2`}>Descrição</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Descreva sua conquista"
                className={`w-full p-3 rounded-xl ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-gray-100'} border-0`}
              />
            </div>
          </div>

          <button
            onClick={() => setStep(3)}
            disabled={!title}
            className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all ${
              title
                ? 'bg-blue-500 hover:bg-blue-600 text-white'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Continuar
          </button>
        </div>
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className={`min-h-screen ${bgClass} pb-20`}>
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className={textClass}>13:04</span>
          <div className="flex items-center space-x-1">
            <span className={`ml-2 ${textClass}`}>5G</span>
            <div className={`w-6 h-3 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-sm ml-2`} />
          </div>
        </div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={() => setStep(2)} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
          <h1 className={`text-xl font-bold ${textClass}`}>Comprovação</h1>
          <div className="w-10" />
        </div>

        <div className="px-6">
          <div className="mb-6">
            <h2 className={`text-2xl font-bold ${textClass} mb-2`}>Adicionar Evidências</h2>
            <p className={secondaryTextClass}>Adicione fotos ou vídeos (mínimo 1, máximo 5)</p>
          </div>

          <div className={`${cardClass} rounded-2xl p-6 border mb-6`}>
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-xl cursor-pointer hover:border-blue-500 transition-all">
              <Upload className={`w-8 h-8 mb-2 ${secondaryTextClass}`} />
              <span className={`text-sm ${secondaryTextClass}`}>Clique para adicionar arquivos</span>
              <input
                type="file"
                className="hidden"
                multiple
                accept="image/jpeg,image/png,image/jpg,video/mp4"
                onChange={handleFileChange}
              />
            </label>
          </div>

          {mediaFiles.length > 0 && (
            <div className="space-y-3 mb-6">
              {mediaFiles.map((file, index) => (
                <div key={index} className={`${cardClass} rounded-xl p-4 border flex items-center justify-between`}>
                  <div className="flex items-center flex-1 overflow-hidden">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                      <Upload className="w-6 h-6 text-blue-500" />
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <p className={`text-sm font-medium ${textClass} truncate`}>{file.name}</p>
                      <p className={`text-xs ${secondaryTextClass}`}>
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <button onClick={() => removeFile(index)} className="ml-3 p-2 hover:bg-red-50 rounded-lg">
                    <X className="w-5 h-5 text-red-500" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className={`${cardClass} rounded-2xl p-6 border mb-6`}>
            <label className="flex items-start">
              <input
                type="checkbox"
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                className="mt-1 mr-3"
              />
              <span className={`text-sm ${textClass}`}>
                Confirmo que esta conquista é verdadeira e autorizo o uso das mídias para verificação.
              </span>
            </label>
          </div>

          {submitError && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 flex items-start">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
              <p className="text-sm text-red-700">{submitError}</p>
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={!agreedToTerms || mediaFiles.length === 0 || isSubmitting}
            className={`w-full py-4 rounded-2xl font-semibold text-lg flex items-center justify-center ${
              agreedToTerms && mediaFiles.length > 0 && !isSubmitting
                ? 'bg-blue-500 hover:bg-blue-600 text-white'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {isSubmitting ? (
              <>
                <Loader className="w-5 h-5 mr-2 animate-spin" />
                Enviando...
              </>
            ) : (
              'Enviar para Verificação'
            )}
          </button>
        </div>
      </div>
    );
  }

  if (step === 4 && submitSuccess) {
    return (
      <div className={`min-h-screen ${bgClass} flex items-center justify-center p-6`}>
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-4`}>Prova Enviada!</h2>
          <p className={`${secondaryTextClass} mb-6`}>
            Sua conquista foi enviada para verificação.
          </p>
          <div className={`${cardClass} rounded-2xl p-6 border mb-6`}>
            <p className={`text-sm ${secondaryTextClass} mb-2`}>Pontos provisórios</p>
            <p className="text-3xl font-bold text-blue-500">+{selectedType?.default_points}</p>
          </div>
          <button
            onClick={onBack}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-2xl font-semibold text-lg"
          >
            Voltar ao Perfil
          </button>
        </div>
      </div>
    );
  }

  return null;
}
