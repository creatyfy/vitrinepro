import React, { useState } from 'react';
import { ChevronLeft, Moon, Sun, Palette, User, Bell, Shield, HelpCircle, LogOut, ChevronRight, Monitor } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';

interface SettingsScreenProps {
  onBack: () => void;
  isDarkMode: boolean;
  onThemeChange: (isDark: boolean) => void;
  onNavigateToPrivacy?: () => void;
  onNavigateToSupport?: () => void;
  onLogout?: () => void;
}

export default function SettingsScreen({ onBack, onThemeChange, onNavigateToPrivacy, onNavigateToSupport, onLogout }: SettingsScreenProps) {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const { theme, setTheme, isDarkMode } = useTheme();
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const settingsOptions = [
    {
      id: 'theme',
      title: 'Tema do Aplicativo',
      description: 'Escolha entre tema claro ou escuro',
      icon: isDarkMode ? Moon : Sun,
      action: 'toggle',
      value: isDarkMode,
      onClick: undefined
    },
    {
      id: 'notifications',
      title: 'Notificações',
      description: 'Receber alertas sobre treinos e oportunidades',
      icon: Bell,
      action: 'toggle',
      value: notificationsEnabled,
      onClick: undefined
    },
    {
      id: 'profile',
      title: 'Editar Perfil',
      description: 'Alterar informações pessoais',
      icon: User,
      action: 'navigate',
      onClick: () => console.log('Navegando para Perfil')
    },
    {
      id: 'privacy',
      title: 'Privacidade',
      description: 'Configurações de privacidade e dados',
      icon: Shield,
      action: 'navigate',
      onClick: onNavigateToPrivacy
    },
    {
      id: 'help',
      title: 'Ajuda e Suporte',
      description: 'Central de ajuda e contato',
      icon: HelpCircle,
      action: 'navigate',
      onClick: onNavigateToSupport
    }
  ];

  const handleToggle = (optionId: string) => {
    if (optionId === 'theme') {
      setTheme(isDarkMode ? 'light' : 'dark');
      onThemeChange(!isDarkMode);
    } else if (optionId === 'notifications') {
      setNotificationsEnabled(!notificationsEnabled);
    }
  };

  const handleLogout = async () => {
    if (isLoggingOut) return;

    const confirmLogout = window.confirm('Tem certeza que deseja sair da conta?');
    if (!confirmLogout) return;

    try {
      setIsLoggingOut(true);

      const { error } = await supabase.auth.signOut();

      if (error) {
        console.error('Erro ao sair:', error);
        alert('Erro ao sair da conta. Tente novamente.');
        return;
      }

      localStorage.clear();
      sessionStorage.clear();

      if (onLogout) {
        onLogout();
      } else {
        window.location.reload();
      }
    } catch (error) {
      console.error('Erro inesperado ao sair:', error);
      alert('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoggingOut(false);
    }
  };

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  return (
    <div className={`min-h-screen ${bgClass}`}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className={textClass}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className={`w-1 h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-full`}></div>
          <div className={`w-1 h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-full`}></div>
          <div className={`w-1 h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-full`}></div>
          <span className={`ml-2 ${textClass}`}>5G</span>
          <div className={`w-6 h-3 ${isDarkMode ? 'bg-white' : 'bg-gray-800'} rounded-sm ml-2`}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>Configurações</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className={`w-16 h-16 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <Palette className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>Personalize sua Experiência</h2>
          <p className={secondaryTextClass}>Configure o app do seu jeito</p>
        </div>

        {/* Theme Preview */}
        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <h3 className={`text-lg font-semibold ${textClass} mb-4`}>Prévia do Tema</h3>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => {
                setTheme('light');
                onThemeChange(false);
              }}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                !isDarkMode 
                  ? 'border-blue-500 bg-blue-50' 
                  : isDarkMode 
                    ? 'border-gray-600 bg-gray-800' 
                    : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="bg-white rounded-lg p-3 mb-3">
                <div className="w-full h-2 bg-blue-500 rounded mb-2"></div>
                <div className="w-3/4 h-1 bg-gray-300 rounded mb-1"></div>
                <div className="w-1/2 h-1 bg-gray-300 rounded"></div>
              </div>
              <div className={`text-sm font-medium ${textClass}`}>Claro</div>
            </button>
            
            <button
              onClick={() => {
                setTheme('dark');
                onThemeChange(true);
              }}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                isDarkMode 
                  ? 'border-blue-500 bg-blue-900' 
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="bg-gray-900 rounded-lg p-3 mb-3">
                <div className="w-full h-2 bg-blue-500 rounded mb-2"></div>
                <div className="w-3/4 h-1 bg-gray-600 rounded mb-1"></div>
                <div className="w-1/2 h-1 bg-gray-600 rounded"></div>
              </div>
              <div className={`text-sm font-medium ${textClass}`}>Escuro</div>
            </button>
          </div>
        </div>

        {/* Settings Options */}
        <div className="space-y-4 mb-8">
          {settingsOptions.map((option) => {
            const IconComponent = option.icon;
            const isClickable = option.action === 'navigate' || option.action === 'toggle';
            const Component = isClickable ? 'button' : 'div';

            return (
              <Component
                key={option.id}
                onClick={option.action === 'navigate' && option.onClick ? option.onClick : undefined}
                className={`${cardClass} rounded-2xl p-6 shadow-sm border ${isClickable && option.action === 'navigate' ? 'w-full cursor-pointer hover:bg-opacity-80 active:scale-95 transition-all' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center flex-1">
                    <div className={`w-12 h-12 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-xl flex items-center justify-center mr-4`}>
                      <IconComponent className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className={`font-semibold ${textClass} mb-1`}>{option.title}</h4>
                      <p className={`text-sm ${secondaryTextClass}`}>{option.description}</p>
                    </div>
                  </div>

                  {option.action === 'toggle' ? (
                    <button
                      onClick={() => handleToggle(option.id)}
                      className={`w-12 h-6 rounded-full transition-all duration-200 ${
                        option.value ? 'bg-blue-500' : isDarkMode ? 'bg-gray-600' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full transition-all duration-200 ${
                        option.value ? 'translate-x-6' : 'translate-x-0.5'
                      }`}></div>
                    </button>
                  ) : (
                    <ChevronRight className={`w-5 h-5 ${secondaryTextClass}`} />
                  )}
                </div>
              </Component>
            );
          })}
        </div>

        {/* App Info */}
        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <h3 className={`text-lg font-semibold ${textClass} mb-4`}>Sobre o App</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className={secondaryTextClass}>Versão</span>
              <span className={`font-medium ${textClass}`}>2.1.0</span>
            </div>
            <div className="flex justify-between">
              <span className={secondaryTextClass}>Última atualização</span>
              <span className={`font-medium ${textClass}`}>15 Jan 2025</span>
            </div>
            <div className="flex justify-between">
              <span className={secondaryTextClass}>Desenvolvido por</span>
              <span className={`font-medium ${textClass}`}>Vitrine Pro Team</span>
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          disabled={isLoggingOut}
          className={`w-full ${isDarkMode ? 'bg-red-600 hover:bg-red-700' : 'bg-red-500 hover:bg-red-600'} text-white py-4 rounded-2xl font-semibold text-lg transition-colors duration-200 active:scale-95 flex items-center justify-center mb-8 ${isLoggingOut ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <LogOut className={`w-5 h-5 mr-2 ${isLoggingOut ? 'animate-spin' : ''}`} />
          {isLoggingOut ? 'Saindo...' : 'Sair da Conta'}
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}