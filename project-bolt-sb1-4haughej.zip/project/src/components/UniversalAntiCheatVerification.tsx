import React, { useState, useRef, useEffect } from 'react';
import { Shield, Clock, Camera as CameraIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface UniversalAntiCheatVerificationProps {
  sessionId?: string;
  isDarkMode?: boolean;
  onComplete?: (points: number) => void;
  onSkip?: () => void;
  onSuccess?: () => void;
  onFailure?: () => void;
}

const GESTURES = [
  { id: 'peace', text: 'Sinal de paz (V)' },
  { id: 'thumbsup', text: 'Joinha' },
  { id: 'ok', text: 'Sinal de OK' },
  { id: 'fist', text: 'Punho fechado' },
  { id: 'smile', text: 'Sorriso' },
  { id: 'chin', text: 'Mão no queixo' },
  { id: 'three', text: 'Número 3 com dedos' },
  { id: 'tongue', text: 'Língua para fora' },
  { id: 'rock', text: 'Rock (🤘)' },
  { id: 'wave', text: 'Aceno com mão' }
];

const CHALLENGE_DURATION_SECONDS = 60;
const POINTS_WITH_PROOF = 100;
const POINTS_SKIP_PENALTY = 0.5;

export default function UniversalAntiCheatVerification({
  sessionId,
  isDarkMode = false,
  onComplete,
  onSkip,
  onSuccess,
  onFailure
}: UniversalAntiCheatVerificationProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [proofCode, setProofCode] = useState<string>('');
  const [requiredGesture, setRequiredGesture] = useState<typeof GESTURES[0] | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(CHALLENGE_DURATION_SECONDS);
  const [isPaused, setIsPaused] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    generateChallenge();
    startCamera();
    return () => stopCamera();
  }, []);

  useEffect(() => {
    if (isPaused || selectedImage) return;
    if (timeRemaining <= 0) {
      generateChallenge();
      return;
    }
    const interval = setInterval(() => setTimeRemaining(prev => prev - 1), 1000);
    return () => clearInterval(interval);
  }, [timeRemaining, isPaused, selectedImage]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCameraActive(true);
      }
    } catch (error) {
      console.error('Camera error:', error);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    stopCamera();
    setIsPaused(true);

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0);
      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], 'photo.jpg', { type: 'image/jpeg' });
          setImageFile(file);
          setSelectedImage(canvas.toDataURL('image/jpeg'));
        }
      }, 'image/jpeg', 0.9);
    }
  };

  const handleSubmitProof = async () => {
    if (!selectedImage) return;
    setIsUploading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (user && sessionId) {
        await supabase
          .from('active_proof_codes')
          .update({ used: true })
          .eq('user_id', user.id)
          .eq('training_session_id', sessionId)
          .eq('code_value', proofCode)
          .eq('used', false);
      }

      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsUploading(false);

      if (onComplete) {
        onComplete(POINTS_WITH_PROOF);
      } else if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      setIsUploading(false);
      if (onFailure) {
        onFailure();
      }
    }
  };

  const generateChallenge = async () => {
    try {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let code = '';
      for (let i = 0; i < 4; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }

      const gesture = GESTURES[Math.floor(Math.random() * GESTURES.length)];

      const { data: { user } } = await supabase.auth.getUser();
      if (user && sessionId) {
        const expiresAt = new Date();
        expiresAt.setSeconds(expiresAt.getSeconds() + CHALLENGE_DURATION_SECONDS);

        await supabase.from('active_proof_codes').insert({
          user_id: user.id,
          training_session_id: sessionId,
          code_value: code,
          expires_at: expiresAt.toISOString(),
          used: false
        });
      }

      setProofCode(code);
      setRequiredGesture(gesture);
      setTimeRemaining(CHALLENGE_DURATION_SECONDS);
      setSelectedImage(null);
      setImageFile(null);
    } catch (error) {
      console.error('Error generating challenge:', error);
      const gesture = GESTURES[Math.floor(Math.random() * GESTURES.length)];
      setRequiredGesture(gesture);
      setTimeRemaining(CHALLENGE_DURATION_SECONDS);
    }
  };


  const handleSkipClick = () => {
    const penaltyPoints = Math.floor(POINTS_WITH_PROOF * POINTS_SKIP_PENALTY);
    if (onComplete) {
      onComplete(penaltyPoints);
    } else if (onSkip) {
      onSkip();
    } else if (onSuccess) {
      onSuccess();
    }
  };

  if (selectedImage && !isUploading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="w-full max-w-md">
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white text-center mb-2">Verificação Anti-Trapaça</h1>
            <p className="text-purple-100 text-center mb-8">Revise sua foto de comprovação</p>
            <div className="mb-6">
              <img src={selectedImage} alt="Preview" className="w-full h-64 object-cover rounded-2xl shadow-xl" />
            </div>
            <button
              onClick={handleSubmitProof}
              className="w-full bg-green-500 text-white py-4 rounded-2xl font-bold text-base mb-3 hover:bg-green-600 transition-colors shadow-lg"
            >
              Enviar Comprovação
            </button>
            <button
              onClick={() => {
                setSelectedImage(null);
                setImageFile(null);
                setIsPaused(false);
                startCamera();
              }}
              className="w-full py-3 text-center text-purple-200 hover:text-white transition-colors text-sm font-medium"
            >
              Tirar outra foto
            </button>
          </div>
        </div>
        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  if (isUploading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="w-full max-w-md">
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white text-center mb-2">Verificação Anti-Trapaça</h1>
            <p className="text-purple-100 text-center mb-8">Enviando sua comprovação...</p>
            <div className="flex items-center justify-center">
              <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
          </div>
        </div>
        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
      <div className="flex-1 flex flex-col">
        <div className="pt-6 pb-4 text-center px-4">
          <div className="w-16 h-16 bg-purple-500 bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Verificação Anti-Trapaça</h1>
          <p className="text-sm text-purple-100">Complete o desafio para comprovar seu treino</p>
        </div>

        <div className="px-4 mb-4">
          <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-3 border border-white border-opacity-20 flex items-center justify-between">
            <div className="flex items-center">
              <Clock className="w-4 h-4 text-white mr-2" />
              <span className="text-white text-sm font-medium">Tempo: {timeRemaining}s</span>
            </div>
            <div className="bg-green-500 px-3 py-1 rounded-full">
              <span className="text-white font-bold text-xs">OK</span>
            </div>
          </div>
        </div>

        {proofCode && requiredGesture && (
          <div className="px-4 space-y-3 mb-4">
            <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
              <p className="text-purple-100 text-center text-xs mb-2">Código do Desafio:</p>
              <div className="text-white text-center text-4xl font-bold tracking-wider">{proofCode}</div>
            </div>
            <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
              <p className="text-purple-100 text-center text-xs mb-2">Faça o Gesto:</p>
              <div className="text-white text-center text-2xl font-bold">{requiredGesture.text}</div>
            </div>
          </div>
        )}

        <div className="flex-1 px-4 mb-4 min-h-[280px]">
          <div className="relative w-full h-full rounded-2xl overflow-hidden bg-black">
            {!isCameraActive && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                <div className="text-center">
                  <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                  <p className="text-white text-sm">Iniciando câmera...</p>
                </div>
              </div>
            )}
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          </div>
        </div>

        <div className="px-4 pb-6">
          <button
            onClick={capturePhoto}
            disabled={!isCameraActive}
            className="w-full bg-white text-purple-600 py-4 rounded-2xl font-bold text-base mb-3 hover:bg-gray-100 transition-colors disabled:opacity-50 flex items-center justify-center"
          >
            <CameraIcon className="w-5 h-5 mr-2" />
            Capturar Prova
          </button>
          <button onClick={handleSkipClick} className="w-full py-3 text-center text-purple-200 hover:text-white transition-colors text-sm font-medium">
            Pular (-50% pontos)
          </button>
          <p className="text-center text-purple-200 text-xs mt-2">Sem prova válida = apenas 50% dos pontos</p>
        </div>
      </div>
      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
