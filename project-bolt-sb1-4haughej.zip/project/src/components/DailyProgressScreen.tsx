import React, { useState } from 'react';
import { ChevronLeft, Calendar, Target, Trophy, Star, CheckCircle, Clock, Zap, Users, Award, TrendingUp, Flame, Medal } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface DailyProgressScreenProps {
  onBack: () => void;
}

export default function DailyProgressScreen({ onBack }: DailyProgressScreenProps) {
  const { tokens, isDarkMode, themeVersion } = useTheme();
  const [selectedWeek, setSelectedWeek] = useState(1);

  const weeklyProgress = [
    { week: 1, completed: 7, total: 7, points: 350, status: 'completed' },
    { week: 2, completed: 5, total: 7, points: 250, status: 'current' },
    { week: 3, completed: 0, total: 7, points: 0, status: 'locked' },
    { week: 4, completed: 0, total: 7, points: 0, status: 'locked' }
  ];

  const dailyStats = {
    currentStreak: 12,
    longestStreak: 28,
    totalWorkouts: 47,
    totalPoints: 2350,
    level: 'Intermediário',
    nextLevel: 'Avançado',
    progressToNext: 65
  };

  const todayWorkouts = [
    {
      id: 1,
      name: 'Explosão Matinal',
      duration: '15 min',
      difficulty: 'Intermediário',
      completed: true,
      points: 25,
      image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop'
    },
    {
      id: 2,
      name: 'Força Unilateral',
      duration: '20 min',
      difficulty: 'Avançado',
      completed: true,
      points: 30,
      image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop'
    },
    {
      id: 3,
      name: 'Agilidade com Bola',
      duration: '12 min',
      difficulty: 'Intermediário',
      completed: false,
      points: 25,
      image: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop'
    }
  ];

  const achievements = [
    { id: 1, title: 'Primeira Semana', description: 'Complete 7 treinos em uma semana', earned: true, icon: '🏆' },
    { id: 2, title: 'Sequência de Fogo', description: 'Treine por 10 dias seguidos', earned: true, icon: '🔥' },
    { id: 3, title: 'Atleta Dedicado', description: 'Complete 50 treinos', earned: false, icon: '⭐' },
    { id: 4, title: 'Mestre da Explosão', description: 'Complete 20 treinos de explosão', earned: false, icon: '💥' }
  ];

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Iniciante': return isDarkMode ? 'bg-green-900 text-green-400' : 'bg-green-100 text-green-800';
      case 'Intermediário': return isDarkMode ? 'bg-yellow-900 text-yellow-400' : 'bg-yellow-100 text-yellow-800';
      case 'Avançado': return isDarkMode ? 'bg-red-900 text-red-400' : 'bg-red-100 text-red-800';
      default: return isDarkMode ? 'bg-gray-800 text-gray-400' : 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'current': return 'bg-blue-500';
      case 'locked': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className={`min-h-screen ${bgClass}`}>
      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>Progresso Diário</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className={`w-16 h-16 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>Seu Progresso</h2>
          <p className={secondaryTextClass}>Acompanhe sua evolução diária</p>
        </div>

        {/* Current Streak */}
        <div className={`${isDarkMode ? 'bg-gradient-to-r from-orange-600 to-orange-700' : 'bg-gradient-to-r from-orange-500 to-orange-600'} rounded-2xl p-6 text-white mb-8`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Flame className="w-6 h-6 mr-2 text-yellow-300" />
              <h3 className="text-lg font-semibold">Sequência Atual</h3>
            </div>
            <Trophy className="w-8 h-8 text-yellow-300" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{dailyStats.currentStreak}</div>
            <p className={`${isDarkMode ? 'text-orange-200' : 'text-orange-100'} mb-4`}>
              dias consecutivos treinando
            </p>
            <div className="flex justify-between items-center">
              <span className={`text-sm ${isDarkMode ? 'text-orange-200' : 'text-orange-100'}`}>
                Recorde: {dailyStats.longestStreak} dias
              </span>
              <button className={`bg-white ${isDarkMode ? 'text-orange-700' : 'text-orange-600'} px-4 py-2 rounded-full font-semibold text-sm hover:bg-orange-50 transition-colors`}>
                Compartilhar
              </button>
            </div>
          </div>
        </div>

        {/* Daily Stats */}
        <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-8`}>
          <h3 className={`text-lg font-semibold ${textClass} mb-4`}>Estatísticas Gerais</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-blue-900' : 'bg-blue-100'} rounded-full flex items-center justify-center mx-auto mb-2`}>
                <Target className={`w-6 h-6 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </div>
              <div className={`text-2xl font-bold ${textClass}`}>{dailyStats.totalWorkouts}</div>
              <div className={`text-sm ${secondaryTextClass}`}>Treinos Totais</div>
            </div>
            <div className="text-center">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-yellow-900' : 'bg-yellow-100'} rounded-full flex items-center justify-center mx-auto mb-2`}>
                <Star className={`w-6 h-6 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
              </div>
              <div className={`text-2xl font-bold ${textClass}`}>{dailyStats.totalPoints}</div>
              <div className={`text-sm ${secondaryTextClass}`}>Pontos Totais</div>
            </div>
            <div className="text-center">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-purple-900' : 'bg-purple-100'} rounded-full flex items-center justify-center mx-auto mb-2`}>
                <Trophy className={`w-6 h-6 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              </div>
              <div className={`text-2xl font-bold ${textClass}`}>{dailyStats.level}</div>
              <div className={`text-sm ${secondaryTextClass}`}>Nível Atual</div>
            </div>
            <div className="text-center">
              <div className={`w-12 h-12 ${isDarkMode ? 'bg-green-900' : 'bg-green-100'} rounded-full flex items-center justify-center mx-auto mb-2`}>
                <TrendingUp className={`w-6 h-6 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
              </div>
              <div className={`text-2xl font-bold ${textClass}`}>{dailyStats.progressToNext}%</div>
              <div className={`text-sm ${secondaryTextClass}`}>Para {dailyStats.nextLevel}</div>
            </div>
          </div>
        </div>

        {/* Today's Workouts */}
        <div className="mb-8">
          <h3 className={`text-xl font-semibold ${textClass} mb-6`}>Treinos de Hoje</h3>
          <div className="space-y-4">
            {todayWorkouts.map((workout) => (
              <div key={workout.id} className={`${cardClass} rounded-2xl shadow-sm border overflow-hidden`}>
                <div className="flex">
                  <div className="relative w-24 h-24 flex-shrink-0">
                    <img 
                      src={workout.image} 
                      alt={workout.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                      <div className="w-8 h-8 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                        {workout.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <Target className="w-4 h-4 text-gray-800" />
                        )}
                      </div>
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 text-white text-xs px-1 rounded">
                      {workout.duration}
                    </div>
                  </div>
                  
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className={`font-semibold ${textClass} text-sm line-clamp-2 flex-1`}>
                        {workout.name}
                      </h4>
                      <div className="flex items-center ml-2">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className={`text-sm ${secondaryTextClass} ml-1`}>+{workout.points}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(workout.difficulty)}`}>
                        {workout.difficulty}
                      </span>
                      <button 
                        className={`px-4 py-2 rounded-xl font-semibold text-sm transition-all duration-200 ${
                          workout.completed
                            ? isDarkMode ? 'bg-green-800 text-green-400' : 'bg-green-100 text-green-800'
                            : isDarkMode ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-blue-500 text-white hover:bg-blue-600'
                        } active:scale-95`}
                      >
                        {workout.completed ? 'Concluído' : 'Iniciar'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Weekly Progress */}
        <div className="mb-8">
          <h3 className={`text-xl font-semibold ${textClass} mb-6`}>Progresso Semanal</h3>
          <div className="grid grid-cols-2 gap-4">
            {weeklyProgress.map((week) => (
              <div key={week.week} className={`${cardClass} rounded-2xl p-4 shadow-sm border`}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className={`font-semibold ${textClass}`}>Semana {week.week}</h4>
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(week.status)}`}></div>
                </div>
                <div className="mb-3">
                  <div className="flex justify-between text-sm mb-1">
                    <span className={secondaryTextClass}>Progresso</span>
                    <span className={textClass}>{week.completed}/{week.total}</span>
                  </div>
                  <div className={`w-full ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-full h-2`}>
                    <div 
                      className={`${getStatusColor(week.status)} h-2 rounded-full transition-all duration-300`}
                      style={{ width: `${(week.completed / week.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs ${secondaryTextClass}`}>
                    {week.status === 'completed' ? 'Completa' : 
                     week.status === 'current' ? 'Em andamento' : 'Bloqueada'}
                  </span>
                  <span className={`text-sm font-bold ${textClass}`}>+{week.points}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="mb-8">
          <h3 className={`text-xl font-semibold ${textClass} mb-6`}>Conquistas</h3>
          <div className="space-y-4">
            {achievements.map((achievement) => (
              <div key={achievement.id} className={`${cardClass} rounded-2xl p-4 shadow-sm border ${
                achievement.earned ? '' : 'opacity-60'
              }`}>
                <div className="flex items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                    achievement.earned 
                      ? isDarkMode ? 'bg-yellow-600' : 'bg-yellow-500' 
                      : isDarkMode ? 'bg-gray-800' : 'bg-gray-200'
                  }`}>
                    <span className="text-2xl">{achievement.icon}</span>
                  </div>
                  <div className="flex-1">
                    <h4 className={`font-semibold ${textClass} mb-1`}>{achievement.title}</h4>
                    <p className={`text-sm ${secondaryTextClass}`}>{achievement.description}</p>
                  </div>
                  {achievement.earned && (
                    <CheckCircle className={`w-6 h-6 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}