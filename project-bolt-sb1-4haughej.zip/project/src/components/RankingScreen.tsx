import React, { useState, useEffect } from 'react';
import { ChevronLeft, Trophy, Star, TrendingUp, Users, MapPin, Calendar, Award, Crown, Medal, Target, Zap, Shield, ChevronRight, Eye, Heart, MessageCircle, Flame, Activity, Brain, LineChart, TrendingDown } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';
import BrazilMap from './BrazilMap';

interface RankingScreenProps {
  onBack: () => void;
}

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  full_content: string;
  image_url: string;
  category: string;
  views_count: number;
  author: string;
  published_at: string;
}

interface CommunityAchievement {
  id: string;
  title: string;
  description: string;
  image_url: string;
  location_city: string;
  location_state: string;
  achievement_type: string;
  created_at: string;
}

export default function RankingScreen({ onBack }: RankingScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [selectedTab, setSelectedTab] = useState('geral');
  const [news, setNews] = useState<NewsArticle[]>([]);
  const [achievements, setAchievements] = useState<CommunityAchievement[]>([]);
  const [selectedNews, setSelectedNews] = useState<NewsArticle | null>(null);
  const [showMap, setShowMap] = useState(false);

  useEffect(() => {
    loadNews();
    loadAchievements();
  }, []);

  const loadNews = async () => {
    const { data } = await supabase
      .from('news_articles')
      .select('*')
      .order('published_at', { ascending: false })
      .limit(6);

    if (data) setNews(data);
  };

  const loadAchievements = async () => {
    const { data } = await supabase
      .from('community_achievements')
      .select('*')
      .eq('is_featured', true)
      .order('created_at', { ascending: false })
      .limit(4);

    if (data) setAchievements(data);
  };

  const tabs = [
    { id: 'geral', label: 'Geral', icon: Trophy },
    { id: 'semanal', label: 'Semanal', icon: Calendar },
    { id: 'posicao', label: 'Por Posição', icon: Target }
  ];

  // Escalação 4-3-3 dos mais dedicados da semana
  const weeklyFormation = {
    goalkeeper: {
      name: 'Carlos Silva',
      photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      points: 2450,
      position: 'Goleiro',
      club: 'Santos FC',
      age: 19
    },
    defenders: [
      {
        name: 'João Santos',
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2380,
        position: 'Zagueiro',
        club: 'Palmeiras',
        age: 20
      },
      {
        name: 'Pedro Lima',
        photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2350,
        position: 'Zagueiro',
        club: 'São Paulo',
        age: 21
      },
      {
        name: 'Lucas Oliveira',
        photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2320,
        position: 'Lateral',
        club: 'Corinthians',
        age: 18
      },
      {
        name: 'Rafael Costa',
        photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2300,
        position: 'Lateral',
        club: 'Flamengo',
        age: 19
      }
    ],
    midfielders: [
      {
        name: 'Gabriel Ferreira',
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2420,
        position: 'Volante',
        club: 'Grêmio',
        age: 22
      },
      {
        name: 'Mateus Rocha',
        photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2390,
        position: 'Meio-campo',
        club: 'Internacional',
        age: 20
      },
      {
        name: 'Diego Alves',
        photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2360,
        position: 'Meia-atacante',
        club: 'Botafogo',
        age: 19
      }
    ],
    forwards: [
      {
        name: 'Bruno Henrique',
        photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2480,
        position: 'Ponta',
        club: 'Fluminense',
        age: 18
      },
      {
        name: 'Vinicius Jr',
        photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2500,
        position: 'Atacante',
        club: 'Vasco',
        age: 17
      },
      {
        name: 'Neymar Silva',
        photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
        points: 2470,
        position: 'Ponta',
        club: 'Athletico-PR',
        age: 19
      }
    ]
  };

  const topPlayers = [
    {
      rank: 1,
      name: 'Vinicius Jr',
      photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop',
      points: 2500,
      position: 'Atacante',
      club: 'Vasco',
      age: 17,
      change: '+50',
      location: 'Rio de Janeiro'
    },
    {
      rank: 2,
      name: 'Bruno Henrique',
      photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop',
      points: 2480,
      position: 'Ponta',
      club: 'Fluminense',
      age: 18,
      change: '+35',
      location: 'Rio de Janeiro'
    },
    {
      rank: 3,
      name: 'Neymar Silva',
      photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop',
      points: 2470,
      position: 'Ponta',
      club: 'Athletico-PR',
      age: 19,
      change: '+28',
      location: 'Curitiba'
    },
    {
      rank: 4,
      name: 'Carlos Silva',
      photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop',
      points: 2450,
      position: 'Goleiro',
      club: 'Santos FC',
      age: 19,
      change: '+42',
      location: 'Santos'
    },
    {
      rank: 5,
      name: 'Gabriel Ferreira',
      photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop',
      points: 2420,
      position: 'Volante',
      club: 'Grêmio',
      age: 22,
      change: '+31',
      location: 'Porto Alegre'
    }
  ];

  const clubsUsingApp = [
    { name: 'Santos FC', logo: '⚪', players: 45, contracts: 8 },
    { name: 'Palmeiras', logo: '🟢', players: 52, contracts: 12 },
    { name: 'São Paulo', logo: '🔴', players: 38, contracts: 6 },
    { name: 'Corinthians', logo: '⚫', players: 41, contracts: 9 },
    { name: 'Flamengo', logo: '🔴', players: 67, contracts: 15 },
    { name: 'Grêmio', logo: '🔵', players: 29, contracts: 4 }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'dica': return 'bg-green-100 text-green-800';
      case 'historia': return 'bg-yellow-100 text-yellow-800';
      case 'metodo': return 'bg-blue-100 text-blue-800';
      case 'projeto': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'dica': return 'Dica';
      case 'historia': return 'História';
      case 'metodo': return 'Método';
      case 'projeto': return 'Projeto';
      default: return 'Notícia';
    }
  };

  const getAchievementIcon = (type: string) => {
    switch (type) {
      case 'profissional': return Trophy;
      case 'medalhas': return Medal;
      case 'treinos': return Flame;
      case 'clube': return Shield;
      default: return Star;
    }
  };

  const renderPlayer = (player: any, isSmall = false) => (
    <div className={`bg-white rounded-xl p-3 shadow-sm border text-center ${isSmall ? 'w-16' : 'w-20'}`}>
      <img
        src={player.photo}
        alt={player.name}
        className={`${isSmall ? 'w-10 h-10' : 'w-12 h-12'} rounded-full mx-auto mb-2 object-cover`}
      />
      <div className={`font-semibold text-gray-900 ${isSmall ? 'text-xs' : 'text-sm'} mb-1 line-clamp-1`}>
        {player.name.split(' ')[0]}
      </div>
      <div className={`text-xs text-gray-600 mb-1 ${isSmall ? 'text-xs' : ''}`}>
        {player.position}
      </div>
      <div className={`text-xs font-bold text-blue-600 ${isSmall ? 'text-xs' : ''}`}>
        {player.points}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: tokens.surface }}>
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-6 pt-12 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Ranking</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>Ranking Nacional</h2>
          <p style={{ color: tokens.textSecondary }}>Os melhores atletas do Brasil</p>
        </div>

        {/* Tabs */}
        <div className="flex space-x-2 mb-8 rounded-2xl p-1" style={{ backgroundColor: tokens.surfaceAlt }}>
          {tabs.map((tab) => {
            const IconComponent = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className="flex-1 flex items-center justify-center py-3 px-4 rounded-xl transition-all duration-200"
                style={{
                  backgroundColor: selectedTab === tab.id ? tokens.surface : 'transparent',
                  color: selectedTab === tab.id ? tokens.textPrimary : tokens.textSecondary
                }}
              >
                <IconComponent className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {selectedTab === 'semanal' && (
          <>
            {/* Escalação Semanal 4-3-3 */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold" style={{ color: tokens.textPrimary }}>Escalação da Semana</h3>
                <div className="flex items-center text-yellow-600">
                  <Crown className="w-5 h-5 mr-1" />
                  <span className="text-sm font-medium">4-3-3</span>
                </div>
              </div>

              <div className="bg-gradient-to-b from-green-400 to-green-600 rounded-2xl p-6 relative overflow-hidden">
                <div className="absolute inset-0 opacity-20">
                  <div className="w-full h-full bg-gradient-to-b from-green-400 to-green-600"></div>
                </div>

                <div className="relative z-10">
                  {/* Atacantes */}
                  <div className="flex justify-center space-x-8 mb-8">
                    {weeklyFormation.forwards.map((player, index) => (
                      <div key={index}>
                        {renderPlayer(player)}
                      </div>
                    ))}
                  </div>

                  {/* Meio-campo */}
                  <div className="flex justify-center space-x-12 mb-8">
                    {weeklyFormation.midfielders.map((player, index) => (
                      <div key={index}>
                        {renderPlayer(player)}
                      </div>
                    ))}
                  </div>

                  {/* Defesa */}
                  <div className="flex justify-center space-x-6 mb-8">
                    {weeklyFormation.defenders.map((player, index) => (
                      <div key={index}>
                        {renderPlayer(player, true)}
                      </div>
                    ))}
                  </div>

                  {/* Goleiro */}
                  <div className="flex justify-center">
                    {renderPlayer(weeklyFormation.goalkeeper)}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {selectedTab === 'geral' && (
          <>
            {/* Top 5 Players */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-6" style={{ color: tokens.textPrimary }}>Top 5 Nacional</h3>
              <div className="space-y-4">
                {topPlayers.map((player) => (
                  <div key={player.rank} className="bg-white rounded-2xl p-4 shadow-sm border">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 font-bold text-white ${
                        player.rank === 1 ? 'bg-yellow-500' :
                        player.rank === 2 ? 'bg-gray-400' :
                        player.rank === 3 ? 'bg-orange-600' : 'bg-blue-500'
                      }`}>
                        {player.rank}
                      </div>

                      <img
                        src={player.photo}
                        alt={player.name}
                        className="w-12 h-12 rounded-full mr-4 object-cover"
                      />

                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold text-gray-900">{player.name}</h4>
                          <div className="text-right">
                            <div className="text-lg font-bold text-gray-900">{player.points}</div>
                            <div className="text-sm text-green-600 font-medium">{player.change}</div>
                          </div>
                        </div>

                        <div className="flex items-center text-sm text-gray-600">
                          <span className="mr-3">{player.position}</span>
                          <span className="mr-3">•</span>
                          <span className="mr-3">{player.club}</span>
                          <span className="mr-3">•</span>
                          <span className="mr-3">{player.age} anos</span>
                        </div>

                        <div className="flex items-center text-xs text-gray-500 mt-1">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span>{player.location}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Clubes Parceiros */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6" style={{ color: tokens.textPrimary }}>Clubes Parceiros</h3>
          <div className="grid grid-cols-2 gap-4">
            {clubsUsingApp.map((club, index) => (
              <div key={index} className="bg-white rounded-2xl p-4 shadow-sm border">
                <div className="flex items-center mb-3">
                  <span className="text-2xl mr-3">{club.logo}</span>
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm">{club.name}</h4>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="text-center bg-blue-50 rounded-lg p-2">
                    <div className="font-bold text-blue-600">{club.players}</div>
                    <div className="text-gray-600">Atletas</div>
                  </div>
                  <div className="text-center bg-green-50 rounded-lg p-2">
                    <div className="font-bold text-green-600">{club.contracts}</div>
                    <div className="text-gray-600">Contratos</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* === NOVAS SEÇÕES === */}

        {/* Notícias da Base */}
        {news.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-semibold" style={{ color: tokens.textPrimary }}>Notícias da Base</h3>
                <p className="text-sm" style={{ color: tokens.textSecondary }}>Histórias e dicas do futebol de formação</p>
              </div>
            </div>

            <div className="space-y-4">
              {news.map((article) => (
                <button
                  key={article.id}
                  onClick={() => setSelectedNews(article)}
                  className="w-full bg-white rounded-2xl shadow-sm border overflow-hidden text-left transition-all active:scale-95"
                >
                  <div className="flex">
                    {article.image_url && (
                      <img
                        src={article.image_url}
                        alt={article.title}
                        className="w-24 h-24 object-cover flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between mb-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
                          {getCategoryLabel(article.category)}
                        </span>
                      </div>

                      <h4 className="font-semibold text-gray-900 text-sm mb-1 line-clamp-1">
                        {article.title}
                      </h4>

                      <p className="text-xs text-gray-600 mb-3 line-clamp-2">
                        {article.summary}
                      </p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-xs text-gray-500">
                          <Eye className="w-3 h-3 mr-1" />
                          <span>{article.views_count} visualizações</span>
                        </div>
                        <span className="text-xs font-medium text-blue-600">
                          Ler mais →
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Estatísticas da Comunidade */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6" style={{ color: tokens.textPrimary }}>Estatísticas da Comunidade</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-4 text-white">
              <Activity className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">12.450</div>
              <div className="text-sm text-blue-100">Treinos esta semana</div>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-4 text-white">
              <Users className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">5.300</div>
              <div className="text-sm text-green-100">Atletas ativos</div>
            </div>
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-4 text-white">
              <Flame className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">280</div>
              <div className="text-sm text-purple-100">Desafios concluídos</div>
            </div>
            <div className="bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl p-4 text-white">
              <Trophy className="w-6 h-6 mb-2" />
              <div className="text-2xl font-bold">42</div>
              <div className="text-sm text-yellow-100">Novos no Top 100</div>
            </div>
          </div>
        </div>

        {/* Mural do Futebol */}
        {achievements.length > 0 && (
          <div className="mb-8">
            <div className="mb-6">
              <h3 className="text-xl font-semibold" style={{ color: tokens.textPrimary }}>Mural do Futebol</h3>
              <p className="text-sm" style={{ color: tokens.textSecondary }}>Grandes conquistas da comunidade</p>
            </div>

            <div className="space-y-4">
              {achievements.map((achievement) => {
                const Icon = getAchievementIcon(achievement.achievement_type);
                return (
                  <div key={achievement.id} className="bg-white rounded-2xl p-4 shadow-sm border">
                    <div className="flex items-start">
                      <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                        <Icon className="w-6 h-6 text-yellow-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 mb-1">{achievement.title}</h4>
                        <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                        <div className="flex items-center text-xs text-gray-500">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span>{achievement.location_city}, {achievement.location_state}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Mapa Interativo do Brasil */}
        <div className="mb-8">
          <div className="mb-6">
            <h3 className="text-xl font-semibold" style={{ color: tokens.textPrimary }}>Mapa de Atletas no Brasil</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Veja onde estão os atletas da comunidade</p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border">
            <BrazilMap isDarkMode={isDarkMode} />
          </div>
        </div>

        {/* Termômetro do Futebol de Base */}
        <div className="mb-8">
          <div className="mb-6">
            <h3 className="text-xl font-semibold" style={{ color: tokens.textPrimary }}>Termômetro do Futebol de Base</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>Tendências e estatísticas da comunidade</p>
          </div>

          <div className="space-y-4">
            {/* Posição mais popular */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-900">Posição mais popular</span>
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-gray-900">Atacante</span>
                <span className="text-2xl font-bold text-blue-600">28%</span>
              </div>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '28%' }}></div>
              </div>
            </div>

            {/* Treino mais executado */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-900">Treino mais executado</span>
                <Flame className="w-5 h-5 text-orange-600" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-gray-900">Velocidade e Potência</span>
                <span className="text-2xl font-bold text-orange-600">35%</span>
              </div>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: '35%' }}></div>
              </div>
            </div>

            {/* Média de treinos */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-900">Média de treinos por atleta/semana</span>
                <LineChart className="w-5 h-5 text-purple-600" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-gray-900">Esta semana</span>
                <span className="text-2xl font-bold text-purple-600">4.2</span>
              </div>
            </div>

            {/* Crescimento */}
            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-5 text-white">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold">Crescimento da base</span>
                <TrendingUp className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold">Este mês</span>
                <span className="text-3xl font-bold">+15%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* News Detail Modal */}
      {selectedNews && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-t-3xl w-full max-h-[85vh] overflow-y-auto p-6`}>
            <div className="flex items-center justify-between mb-4">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(selectedNews.category)}`}>
                {getCategoryLabel(selectedNews.category)}
              </span>
              <button
                onClick={() => setSelectedNews(null)}
                className={`p-2 rounded-lg ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}
              >
                <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
              </button>
            </div>

            {selectedNews.image_url && (
              <img
                src={selectedNews.image_url}
                alt={selectedNews.title}
                className="w-full h-48 object-cover rounded-2xl mb-4"
              />
            )}

            <h2 className={`text-2xl font-bold mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {selectedNews.title}
            </h2>

            <div className={`text-sm mb-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Por {selectedNews.author}
            </div>

            <p className={`text-base leading-relaxed whitespace-pre-line ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              {selectedNews.full_content}
            </p>

            <button
              onClick={() => setSelectedNews(null)}
              className="w-full mt-6 bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-2xl font-semibold"
            >
              Fechar
            </button>
          </div>
        </div>
      )}

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
