import React, { useState, useEffect, useMemo } from 'react';
import { X, Clock, Camera, AlertCircle, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';
import UniversalAntiCheatVerification from './UniversalAntiCheatVerification';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface DailyChallenge {
  id: string;
  challenge_date: string;
  expires_at: string;
  points_reward: number;
  dish: {
    id: string;
    name: string;
    image_url: string;
    ingredients: string[];
    preparation_steps: string[];
  };
  user_submission?: {
    photo_url: string;
    points_earned: number;
    submitted_at: string;
  };
}

interface DailyNutritionChallengeProps {
  userId: string;
  onBack: () => void;
}

export default function DailyNutritionChallenge({ userId, onBack }: DailyNutritionChallengeProps) {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(true);
  const [challenge, setChallenge] = useState<DailyChallenge | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [showCamera, setShowCamera] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  const styles = useMemo(() => ({
    container: { backgroundColor: theme.surface },
    header: { backgroundColor: theme.surface, borderColor: theme.border },
    card: { backgroundColor: theme.surfaceAlt, borderColor: theme.border },
    textPrimary: { color: theme.textPrimary },
    textSecondary: { color: theme.textSecondary },
    icon: { color: theme.icon },
    accent: { backgroundColor: theme.accent, color: theme.textInverse },
    accentText: { color: theme.accent },
    success: { color: theme.success, backgroundColor: `${theme.success}15` },
    error: { color: theme.error, backgroundColor: `${theme.error}15` },
    border: { borderColor: theme.border }
  }), [theme]);

  useEffect(() => {
    loadChallenge();
  }, [userId]);

  useEffect(() => {
    if (challenge?.expires_at) {
      const interval = setInterval(() => {
        setTimeRemaining(calculateTimeRemaining(challenge.expires_at));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [challenge]);

  async function loadChallenge() {
    try {
      setLoading(true);
      setError(null);

      await supabase.rpc('create_daily_nutrition_challenge');

      const today = new Date().toISOString().split('T')[0];

      const { data: challengeData, error: challengeError } = await supabase
        .from('daily_nutrition_challenges_simple')
        .select(`
          id,
          challenge_date,
          expires_at,
          points_reward,
          dish:daily_nutrition_dishes(
            id,
            name,
            image_url,
            ingredients,
            preparation_steps
          )
        `)
        .eq('challenge_date', today)
        .eq('is_active', true)
        .maybeSingle();

      if (challengeError) throw challengeError;
      if (!challengeData) throw new Error('Nenhum desafio disponível para hoje');

      const { data: submission } = await supabase
        .from('daily_nutrition_submissions_simple')
        .select('*')
        .eq('user_id', userId)
        .eq('challenge_date', today)
        .maybeSingle();

      setChallenge({
        ...challengeData,
        user_submission: submission ? {
          photo_url: submission.photo_url,
          points_earned: submission.points_earned,
          submitted_at: submission.submitted_at
        } : undefined
      });

    } catch (err: any) {
      console.error('Erro ao carregar desafio:', err);
      setError(err.message || 'Não foi possível carregar o desafio do dia');
    } finally {
      setLoading(false);
    }
  }

  function calculateTimeRemaining(expiresAt: string): string {
    const now = new Date().getTime();
    const deadline = new Date(expiresAt).getTime();
    const diff = deadline - now;

    if (diff <= 0) return 'Expirado';

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  function handlePhotoTaken(photoUrl: string) {
    setCapturedPhoto(photoUrl);
    setShowCamera(false);
  }

  async function handleSubmitProof() {
    if (!capturedPhoto || !challenge) return;

    try {
      setSubmitting(true);
      setError(null);

      const verificationCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const today = new Date().toISOString().split('T')[0];

      const { error: insertError } = await supabase
        .from('daily_nutrition_submissions_simple')
        .insert({
          user_id: userId,
          challenge_id: challenge.id,
          challenge_date: today,
          photo_url: capturedPhoto,
          verification_code: verificationCode,
          points_earned: challenge.points_reward
        });

      if (insertError) throw insertError;

      await supabase
        .from('athlete_meal_history')
        .insert({
          user_id: userId,
          meal_type: 'desafio_diario',
          date: today,
          points_earned: challenge.points_reward,
          quality_score: 90,
          notes: `Desafio Diário: ${challenge.dish.name}`
        });

      setSuccess(`Foto enviada! +${challenge.points_reward} pontos creditados`);

      setTimeout(() => {
        loadChallenge();
        setCapturedPhoto(null);
      }, 2000);

    } catch (err: any) {
      console.error('Erro ao enviar comprovação:', err);
      setError(err.message || 'Não foi possível enviar a comprovação');
    } finally {
      setSubmitting(false);
    }
  }

  if (showCamera) {
    return (
      <UniversalAntiCheatVerification
        userId={userId}
        exerciseName={challenge?.dish.name || 'Desafio de Nutrição'}
        onPhotoVerified={handlePhotoTaken}
        onBack={() => setShowCamera(false)}
        singlePhotoMode={true}
      />
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Desafio da Nutrição</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: theme.accent }} />
        </div>
      </div>
    );
  }

  if (error || !challenge) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Desafio da Nutrição</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="rounded-2xl p-8 text-center max-w-md border" style={{ ...styles.card, ...styles.border }}>
            <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: theme.error }} />
            <h2 className="text-2xl font-bold mb-2" style={styles.textPrimary}>Ops! Algo deu errado</h2>
            <p className="mb-6" style={styles.textSecondary}>{error || 'Não foi possível carregar o desafio'}</p>
            <button
              onClick={loadChallenge}
              className="w-full py-3 rounded-xl font-semibold transition-all active:scale-95"
              style={styles.accent}
            >
              Tentar novamente
            </button>
          </div>
        </div>
      </div>
    );
  }

  const isExpired = timeRemaining === 'Expirado';
  const hasSubmitted = !!challenge.user_submission;

  if (capturedPhoto && !hasSubmitted) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={() => setCapturedPhoto(null)} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Confirmar Envio</h1>
            <div className="w-10" />
          </div>
        </div>

        <div className="flex-1 flex flex-col p-6">
          <div className="flex-1 flex items-center justify-center mb-6">
            <img
              src={capturedPhoto}
              alt="Foto capturada"
              className="max-w-full max-h-96 rounded-2xl object-cover"
            />
          </div>

          <button
            onClick={handleSubmitProof}
            disabled={submitting}
            className="w-full py-4 rounded-xl font-bold text-lg transition-all active:scale-95 flex items-center justify-center gap-2"
            style={submitting ? { ...styles.accent, opacity: 0.6 } : { ...styles.accent, backgroundColor: theme.success }}
          >
            {submitting ? 'Enviando...' : 'Enviar Comprovação'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="p-2 rounded-lg">
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>Prato do Dia</h1>
          <div className="w-10" />
        </div>
      </div>

      {error && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.error, ...styles.border }}>
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium flex-1">{error}</p>
          <button onClick={() => setError(null)} className="p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.success, ...styles.border }}>
          <Check className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">{success}</p>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-2" style={styles.textPrimary}>
            {challenge.dish.name}
          </h2>
          <p className="text-sm" style={styles.textSecondary}>
            Faça este prato e envie uma foto para ganhar pontos!
          </p>
        </div>

        <div className="rounded-2xl overflow-hidden border" style={{ ...styles.card, ...styles.border }}>
          <div className="relative w-full aspect-video">
            <img
              src={challenge.dish.image_url}
              alt={challenge.dish.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800';
              }}
            />
          </div>
        </div>

        <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
          <h3 className="text-xl font-bold mb-4" style={styles.textPrimary}>Ingredientes</h3>
          <ul className="space-y-2">
            {challenge.dish.ingredients.map((ingredient, idx) => (
              <li key={idx} className="flex items-start gap-3">
                <span className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{ backgroundColor: theme.accent }} />
                <span style={styles.textSecondary}>{ingredient}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
          <h3 className="text-xl font-bold mb-4" style={styles.textPrimary}>Modo de Preparo</h3>
          <ol className="space-y-3">
            {challenge.dish.preparation_steps.map((step, idx) => (
              <li key={idx} className="flex gap-3">
                <span className="font-bold flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-sm"
                      style={{ backgroundColor: theme.accent, color: theme.textInverse }}>
                  {idx + 1}
                </span>
                <span style={styles.textSecondary}>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="rounded-2xl p-6 border text-center" style={{ ...styles.card, ...styles.border }}>
          <Clock className="w-12 h-12 mx-auto mb-3" style={styles.accentText} />
          <h3 className="text-lg font-bold mb-2" style={styles.textPrimary}>Tempo Restante</h3>
          <div className="text-4xl font-bold mb-2" style={isExpired ? { color: theme.error } : styles.accentText}>
            {timeRemaining}
          </div>
          <p className="text-sm" style={styles.textSecondary}>
            {isExpired ? 'Desafio expirado' : 'Envie sua foto antes do tempo acabar'}
          </p>
        </div>

        <div className="rounded-xl p-4 border text-center" style={{ ...styles.card, ...styles.border, backgroundColor: `${theme.accent}10` }}>
          <p className="font-bold text-lg" style={styles.accentText}>
            +{challenge.points_reward} pontos disponíveis
          </p>
        </div>

        {hasSubmitted ? (
          <div className="p-6 rounded-xl border text-center" style={{ ...styles.success, ...styles.border }}>
            <Check className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-xl font-bold mb-2">Foto Enviada!</h3>
            <p className="mb-2">+{challenge.user_submission?.points_earned} pontos creditados</p>
            <p className="text-sm opacity-75">Parabéns! Volte amanhã para um novo desafio</p>
          </div>
        ) : !isExpired ? (
          <button
            onClick={() => setShowCamera(true)}
            className="w-full py-4 rounded-xl font-bold text-lg transition-all active:scale-95 flex items-center justify-center gap-2"
            style={styles.accent}
          >
            <Camera className="w-6 h-6" />
            Enviar Foto
          </button>
        ) : (
          <div className="w-full py-4 rounded-xl font-semibold text-center border"
               style={{ backgroundColor: theme.border, color: theme.textSecondary, ...styles.border }}>
            Desafio expirado – Volte amanhã!
          </div>
        )}
      </div>
    </div>
  );
}
