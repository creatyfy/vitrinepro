import React, { useState } from 'react';
import { ChevronLeft, Image, Clock, CheckCircle, XCircle, AlertCircle, Camera } from 'lucide-react';

interface ProofHistoryScreenProps {
  isDarkMode: boolean;
  onBack: () => void;
}

interface Proof {
  id: string;
  photoUrl: string;
  status: 'pending' | 'approved' | 'rejected' | 'manual_review';
  date: string;
  provisionalPoints: number;
  finalPoints?: number;
  challengeCode: string;
  gesture: string;
  rejectionReason?: string;
  autoChecks: {
    challengeValid: boolean;
    gestureMatched: boolean;
    notDuplicate: boolean;
    movementDetected: boolean;
    timestampValid: boolean;
  };
  confidenceScores: {
    gesture: number;
    overall: number;
  };
  resubmissionCount: number;
}

export default function ProofHistoryScreen({ isDarkMode, onBack }: ProofHistoryScreenProps) {
  const [selectedProof, setSelectedProof] = useState<Proof | null>(null);

  // Mock data - in real app, fetch from Supabase
  const proofs: Proof[] = [
    {
      id: '1',
      photoUrl: '/6.jpg',
      status: 'approved',
      date: '2025-10-01 18:30',
      provisionalPoints: 100,
      finalPoints: 100,
      challengeCode: 'A7X2',
      gesture: 'joinha',
      autoChecks: {
        challengeValid: true,
        gestureMatched: true,
        notDuplicate: true,
        movementDetected: true,
        timestampValid: true
      },
      confidenceScores: {
        gesture: 0.95,
        overall: 0.92
      },
      resubmissionCount: 0
    },
    {
      id: '2',
      photoUrl: '/6.jpg',
      status: 'pending',
      date: '2025-10-01 16:15',
      provisionalPoints: 100,
      challengeCode: 'B3M9',
      gesture: 'sorriso',
      autoChecks: {
        challengeValid: true,
        gestureMatched: true,
        notDuplicate: true,
        movementDetected: true,
        timestampValid: true
      },
      confidenceScores: {
        gesture: 0.88,
        overall: 0.85
      },
      resubmissionCount: 0
    },
    {
      id: '3',
      photoUrl: '/6.jpg',
      status: 'rejected',
      date: '2025-09-30 14:45',
      provisionalPoints: 100,
      finalPoints: 5,
      challengeCode: 'Q5T1',
      gesture: 'mao_no_queixo',
      rejectionReason: 'Gesto não correspondente detectado. Confidence: 0.32',
      autoChecks: {
        challengeValid: true,
        gestureMatched: false,
        notDuplicate: true,
        movementDetected: true,
        timestampValid: true
      },
      confidenceScores: {
        gesture: 0.32,
        overall: 0.45
      },
      resubmissionCount: 1
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'green';
      case 'pending': return 'yellow';
      case 'rejected': return 'red';
      case 'manual_review': return 'orange';
      default: return 'gray';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'approved': return 'Aprovada';
      case 'pending': return 'Pendente';
      case 'rejected': return 'Rejeitada';
      case 'manual_review': return 'Em Revisão';
      default: return 'Desconhecido';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-5 h-5" />;
      case 'pending': return <Clock className="w-5 h-5" />;
      case 'rejected': return <XCircle className="w-5 h-5" />;
      case 'manual_review': return <AlertCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const getGestureLabel = (gesture: string) => {
    const labels: Record<string, string> = {
      joinha: 'Joinha 👍',
      sorriso: 'Sorriso 😊',
      serio: 'Sério 😐',
      mao_no_queixo: 'Mão no Queixo',
      lingua_de_fora: 'Língua de Fora 😛'
    };
    return labels[gesture] || gesture;
  };

  if (selectedProof) {
    const statusColor = getStatusColor(selectedProof.status);

    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white'}`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={() => setSelectedProof(null)} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
          <h1 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Detalhes da Prova</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6 pb-8">
          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl overflow-hidden mb-6`}>
            <img
              src={selectedProof.photoUrl}
              alt="Proof"
              className="w-full h-64 object-cover"
            />
          </div>

          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 mb-4`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Status</h3>
              <div className={`flex items-center bg-${statusColor}-500 bg-opacity-20 px-4 py-2 rounded-full`}>
                <span className={`text-${statusColor}-600 mr-2`}>{getStatusIcon(selectedProof.status)}</span>
                <span className={`text-${statusColor}-600 font-semibold`}>{getStatusLabel(selectedProof.status)}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Data</span>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {selectedProof.date}
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Pontos Provisórios</span>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  +{selectedProof.provisionalPoints}
                </span>
              </div>
              {selectedProof.finalPoints !== undefined && (
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Pontos Finais</span>
                  <span className={`font-semibold ${selectedProof.finalPoints < selectedProof.provisionalPoints ? 'text-red-500' : 'text-green-500'}`}>
                    {selectedProof.finalPoints > 0 ? '+' : ''}{selectedProof.finalPoints}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 mb-4`}>
            <h3 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>Desafio</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Código</span>
                <span className={`font-mono font-bold text-xl ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {selectedProof.challengeCode}
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Gesto</span>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {getGestureLabel(selectedProof.gesture)}
                </span>
              </div>
            </div>
          </div>

          <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 mb-4`}>
            <h3 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
              Análise Automática
            </h3>
            <div className="space-y-3">
              {Object.entries(selectedProof.autoChecks).map(([key, value]) => {
                const labels: Record<string, string> = {
                  challengeValid: 'Código Válido',
                  gestureMatched: 'Gesto Correspondente',
                  notDuplicate: 'Foto Original',
                  movementDetected: 'Movimento Detectado',
                  timestampValid: 'Timestamp Válido'
                };

                return (
                  <div key={key} className="flex items-center justify-between">
                    <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      {labels[key]}
                    </span>
                    <span className={value ? 'text-green-500' : 'text-red-500'}>
                      {value ? '✓' : '✗'}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 pt-4 border-t border-gray-700">
              <div className="flex justify-between mb-2">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                  Confidence Gesto
                </span>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {(selectedProof.confidenceScores.gesture * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                  Score Geral
                </span>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {(selectedProof.confidenceScores.overall * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          </div>

          {selectedProof.rejectionReason && (
            <div className="bg-red-500 bg-opacity-20 rounded-2xl p-6 mb-4">
              <h3 className="text-lg font-bold text-red-600 mb-2">Motivo da Rejeição</h3>
              <p className="text-red-700">{selectedProof.rejectionReason}</p>
            </div>
          )}

          {selectedProof.status === 'rejected' && selectedProof.resubmissionCount < 3 && (
            <button className="w-full bg-blue-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-blue-600 transition-colors flex items-center justify-center">
              <Camera className="w-6 h-6 mr-2" />
              Reenviar Nova Prova
            </button>
          )}
        </div>

        <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white'}`}>
      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Minhas Provas</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6 pb-8">
        <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 mb-6`}>
          <h2 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
            Histórico de Verificações
          </h2>
          <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
            Acompanhe o status das suas provas de treino
          </p>
        </div>

        <div className="space-y-4">
          {proofs.map((proof) => {
            const statusColor = getStatusColor(proof.status);

            return (
              <div
                key={proof.id}
                onClick={() => setSelectedProof(proof)}
                className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-4 cursor-pointer hover:scale-[1.02] transition-transform`}
              >
                <div className="flex items-center">
                  <div className="relative">
                    <img
                      src={proof.photoUrl}
                      alt="Proof thumbnail"
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    <div className={`absolute -top-2 -right-2 bg-${statusColor}-500 rounded-full p-1`}>
                      {getStatusIcon(proof.status)}
                    </div>
                  </div>

                  <div className="flex-1 ml-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        {getStatusLabel(proof.status)}
                      </span>
                      <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        {proof.date.split(' ')[0]}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Código: {proof.challengeCode}
                      </span>
                      <span className={`font-semibold ${proof.finalPoints !== undefined && proof.finalPoints < proof.provisionalPoints ? 'text-red-500' : 'text-green-500'}`}>
                        {proof.finalPoints !== undefined ? `+${proof.finalPoints}` : `+${proof.provisionalPoints} (prov)`}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}
