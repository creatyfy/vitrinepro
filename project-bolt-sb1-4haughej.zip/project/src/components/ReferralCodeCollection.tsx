import React, { useState } from 'react';
import { ChevronLeft } from 'lucide-react';

interface ReferralCodeCollectionProps {
  referralCode: string;
  onReferralCodeChange: (code: string) => void;
  onNext: () => void;
  onSkip: () => void;
  onBack: () => void;
}

export default function ReferralCodeCollection({ 
  referralCode, 
  onReferralCodeChange, 
  onNext, 
  onSkip,
  onBack 
}: ReferralCodeCollectionProps) {
  const [inputValue, setInputValue] = useState(referralCode);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    onReferralCodeChange(value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  const handleSkip = () => {
    onSkip();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">FitCal</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '100%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
            Você tem um código de indicação?
          </h1>
          <p className="text-gray-500 text-lg">
            Você pode pular esta etapa
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <label htmlFor="referralCode" className="block text-lg font-semibold text-gray-900 mb-4">
              Código de Indicação
            </label>
            <input
              type="text"
              id="referralCode"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Código de Indicação"
              className="w-full px-6 py-4 text-lg bg-gray-100 border-0 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all duration-200"
              autoFocus
            />
          </div>
        </form>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8 space-y-4">
        <button
          onClick={handleSubmit}
          className="w-full bg-gray-900 text-white py-4 rounded-2xl font-semibold text-lg hover:bg-gray-800 transition-colors duration-200 active:scale-95 transform"
        >
          Continuar
        </button>
        
        {/* Skip Button */}
        <button
          onClick={handleSkip}
          className="w-full text-gray-600 py-2 font-medium text-lg hover:text-gray-800 transition-colors duration-200"
        >
          Pular esta etapa
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}