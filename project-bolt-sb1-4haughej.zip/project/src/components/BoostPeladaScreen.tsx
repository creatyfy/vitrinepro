import React, { useState } from 'react';
import { ChevronLeft, Zap, Crown, Award, Users, Eye, Bell, MapPin, Clock, CheckCircle, CreditCard, Trophy } from 'lucide-react';
import CardPaymentForm, { CardData } from './CardPaymentForm';

interface BoostPeladaScreenProps {
  pelada: any;
  onBack: () => void;
  onBoostComplete: () => void;
}

export default function BoostPeladaScreen({ pelada, onBack, onBoostComplete }: BoostPeladaScreenProps) {
  const [selectedPlan, setSelectedPlan] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('pix');
  const [cardData, setCardData] = useState<CardData | null>(null);
  const [isCardValid, setIsCardValid] = useState(false);

  const boostPlans = [
    {
      id: 'bronze',
      name: 'Bronze',
      icon: Zap,
      color: 'from-orange-400 to-orange-500',
      borderColor: 'border-orange-500',
      price: 9.90,
      duration: '6 horas',
      features: [
        'Destaque por 6 horas',
        'Aparece no topo da lista',
        'Badge "Turbinado"',
        'Alcance +50% na região'
      ],
      reach: '+50%',
      badge: 'BRONZE'
    },
    {
      id: 'prata',
      name: 'Prata',
      icon: Crown,
      color: 'from-gray-400 to-gray-500',
      borderColor: 'border-gray-500',
      price: 19.90,
      duration: '24 horas',
      features: [
        'Destaque por 24 horas',
        'Prioridade máxima na lista',
        'Badge "Prata"',
        'Alcance +100% na região',
        'Notificação para usuários próximos'
      ],
      reach: '+100%',
      badge: 'PRATA',
      popular: true
    },
    {
      id: 'ouro',
      name: 'Ouro',
      icon: Award,
      color: 'from-yellow-400 to-yellow-500',
      borderColor: 'border-yellow-500',
      price: 39.90,
      duration: '3 dias',
      features: [
        'Destaque por 3 dias completos',
        'Posição #1 garantida',
        'Badge "Ouro"',
        'Alcance +200% na região',
        'Push notification no celular',
        'Email marketing para usuários',
        'Destaque nas redes sociais'
      ],
      reach: '+200%',
      badge: 'OURO',
      premium: true
    }
  ];

  const paymentMethods = [
    { id: 'pix', name: 'PIX', discount: 10, icon: '💳' },
    { id: 'credit', name: 'Cartão de Crédito', discount: 0, icon: '💳' },
    { id: 'debit', name: 'Cartão de Débito', discount: 0, icon: '💳' }
  ];

  const calculatePrice = (basePrice: number) => {
    const selectedPaymentMethod = paymentMethods.find(p => p.id === paymentMethod);
    const discount = selectedPaymentMethod?.discount || 0;
    return basePrice * (1 - discount / 100);
  };

  const handleCardDataChange = (data: CardData) => {
    setCardData(data);
    const cardDataWithValidation = data as CardData & { isValid?: boolean };
    setIsCardValid(cardDataWithValidation.isValid || false);
  };

  const canBoostPurchase = () => {
    if (!selectedPlan) return false;
    if (paymentMethod === 'credit' || paymentMethod === 'debit') {
      return isCardValid;
    }
    return true;
  };

  const handleBoostPurchase = () => {
    const selectedPlanData = boostPlans.find(p => p.id === selectedPlan);
    if (!selectedPlanData) return;

    if (!canBoostPurchase()) {
      alert('Por favor, preencha todos os dados do cartão corretamente.');
      return;
    }

    if (paymentMethod === 'credit' || paymentMethod === 'debit') {
      console.log('Processando pagamento com cartão:', cardData);
    }

    console.log('Processando turbinação:', {
      plan: selectedPlan,
      price: calculatePrice(selectedPlanData.price),
      paymentMethod,
      pelada: pelada.title
    });

    setTimeout(() => {
      alert(`🚀 Evento turbinado com sucesso! Seu evento agora tem destaque ${selectedPlanData.badge}.`);
      onBoostComplete();
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-white">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Turbinar Evento</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Alcance Mais Pessoas</h2>
          <p className="text-gray-600">Turbine seu evento e garanta mais participantes</p>
        </div>

        {/* Event Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border mb-8">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mr-3">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{pelada.title}</h3>
              <p className="text-sm text-gray-600">{pelada.date} • {pelada.time}</p>
            </div>
          </div>
        </div>

        {/* Boost Plans */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Escolha seu Plano</h3>
          <div className="space-y-4">
            {boostPlans.map((plan) => {
              const IconComponent = plan.icon;
              const isSelected = selectedPlan === plan.id;
              
              return (
                <button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`w-full p-6 rounded-2xl border-2 transition-all duration-200 relative ${
                    isSelected 
                      ? `${plan.borderColor} bg-gradient-to-r ${plan.color} text-white` 
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  {/* Popular Badge */}
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-xs font-bold">
                      MAIS POPULAR
                    </div>
                  )}
                  
                  {/* Premium Badge */}
                  {plan.premium && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-500 text-white px-4 py-1 rounded-full text-xs font-bold">
                      PREMIUM
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mr-4 ${
                        isSelected ? 'bg-white/20' : 'bg-gray-100'
                      }`}>
                        <IconComponent className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-gray-600'}`} />
                      </div>
                      <div className="text-left">
                        <h4 className={`text-xl font-bold ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                          {plan.name}
                        </h4>
                        <p className={`text-sm ${isSelected ? 'text-white/80' : 'text-gray-600'}`}>
                          Destaque por {plan.duration}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                        R$ {plan.price.toFixed(2).replace('.', ',')}
                      </div>
                      <div className={`text-sm ${isSelected ? 'text-white/80' : 'text-gray-600'}`}>
                        Alcance {plan.reach}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center">
                        <CheckCircle className={`w-4 h-4 mr-2 ${isSelected ? 'text-white' : 'text-green-500'}`} />
                        <span className={`text-sm ${isSelected ? 'text-white' : 'text-gray-700'}`}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Payment Method */}
        {selectedPlan && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Forma de Pagamento</h3>
            <div className="space-y-3">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id)}
                  className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                    paymentMethod === method.id
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{method.icon}</span>
                      <span className="font-medium text-gray-900">{method.name}</span>
                    </div>
                    {method.discount > 0 && (
                      <span className="text-green-600 font-bold text-sm">
                        -{method.discount}%
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Card Payment Form */}
        {selectedPlan && (paymentMethod === 'credit' || paymentMethod === 'debit') && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-8">
            <CardPaymentForm
              onCardDataChange={handleCardDataChange}
              isValid={isCardValid}
            />
          </div>
        )}

        {/* Order Summary */}
        {selectedPlan && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-24">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Plano {boostPlans.find(p => p.id === selectedPlan)?.name}</span>
                <span className="font-medium text-gray-900">
                  R$ {boostPlans.find(p => p.id === selectedPlan)?.price.toFixed(2).replace('.', ',')}
                </span>
              </div>
              
              {paymentMethod === 'pix' && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Desconto PIX (10%)</span>
                  <span className="font-medium text-green-600">
                    -R$ {((boostPlans.find(p => p.id === selectedPlan)?.price || 0) * 0.1).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              )}
              
              <div className="border-t border-gray-200 pt-3">
                <div className="flex justify-between">
                  <span className="text-lg font-semibold text-gray-900">Total</span>
                  <span className="text-xl font-bold text-gray-900">
                    R$ {calculatePrice(boostPlans.find(p => p.id === selectedPlan)?.price || 0).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Fixed Bottom */}
      {selectedPlan && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-6">
          <button
            onClick={handleBoostPurchase}
            disabled={!canBoostPurchase()}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-colors duration-200 active:scale-95 flex items-center justify-center ${
              canBoostPurchase()
                ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white hover:from-yellow-600 hover:to-yellow-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Zap className="w-5 h-5 mr-2" />
            Turbinar por R$ {calculatePrice(boostPlans.find(p => p.id === selectedPlan)?.price || 0).toFixed(2).replace('.', ',')}
          </button>
        </div>
      )}

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}