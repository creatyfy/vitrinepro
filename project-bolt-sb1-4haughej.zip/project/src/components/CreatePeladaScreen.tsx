import React, { useState } from 'react';
import { ChevronLeft, MapPin, Calendar, Clock, Users, Trophy, Target, Zap, DollarSign, Phone, MessageCircle } from 'lucide-react';

interface CreatePeladaScreenProps {
  onBack: () => void;
  userType: 'atleta' | 'clube' | 'empresario';
  userName: string;
  onPeladaCreated: (pelada: any) => void;
  onBoostPelada: (peladaData: any) => void;
}

export default function CreatePeladaScreen({ 
  onBack, 
  userType, 
  userName, 
  onPeladaCreated,
  onBoostPelada 
}: CreatePeladaScreenProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'pelada', // 'pelada' ou 'torneio'
    date: '',
    time: '',
    duration: '',
    location: '',
    maxPlayers: 22,
    price: '',
    level: 'todos',
    field: 'society',
    amenities: [] as string[],
    contact: '',
    whatsapp: '',
    prize: ''
  });

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const eventTypes = [
    { id: 'pelada', label: 'Pelada/Rachão', icon: Users, description: 'Jogo casual entre amigos' },
    { id: 'torneio', label: 'Torneio', icon: Trophy, description: 'Competição organizada com premiação' }
  ];

  const levels = [
    { id: 'todos', label: 'Todos os níveis' },
    { id: 'iniciante', label: 'Iniciante' },
    { id: 'intermediario', label: 'Intermediário' },
    { id: 'avancado', label: 'Avançado' }
  ];

  const fieldTypes = [
    { id: 'society', label: 'Society' },
    { id: 'campo', label: 'Campo' },
    { id: 'quadra', label: 'Quadra' },
    { id: 'areia', label: 'Areia' }
  ];

  const availableAmenities = [
    'Vestiário', 'Estacionamento', 'Lanchonete', 'Água', 'Iluminação', 
    'Arbitragem', 'Troféus', 'Chuveiro', 'Segurança', 'Som'
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleCreateEvent = () => {
    const newPelada = {
      ...formData,
      id: Date.now(),
      organizer: userName,
      organizerType: userType,
      organizerPhoto: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      currentPlayers: 1,
      status: 'aberta',
      boosted: false,
      boostLevel: null,
      distance: '0 km',
      rating: 0,
      reviews: 0,
      image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      participants: []
    };

    onPeladaCreated(newPelada);
  };

  const handleBoostEvent = () => {
    const peladaData = {
      ...formData,
      organizer: userName,
      organizerType: userType
    };
    onBoostPelada(peladaData);
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.description && formData.type;
      case 2:
        return formData.date && formData.time && formData.location;
      case 3:
        return formData.maxPlayers && formData.level && formData.field;
      case 4:
        return formData.contact;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={currentStep === 1 ? onBack : handlePrevious} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Criar Evento</h1>
        <div className="text-sm text-gray-500">
          {currentStep}/{totalSteps}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="px-6 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-green-500 h-2 rounded-full transition-all duration-300" 
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
      </div>

      <div className="px-6">
        {/* Step 1: Basic Info */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Informações Básicas</h2>
              <p className="text-gray-600">Conte-nos sobre seu evento</p>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Tipo de Evento</label>
              <div className="grid grid-cols-2 gap-4">
                {eventTypes.map((type) => {
                  const IconComponent = type.icon;
                  return (
                    <button
                      key={type.id}
                      onClick={() => handleInputChange('type', type.id)}
                      className={`p-4 rounded-2xl border-2 transition-all duration-200 ${
                        formData.type === type.id
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <IconComponent className={`w-8 h-8 mx-auto mb-2 ${
                        formData.type === type.id ? 'text-green-600' : 'text-gray-600'
                      }`} />
                      <div className="text-sm font-semibold text-gray-900">{type.label}</div>
                      <div className="text-xs text-gray-600">{type.description}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Título do Evento</label>
              <input
                type="text"
                placeholder="Ex: Pelada do Domingo - Ibirapuera"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Descrição</label>
              <textarea
                placeholder="Descreva seu evento, nível de jogo, ambiente..."
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        )}

        {/* Step 2: Date, Time & Location */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Data e Local</h2>
              <p className="text-gray-600">Quando e onde será o evento?</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Data</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  min="2025-01-01"
                  max="2099-12-31"
                  className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Horário</label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => handleInputChange('time', e.target.value)}
                  className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Duração</label>
              <select
                value={formData.duration}
                onChange={(e) => handleInputChange('duration', e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="">Selecione a duração</option>
                <option value="1 hora">1 hora</option>
                <option value="1.5 horas">1.5 horas</option>
                <option value="2 horas">2 horas</option>
                <option value="3 horas">3 horas</option>
                <option value="4 horas">4 horas</option>
                <option value="6 horas">6 horas (Torneio)</option>
                <option value="8 horas">8 horas (Torneio)</option>
              </select>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Local</label>
              <input
                type="text"
                placeholder="Endereço completo do local"
                value={formData.location}
                onChange={(e) => handleInputChange('location', e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        )}

        {/* Step 3: Game Details */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Detalhes do Jogo</h2>
              <p className="text-gray-600">Configure as regras e estrutura</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Máx. Participantes</label>
                <input
                  type="number"
                  placeholder="22"
                  value={formData.maxPlayers}
                  onChange={(e) => handleInputChange('maxPlayers', parseInt(e.target.value))}
                  className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Valor por Pessoa</label>
                <input
                  type="text"
                  placeholder="R$ 15,00 ou Gratuito"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Nível de Jogo</label>
              <div className="grid grid-cols-2 gap-3">
                {levels.map((level) => (
                  <button
                    key={level.id}
                    onClick={() => handleInputChange('level', level.id)}
                    className={`p-3 rounded-xl border-2 transition-all duration-200 ${
                      formData.level === level.id
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700'
                    }`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Tipo de Campo</label>
              <div className="grid grid-cols-2 gap-3">
                {fieldTypes.map((field) => (
                  <button
                    key={field.id}
                    onClick={() => handleInputChange('field', field.id)}
                    className={`p-3 rounded-xl border-2 transition-all duration-200 ${
                      formData.field === field.id
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700'
                    }`}
                  >
                    {field.label}
                  </button>
                ))}
              </div>
            </div>

            {formData.type === 'torneio' && (
              <div>
                <label className="block text-lg font-semibold text-gray-900 mb-3">Premiação</label>
                <input
                  type="text"
                  placeholder="Ex: R$ 500 para o campeão + Troféu"
                  value={formData.prize}
                  onChange={(e) => handleInputChange('prize', e.target.value)}
                  className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            )}

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Comodidades Disponíveis</label>
              <div className="grid grid-cols-2 gap-2">
                {availableAmenities.map((amenity) => (
                  <button
                    key={amenity}
                    onClick={() => handleAmenityToggle(amenity)}
                    className={`p-3 rounded-xl border transition-all duration-200 text-sm ${
                      formData.amenities.includes(amenity)
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700'
                    }`}
                  >
                    {amenity}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Contact & Finish */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Contato</h2>
              <p className="text-gray-600">Como os participantes podem te encontrar?</p>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Telefone/WhatsApp</label>
              <input
                type="tel"
                placeholder="(11) 99999-9999"
                value={formData.contact}
                onChange={(e) => handleInputChange('contact', e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">Link do WhatsApp (opcional)</label>
              <input
                type="url"
                placeholder="https://wa.me/5511999999999"
                value={formData.whatsapp}
                onChange={(e) => handleInputChange('whatsapp', e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            {/* Event Summary */}
            <div className="bg-white rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo do Evento</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Tipo:</span>
                  <span className="font-medium text-gray-900 capitalize">{formData.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Data:</span>
                  <span className="font-medium text-gray-900">{formData.date} às {formData.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duração:</span>
                  <span className="font-medium text-gray-900">{formData.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Participantes:</span>
                  <span className="font-medium text-gray-900">{formData.maxPlayers} pessoas</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Valor:</span>
                  <span className="font-medium text-gray-900">{formData.price || 'Gratuito'}</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <button
                onClick={handleCreateEvent}
                className="w-full bg-green-500 text-white py-4 rounded-xl font-semibold text-lg hover:bg-green-600 transition-colors"
              >
                Publicar Evento
              </button>
              
              <button
                onClick={handleBoostEvent}
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 text-white py-4 rounded-xl font-semibold text-lg hover:from-yellow-600 hover:to-yellow-700 transition-colors flex items-center justify-center"
              >
                <Zap className="w-5 h-5 mr-2" />
                Turbinar Evento
              </button>
              
              <p className="text-center text-gray-500 text-sm">
                Turbine seu evento para alcançar mais pessoas e garantir mais participantes!
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Buttons */}
      {currentStep < 4 && (
        <div className="px-6 pb-8">
          <button
            onClick={handleNext}
            disabled={!canProceed()}
            className={`w-full py-4 rounded-xl font-semibold text-lg transition-all duration-200 ${
              canProceed()
                ? 'bg-green-500 text-white hover:bg-green-600 active:scale-95'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Continuar
          </button>
        </div>
      )}

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}