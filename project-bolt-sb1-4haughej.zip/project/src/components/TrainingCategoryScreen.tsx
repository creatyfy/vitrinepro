import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Play, Clock, Star, ChevronRight, Pause, SkipForward, CheckCircle, Trophy, Target, Flame, Award, Camera, Shield, AlertTriangle, ArrowLeft } from 'lucide-react';
import PauseOverlay from './PauseOverlay';
import ResumeTrainingModal from './ResumeTrainingModal';
import { trainingTopics, type Training } from '../data/trainingData';
import { Challenge, generateChallenge, isChallengeExpired, getGestureLabel, calculatePhash, isDuplicatePhoto, calculateMovementScore, calculateRiskScore, getPointsMultiplier } from '../utils/antiCheat';
import { useMotionSensor } from '../hooks/useMotionSensor';
import { saveTrainingProgress, getTrainingProgress, deleteTrainingProgress, TrainingProgress } from '../utils/trainingProgress';

interface TrainingCategoryScreenProps {
  categoryId: string;
  isDarkMode: boolean;
  onBack: () => void;
  onStartTraining: (training: Training) => void;
}

interface TrainingSession {
  training: Training;
  currentExerciseIndex: number;
  totalPoints: number;
  startTime: Date;
  submittedProof: boolean;
  riskScore: number;
  photoHashes: string[];
}

export default function TrainingCategoryScreen({
  categoryId,
  isDarkMode,
  onBack,
  onStartTraining
}: TrainingCategoryScreenProps) {
  const [currentView, setCurrentView] = useState<'selection' | 'detail' | 'preroll' | 'exercise' | 'rest' | 'proof' | 'completion'>('selection');
  const [selectedTraining, setSelectedTraining] = useState<Training | null>(null);
  const [trainingSession, setTrainingSession] = useState<TrainingSession | null>(null);
  const [prerollTime, setPrerollTime] = useState(10);
  const [prerollCountdown, setPrerollCountdown] = useState(10);
  const [isPrerollRunning, setIsPrerollRunning] = useState(false);
  const [timer, setTimer] = useState(20);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [restTimer, setRestTimer] = useState(10);
  const [isRestTimerRunning, setIsRestTimerRunning] = useState(false);
  const [capturedMedia, setCapturedMedia] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [currentChallenge, setCurrentChallenge] = useState<Challenge | null>(null);
  const [challengeTimeLeft, setChallengeTimeLeft] = useState(60);
  const [isDuplicateWarning, setIsDuplicateWarning] = useState(false);
  const [showPauseOverlay, setShowPauseOverlay] = useState(false);
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [savedProgress, setSavedProgress] = useState<TrainingProgress | null>(null);
  const { movementData, resetMovementData } = useMotionSensor(currentView === 'exercise' && isTimerRunning);

  const category = trainingTopics.find(t => t.id === categoryId);

  useEffect(() => {
    const checkForSavedProgress = async () => {
      const progress = await getTrainingProgress('category', categoryId);
      if (progress) {
        setSavedProgress(progress);
        setShowResumeModal(true);
      }
    };
    checkForSavedProgress();
  }, [categoryId]);

  useEffect(() => {
    if (currentView === 'exercise' && trainingSession) {
      const interval = setInterval(async () => {
        await saveTrainingProgress({
          training_type: 'category',
          training_id: categoryId,
          exercise_id: trainingSession.training.id,
          current_exercise_index: trainingSession.currentExerciseIndex,
          total_exercises: 1,
          timer_remaining: timer,
          is_resting: false,
          rest_timer_remaining: 0,
          progress_data: {
            categoryId,
            categoryName: category?.name || '',
            exerciseName: trainingSession.training.title
          }
        });
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [currentView, trainingSession, timer, categoryId, category]);

  if (!category) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-white'} flex items-center justify-center`}>
        <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          Categoria não encontrada
        </div>
      </div>
    );
  }

  const startTrainingSession = (training: Training) => {
    setTrainingSession({
      training,
      currentExerciseIndex: 0,
      totalPoints: 0,
      startTime: new Date(),
      submittedProof: false,
      riskScore: 0,
      photoHashes: []
    });
    resetMovementData();
    setCurrentView('exercise');
    setTimer(20);
    setIsTimerRunning(true);
  };

  const handlePauseTraining = () => {
    setIsTimerRunning(false);
    setShowPauseOverlay(true);
  };

  const handleResumeTraining = () => {
    setShowPauseOverlay(false);
    setIsTimerRunning(true);
  };

  const handleRestartExercise = () => {
    setTimer(20);
    setShowPauseOverlay(false);
    setIsTimerRunning(true);
  };

  const handleExitFromPause = async () => {
    setShowPauseOverlay(false);
    setCurrentView('selection');
    setTrainingSession(null);
  };

  const handleResumeFromSaved = () => {
    if (!savedProgress) return;

    const allTrainings = [
      ...category.trainings.academia,
      ...category.trainings.arLivre,
      ...category.trainings.equipamentosSimples
    ];
    const training = allTrainings.find(t => t.id === savedProgress.exercise_id);
    if (!training) return;

    setTrainingSession({
      training,
      currentExerciseIndex: savedProgress.current_exercise_index,
      totalPoints: 0,
      startTime: new Date(),
      submittedProof: false,
      riskScore: 0,
      photoHashes: []
    });

    setTimer(savedProgress.timer_remaining || 20);
    setCurrentView('exercise');
    setIsTimerRunning(true);
    setShowResumeModal(false);
    setSavedProgress(null);
  };

  const handleStartNewTraining = async () => {
    if (savedProgress?.id) {
      await deleteTrainingProgress(savedProgress.id);
    }
    setShowResumeModal(false);
    setSavedProgress(null);
  };

  const handleCompleteTraining = async () => {
    if (savedProgress?.id) {
      await deleteTrainingProgress(savedProgress.id);
    }
    setSavedProgress(null);
  };

  const completeExercise = () => {
    if (!trainingSession) return;

    const newPoints = trainingSession.totalPoints + trainingSession.training.points;
    const nextIndex = trainingSession.currentExerciseIndex + 1;

    if (nextIndex >= 1) {
      const challenge = generateChallenge();
      setCurrentChallenge(challenge);
      setChallengeTimeLeft(60);
      setTrainingSession({
        ...trainingSession,
        totalPoints: newPoints
      });
      setCurrentView('proof');
    } else {
      setTrainingSession({
        ...trainingSession,
        currentExerciseIndex: nextIndex,
        totalPoints: newPoints
      });
      setCurrentView('rest');
      setRestTimer(10);
      setIsRestTimerRunning(true);
    }
    setTimer(20);
    setIsTimerRunning(false);
  };

  const skipExercise = () => {
    if (!trainingSession) return;
    const nextIndex = trainingSession.currentExerciseIndex + 1;

    if (nextIndex >= 1) {
      const challenge = generateChallenge();
      setCurrentChallenge(challenge);
      setChallengeTimeLeft(60);
      setCurrentView('proof');
    } else {
      setTrainingSession({
        ...trainingSession,
        currentExerciseIndex: nextIndex
      });
      setCurrentView('rest');
      setRestTimer(10);
      setIsRestTimerRunning(true);
    }
    setTimer(20);
    setIsTimerRunning(false);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const capturePhoto = async () => {
    if (videoRef.current && currentChallenge) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const photoData = canvas.toDataURL('image/jpeg');
        const hash = await calculatePhash(photoData);

        if (trainingSession && isDuplicatePhoto(hash, trainingSession.photoHashes)) {
          setIsDuplicateWarning(true);
          return;
        }

        setCapturedMedia(photoData);
        stopCamera();
      }
    }
  };

  const submitProof = async () => {
    if (trainingSession && capturedMedia && currentChallenge) {
      const provisionalPoints = trainingSession.totalPoints;
      const photoHash = await calculatePhash(capturedMedia);
      const movementScore = calculateMovementScore(movementData);

      const riskScore = calculateRiskScore({
        hasChallengeCode: !isChallengeExpired(currentChallenge),
        gestureMatched: true,
        hasMovement: movementScore > 30,
        timestampValid: true,
        notDuplicate: !isDuplicatePhoto(photoHash, trainingSession.photoHashes),
        hasLocation: false,
        hasQrCode: false
      });

      setTrainingSession({
        ...trainingSession,
        totalPoints: provisionalPoints,
        submittedProof: true,
        riskScore,
        photoHashes: [...trainingSession.photoHashes, photoHash]
      });

      setCapturedMedia(null);
      setCurrentChallenge(null);
      setIsDuplicateWarning(false);
      setCurrentView('completion');
      await handleCompleteTraining();
    }
  };

  const skipProof = () => {
    if (trainingSession) {
      const penalizedPoints = Math.floor(trainingSession.totalPoints * 0.5);
      const riskScore = calculateRiskScore({
        hasChallengeCode: false,
        gestureMatched: false,
        hasMovement: calculateMovementScore(movementData) > 30,
        timestampValid: true,
        notDuplicate: true,
        hasLocation: false,
        hasQrCode: false
      });

      setTrainingSession({
        ...trainingSession,
        totalPoints: penalizedPoints,
        submittedProof: false,
        riskScore
      });

      setCurrentChallenge(null);
      setCurrentView('completion');
      handleCompleteTraining();
    }
  };

  const finishTraining = () => {
    setCurrentView('selection');
    setTrainingSession(null);
    setTimer(20);
    setIsTimerRunning(false);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timer]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRestTimerRunning && restTimer > 0) {
      interval = setInterval(() => {
        setRestTimer(prev => {
          if (prev <= 1) {
            setIsRestTimerRunning(false);
            setCurrentView('exercise');
            setTimer(20);
            setIsTimerRunning(true);
            return 10;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRestTimerRunning, restTimer]);

  useEffect(() => {
    if (currentView === 'proof') {
      startCamera();
    }
    return () => {
      stopCamera();
    };
  }, [currentView]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (currentView === 'proof' && currentChallenge && challengeTimeLeft > 0) {
      interval = setInterval(() => {
        setChallengeTimeLeft(prev => {
          if (prev <= 1) {
            const newChallenge = generateChallenge();
            setCurrentChallenge(newChallenge);
            return 60;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [currentView, currentChallenge, challengeTimeLeft]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPrerollRunning && prerollCountdown > 0) {
      interval = setInterval(() => {
        setPrerollCountdown(prev => {
          if (prev <= 1) {
            setIsPrerollRunning(false);
            if (selectedTraining) {
              startTrainingSession(selectedTraining);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPrerollRunning, prerollCountdown, selectedTraining]);

  const bgClass = isDarkMode ? 'bg-black' : 'bg-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';
  const cardClass = isDarkMode ? 'bg-gray-900' : 'bg-gray-50';

  const trainings = [
    ...category.trainings.academia,
    ...category.trainings.arLivre,
    ...category.trainings.equipamentosSimples
  ];

  // Detail View
  if (currentView === 'detail' && selectedTraining) {
    return (
      <div className={`min-h-screen ${bgClass}`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-between px-6 py-4 mb-6">
          <button onClick={() => { setCurrentView('selection'); setSelectedTraining(null); }} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${textClass}`} />
          </button>
          <h1 className={`text-xl font-bold ${textClass}`}>Detalhes do Treino</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6 pb-8">
          <img
            src={selectedTraining.videoUrl}
            alt={selectedTraining.title}
            className="w-full h-48 rounded-2xl object-cover mb-6"
          />

          <h2 className={`text-2xl font-bold ${textClass} mb-4`}>{selectedTraining.title}</h2>
          <p className={`${secondaryTextClass} mb-6`}>{selectedTraining.description}</p>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className={`${cardClass} rounded-xl p-3 text-center`}>
              <Clock className={`w-5 h-5 ${secondaryTextClass} mx-auto mb-1`} />
              <p className={`text-xs ${secondaryTextClass}`}>Duração</p>
              <p className={`font-bold ${textClass}`}>{selectedTraining.duration}</p>
            </div>
            <div className={`${cardClass} rounded-xl p-3 text-center`}>
              <Target className={`w-5 h-5 ${secondaryTextClass} mx-auto mb-1`} />
              <p className={`text-xs ${secondaryTextClass}`}>Nível</p>
              <p className={`font-bold ${textClass}`}>{selectedTraining.difficulty}</p>
            </div>
            <div className={`${cardClass} rounded-xl p-3 text-center`}>
              <Star className="w-5 h-5 text-yellow-400 fill-current mx-auto mb-1" />
              <p className={`text-xs ${secondaryTextClass}`}>Pontos</p>
              <p className={`font-bold ${textClass}`}>+{selectedTraining.points}</p>
            </div>
          </div>

          <div className={`${cardClass} rounded-2xl p-4 mb-4`}>
            <h3 className={`font-bold ${textClass} mb-3`}>Instruções</h3>
            <div className="space-y-2">
              <p className={secondaryTextClass}><span className={`font-semibold ${textClass}`}>Séries:</span> {selectedTraining.instructions.series}</p>
              <p className={secondaryTextClass}><span className={`font-semibold ${textClass}`}>Repetições:</span> {selectedTraining.instructions.repetitions}</p>
              <p className={secondaryTextClass}><span className={`font-semibold ${textClass}`}>Descanso:</span> {selectedTraining.instructions.rest}</p>
            </div>
          </div>

          <div className={`${cardClass} rounded-2xl p-4 mb-4`}>
            <h3 className={`font-bold ${textClass} mb-3`}>Dicas</h3>
            <ul className="space-y-2">
              {selectedTraining.instructions.tips.map((tip, idx) => (
                <li key={idx} className={`flex items-start ${secondaryTextClass}`}>
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className={`${cardClass} rounded-2xl p-4 mb-6`}>
            <h3 className={`font-bold ${textClass} mb-3`}>Músculos Trabalhados</h3>
            <div className="flex flex-wrap gap-2">
              {selectedTraining.targetMuscles.map((muscle, idx) => (
                <span key={idx} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                  {muscle}
                </span>
              ))}
            </div>
          </div>

        </div>

        <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
      </div>
    );
  }

  // Pre-roll View
  if (currentView === 'preroll' && selectedTraining) {
    return (
      <div className={`min-h-screen ${bgClass} flex flex-col`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-between px-6 py-4">
          <button onClick={() => { setCurrentView('detail'); setIsPrerollRunning(false); }} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${textClass}`} />
          </button>
          <h1 className={`text-lg font-bold ${textClass}`}>Preparação</h1>
          <div className="w-10"></div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="text-center mb-12">
            <div className="text-8xl mb-6">{category?.icon}</div>
            <h2 className={`text-3xl font-bold ${textClass} mb-4`}>
              {selectedTraining.title}
            </h2>
            <p className={`${secondaryTextClass} text-lg mb-8 max-w-md`}>
              Prepare-se, mantenha-se hidratado e foque no seu objetivo
            </p>
          </div>

          <div className={`${cardClass} rounded-3xl p-8 w-full max-w-sm`}>
            <div className="text-center mb-8">
              <div className={`text-8xl font-bold ${textClass} mb-2`}>
                {prerollCountdown}
              </div>
              <div className={`text-sm ${secondaryTextClass} uppercase tracking-wide`}>
                segundos para começar
              </div>
            </div>

            <div className="mb-6">
              <p className={`text-sm ${secondaryTextClass} mb-3 text-center`}>
                Tempo de preparação:
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={() => { setPrerollTime(10); setPrerollCountdown(10); }}
                  className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                    prerollTime === 10
                      ? 'bg-blue-500 text-white scale-105'
                      : isDarkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  10s
                </button>
                <button
                  onClick={() => { setPrerollTime(20); setPrerollCountdown(20); }}
                  className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                    prerollTime === 20
                      ? 'bg-blue-500 text-white scale-105'
                      : isDarkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  20s
                </button>
              </div>
            </div>

            <div className={`${isDarkMode ? 'bg-blue-900/30' : 'bg-blue-50'} rounded-xl p-4 border ${isDarkMode ? 'border-blue-800' : 'border-blue-200'}`}>
              <p className={`text-sm ${isDarkMode ? 'text-blue-300' : 'text-blue-700'} text-center`}>
                O treino iniciará automaticamente quando o contador chegar a zero
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (selectedTraining) {
                startTrainingSession(selectedTraining);
              }
            }}
            className="mt-8 bg-green-500 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-green-600 transition-colors active:scale-95"
          >
            Começar Agora
          </button>
        </div>

        <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
      </div>
    );
  }

  // Exercise View
  if (currentView === 'exercise' && trainingSession) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-700 text-white">
        {showPauseOverlay && (
          <PauseOverlay
            isDarkMode={true}
            currentExercise={trainingSession.currentExerciseIndex + 1}
            totalExercises={1}
            onResume={handleResumeTraining}
            onRestart={handleRestartExercise}
            onExit={handleExitFromPause}
          />
        )}

        <div className="pt-12"></div>

        <div className="absolute top-16 right-6">
          <button
            onClick={handlePauseTraining}
            className="p-3 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 min-h-screen">
          <h1 className="text-3xl font-bold text-white mb-8">
            {trainingSession.training.title}
          </h1>

          <div className="relative w-48 h-48 mb-8">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="rgba(255,255,255,0.3)"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="white"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 90}`}
                strokeDashoffset={`${2 * Math.PI * 90 * (1 - timer / 20)}`}
                className="transition-all duration-1000 ease-linear"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-6xl font-bold text-white">{timer}</span>
            </div>
          </div>

          <p className="text-blue-100 text-center mb-8 max-w-md">
            {trainingSession.training.description}
          </p>

          <div className="flex space-x-4">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="bg-white bg-opacity-20 text-white px-6 py-3 rounded-full font-semibold hover:bg-opacity-30 transition-colors"
            >
              {isTimerRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </button>
            <button
              onClick={completeExercise}
              className="bg-green-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-green-600 transition-colors flex items-center"
            >
              <CheckCircle className="w-5 h-5 mr-2" />
              Concluir
            </button>
            <button
              onClick={skipExercise}
              className="bg-white bg-opacity-20 text-white px-6 py-3 rounded-full font-semibold hover:bg-opacity-30 transition-colors"
            >
              <SkipForward className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Rest View
  if (currentView === 'rest' && trainingSession) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-700 text-white">
        {showPauseOverlay && (
          <PauseOverlay
            isDarkMode={true}
            currentExercise={trainingSession.currentExerciseIndex + 1}
            totalExercises={1}
            onResume={handleResumeTraining}
            onRestart={handleRestartExercise}
            onExit={handleExitFromPause}
          />
        )}

        <div className="pt-12"></div>

        <div className="absolute top-16 right-6">
          <button
            onClick={handlePauseTraining}
            className="p-3 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 min-h-screen">
          <h1 className="text-3xl font-bold text-white mb-8 text-center">
            Prepare-se para o próximo
          </h1>

          <div className="relative w-48 h-48 mb-8">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="rgba(255,255,255,0.3)"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="white"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 90}`}
                strokeDashoffset={`${2 * Math.PI * 90 * (1 - restTimer / 10)}`}
                className="transition-all duration-1000 ease-linear"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-4xl font-bold text-white">{restTimer}</span>
            </div>
          </div>

          <p className="text-blue-100 text-center mb-8">
            Descanse e prepare-se para o próximo exercício
          </p>

          <div className="flex space-x-4">
            <button
              onClick={() => {
                setRestTimer(prev => prev + 10);
              }}
              className="bg-white bg-opacity-20 text-white px-6 py-3 rounded-full font-semibold hover:bg-opacity-30 transition-colors"
            >
              +10s
            </button>
            <button
              onClick={() => {
                setIsRestTimerRunning(false);
                setCurrentView('exercise');
                setTimer(20);
                setIsTimerRunning(true);
              }}
              className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-blue-50 transition-colors"
            >
              Pular Descanso
            </button>
          </div>
        </div>

        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Proof View - Matching UniversalAntiCheatVerification design
  if (currentView === 'proof' && trainingSession && currentChallenge) {
    if (capturedMedia) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
          <div className="flex-1 flex flex-col items-center justify-center px-6">
            <div className="w-full max-w-md">
              <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white text-center mb-2">Verificação Anti-Trapaça</h1>
              <p className="text-purple-100 text-center mb-8">Confirme sua foto</p>
              <div className="mb-6">
                <img src={capturedMedia} alt="Preview" className="w-full h-64 object-cover rounded-2xl" />
              </div>
              <div className="space-y-3">
                <button
                  onClick={submitProof}
                  className="w-full bg-green-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-green-600 transition-colors"
                >
                  Confirmar envio
                </button>
                <button
                  onClick={() => { setCapturedMedia(null); startCamera(); }}
                  className="w-full bg-white bg-opacity-10 text-white py-4 rounded-2xl font-bold hover:bg-opacity-20"
                >
                  Tirar outra foto
                </button>
              </div>
            </div>
          </div>
          <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-purple-700 flex flex-col">
        <div className="flex-1 flex flex-col">
          <div className="pt-6 pb-4 text-center px-4">
            <div className="w-16 h-16 bg-purple-500 bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Verificação Anti-Trapaça</h1>
            <p className="text-sm text-purple-100">Complete o desafio para comprovar seu treino</p>
          </div>

          <div className="px-4 mb-4">
            <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-3 border border-white border-opacity-20 flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-white mr-2" />
                <span className="text-white text-sm font-medium">Tempo: {challengeTimeLeft}s</span>
              </div>
              <div className="bg-green-500 px-3 py-1 rounded-full">
                <span className="text-white font-bold text-xs">OK</span>
              </div>
            </div>
          </div>

          <div className="px-4 space-y-3 mb-4">
            <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
              <p className="text-purple-100 text-center text-xs mb-2">Código do Desafio</p>
              <div className="text-white text-center text-4xl font-bold tracking-wider">{currentChallenge.code}</div>
            </div>
            <div className="bg-purple-500 bg-opacity-30 backdrop-blur-sm rounded-2xl p-4 border border-white border-opacity-20">
              <p className="text-purple-100 text-center text-xs mb-2">Faça o Gesto</p>
              <div className="text-white text-center text-2xl font-bold">{getGestureLabel(currentChallenge.gesture)}</div>
            </div>
          </div>

          {isDuplicateWarning && (
            <div className="px-4 mb-4">
              <div className="bg-red-500 bg-opacity-90 rounded-xl p-4 flex items-start">
                <AlertTriangle className="w-6 h-6 mr-3 flex-shrink-0 text-white" />
                <div className="text-left text-white">
                  <p className="font-bold">Foto Duplicada Detectada!</p>
                  <p className="text-sm">Esta foto já foi usada. Tire uma nova foto.</p>
                </div>
              </div>
            </div>
          )}

          <div className="flex-1 px-4 mb-4 min-h-[280px]">
            <div className="relative w-full h-full rounded-2xl overflow-hidden bg-black">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <button
                onClick={capturePhoto}
                className="absolute bottom-4 right-4 bg-gray-900 bg-opacity-80 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-opacity-100 transition-all"
              >
                {getGestureLabel(currentChallenge.gesture)}
              </button>
            </div>
          </div>

          <div className="px-4 pb-6">
            <button
              onClick={capturePhoto}
              className="w-full bg-white text-purple-600 py-4 rounded-2xl font-bold text-base mb-3 hover:bg-gray-100 transition-colors flex items-center justify-center"
            >
              <Camera className="w-5 h-5 mr-2" />
              Capturar Prova
            </button>
            <button onClick={skipProof} className="w-full py-3 text-center text-purple-200 hover:text-white transition-colors text-sm font-medium">
              Pular (-50% pontos)
            </button>
            <p className="text-center text-purple-200 text-xs mt-2">Sem prova válida = apenas 50% dos pontos</p>
          </div>
        </div>
        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Completion View
  if (currentView === 'completion' && trainingSession) {
    const AnimatedCounter = ({ target, duration = 2000 }: { target: number; duration?: number }) => {
      const [count, setCount] = useState(0);

      useEffect(() => {
        let startTime: number;
        let animationFrame: number;

        const animate = (currentTime: number) => {
          if (!startTime) startTime = currentTime;
          const progress = Math.min((currentTime - startTime) / duration, 1);
          const easeOutQuart = 1 - Math.pow(1 - progress, 4);
          setCount(Math.floor(target * easeOutQuart));

          if (progress < 1) {
            animationFrame = requestAnimationFrame(animate);
          } else {
            setCount(target);
          }
        };

        animationFrame = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animationFrame);
      }, [target, duration]);

      return <span>{count}</span>;
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 to-green-600 text-white">
        <div className="pt-12"></div>

        <div className="px-6 py-8">
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <Trophy className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Parabéns!
            </h1>
            <p className="text-green-100 text-xl">
              Treino concluído com sucesso!
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white bg-opacity-20 rounded-2xl p-6 text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
              <div className="text-3xl font-bold text-white mb-1">
                <AnimatedCounter target={trainingSession.totalPoints} />
              </div>
              <div className="text-green-100 text-sm">Pontos Ganhos</div>
              {trainingSession.submittedProof && (
                <div className="text-yellow-300 text-xs mt-1">
                  Provisórios - verificando...
                </div>
              )}
              {!trainingSession.submittedProof && (
                <div className="text-red-300 text-xs mt-1">-50% sem prova</div>
              )}
            </div>

            <div className="bg-white bg-opacity-20 rounded-2xl p-6 text-center">
              <Target className="w-8 h-8 text-blue-300 mx-auto mb-2" />
              <div className="text-3xl font-bold text-white mb-1">1</div>
              <div className="text-green-100 text-sm">Treino Completo</div>
            </div>
          </div>

          <button
            onClick={finishTraining}
            className="w-full bg-white text-green-600 py-4 rounded-2xl font-bold text-lg hover:bg-green-50 transition-colors duration-200 active:scale-95"
          >
            Finalizar Treino
          </button>
        </div>

        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  // Selection View
  return (
    <div className={`min-h-screen ${bgClass}`}>
      {showResumeModal && savedProgress && (
        <ResumeTrainingModal
          progress={savedProgress}
          isDarkMode={isDarkMode}
          onResume={handleResumeFromSaved}
          onStartNew={handleStartNewTraining}
          onClose={() => setShowResumeModal(false)}
        />
      )}

      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-4 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${textClass}`} />
        </button>
        <h1 className={`text-xl font-bold ${textClass}`}>{category.name}</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <div className={`w-16 h-16 ${category.color} rounded-2xl flex items-center justify-center mr-4`}>
              <span className="text-3xl">{category.icon}</span>
            </div>
            <div className="flex-1">
              <h2 className={`text-2xl font-bold ${textClass} mb-1`}>
                {category.name}
              </h2>
              <p className={secondaryTextClass}>
                {category.description}
              </p>
            </div>
          </div>
        </div>


        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className={`text-lg font-semibold ${textClass}`}>Treinos Disponíveis</h3>
            <span className={`text-sm ${secondaryTextClass}`}>{trainings.length} treinos</span>
          </div>

          <div className="space-y-4">
            {trainings.map((training) => (
              <button
                key={training.id}
                onClick={() => { setSelectedTraining(training); setCurrentView('detail'); }}
                className={`w-full ${cardClass} rounded-2xl p-4 text-left hover:opacity-80 transition-all active:scale-95`}
              >
                <div className="flex items-start">
                  <div className={`w-24 h-24 rounded-xl ${category.color} flex items-center justify-center mr-4`}>
                    <Play className="w-12 h-12 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className={`font-bold text-lg ${textClass} mb-2`}>
                      {training.title}
                    </h4>
                    <p className={`text-sm ${secondaryTextClass} mb-3 line-clamp-2`}>
                      {training.description}
                    </p>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Clock className={`w-4 h-4 ${secondaryTextClass} mr-1`} />
                        <span className={`text-sm ${secondaryTextClass}`}>{training.duration}</span>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                        training.difficulty === 'Iniciante' ? isDarkMode ? 'bg-green-900 text-green-300' : 'bg-green-100 text-green-700' :
                        training.difficulty === 'Amador' ? isDarkMode ? 'bg-blue-900 text-blue-300' : 'bg-blue-100 text-blue-700' :
                        training.difficulty === 'Intermediário' ? isDarkMode ? 'bg-yellow-900 text-yellow-300' : 'bg-yellow-100 text-yellow-700' :
                        isDarkMode ? 'bg-red-900 text-red-300' : 'bg-red-100 text-red-700'
                      }`}>
                        {training.difficulty}
                      </div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                        <span className={`text-sm ${secondaryTextClass}`}>+{training.points}</span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className={`w-6 h-6 ${secondaryTextClass} ml-2`} />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}
