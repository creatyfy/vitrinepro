import React, { useState, useEffect } from 'react';
import { ChevronLeft, Play, Pause, SkipForward, X } from 'lucide-react';
import PauseOverlay from './PauseOverlay';
import UniversalAntiCheatVerification from './UniversalAntiCheatVerification';
import { allChallenges } from '../data/challenge28Data';
import type { ChallengeExercise } from '../data/challenge28Data';

interface Challenge28ExecutionScreenProps {
  challengeId: string;
  day: number;
  isDarkMode: boolean;
  onComplete: () => void;
  onExit: () => void;
}

export default function Challenge28ExecutionScreen({
  challengeId,
  day,
  isDarkMode,
  onComplete,
  onExit
}: Challenge28ExecutionScreenProps) {
  const challenge = allChallenges[challengeId as keyof typeof allChallenges];
  const dayData = challenge?.days.find(d => d.day === day);

  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentView, setCurrentView] = useState<'exercise' | 'rest' | 'verification'>('exercise');
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [restTimer, setRestTimer] = useState(10);
  const [showPauseOverlay, setShowPauseOverlay] = useState(false);

  const currentExercise = dayData?.exercises[currentExerciseIndex];
  const totalExercises = dayData?.exercises.length || 0;
  const isLastExercise = currentExerciseIndex === totalExercises - 1;

  const getExerciseDuration = (exercise?: ChallengeExercise): number => {
    if (!exercise) return 20;
    if (exercise.duration) {
      const [min, sec] = exercise.duration.split(':').map(Number);
      return (min * 60) + sec;
    }
    return 20;
  };

  const [timer, setTimer] = useState(getExerciseDuration(currentExercise));

  useEffect(() => {
    if (currentView === 'exercise' && isTimerRunning && timer > 0) {
      const interval = setInterval(() => {
        setTimer(prev => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
    if (timer === 0 && currentView === 'exercise') {
      handleCompleteExercise();
    }
  }, [timer, currentView, isTimerRunning]);

  useEffect(() => {
    if (currentView === 'rest' && isTimerRunning && restTimer > 0) {
      const interval = setInterval(() => {
        setRestTimer(prev => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
    if (restTimer === 0 && currentView === 'rest') {
      advanceToNext();
    }
  }, [restTimer, currentView, isTimerRunning]);

  const handleCompleteExercise = () => {
    if (isLastExercise) {
      setCurrentView('verification');
      setIsTimerRunning(false);
    } else {
      setCurrentView('rest');
      setRestTimer(10);
      setIsTimerRunning(true);
    }
  };

  const advanceToNext = () => {
    setCurrentExerciseIndex(prev => prev + 1);
    setCurrentView('exercise');
    setTimer(getExerciseDuration(dayData?.exercises[currentExerciseIndex + 1]));
    setIsTimerRunning(true);
  };

  const handleSkipExercise = () => {
    handleCompleteExercise();
  };

  const handlePlayPause = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const handlePauseTraining = () => {
    setIsTimerRunning(false);
    setShowPauseOverlay(true);
  };

  const handleResumeTraining = () => {
    setShowPauseOverlay(false);
    setIsTimerRunning(true);
  };

  const handleRestartExercise = () => {
    setTimer(getExerciseDuration(currentExercise));
    setShowPauseOverlay(false);
    setIsTimerRunning(true);
  };

  const handleExitFromPause = () => {
    setShowPauseOverlay(false);
    onExit();
  };

  if (!dayData || !currentExercise) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-white">Exercício não encontrado</p>
      </div>
    );
  }

  if (currentView === 'verification') {
    return (
      <UniversalAntiCheatVerification
        sessionId={`${challengeId}-day${day}`}
        isDarkMode={isDarkMode}
        onComplete={(points) => {
          console.log('Challenge28 completed with points:', points);
          onComplete();
        }}
        onSkip={() => {
          console.log('Challenge28 verification skipped');
          onComplete();
        }}
      />
    );
  }

  if (currentView === 'rest') {
    const nextExercise = dayData.exercises[currentExerciseIndex + 1];

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-700 text-white">
        {showPauseOverlay && (
          <PauseOverlay
            isDarkMode={true}
            currentExercise={currentExerciseIndex + 1}
            totalExercises={totalExercises}
            onResume={handleResumeTraining}
            onRestart={handleRestartExercise}
            onExit={handleExitFromPause}
          />
        )}

        <div className="pt-12"></div>

        <div className="absolute top-16 left-6">
          <button
            onClick={handlePauseTraining}
            className="p-3 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 min-h-screen">
          <h1 className="text-3xl font-bold text-white mb-8 text-center">
            Prepare-se para o próximo
          </h1>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">{nextExercise.name}</h2>
            <p className="text-blue-100">
              Exercício {currentExerciseIndex + 2} de {totalExercises}
            </p>
          </div>

          <div className="relative w-48 h-48 mb-8">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="rgba(255,255,255,0.3)"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="100"
                cy="100"
                r="90"
                stroke="white"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 90}`}
                strokeDashoffset={`${2 * Math.PI * 90 * (1 - restTimer / 10)}`}
                className="transition-all duration-1000 ease-linear"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-4xl font-bold text-white">{restTimer}</span>
            </div>
          </div>

          <p className="text-blue-100 text-center mb-8">
            Descanse e prepare-se para o próximo exercício
          </p>

          <button
            onClick={advanceToNext}
            className="bg-white text-blue-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-blue-50 transition-colors"
          >
            Pular Descanso
          </button>
        </div>

        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {showPauseOverlay && (
        <PauseOverlay
          isDarkMode={true}
          currentExercise={currentExerciseIndex + 1}
          totalExercises={totalExercises}
          onResume={handleResumeTraining}
          onRestart={handleRestartExercise}
          onExit={handleExitFromPause}
        />
      )}

      <div className="pt-12"></div>

      <div className="absolute top-16 left-6">
        <button
          onClick={handlePauseTraining}
          className="p-3 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors"
        >
          <X className="w-6 h-6 text-white" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 min-h-screen">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">{dayData.focusArea}</h1>
          <h2 className="text-3xl font-bold text-white mb-4">{currentExercise.name}</h2>
          <p className="text-gray-400">
            Exercício {currentExerciseIndex + 1} de {totalExercises}
          </p>
        </div>

        <div className="mb-8 w-full max-w-sm">
          <img
            src={currentExercise.imageUrl}
            alt={currentExercise.name}
            className="w-full h-64 object-cover rounded-2xl"
          />
        </div>

        <div className="relative w-64 h-64 mb-8">
          <div className="absolute inset-0 rounded-full border-4 border-gray-700"></div>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-6xl font-bold text-white">{timer}</span>
            {currentExercise.duration && (
              <span className="text-sm text-gray-400 mt-2">segundos</span>
            )}
            {currentExercise.reps && (
              <span className="text-2xl text-gray-400 mt-2">{currentExercise.reps}</span>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4 mb-8">
          <button
            onClick={() => {
              if (currentExerciseIndex > 0) {
                setCurrentExerciseIndex(prev => prev - 1);
                setTimer(getExerciseDuration(dayData.exercises[currentExerciseIndex - 1]));
                setIsTimerRunning(false);
              }
            }}
            disabled={currentExerciseIndex === 0}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 ${
              currentExerciseIndex === 0
                ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                : 'bg-gray-700 text-white hover:bg-gray-600 active:scale-95'
            }`}
          >
            <ChevronLeft className="w-8 h-8" />
          </button>

          <button
            onClick={handlePlayPause}
            className="w-20 h-20 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-all duration-200 active:scale-95"
          >
            {isTimerRunning ? (
              <Pause className="w-10 h-10 text-black" />
            ) : (
              <Play className="w-10 h-10 text-black ml-1" />
            )}
          </button>

          <button
            onClick={handleCompleteExercise}
            className="w-14 h-14 bg-gray-700 rounded-full flex items-center justify-center text-white hover:bg-gray-600 transition-all duration-200 active:scale-95"
          >
            <SkipForward className="w-8 h-8" />
          </button>
        </div>

        <div className="flex space-x-4 w-full max-w-sm">
          <button
            onClick={handleSkipExercise}
            className="flex-1 bg-gray-800 text-white py-3 rounded-xl font-semibold hover:bg-gray-700 transition-colors"
          >
            Pular
          </button>
          <button
            onClick={handleCompleteExercise}
            className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-colors"
          >
            {isLastExercise ? 'Finalizar' : 'Concluir'}
          </button>
        </div>
      </div>

      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
