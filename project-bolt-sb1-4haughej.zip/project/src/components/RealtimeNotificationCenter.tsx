import React, { useState, useEffect } from 'react';
import { Bell, X, Trophy, MessageCircle, ShoppingCart, Target, CheckCircle, AlertCircle, Zap } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';
import { realtimeService, markNotificationAsRead, getUnreadNotificationCount } from '../services/realtimeService';

interface Notification {
  id: string;
  type: 'peneira' | 'ranking' | 'achievement' | 'message' | 'payment' | 'system';
  title: string;
  message: string;
  data: any;
  is_read: boolean;
  priority: 'high' | 'medium' | 'low';
  created_at: string;
}

interface RealtimeNotificationCenterProps {
  userId: string;
}

export default function RealtimeNotificationCenter({ userId }: RealtimeNotificationCenterProps) {
  const { tokens } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showIndicator, setShowIndicator] = useState(false);

  useEffect(() => {
    loadNotifications();
    loadUnreadCount();

    const unsubscribe = realtimeService.subscribeToNotifications(userId, (payload) => {
      if (payload.eventType === 'INSERT') {
        const newNotification = payload.new as Notification;
        setNotifications(prev => [newNotification, ...prev]);
        setUnreadCount(prev => prev + 1);
        setShowIndicator(true);
        setTimeout(() => setShowIndicator(false), 3000);

        if (newNotification.priority === 'high') {
          showBrowserNotification(newNotification);
        }
      }
    });

    return () => {
      unsubscribe();
    };
  }, [userId]);

  const loadNotifications = async () => {
    const { data, error } = await supabase
      .from('real_time_notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50);

    if (data) {
      setNotifications(data);
    }
  };

  const loadUnreadCount = async () => {
    const count = await getUnreadNotificationCount(userId);
    setUnreadCount(count);
  };

  const handleMarkAsRead = async (notificationId: string) => {
    await markNotificationAsRead(notificationId);
    setNotifications(prev =>
      prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const handleMarkAllAsRead = async () => {
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);

    for (const id of unreadIds) {
      await markNotificationAsRead(id);
    }

    setNotifications(prev =>
      prev.map(n => ({ ...n, is_read: true }))
    );
    setUnreadCount(0);
  };

  const showBrowserNotification = (notification: Notification) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(notification.title, {
        body: notification.message,
        icon: '/icon.png',
        badge: '/badge.png',
        tag: notification.id
      });
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'peneira':
        return <Trophy className="w-5 h-5" />;
      case 'ranking':
        return <Target className="w-5 h-5" />;
      case 'achievement':
        return <CheckCircle className="w-5 h-5" />;
      case 'message':
        return <MessageCircle className="w-5 h-5" />;
      case 'payment':
        return <ShoppingCart className="w-5 h-5" />;
      case 'system':
        return <AlertCircle className="w-5 h-5" />;
      default:
        return <Bell className="w-5 h-5" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'peneira':
        return 'bg-blue-500';
      case 'ranking':
        return 'bg-yellow-500';
      case 'achievement':
        return 'bg-green-500';
      case 'message':
        return 'bg-purple-500';
      case 'payment':
        return 'bg-red-500';
      case 'system':
        return 'bg-gray-500';
      default:
        return 'bg-blue-500';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return 'Agora';
    if (diffInMinutes < 60) return `${diffInMinutes}m atrás`;

    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h atrás`;

    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d atrás`;

    return date.toLocaleDateString('pt-BR');
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-full transition-all duration-200"
        style={{ backgroundColor: tokens.surfaceAlt }}
      >
        <Bell className="w-6 h-6" style={{ color: tokens.icon }} />
        {unreadCount > 0 && (
          <span
            className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white"
            style={{ backgroundColor: tokens.error }}
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
        {showIndicator && (
          <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-green-500 animate-ping"></span>
        )}
      </button>

      {isOpen && (
        <div
          className="fixed inset-0 z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
          onClick={() => setIsOpen(false)}
        >
          <div
            className="absolute right-4 top-20 w-96 max-h-[600px] rounded-2xl shadow-2xl overflow-hidden"
            style={{ backgroundColor: tokens.surface }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: tokens.border }}>
              <div className="flex items-center gap-3">
                <Bell className="w-6 h-6" style={{ color: tokens.accent }} />
                <div>
                  <h3 className="font-bold text-lg" style={{ color: tokens.textPrimary }}>Notificações</h3>
                  <p className="text-xs flex items-center gap-1" style={{ color: tokens.textSecondary }}>
                    <Zap className="w-3 h-3 text-green-500" />
                    Atualizações em tempo real
                  </p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-1">
                <X className="w-5 h-5" style={{ color: tokens.iconSecondary }} />
              </button>
            </div>

            {notifications.length > 0 && unreadCount > 0 && (
              <div className="p-3 border-b" style={{ borderColor: tokens.border }}>
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-sm font-medium"
                  style={{ color: tokens.accent }}
                >
                  Marcar todas como lidas
                </button>
              </div>
            )}

            <div className="overflow-y-auto max-h-[500px]">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <Bell className="w-16 h-16 mx-auto mb-4" style={{ color: tokens.iconSecondary, opacity: 0.3 }} />
                  <p className="text-sm" style={{ color: tokens.textSecondary }}>
                    Nenhuma notificação ainda
                  </p>
                </div>
              ) : (
                <div>
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className="p-4 border-b cursor-pointer transition-all duration-200 hover:bg-opacity-50"
                      style={{
                        borderColor: tokens.border,
                        backgroundColor: notification.is_read ? 'transparent' : tokens.surfaceAlt
                      }}
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      <div className="flex gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0 ${getNotificationColor(notification.type)}`}>
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <h4 className="font-semibold text-sm" style={{ color: tokens.textPrimary }}>
                              {notification.title}
                            </h4>
                            {!notification.is_read && (
                              <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 ml-2 mt-1"></span>
                            )}
                          </div>
                          <p className="text-sm mb-2" style={{ color: tokens.textSecondary }}>
                            {notification.message}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs" style={{ color: tokens.textSecondary, opacity: 0.7 }}>
                              {formatTimestamp(notification.created_at)}
                            </span>
                            {notification.priority === 'high' && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-600 font-medium">
                                Urgente
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {notifications.length > 0 && (
              <div className="p-3 border-t text-center" style={{ borderColor: tokens.border }}>
                <button
                  className="text-sm font-medium"
                  style={{ color: tokens.accent }}
                  onClick={() => {
                    setIsOpen(false);
                  }}
                >
                  Ver todas as notificações
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
