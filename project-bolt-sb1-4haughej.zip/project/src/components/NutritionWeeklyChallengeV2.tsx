import React, { useState, useEffect, useMemo } from 'react';
import { X, Camera, Clock, Award, RefreshCw, AlertCircle, Check, Flame, Timer } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface WeeklyChallengeData {
  week_id: string;
  title: string;
  dish_name: string;
  image_url: string;
  recipe_steps: string[];
  prep_time_minutes: number;
  macros: {
    kcal: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  deadline_iso: string;
  points_on_submit: number;
  challenge_id: string;
  user_submission: {
    exists: boolean;
    image_url?: string;
    submitted_at?: string;
    points_awarded?: number;
  };
}

interface NutritionWeeklyChallengeV2Props {
  userId: string;
  onBack: () => void;
}

export default function NutritionWeeklyChallengeV2({ userId, onBack }: NutritionWeeklyChallengeV2Props) {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(true);
  const [challengeData, setChallengeData] = useState<WeeklyChallengeData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [retryCount, setRetryCount] = useState(0);

  const styles = useMemo(() => ({
    container: { backgroundColor: theme.surface },
    header: { backgroundColor: theme.surface, borderColor: theme.border },
    card: { backgroundColor: theme.surfaceAlt, borderColor: theme.border },
    textPrimary: { color: theme.textPrimary },
    textSecondary: { color: theme.textSecondary },
    textInverse: { color: theme.textInverse },
    icon: { color: theme.icon },
    accent: { backgroundColor: theme.accent, color: theme.textInverse },
    accentText: { color: theme.accent },
    success: { color: theme.success, backgroundColor: `${theme.success}15` },
    error: { color: theme.error, backgroundColor: `${theme.error}15` },
    border: { borderColor: theme.border }
  }), [theme]);

  useEffect(() => {
    loadChallenge();
  }, [userId, retryCount]);

  useEffect(() => {
    if (challengeData?.deadline_iso) {
      const interval = setInterval(() => {
        setTimeRemaining(calculateTimeRemaining(challengeData.deadline_iso));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [challengeData]);

  async function loadChallenge() {
    try {
      setLoading(true);
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Não autenticado');
      }

      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-weekly-challenge-v2`;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Não foi possível carregar o desafio. Tente novamente em alguns instantes.');
      }

      const data = await response.json();
      setChallengeData(data);

    } catch (err: any) {
      console.error('Erro ao carregar desafio:', err);

      if (err.name === 'AbortError') {
        setError('Sem internet. Verifique sua conexão e tente de novo.');
      } else {
        setError(err.message || 'Não foi possível carregar o desafio. Tente novamente em alguns instantes.');
      }
    } finally {
      setLoading(false);
    }
  }

  function calculateTimeRemaining(deadlineIso: string): string {
    const now = new Date().getTime();
    const deadline = new Date(deadlineIso).getTime();
    const diff = deadline - now;

    if (diff <= 0) return 'Expirado';

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  function handleRetry() {
    setRetryCount(prev => prev + 1);
  }

  async function handlePhotoUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file || !challengeData) return;

    try {
      setUploading(true);
      setError(null);
      setSuccess(null);

      if (file.size > 5 * 1024 * 1024) {
        setError('Foto muito grande. Máximo 5MB.');
        return;
      }

      if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
        setError('Formato inválido. Use JPEG ou PNG.');
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Não autenticado');
      }

      const formData = new FormData();
      formData.append('week_id', challengeData.week_id);
      formData.append('challenge_id', challengeData.challenge_id);
      formData.append('photo', file);
      formData.append('replace_existing', challengeData.user_submission.exists ? 'true' : 'false');

      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/submit-weekly-challenge-v2`;

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        },
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Falha no envio da foto. Tentar novamente?');
      }

      const result = await response.json();
      setSuccess(result.message || `Foto enviada! +${result.awarded_points} pontos.`);

      setTimeout(() => {
        loadChallenge();
      }, 1500);

    } catch (err: any) {
      console.error('Erro no upload:', err);
      setError(err.message || 'Falha no envio da foto. Tentar novamente?');
    } finally {
      setUploading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Prato da Semana</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: theme.accent }} />
        </div>
      </div>
    );
  }

  if (error && !challengeData) {
    return (
      <div className="min-h-screen flex flex-col" style={styles.container}>
        <div className="sticky top-0 z-20 p-4 border-b" style={{ ...styles.header, ...styles.border }}>
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="p-2 rounded-lg">
              <X className="w-6 h-6" style={styles.icon} />
            </button>
            <h1 className="text-xl font-bold" style={styles.textPrimary}>Prato da Semana</h1>
            <div className="w-10" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="rounded-2xl p-8 text-center max-w-md border" style={{ ...styles.card, ...styles.border }}>
            <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: theme.error }} />
            <h2 className="text-2xl font-bold mb-2" style={styles.textPrimary}>Ops! Algo deu errado.</h2>
            <p className="mb-6" style={styles.textSecondary}>{error}</p>
            <button
              onClick={handleRetry}
              className="w-full py-3 rounded-xl font-semibold transition-all active:scale-95 flex items-center justify-center gap-2"
              style={styles.accent}
            >
              <RefreshCw className="w-5 h-5" />
              Tentar novamente
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!challengeData) return null;

  const isExpired = timeRemaining === 'Expirado';
  const hasSubmitted = challengeData.user_submission.exists;

  return (
    <div className="min-h-screen flex flex-col" style={styles.container}>
      <div className="sticky top-0 z-20 border-b" style={{ ...styles.header, ...styles.border }}>
        <div className="flex items-center justify-between p-4">
          <button onClick={onBack} className="p-2 rounded-lg transition-all active:scale-95">
            <X className="w-6 h-6" style={styles.icon} />
          </button>
          <h1 className="text-xl font-bold" style={styles.textPrimary}>{challengeData.title}</h1>
          <div className="w-10" />
        </div>
      </div>

      {error && challengeData && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.error, ...styles.border }}>
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium flex-1">{error}</p>
          <button onClick={() => setError(null)} className="p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="mx-6 mt-4 p-4 rounded-xl flex items-center gap-3 border" style={{ ...styles.success, ...styles.border }}>
          <Check className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">{success}</p>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="rounded-2xl border overflow-hidden" style={{ ...styles.card, ...styles.border }}>
          <div className="relative w-full aspect-video" style={{ backgroundColor: theme.border }}>
            <img
              src={challengeData.image_url}
              alt={challengeData.dish_name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800';
              }}
            />
            {!isExpired && (
              <div className="absolute top-4 right-4 bg-black bg-opacity-70 px-3 py-2 rounded-lg flex items-center gap-2">
                <Clock className="w-4 h-4 text-white" />
                <span className="text-white text-sm font-bold">{timeRemaining}</span>
              </div>
            )}
          </div>

          <div className="p-6 space-y-4">
            <div>
              <h2 className="text-3xl font-bold mb-2" style={styles.textPrimary}>
                {challengeData.dish_name}
              </h2>
              <p className="text-sm" style={styles.textSecondary}>
                Envie sua foto até o prazo para ganhar pontos
              </p>
            </div>

            <div className="flex items-center justify-between p-4 rounded-xl" style={{ backgroundColor: theme.surface }}>
              <span className="font-semibold" style={styles.textSecondary}>Pontos disponíveis</span>
              <span className="text-2xl font-bold" style={styles.accentText}>
                {challengeData.points_on_submit}
              </span>
            </div>

            {hasSubmitted ? (
              <div className="p-4 rounded-xl border" style={{ ...styles.success, ...styles.border }}>
                <div className="flex items-center gap-2 mb-2">
                  <Check className="w-5 h-5" />
                  <span className="font-bold">Foto enviada</span>
                </div>
                <p className="text-sm mb-2">
                  +{challengeData.user_submission.points_awarded} pontos creditados
                </p>
                {challengeData.user_submission.image_url && (
                  <button
                    onClick={() => window.open(challengeData.user_submission.image_url, '_blank')}
                    className="text-sm underline"
                  >
                    Ver minha foto
                  </button>
                )}
              </div>
            ) : !isExpired ? (
              <label className="block">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/jpg"
                  capture="environment"
                  onChange={handlePhotoUpload}
                  disabled={uploading}
                  className="hidden"
                />
                <div
                  className="w-full py-4 rounded-xl font-bold text-lg transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                  style={uploading ? { ...styles.accent, opacity: 0.6 } : styles.accent}
                >
                  <Camera className="w-6 h-6" />
                  {uploading ? 'Enviando...' : 'Enviar foto do prato'}
                </div>
              </label>
            ) : (
              <div className="w-full py-4 rounded-xl font-semibold text-center" style={{ backgroundColor: theme.border, color: theme.textSecondary }}>
                Prazo expirado – aguarde o próximo desafio
              </div>
            )}
          </div>
        </div>

        <div className="rounded-2xl p-6 border" style={{ ...styles.card, ...styles.border }}>
          <h3 className="text-xl font-bold mb-4" style={styles.textPrimary}>Modo de Preparo</h3>
          <ol className="space-y-3">
            {challengeData.recipe_steps.map((step, idx) => (
              <li key={idx} className="flex gap-3">
                <span className="font-bold flex-shrink-0" style={styles.accentText}>{idx + 1}.</span>
                <span style={styles.textSecondary}>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl p-4 text-center border" style={{ ...styles.card, ...styles.border }}>
            <Timer className="w-6 h-6 mx-auto mb-2" style={styles.accentText} />
            <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
              {challengeData.prep_time_minutes}min
            </div>
            <div className="text-xs" style={styles.textSecondary}>Tempo de preparo</div>
          </div>
          <div className="rounded-xl p-4 text-center border" style={{ ...styles.card, ...styles.border }}>
            <Flame className="w-6 h-6 mx-auto mb-2" style={{ color: theme.warning }} />
            <div className="text-2xl font-bold mb-1" style={styles.textPrimary}>
              {challengeData.macros.kcal}
            </div>
            <div className="text-xs" style={styles.textSecondary}>Calorias</div>
          </div>
        </div>

        <div className="rounded-xl p-4 border" style={{ ...styles.card, ...styles.border }}>
          <h4 className="font-semibold mb-3" style={styles.textPrimary}>Macronutrientes</h4>
          <div className="flex justify-between gap-3">
            <div className="text-center">
              <div className="text-lg font-bold" style={styles.textPrimary}>{challengeData.macros.protein}g</div>
              <div className="text-xs" style={styles.textSecondary}>Proteínas</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={styles.textPrimary}>{challengeData.macros.carbs}g</div>
              <div className="text-xs" style={styles.textSecondary}>Carboidratos</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={styles.textPrimary}>{challengeData.macros.fat}g</div>
              <div className="text-xs" style={styles.textSecondary}>Gorduras</div>
            </div>
          </div>
        </div>

        <div className="rounded-xl p-4 border" style={{ ...styles.card, ...styles.border, backgroundColor: `${theme.accent}10` }}>
          <h4 className="font-semibold mb-2" style={styles.textPrimary}>Regras de Pontuação</h4>
          <p className="text-sm" style={styles.textSecondary}>
            Só ganha pontos quem enviar a foto até o prazo. Sem envio = 0 ponto.
          </p>
        </div>
      </div>
    </div>
  );
}
