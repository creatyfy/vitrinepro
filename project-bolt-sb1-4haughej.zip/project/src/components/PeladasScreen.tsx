import React, { useState } from 'react';
import { ChevronLeft, MapPin, Calendar, Users, Clock, Star, Filter, Search, Trophy, Target, AlertCircle, CheckCircle, Plus, Zap, Crown, Award, Eye, Heart, MessageCircle, Share2, Phone, Mail } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import CreatePeladaScreen from './CreatePeladaScreen';
import PeladaDetailScreen from './PeladaDetailScreen';
import BoostPeladaScreen from './BoostPeladaScreen';

interface PeladasScreenProps {
  onBack: () => void;
  userType: 'atleta' | 'clube' | 'empresario';
  userName: string;
}

export default function PeladasScreen({ onBack, userType, userName }: PeladasScreenProps) {
  const { tokens, themeVersion, isDarkMode } = useTheme();
  const [currentView, setCurrentView] = useState('list'); // 'list', 'create', 'detail', 'boost'
  const [selectedFilter, setSelectedFilter] = useState('todas');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPelada, setSelectedPelada] = useState<any>(null);
  const [userLocation] = useState('São Paulo, SP'); // Simular localização do usuário

  const filters = [
    { id: 'todas', label: 'Todas', count: 12 },
    { id: 'hoje', label: 'Hoje', count: 3 },
    { id: 'amanha', label: 'Amanhã', count: 5 },
    { id: 'fim-semana', label: 'Fim de Semana', count: 4 }
  ];

  const peladas = [
    {
      id: 1,
      title: 'Pelada do Domingo - Ibirapuera',
      description: 'Pelada tradicional todo domingo no Parque Ibirapuera. Venha jogar com a galera!',
      organizer: 'João Silva',
      organizerType: 'atleta',
      organizerPhoto: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      location: 'Parque Ibirapuera - São Paulo, SP',
      date: '2024-02-18',
      time: '08:00',
      duration: '2 horas',
      maxPlayers: 22,
      currentPlayers: 18,
      price: 'R$ 15,00',
      type: 'pelada',
      level: 'Todos os níveis',
      field: 'Society',
      amenities: ['Vestiário', 'Estacionamento', 'Água'],
      contact: '(11) 99999-9999',
      whatsapp: 'https://wa.me/5511999999999',
      status: 'aberta',
      boosted: false,
      boostLevel: null,
      distance: '2.3 km',
      rating: 4.8,
      reviews: 45,
      image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      participants: [
        { name: 'Pedro', photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' },
        { name: 'Carlos', photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' }
      ]
    },
    {
      id: 2,
      title: 'Torneio Mensal - Vila Madalena',
      description: 'Torneio eliminatório com premiação para os 3 primeiros colocados. Inscrições limitadas!',
      organizer: 'Santos FC Academy',
      organizerType: 'clube',
      organizerPhoto: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      location: 'Centro Esportivo Vila Madalena - São Paulo, SP',
      date: '2024-02-25',
      time: '14:00',
      duration: '6 horas',
      maxPlayers: 64,
      currentPlayers: 48,
      price: 'R$ 50,00',
      type: 'torneio',
      level: 'Intermediário/Avançado',
      field: 'Campo',
      amenities: ['Vestiário', 'Lanchonete', 'Estacionamento', 'Arbitragem'],
      contact: 'torneios@santosfc.com.br',
      whatsapp: 'https://wa.me/5511888888888',
      status: 'aberta',
      boosted: true,
      boostLevel: 'ouro',
      distance: '5.7 km',
      rating: 4.9,
      reviews: 89,
      image: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      prize: 'R$ 2.000 para o campeão',
      participants: [
        { name: 'Time A', photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' },
        { name: 'Time B', photo: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' }
      ]
    },
    {
      id: 3,
      title: 'Rachão Quinta-feira - Morumbi',
      description: 'Rachão toda quinta no Morumbi. Galera animada e nível bom de jogo!',
      organizer: 'Carlos Empresário',
      organizerType: 'empresario',
      organizerPhoto: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      location: 'Arena Morumbi - São Paulo, SP',
      date: '2024-02-22',
      time: '19:30',
      duration: '1.5 horas',
      maxPlayers: 20,
      currentPlayers: 16,
      price: 'R$ 25,00',
      type: 'pelada',
      level: 'Intermediário',
      field: 'Society',
      amenities: ['Vestiário', 'Iluminação'],
      contact: '(11) 77777-7777',
      whatsapp: 'https://wa.me/5511777777777',
      status: 'aberta',
      boosted: true,
      boostLevel: 'prata',
      distance: '8.1 km',
      rating: 4.6,
      reviews: 23,
      image: 'https://images.pexels.com/photos/1171084/pexels-photo-1171084.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      participants: [
        { name: 'André', photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' }
      ]
    },
    {
      id: 4,
      title: 'Copa Zona Sul - Fim de Semana',
      description: 'Torneio de fim de semana com times da zona sul. Venha representar seu bairro!',
      organizer: 'Liga Zona Sul',
      organizerType: 'clube',
      organizerPhoto: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      location: 'Complexo Esportivo Zona Sul - São Paulo, SP',
      date: '2024-02-24',
      time: '09:00',
      duration: '8 horas',
      maxPlayers: 128,
      currentPlayers: 95,
      price: 'R$ 80,00',
      type: 'torneio',
      level: 'Todos os níveis',
      field: 'Campo',
      amenities: ['Vestiário', 'Lanchonete', 'Estacionamento', 'Arbitragem', 'Troféus'],
      contact: 'copa@zonasul.com.br',
      whatsapp: 'https://wa.me/5511666666666',
      status: 'aberta',
      boosted: true,
      boostLevel: 'bronze',
      distance: '12.4 km',
      rating: 4.7,
      reviews: 67,
      image: 'https://images.pexels.com/photos/114296/pexels-photo-114296.jpeg?auto=compress&cs=tinysrgb&w=600&h=300&fit=crop',
      prize: 'Troféu + R$ 1.500',
      participants: [
        { name: 'Vila Olímpia FC', photo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' }
      ]
    }
  ];

  const filteredPeladas = peladas.filter(pelada => {
    const matchesFilter = selectedFilter === 'todas' || 
      (selectedFilter === 'hoje' && pelada.date === '2024-02-18') ||
      (selectedFilter === 'amanha' && pelada.date === '2024-02-19') ||
      (selectedFilter === 'fim-semana' && ['2024-02-24', '2024-02-25'].includes(pelada.date));
    
    const matchesSearch = pelada.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pelada.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pelada.organizer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'aberta': return 'bg-green-100 text-green-800';
      case 'lotada': return 'bg-yellow-100 text-yellow-800';
      case 'encerrada': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'aberta': return 'Vagas Abertas';
      case 'lotada': return 'Lotada';
      case 'encerrada': return 'Encerrada';
      default: return 'Status';
    }
  };

  const getBoostBadge = (boostLevel: string | null) => {
    if (!boostLevel) return null;
    
    switch (boostLevel) {
      case 'bronze':
        return <div className="bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center">
          <Zap className="w-3 h-3 mr-1" />
          BRONZE
        </div>;
      case 'prata':
        return <div className="bg-gray-400 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center">
          <Crown className="w-3 h-3 mr-1" />
          PRATA
        </div>;
      case 'ouro':
        return <div className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center">
          <Award className="w-3 h-3 mr-1" />
          OURO
        </div>;
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit',
      weekday: 'short'
    });
  };

  const getOrganizerTypeLabel = (type: string) => {
    switch (type) {
      case 'atleta': return 'Atleta';
      case 'clube': return 'Clube';
      case 'empresario': return 'Empresário';
      default: return 'Organizador';
    }
  };

  // Create Pelada Screen
  if (currentView === 'create') {
    return (
      <CreatePeladaScreen
        onBack={() => setCurrentView('list')}
        userType={userType}
        userName={userName}
        onPeladaCreated={(pelada) => {
          console.log('Nova pelada criada:', pelada);
          setCurrentView('list');
        }}
        onBoostPelada={(peladaData) => {
          setSelectedPelada(peladaData);
          setCurrentView('boost');
        }}
      />
    );
  }

  // Pelada Detail Screen
  if (currentView === 'detail' && selectedPelada) {
    return (
      <PeladaDetailScreen
        pelada={selectedPelada}
        onBack={() => setCurrentView('list')}
        userType={userType}
        userName={userName}
      />
    );
  }

  // Boost Pelada Screen
  if (currentView === 'boost' && selectedPelada) {
    return (
      <BoostPeladaScreen
        pelada={selectedPelada}
        onBack={() => setCurrentView('create')}
        onBoostComplete={() => {
          setCurrentView('list');
          setSelectedPelada(null);
        }}
      />
    );
  }

  // Main Peladas List
  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={{ color: tokens.textPrimary }}>13:04</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
        <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Peladas & Torneios</h1>
        <button 
          onClick={() => setCurrentView('create')}
          className="p-2"
        >
          <Plus className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
      </div>

      <div className="px-6">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Encontre sua Pelada</h2>
          <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Peladas e torneios na sua região</p>
          <div className="flex items-center justify-center mt-2 text-sm text-gray-500">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{userLocation}</span>
          </div>
        </div>

        {/* Quick Action */}
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-6 text-white mb-8">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-2">Organize sua Pelada</h3>
              <p className="text-green-100 text-sm mb-4">
                Crie um evento e reúna a galera para jogar!
              </p>
              <button 
                onClick={() => setCurrentView('create')}
                className="bg-white text-green-600 px-6 py-3 rounded-xl font-semibold hover:bg-green-50 transition-colors"
              >
                Criar Evento
              </button>
            </div>
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <Plus className="w-10 h-10 text-white" />
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por local, organizador..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full pl-12 pr-4 py-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-green-500 ${isDarkMode ? 'bg-gray-800 border-0 text-white placeholder-gray-400' : 'bg-white border border-gray-200 focus:border-transparent'}`}
          />
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Filtros</h3>
            <Filter className="w-5 h-5 text-gray-500" />
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setSelectedFilter(filter.id)}
                className={`flex items-center px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  selectedFilter === filter.id
                    ? 'bg-green-500 text-white'
                    : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                {filter.label}
                <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-medium ${
                  selectedFilter === filter.id
                    ? 'bg-white/20 text-white'
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {filter.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className={`rounded-2xl p-6 shadow-sm border mb-8 ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'}`}>
          <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Estatísticas da Região</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Trophy className="w-6 h-6 text-green-600" />
              </div>
              <div className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>12</div>
              <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Eventos Ativos</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>347</div>
              <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Participantes</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
              <div className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>4.7</div>
              <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Avaliação</div>
            </div>
          </div>
        </div>

        {/* Peladas List */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {selectedFilter === 'todas' ? 'Todos os Eventos' : filters.find(f => f.id === selectedFilter)?.label}
            </h3>
            <span className="text-sm text-gray-500">{filteredPeladas.length} eventos</span>
          </div>
          
          <div className="space-y-4">
            {filteredPeladas.map((pelada) => (
              <div key={pelada.id} className="bg-white rounded-2xl shadow-sm border overflow-hidden">
                {/* Boost Badge */}
                {pelada.boosted && (
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 px-4 py-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Zap className="w-4 h-4 text-white mr-2" />
                        <span className="text-white font-bold text-sm">EVENTO TURBINADO</span>
                      </div>
                      {getBoostBadge(pelada.boostLevel)}
                    </div>
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <img 
                        src={pelada.organizerPhoto} 
                        alt={pelada.organizer}
                        className="w-12 h-12 rounded-full mr-3 object-cover"
                      />
                      <div>
                        <h4 className="font-semibold text-gray-900 text-lg">{pelada.title}</h4>
                        <div className="flex items-center text-sm text-gray-600">
                          <span>{pelada.organizer}</span>
                          <span className="mx-2">•</span>
                          <span className="capitalize">{getOrganizerTypeLabel(pelada.organizerType)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(pelada.status)}`}>
                        {getStatusLabel(pelada.status)}
                      </span>
                      <div className="flex items-center text-sm text-gray-500">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{pelada.distance}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{pelada.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{pelada.location}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{formatDate(pelada.date)} • {pelada.time}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock className="w-4 h-4 mr-2" />
                      <span>{pelada.duration}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Target className="w-4 h-4 mr-2" />
                      <span>{pelada.level}</span>
                    </div>
                  </div>

                  {/* Participants Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Participantes:</span>
                      <span className="text-sm text-gray-600">
                        {pelada.currentPlayers}/{pelada.maxPlayers}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${(pelada.currentPlayers / pelada.maxPlayers) * 100}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-2">
                      {pelada.amenities.slice(0, 3).map((amenity, index) => (
                        <span key={index} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                          {amenity}
                        </span>
                      ))}
                      {pelada.amenities.length > 3 && (
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                          +{pelada.amenities.length - 3} mais
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Price and Rating */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-sm font-medium text-gray-700">Valor: </span>
                      <span className="text-lg font-bold text-gray-900">{pelada.price}</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                      <span className="text-sm font-medium text-gray-700">{pelada.rating}</span>
                      <span className="text-sm text-gray-500 ml-1">({pelada.reviews})</span>
                    </div>
                  </div>

                  {/* Participants Preview */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="flex -space-x-2">
                        {pelada.participants.slice(0, 3).map((participant, index) => (
                          <img
                            key={index}
                            src={participant.photo}
                            alt={participant.name}
                            className="w-8 h-8 rounded-full border-2 border-white"
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600 ml-3">
                        {pelada.participants.length > 3 
                          ? `+${pelada.participants.length - 3} participantes`
                          : `${pelada.participants.length} participantes`
                        }
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-3">
                    <button 
                      onClick={() => {
                        setSelectedPelada(pelada);
                        setCurrentView('detail');
                      }}
                      className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-colors"
                    >
                      {pelada.type === 'torneio' ? 'Inscrever Time' : 'Participar'}
                    </button>
                    <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                      <Heart className="w-5 h-5" />
                    </button>
                    <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                    <button className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors">
                      <MessageCircle className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tips Section */}
        <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200 mb-8">
          <h3 className="font-semibold text-blue-900 mb-3">💡 Dicas para Organizar</h3>
          <div className="space-y-2 text-blue-700 text-sm">
            <p>• Defina claramente o nível de jogo esperado</p>
            <p>• Confirme a disponibilidade do campo antes de anunciar</p>
            <p>• Use o sistema de turbinação para alcançar mais pessoas</p>
            <p>• Mantenha contato direto via WhatsApp para confirmações</p>
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}