import React, { useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface MyTrainingsProps {
  selectedPosition: string;
  onBack: () => void;
  onNavigateToTreinoDoDia: () => void;
}

export default function MyTrainings({ selectedPosition, onBack, onNavigateToTreinoDoDia }: MyTrainingsProps) {
  const { tokens, isDarkMode } = useTheme();

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white'}`}>
      <div className="pt-12"></div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <h1 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Meus Treinos</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6 flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className={`w-20 h-20 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-full flex items-center justify-center mx-auto mb-6`}>
            <span className="text-4xl">🏋️</span>
          </div>
          <h2 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
            Em Breve
          </h2>
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-lg max-w-md mx-auto`}>
            Novos treinos personalizados estão sendo preparados para você. Continue acompanhando!
          </p>
        </div>
      </div>

      <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
    </div>
  );
}
