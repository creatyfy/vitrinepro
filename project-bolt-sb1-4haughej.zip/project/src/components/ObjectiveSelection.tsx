import React from 'react';
import { ChevronLeft } from 'lucide-react';

interface ObjectiveSelectionProps {
  selectedObjective: string;
  onObjectiveSelect: (objective: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function ObjectiveSelection({ selectedObjective, onObjectiveSelect, onNext, onBack }: ObjectiveSelectionProps) {
  const objectives = [
    { 
      id: 'melhorar-desempenho', 
      label: 'Apenas Melhorar meu desempenho',
      description: 'Foco no desenvolvimento pessoal'
    },
    { 
      id: 'virar-profissional', 
      label: 'Virar jogador profissional',
      description: 'Busco oportunidades no futebol profissional'
    },
    { 
      id: 'mais-visibilidade', 
      label: 'Já sou profissional, quero mais visibilidade',
      description: 'Expandir minha presença no mercado'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '90%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">
            Qual é seu objetivo?
          </h1>
          <p className="text-gray-600 text-lg">
            Escolha seu objetivo principal
          </p>
        </div>

        {/* Objective Options */}
        <div className="space-y-4 mb-12">
          {objectives.map((objective) => (
            <button
              key={objective.id}
              onClick={() => onObjectiveSelect(objective.id)}
              className={`w-full p-6 rounded-2xl text-left transition-all duration-200 ${
                selectedObjective === objective.id
                  ? 'bg-gray-900 text-white'
                  : 'bg-white border border-gray-200 hover:bg-gray-50 text-gray-800'
              }`}
            >
              <div className="flex flex-col">
                <span className="text-lg font-medium mb-1">
                  {objective.label}
                </span>
                <span className={`text-sm ${
                  selectedObjective === objective.id ? 'text-gray-300' : 'text-gray-500'
                }`}>
                  {objective.description}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedObjective}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedObjective
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}