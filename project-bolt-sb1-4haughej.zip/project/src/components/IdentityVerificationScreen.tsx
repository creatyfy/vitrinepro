import React, { useState, useRef } from 'react';
import { ChevronLeft, Video, CheckCircle, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTheme } from '../contexts/ThemeContext';

interface IdentityVerificationScreenProps {
  onBack: () => void;
  onComplete: () => void;
}

export default function IdentityVerificationScreen({ onBack, onComplete }: IdentityVerificationScreenProps) {
  const [step, setStep] = useState<'intro' | 'recording' | 'success'>('intro');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const { t } = useLanguage();
  const { isDarkMode } = useTheme();

  const bgClass = isDarkMode ? 'bg-black' : 'bg-gradient-to-br from-blue-50 to-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const cardClass = isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setVideoBlob(blob);
        stream.getTracks().forEach(track => track.stop());
        setStep('success');
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 5) {
            stopRecording();
            return 5;
          }
          return prev + 1;
        });
      }, 1000);

      setStep('recording');
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Não foi possível acessar a câmera. Verifique as permissões.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  };

  const handleSubmit = () => {
    setTimeout(() => {
      onComplete();
    }, 1500);
  };

  if (step === 'intro') {
    return (
      <div className={`min-h-screen ${bgClass}`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-gray-600'}`} />
          </button>
          <h1 className={`text-xl font-bold ${textClass}`}>{t('identityVerification')}</h1>
          <div className="w-10"></div>
        </div>

        <div className="px-6">
          <div className="text-center mb-8">
            <div className={`w-24 h-24 ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} rounded-full flex items-center justify-center mx-auto mb-6`}>
              <Video className="w-12 h-12 text-white" />
            </div>
            <h2 className={`text-3xl font-bold ${textClass} mb-4`}>
              Validação de Identidade
            </h2>
            <p className={`${secondaryTextClass} text-lg`}>
              Grave um pequeno vídeo do seu rosto para validar sua identidade
            </p>
          </div>

          <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-6`}>
            <h3 className={`text-lg font-semibold ${textClass} mb-4`}>Como funciona:</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="text-white font-bold text-sm">1</span>
                </div>
                <div>
                  <h4 className={`font-medium ${textClass} mb-1`}>Posicione seu rosto</h4>
                  <p className={`text-sm ${secondaryTextClass}`}>
                    Mantenha seu rosto centralizado e bem iluminado
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="text-white font-bold text-sm">2</span>
                </div>
                <div>
                  <h4 className={`font-medium ${textClass} mb-1`}>Grave o vídeo</h4>
                  <p className={`text-sm ${secondaryTextClass}`}>
                    O vídeo será gravado automaticamente por 5 segundos
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="text-white font-bold text-sm">3</span>
                </div>
                <div>
                  <h4 className={`font-medium ${textClass} mb-1`}>Envie para validação</h4>
                  <p className={`text-sm ${secondaryTextClass}`}>
                    Nossa equipe validará seu vídeo em até 24 horas
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className={`${isDarkMode ? 'bg-yellow-900 border-yellow-800' : 'bg-yellow-50 border-yellow-200'} rounded-2xl p-6 border mb-6`}>
            <div className="flex items-start">
              <AlertCircle className={`w-5 h-5 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'} mr-3 flex-shrink-0 mt-0.5`} />
              <div>
                <h4 className={`font-medium ${isDarkMode ? 'text-yellow-200' : 'text-yellow-800'} mb-2`}>
                  Importante
                </h4>
                <ul className={`text-sm ${isDarkMode ? 'text-yellow-300' : 'text-yellow-700'} space-y-1`}>
                  <li>• Remova óculos escuros e máscaras</li>
                  <li>• Grave em local bem iluminado</li>
                  <li>• Olhe diretamente para a câmera</li>
                  <li>• Não use filtros ou efeitos</li>
                </ul>
              </div>
            </div>
          </div>

          <button
            onClick={startRecording}
            className={`w-full ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white py-4 rounded-2xl font-bold text-lg transition-colors duration-200 active:scale-95`}
          >
            Iniciar Gravação
          </button>
        </div>

        <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
      </div>
    );
  }

  if (step === 'recording') {
    return (
      <div className={`min-h-screen ${bgClass}`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-center px-6 py-8 min-h-screen">
          <div className="w-full max-w-md">
            <div className="relative mb-6">
              <video
                ref={videoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-96 object-cover rounded-2xl bg-black"
              />
              <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded-full flex items-center">
                <div className="w-3 h-3 bg-white rounded-full mr-2 animate-pulse"></div>
                <span className="font-bold">Gravando {recordingTime}s / 5s</span>
              </div>
            </div>

            <p className={`text-center ${textClass} mb-4`}>
              Mantenha seu rosto centralizado e olhe para a câmera
            </p>

            {!isRecording && recordingTime >= 5 && (
              <button
                onClick={stopRecording}
                className={`w-full ${isDarkMode ? 'bg-green-600 hover:bg-green-700' : 'bg-green-500 hover:bg-green-600'} text-white py-4 rounded-2xl font-bold text-lg transition-colors duration-200`}
              >
                Finalizar Gravação
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className={`min-h-screen ${bgClass}`}>
        <div className="pt-12"></div>

        <div className="flex items-center justify-center px-6 py-8 min-h-screen">
          <div className="w-full max-w-md text-center">
            <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>

            <h2 className={`text-3xl font-bold ${textClass} mb-4`}>
              Vídeo Gravado!
            </h2>

            <p className={`${secondaryTextClass} text-lg mb-8`}>
              Seu vídeo foi gravado com sucesso e será validado em breve
            </p>

            <div className={`${cardClass} rounded-2xl p-6 shadow-sm border mb-6`}>
              <h3 className={`font-semibold ${textClass} mb-3`}>Próximos passos:</h3>
              <ul className={`text-sm ${secondaryTextClass} space-y-2 text-left`}>
                <li>• Nossa equipe analisará seu vídeo</li>
                <li>• Você receberá uma notificação quando for validado</li>
                <li>• O processo leva até 24 horas</li>
              </ul>
            </div>

            <button
              onClick={handleSubmit}
              className={`w-full ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white py-4 rounded-2xl font-bold text-lg transition-colors duration-200 active:scale-95`}
            >
              Concluir
            </button>
          </div>
        </div>

        <div className={`h-1 ${isDarkMode ? 'bg-white' : 'bg-gray-900'} mx-auto mb-2 rounded-full`} style={{width: '134px'}}></div>
      </div>
    );
  }

  return null;
}
