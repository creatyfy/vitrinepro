import React, { useMemo, useCallback } from 'react';
import { ChevronLeft } from 'lucide-react';

interface GenderSelectionProps {
  selectedGender: string;
  onGenderSelect: (gender: string) => void;
  onNext: () => void;
  onBack: () => void;
}

const GenderSelection = React.memo(({ selectedGender, onGenderSelect, onNext, onBack }: GenderSelectionProps) => {
  const genders = useMemo(() => [
    { id: 'masculino', label: 'Masculino' },
    { id: 'feminino', label: 'Feminino' },
    { id: 'outro', label: 'Outro' }
  ], []);

  const handleGenderSelect = useCallback((genderId: string) => {
    onGenderSelect(genderId);
  }, [onGenderSelect]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">13:03</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">5G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm">Vitrine Pro</span>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '25%' }}></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Escolha seu Gênero
          </h1>
          <p className="text-gray-600 text-lg">
            Isso será usado para calibrar seu perfil personalizado
          </p>
        </div>

        {/* Gender Options */}
        <div className="space-y-4 mb-12">
          {genders.map((gender) => (
            <button
              key={gender.id}
              onClick={() => handleGenderSelect(gender.id)}
              className={`w-full p-6 rounded-2xl text-left button-press ${
                selectedGender === gender.id
                  ? 'bg-green-100 border-2 border-green-500'
                  : 'bg-white border border-gray-200 hover:bg-gray-50'
              }`}
            >
              <span className="text-lg font-medium text-gray-800">
                {gender.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onNext}
          disabled={!selectedGender}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all duration-200 ${
            selectedGender
              ? 'bg-gray-900 text-white hover:bg-gray-800 active:scale-95'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuar
        </button>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
});

GenderSelection.displayName = 'GenderSelection';

export default GenderSelection;