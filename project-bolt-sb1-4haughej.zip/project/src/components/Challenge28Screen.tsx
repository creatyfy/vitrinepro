import React, { useState } from 'react';
import { ChevronLeft, Heart, MoreVertical, Trophy, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { allChallenges, Challenge28 } from '../data/challenge28Data';

interface Challenge28ScreenProps {
  challengeId: string;
  onBack: () => void;
  onDaySelect: (day: number) => void;
  onSettings: () => void;
}

export default function Challenge28Screen({
  challengeId,
  onBack,
  onDaySelect,
  onSettings
}: Challenge28ScreenProps) {
  const { tokens, isDarkMode } = useTheme();
  const [challenge] = useState<Challenge28>(allChallenges[challengeId as keyof typeof allChallenges]);
  const [liked, setLiked] = useState(false);

  const completedDays = challenge.days.filter(d => d.completed).length;
  const progressPercentage = (completedDays / challenge.totalDays) * 100;

  const weeks = [1, 2, 3, 4];

  const getDaysForWeek = (week: number) => {
    return challenge.days.filter(d => d.week === week);
  };

  const getCompletedDaysForWeek = (week: number) => {
    const days = getDaysForWeek(week);
    return days.filter(d => d.completed).length;
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface, color: tokens.textPrimary }}>
      <div className="pt-12"></div>

      {/* Header with background image */}
      <div className="relative h-64">
        <img
          src={challenge.bannerImage}
          alt={challenge.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>

        {/* Header icons */}
        <div className="absolute top-4 left-0 right-0 flex items-center justify-between px-6">
          <button onClick={onBack} className="p-2 bg-black bg-opacity-50 rounded-full">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <div className="flex items-center space-x-4">
            <button onClick={() => setLiked(!liked)} className="p-2">
              <Heart className={`w-6 h-6 ${liked ? 'fill-current text-red-500' : 'text-white'}`} />
            </button>
            <button onClick={onSettings} className="p-2">
              <MoreVertical className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>

        {/* Title overlay */}
        <div className="absolute bottom-6 left-6 right-6">
          <h1 className="text-3xl font-bold text-white leading-tight">
            {challenge.title}
          </h1>
        </div>
      </div>

      {/* Progress section */}
      <div className="px-6 py-6 bg-black">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xl font-bold">
            {completedDays} / {challenge.totalDays} <span className="text-gray-400 font-normal">Dias Concluídos</span>
          </span>
          <span className="text-xl font-bold">{Math.round(progressPercentage)}%</span>
        </div>

        {/* Progress bar */}
        <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
          <div
            className="absolute top-0 left-0 h-full bg-blue-500 rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Weeks */}
      <div className="px-6 pb-24">
        {weeks.map((week) => {
          const days = getDaysForWeek(week);
          const completedInWeek = getCompletedDaysForWeek(week);
          const isCurrentWeek = completedInWeek < 7 && (week === 1 || getCompletedDaysForWeek(week - 1) === 7);

          return (
            <div key={week} className="mb-8">
              {/* Week header */}
              <div className="flex items-center mb-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
                  isCurrentWeek ? 'bg-blue-500' : 'bg-gray-700'
                }`}>
                  <Trophy className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-xl font-bold flex-1">SEMANA {week}</h2>
                <span className="text-gray-400">{completedInWeek}/7</span>
              </div>

              {/* Week card */}
              <div className="bg-gray-900 rounded-3xl p-6">
                {/* Days grid */}
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {days.slice(0, 4).map((day) => (
                    <button
                      key={day.day}
                      onClick={() => onDaySelect(day.day)}
                      className={`aspect-square rounded-full flex items-center justify-center text-xl font-bold transition-all ${
                        day.completed
                          ? 'bg-green-500 text-white'
                          : day.day === completedDays + 1
                          ? 'bg-blue-500 text-white scale-110'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {day.completed ? <Check className="w-6 h-6" /> : day.day % 7 || 7}
                    </button>
                  ))}
                </div>

                {/* Arrows row */}
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="flex justify-center">
                      <ChevronLeft className="w-5 h-5 text-gray-600 rotate-[-90deg]" />
                    </div>
                  ))}
                </div>

                {/* Days grid second row */}
                <div className="grid grid-cols-4 gap-3 mb-6">
                  {days.slice(4, 7).map((day) => (
                    <button
                      key={day.day}
                      onClick={() => onDaySelect(day.day)}
                      className={`aspect-square rounded-full flex items-center justify-center text-xl font-bold transition-all ${
                        day.completed
                          ? 'bg-green-500 text-white'
                          : day.day === completedDays + 1
                          ? 'bg-blue-500 text-white scale-110'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {day.completed ? <Check className="w-6 h-6" /> : day.day % 7 || 7}
                    </button>
                  ))}
                  <div className="aspect-square rounded-full bg-gray-800 flex items-center justify-center">
                    <Trophy className="w-8 h-8 text-gray-600" />
                  </div>
                </div>

                {/* Start button */}
                {isCurrentWeek && (
                  <button
                    onClick={() => {
                      const nextDay = days.find(d => !d.completed);
                      if (nextDay) {
                        onDaySelect(nextDay.day);
                      }
                    }}
                    className="w-full bg-blue-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-blue-600 transition-colors"
                  >
                    COMEÇO
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
