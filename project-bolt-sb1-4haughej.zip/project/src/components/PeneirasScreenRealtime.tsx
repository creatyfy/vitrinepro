import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, MapPin, Calendar, Users, Clock, Star, Filter, Search, Trophy, Target, AlertCircle, CheckCircle, TrendingUp, Zap } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';
import { realtimeService, registerForPeneira } from '../services/realtimeService';

interface PeneirasScreenProps {
  onBack: () => void;
}

interface Peneira {
  id: string;
  club_name: string;
  club_logo: string;
  title: string;
  description: string;
  location_city: string;
  location_state: string;
  location_address: string;
  event_date: string;
  event_time: string;
  age_range_min: number;
  age_range_max: number;
  positions: string[];
  max_participants: number;
  current_participants: number;
  status: 'aberta' | 'fechando' | 'encerrada';
  fee_amount: number;
  fee_currency: string;
  requirements: string[];
  contact_email: string;
  contact_phone: string;
  priority: 'alta' | 'media' | 'baixa';
  is_featured: boolean;
  created_at: string;
  updated_at: string;
}

export default function PeneirasScreenRealtime({ onBack }: PeneirasScreenProps) {
  const { tokens } = useTheme();
  const [peneiras, setPeneiras] = useState<Peneira[]>([]);
  const [selectedFilter, setSelectedFilter] = useState('todas');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState<string | null>(null);
  const [realtimeIndicator, setRealtimeIndicator] = useState(false);

  useEffect(() => {
    loadPeneiras();

    const unsubscribe = realtimeService.subscribeToPeneiras((payload) => {
      setRealtimeIndicator(true);
      setTimeout(() => setRealtimeIndicator(false), 2000);

      if (payload.eventType === 'INSERT') {
        setPeneiras(prev => [payload.new as Peneira, ...prev]);
      } else if (payload.eventType === 'UPDATE') {
        setPeneiras(prev =>
          prev.map(p => p.id === payload.new.id ? payload.new as Peneira : p)
        );
      } else if (payload.eventType === 'DELETE') {
        setPeneiras(prev => prev.filter(p => p.id !== payload.old.id));
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const loadPeneiras = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('peneiras')
      .select('*')
      .order('event_date', { ascending: true });

    if (data) {
      setPeneiras(data);
    }
    setLoading(false);
  };

  const handleRegister = async (peneiraId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      alert('Você precisa estar logado para se inscrever');
      return;
    }

    setRegistering(peneiraId);
    try {
      await registerForPeneira(peneiraId, user.id);
      alert('Inscrição realizada com sucesso!');
    } catch (error: any) {
      alert(error.message || 'Erro ao realizar inscrição');
    } finally {
      setRegistering(null);
    }
  };

  const filters = useMemo(() => {
    const counts = {
      todas: peneiras.length,
      aberta: peneiras.filter(p => p.status === 'aberta').length,
      fechando: peneiras.filter(p => p.status === 'fechando').length,
      encerrada: peneiras.filter(p => p.status === 'encerrada').length
    };

    return [
      { id: 'todas', label: 'Todas', count: counts.todas },
      { id: 'aberta', label: 'Abertas', count: counts.aberta },
      { id: 'fechando', label: 'Fechando', count: counts.fechando },
      { id: 'encerrada', label: 'Encerradas', count: counts.encerrada }
    ];
  }, [peneiras]);

  const filteredPeneiras = useMemo(() => {
    return peneiras.filter(peneira => {
      const matchesFilter = selectedFilter === 'todas' || peneira.status === selectedFilter;
      const matchesSearch =
        peneira.club_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        peneira.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        peneira.location_city.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [peneiras, selectedFilter, searchTerm]);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'aberta':
        return { backgroundColor: tokens.success + '20', color: tokens.success };
      case 'fechando':
        return { backgroundColor: tokens.warning + '20', color: tokens.warning };
      case 'encerrada':
        return { backgroundColor: tokens.error + '20', color: tokens.error };
      default:
        return { backgroundColor: tokens.surfaceAlt, color: tokens.textSecondary };
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'aberta': return 'Inscrições Abertas';
      case 'fechando': return 'Últimas Vagas';
      case 'encerrada': return 'Encerrada';
      default: return 'Status';
    }
  };

  const getPriorityBorderColor = (priority: string) => {
    switch (priority) {
      case 'alta': return tokens.error;
      case 'media': return tokens.warning;
      case 'baixa': return tokens.border;
      default: return tokens.border;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: tokens.surface }}>
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-t-transparent rounded-full animate-spin mx-auto mb-4"
               style={{ borderColor: tokens.accent, borderTopColor: 'transparent' }}></div>
          <p style={{ color: tokens.textSecondary }}>Carregando peneiras...</p>
        </div>
      </div>
    );
  }

  if (peneiras.length === 0) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span style={{ color: tokens.textPrimary }}>13:04</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
            <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
            <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
          </div>
        </div>

        <div className="flex items-center justify-between px-6 py-2 mb-6">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
          </button>
          <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Peneiras</h1>
          <div className="w-10"></div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <div className="w-24 h-24 rounded-full flex items-center justify-center mb-6" style={{ backgroundColor: tokens.surfaceAlt }}>
            <AlertCircle className="w-12 h-12" style={{ color: tokens.iconSecondary }} />
          </div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: tokens.textPrimary }}>
            Nenhuma peneira disponível no momento
          </h2>
          <p className="text-lg mb-8 max-w-sm" style={{ color: tokens.textSecondary }}>
            Não há oportunidades abertas agora, mas fique atento! Novas peneiras aparecem em tempo real.
          </p>
          <div className="rounded-2xl p-6 border max-w-sm" style={{ backgroundColor: tokens.surfaceAlt, borderColor: tokens.border }}>
            <h3 className="font-semibold mb-2" style={{ color: tokens.textPrimary }}>💡 Dica</h3>
            <p className="text-sm" style={{ color: tokens.textSecondary }}>
              Continue treinando e melhorando sua pontuação. Clubes observam atletas com melhor desempenho no Vitrine Pro!
            </p>
          </div>
        </div>

        <div className="h-1 mx-auto mb-2 rounded-full" style={{width: '134px', backgroundColor: tokens.border}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.surface }}>
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span style={{ color: tokens.textPrimary }}>13:04</span>
        <div className="flex items-center space-x-1">
          {realtimeIndicator && (
            <Zap className="w-4 h-4 text-green-500 animate-pulse" />
          )}
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tokens.icon }}></div>
          <span className="ml-2" style={{ color: tokens.textPrimary }}>5G</span>
          <div className="w-6 h-3 rounded-sm ml-2" style={{ backgroundColor: tokens.icon }}></div>
        </div>
      </div>

      <div className="flex items-center justify-between px-6 py-2 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6" style={{ color: tokens.iconSecondary }} />
        </button>
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold" style={{ color: tokens.textPrimary }}>Peneiras</h1>
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" title="Atualizações em tempo real"></span>
        </div>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: tokens.textPrimary }}>Oportunidades ao Vivo</h2>
          <p style={{ color: tokens.textSecondary }}>Peneiras atualizando em tempo real</p>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: tokens.iconSecondary }} />
          <input
            type="text"
            placeholder="Buscar por clube ou cidade..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border focus:outline-none focus:ring-2"
            style={{
              backgroundColor: tokens.surfaceAlt,
              borderColor: tokens.border,
              color: tokens.textPrimary
            }}
          />
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>Filtros</h3>
            <Filter className="w-5 h-5" style={{ color: tokens.iconSecondary }} />
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setSelectedFilter(filter.id)}
                className="flex items-center px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 border"
                style={{
                  backgroundColor: selectedFilter === filter.id ? tokens.accent : tokens.surfaceAlt,
                  color: selectedFilter === filter.id ? tokens.textInverse : tokens.textPrimary,
                  borderColor: selectedFilter === filter.id ? tokens.accent : tokens.border
                }}
              >
                {filter.label}
                <span
                  className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium"
                  style={{
                    backgroundColor: selectedFilter === filter.id ? 'rgba(255,255,255,0.2)' : tokens.surface,
                    color: selectedFilter === filter.id ? tokens.textInverse : tokens.textSecondary
                  }}
                >
                  {filter.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ color: tokens.textPrimary }}>
              {selectedFilter === 'todas' ? 'Todas as Peneiras' : filters.find(f => f.id === selectedFilter)?.label}
            </h3>
            <span className="text-sm" style={{ color: tokens.textSecondary }}>{filteredPeneiras.length} oportunidades</span>
          </div>

          <div className="space-y-4">
            {filteredPeneiras.map((peneira) => {
              const vacancyPercentage = (peneira.current_participants / peneira.max_participants) * 100;

              return (
                <div
                  key={peneira.id}
                  className="rounded-2xl shadow-sm border-l-4 overflow-hidden transition-all duration-300"
                  style={{
                    backgroundColor: tokens.surfaceAlt,
                    borderLeftColor: getPriorityBorderColor(peneira.priority)
                  }}
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center">
                        <span className="text-2xl mr-3">{peneira.club_logo}</span>
                        <div>
                          <h4 className="font-semibold text-lg" style={{ color: tokens.textPrimary }}>{peneira.club_name}</h4>
                          <p className="text-sm" style={{ color: tokens.textSecondary }}>{peneira.title}</p>
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-full text-xs font-medium" style={getStatusStyle(peneira.status)}>
                        {getStatusLabel(peneira.status)}
                      </span>
                    </div>

                    <p className="mb-4" style={{ color: tokens.textSecondary }}>{peneira.description}</p>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                        <MapPin className="w-4 h-4 mr-2" />
                        <span>{peneira.location_city}, {peneira.location_state}</span>
                      </div>
                      <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{formatDate(peneira.event_date)}</span>
                      </div>
                      <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                        <Clock className="w-4 h-4 mr-2" />
                        <span>{peneira.event_time}</span>
                      </div>
                      <div className="flex items-center text-sm" style={{ color: tokens.textSecondary }}>
                        <Target className="w-4 h-4 mr-2" />
                        <span>{peneira.age_range_min}-{peneira.age_range_max} anos</span>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm font-medium mb-2" style={{ color: tokens.textPrimary }}>Posições:</p>
                      <div className="flex flex-wrap gap-2">
                        {peneira.positions.map((position, index) => (
                          <span key={index} className="px-2 py-1 text-xs rounded-full" style={{ backgroundColor: tokens.accent + '20', color: tokens.accent }}>
                            {position}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium flex items-center gap-2" style={{ color: tokens.textPrimary }}>
                          <Users className="w-4 h-4" />
                          Vagas:
                        </span>
                        <span className="text-sm font-mono" style={{ color: tokens.textSecondary }}>
                          {peneira.current_participants}/{peneira.max_participants}
                        </span>
                      </div>
                      <div className="w-full rounded-full h-2" style={{ backgroundColor: tokens.border }}>
                        <div
                          className="h-2 rounded-full transition-all duration-500"
                          style={{
                            width: `${vacancyPercentage}%`,
                            backgroundColor: vacancyPercentage >= 90 ? tokens.error : vacancyPercentage >= 70 ? tokens.warning : tokens.accent
                          }}
                        ></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-medium" style={{ color: tokens.textPrimary }}>Taxa: </span>
                        <span className="text-sm font-bold" style={{ color: peneira.fee_amount === 0 ? tokens.success : tokens.textPrimary }}>
                          {peneira.fee_amount === 0 ? 'Gratuita' : `R$ ${peneira.fee_amount.toFixed(2)}`}
                        </span>
                      </div>
                      <button
                        disabled={peneira.status === 'encerrada' || registering === peneira.id}
                        onClick={() => handleRegister(peneira.id)}
                        className="px-6 py-2 rounded-xl font-semibold text-sm transition-all duration-200 active:scale-95"
                        style={{
                          backgroundColor: peneira.status === 'encerrada' ? tokens.surfaceAlt : tokens.accent,
                          color: peneira.status === 'encerrada' ? tokens.textSecondary : tokens.textInverse,
                          cursor: peneira.status === 'encerrada' || registering === peneira.id ? 'not-allowed' : 'pointer',
                          opacity: peneira.status === 'encerrada' || registering === peneira.id ? 0.6 : 1
                        }}
                      >
                        {registering === peneira.id ? 'Inscrevendo...' : peneira.status === 'encerrada' ? 'Encerrada' : 'Inscrever-se'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-2xl p-6 mb-8" style={{ backgroundColor: tokens.success, color: tokens.textInverse }}>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Sistema em Tempo Real Ativo
          </h3>
          <div className="space-y-2" style={{ opacity: 0.9 }}>
            <p className="text-sm">• As vagas atualizam automaticamente quando alguém se inscreve</p>
            <p className="text-sm">• Novas peneiras aparecem instantaneamente</p>
            <p className="text-sm">• Você receberá notificações de peneiras próximas</p>
            <p className="text-sm">• Status muda em tempo real (aberta → fechando → encerrada)</p>
          </div>
        </div>
      </div>

      <div className="h-1 mx-auto mb-2 rounded-full" style={{width: '134px', backgroundColor: tokens.border}}></div>
    </div>
  );
}
