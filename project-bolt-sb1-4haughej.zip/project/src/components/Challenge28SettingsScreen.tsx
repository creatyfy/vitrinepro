import React, { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { ChevronLeft, ChevronRight, Volume2 } from 'lucide-react';
import { defaultWorkoutSettings, WorkoutSettings } from '../data/challenge28Data';

interface Challenge28SettingsScreenProps {
  onBack: () => void;
}

export default function Challenge28SettingsScreen({
  onBack
}: Challenge28SettingsScreenProps) {
  const { tokens, isDarkMode } = useTheme();
  const [settings, setSettings] = useState<WorkoutSettings>(defaultWorkoutSettings);

  const updateSetting = <K extends keyof WorkoutSettings>(
    key: K,
    value: WorkoutSettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const trainerVoices = ['Rodrigo', 'Ana', 'Carlos', 'Maria', 'Pedro'];

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="pt-12"></div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 mb-6">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="text-xl font-bold">Configurações Do Treino</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6 pb-24">
        {/* Music */}
        <div className="bg-gray-900 rounded-3xl p-6 mb-4">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold">Música</h3>
            <button
              onClick={() => updateSetting('musicEnabled', !settings.musicEnabled)}
              className="relative w-14 h-8 rounded-full transition-colors"
              style={{ backgroundColor: settings.musicEnabled ? '#3b82f6' : '#374151' }}
            >
              <div
                className="absolute top-1 w-6 h-6 bg-white rounded-full transition-transform"
                style={{ transform: settings.musicEnabled ? 'translateX(28px)' : 'translateX(4px)' }}
              ></div>
            </button>
          </div>

          {settings.musicEnabled && (
            <div className="flex items-center">
              <Volume2 className="w-5 h-5 text-gray-400 mr-4" />
              <input
                type="range"
                min="0"
                max="100"
                value={settings.musicVolume}
                onChange={(e) => updateSetting('musicVolume', parseInt(e.target.value))}
                className="flex-1 h-2 bg-gray-700 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${settings.musicVolume}%, #374151 ${settings.musicVolume}%, #374151 100%)`
                }}
              />
              <Volume2 className="w-6 h-6 text-gray-400 ml-4" />
            </div>
          )}
        </div>

        {/* Voice Guidance */}
        <div className="bg-gray-900 rounded-3xl p-6 mb-4">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold">Orientação de voz</h3>
            <button
              onClick={() => updateSetting('voiceGuidanceEnabled', !settings.voiceGuidanceEnabled)}
              className="relative w-14 h-8 rounded-full transition-colors"
              style={{ backgroundColor: settings.voiceGuidanceEnabled ? '#3b82f6' : '#374151' }}
            >
              <div
                className="absolute top-1 w-6 h-6 bg-white rounded-full transition-transform"
                style={{ transform: settings.voiceGuidanceEnabled ? 'translateX(28px)' : 'translateX(4px)' }}
              ></div>
            </button>
          </div>

          {settings.voiceGuidanceEnabled && (
            <>
              <div className="flex items-center mb-6">
                <Volume2 className="w-5 h-5 text-gray-400 mr-4" />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.voiceVolume}
                  onChange={(e) => updateSetting('voiceVolume', parseInt(e.target.value))}
                  className="flex-1 h-2 bg-gray-700 rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${settings.voiceVolume}%, #374151 ${settings.voiceVolume}%, #374151 100%)`
                  }}
                />
                <Volume2 className="w-6 h-6 text-gray-400 ml-4" />
              </div>

              {/* Trainer voice selector */}
              <div className="flex items-center justify-between py-4">
                <span className="text-lg">Voz do(a) treinador(a)</span>
                <button
                  onClick={() => {
                    const currentIndex = trainerVoices.indexOf(settings.trainerVoice);
                    const nextIndex = (currentIndex + 1) % trainerVoices.length;
                    updateSetting('trainerVoice', trainerVoices[nextIndex]);
                  }}
                  className="flex items-center text-gray-400"
                >
                  <span className="mr-2">{settings.trainerVoice}</span>
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </>
          )}
        </div>

        {/* Sound Effects */}
        <div className="bg-gray-900 rounded-3xl p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold mb-1">Efeitos Sonoros</h3>
              <p className="text-sm text-gray-400">Som de 'ding' após os exercícios, etc.</p>
            </div>
            <button
              onClick={() => updateSetting('soundEffectsEnabled', !settings.soundEffectsEnabled)}
              className="relative w-14 h-8 rounded-full transition-colors"
              style={{ backgroundColor: settings.soundEffectsEnabled ? '#3b82f6' : '#374151' }}
            >
              <div
                className="absolute top-1 w-6 h-6 bg-white rounded-full transition-transform"
                style={{ transform: settings.soundEffectsEnabled ? 'translateX(28px)' : 'translateX(4px)' }}
              ></div>
            </button>
          </div>

          {settings.soundEffectsEnabled && (
            <div className="flex items-center">
              <Volume2 className="w-5 h-5 text-gray-400 mr-4" />
              <input
                type="range"
                min="0"
                max="100"
                value={settings.soundEffectsVolume}
                onChange={(e) => updateSetting('soundEffectsVolume', parseInt(e.target.value))}
                className="flex-1 h-2 bg-gray-700 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${settings.soundEffectsVolume}%, #374151 ${settings.soundEffectsVolume}%, #374151 100%)`
                }}
              />
              <Volume2 className="w-6 h-6 text-gray-400 ml-4" />
            </div>
          )}
        </div>

        {/* Timer Settings */}
        <button className="w-full bg-gray-900 rounded-3xl p-6 mb-4 flex items-center justify-between">
          <span className="text-xl font-bold">Ajustes Do Timer</span>
          <ChevronRight className="w-6 h-6 text-gray-400" />
        </button>

        {/* Calorie Estimates */}
        <button className="w-full bg-gray-900 rounded-3xl p-6 flex items-center justify-between">
          <span className="text-xl font-bold">Estimativas De Calorias</span>
          <ChevronRight className="w-6 h-6 text-gray-400" />
        </button>
      </div>

      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}
