import React from 'react';
import { Play, X, Clock } from 'lucide-react';
import { formatPausedTime, TrainingProgress } from '../utils/trainingProgress';

interface ResumeTrainingModalProps {
  progress: TrainingProgress;
  isDarkMode: boolean;
  onResume: () => void;
  onStartNew: () => void;
  onClose: () => void;
}

export default function ResumeTrainingModal({
  progress,
  isDarkMode,
  onResume,
  onStartNew,
  onClose
}: ResumeTrainingModalProps) {
  const bgClass = isDarkMode ? 'bg-black' : 'bg-white';
  const textClass = isDarkMode ? 'text-white' : 'text-gray-900';
  const secondaryTextClass = isDarkMode ? 'text-gray-400' : 'text-gray-600';
  const cardClass = isDarkMode ? 'bg-gray-900' : 'bg-gray-50';

  const getProgressPercentage = () => {
    if (progress.total_exercises === 0) return 0;
    return Math.round((progress.current_exercise_index / progress.total_exercises) * 100);
  };

  const getTrainingTypeName = () => {
    switch (progress.training_type) {
      case 'daily':
        return 'Treino Diário';
      case 'category':
        return progress.progress_data.categoryName || 'Treino por Categoria';
      case 'challenge28':
        return 'Desafio 28 Dias';
      case 'exercise':
        return progress.progress_data.exerciseName || 'Exercício';
      default:
        return 'Treino';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`${cardClass} rounded-3xl max-w-md w-full p-6 relative`}>
        <button
          onClick={onClose}
          className={`absolute top-4 right-4 p-2 rounded-full ${
            isDarkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-200 hover:bg-gray-300'
          } transition-colors`}
        >
          <X className={`w-5 h-5 ${textClass}`} />
        </button>

        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-white" />
          </div>
          <h2 className={`text-2xl font-bold ${textClass} mb-2`}>
            Treino em Andamento
          </h2>
          <p className={`${secondaryTextClass} text-sm`}>
            Você tem um treino pausado
          </p>
        </div>

        <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-4 mb-6`}>
          <div className="flex items-center justify-between mb-3">
            <span className={`text-sm ${secondaryTextClass}`}>Treino:</span>
            <span className={`text-sm font-bold ${textClass}`}>{getTrainingTypeName()}</span>
          </div>

          <div className="flex items-center justify-between mb-3">
            <span className={`text-sm ${secondaryTextClass}`}>Progresso:</span>
            <span className={`text-sm font-bold ${textClass}`}>
              {progress.current_exercise_index + 1} de {progress.total_exercises} exercícios
            </span>
          </div>

          <div className="mb-3">
            <div className="flex justify-between items-center mb-1">
              <span className={`text-xs ${secondaryTextClass}`}>Conclusão</span>
              <span className={`text-xs font-bold ${textClass}`}>{getProgressPercentage()}%</span>
            </div>
            <div className={`w-full h-2 rounded-full ${isDarkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${getProgressPercentage()}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className={`text-sm ${secondaryTextClass}`}>Pausado:</span>
            <span className={`text-sm font-bold ${textClass}`}>
              {progress.paused_at ? formatPausedTime(progress.paused_at) : 'há pouco'}
            </span>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={onResume}
            className="w-full bg-green-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2 active:scale-95"
          >
            <Play className="w-5 h-5" />
            Retomar de Onde Parou
          </button>

          <button
            onClick={onStartNew}
            className={`w-full ${
              isDarkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-200 hover:bg-gray-300'
            } ${textClass} py-4 rounded-2xl font-bold text-lg transition-colors active:scale-95`}
          >
            Começar Novo Treino
          </button>
        </div>

        <p className={`text-xs ${secondaryTextClass} text-center mt-4`}>
          Se começar um novo treino, o progresso atual será perdido
        </p>
      </div>
    </div>
  );
}
