import React, { useState } from 'react';
import { ChevronLeft, Heart, Play, Clock, Zap, Users, Settings, Calendar, Target, Trophy, Star, CheckCircle, Lock } from 'lucide-react';

interface WeeklyTrainingProgramProps {
  selectedPosition: string;
  onBack: () => void;
}

interface DayTraining {
  day: number;
  date: string;
  dayName: string;
  duration: string;
  calories: string;
  focusArea: string;
  image: string;
  completed: boolean;
  locked: boolean;
  exercises: {
    name: string;
    duration: string;
    image: string;
  }[];
  warmup?: {
    name: string;
    duration: string;
    image: string;
  }[];
  suggestions?: {
    name: string;
    duration: string;
    difficulty: string;
    participants: string;
    image: string;
  }[];
}

interface WeekData {
  week: number;
  title: string;
  subtitle: string;
  progress: number;
  totalDays: number;
  completedDays: number;
  days: DayTraining[];
}

export default function WeeklyTrainingProgram({ selectedPosition, onBack }: WeeklyTrainingProgramProps) {
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [warmupEnabled, setWarmupEnabled] = useState(true);

  // Gerar dados das 12 semanas
  const generateWeekData = (weekNumber: number): WeekData => {
    const baseDate = new Date();
    const weekStart = new Date(baseDate.getTime() + (weekNumber - 1) * 7 * 24 * 60 * 60 * 1000);
    
    const focusAreas = [
      'Explosão', 'Força', 'Resistência', 'Agilidade', 
      'Velocidade', 'Coordenação', 'Prevenção'
    ];
    
    const days: DayTraining[] = [];
    
    for (let i = 0; i < 7; i++) {
      const dayDate = new Date(weekStart.getTime() + i * 24 * 60 * 60 * 1000);
      const dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
      
      days.push({
        day: i + 1,
        date: dayDate.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }),
        dayName: dayNames[dayDate.getDay()],
        duration: i === 6 ? '0 min' : ['5 min', '8 min', '12 min', '15 min'][Math.floor(Math.random() * 4)],
        calories: i === 6 ? '0 kcal' : `${Math.floor(Math.random() * 100) + 50} kcal`,
        focusArea: i === 6 ? 'Descanso' : focusAreas[i],
        image: i === 6 ? 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop' : 
               `https://images.pexels.com/photos/${1552242 + i}/pexels-photo-${1552242 + i}.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop`,
        completed: weekNumber === 1 && i === 0,
        locked: weekNumber > 1 && i > 0,
        exercises: i === 6 ? [] : [
          {
            name: 'Flexão Com Os Joelhos',
            duration: '00:30',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          },
          {
            name: 'Abdominais',
            duration: '00:30',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          }
        ],
        warmup: [
          {
            name: 'Alongamento da parte superior do corpo',
            duration: '9 min',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          },
          {
            name: 'Alongamento para todo o corpo',
            duration: '8 min',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          }
        ],
        suggestions: [
          {
            name: 'Treino para abdômen em 7 min',
            duration: '7 min',
            difficulty: 'Iniciante',
            participants: '78.8 mil',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          },
          {
            name: 'Queima da gordura do braço com haltere',
            duration: '12 min',
            difficulty: 'Intermediário',
            participants: '142.2 mil',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          },
          {
            name: 'Dure mais na cama',
            duration: '16 min',
            difficulty: 'Avançado',
            participants: '73.4 mil',
            image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
          }
        ]
      });
    }
    
    return {
      week: weekNumber,
      title: `SEMANA ${weekNumber} - DESENVOLVIMENTO ATLÉTICO`,
      subtitle: weekNumber <= 4 ? 'Base Física' : 
                weekNumber <= 8 ? 'Condicionamento' : 'Performance Avançada',
      progress: Math.floor((weekNumber - 1) / 12 * 100),
      totalDays: 7,
      completedDays: weekNumber === 1 ? 1 : 0,
      days
    };
  };

  const weeks = Array.from({ length: 12 }, (_, i) => generateWeekData(i + 1));
  const currentWeek = weeks.find(w => w.week === selectedWeek) || weeks[0];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Iniciante': return 'text-green-500';
      case 'Intermediário': return 'text-yellow-500';
      case 'Avançado': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  if (selectedDay !== null) {
    const dayData = currentWeek.days[selectedDay - 1];
    
    return (
      <div className="min-h-screen bg-black text-white">
        {/* Status Bar */}
        <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
          <span className="text-white">23:43</span>
          <div className="flex items-center space-x-1">
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <span className="ml-2 text-white">5G</span>
            <div className="w-6 h-3 bg-white rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4">
          <button onClick={() => setSelectedDay(null)} className="p-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white">DIA {dayData.day}</h1>
          <button className="p-2">
            <Heart className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Hero Image */}
        <div className="relative h-64 mx-6 rounded-2xl overflow-hidden mb-8">
          <img 
            src={dayData.image} 
            alt={`Treino do dia ${dayData.day}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-6 left-6 right-6">
            <h2 className="text-2xl font-bold text-white mb-4">DIA {dayData.day}</h2>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-white">{dayData.duration}</div>
                <div className="text-sm text-gray-300">Duração</div>
              </div>
              <div>
                <div className="text-lg font-bold text-white">{dayData.calories}</div>
                <div className="text-sm text-gray-300">Calorias</div>
              </div>
              <div>
                <div className="text-lg font-bold text-white">{dayData.focusArea}</div>
                <div className="text-sm text-gray-300">Área de foco</div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6">
          {/* Equipment */}
          <div className="mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Equipamento</h3>
            <div className="flex items-center justify-between bg-gray-800 rounded-2xl p-4">
              <span className="text-white">Parede</span>
              <div className="w-8 h-8 bg-gray-600 rounded-full"></div>
            </div>
          </div>

          {/* Warmup Toggle */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">Aquecimento</h3>
              <button 
                onClick={() => setWarmupEnabled(!warmupEnabled)}
                className={`w-12 h-6 rounded-full transition-all duration-200 ${
                  warmupEnabled ? 'bg-blue-500' : 'bg-gray-600'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-all duration-200 ${
                  warmupEnabled ? 'translate-x-6' : 'translate-x-0.5'
                }`}></div>
              </button>
            </div>
          </div>

          {/* Exercises */}
          <div className="mb-8">
            <h3 className="text-xl font-bold text-white mb-4">Exercícios ({dayData.exercises.length})</h3>
            <div className="space-y-4">
              {dayData.exercises.map((exercise, index) => (
                <div key={index} className="flex items-center bg-gray-900 rounded-2xl p-4">
                  <img 
                    src={exercise.image} 
                    alt={exercise.name}
                    className="w-16 h-16 rounded-xl object-cover mr-4"
                  />
                  <div className="flex-1">
                    <h4 className="text-white font-semibold mb-1">{exercise.name}</h4>
                    <p className="text-gray-400 text-sm">{exercise.duration}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Warmup Section */}
          {warmupEnabled && dayData.warmup && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Alongamento relacionado</h3>
              <div className="space-y-4">
                {dayData.warmup.map((warmup, index) => (
                  <div key={index} className="flex items-center">
                    <img 
                      src={warmup.image} 
                      alt={warmup.name}
                      className="w-16 h-16 rounded-xl object-cover mr-4"
                    />
                    <div className="flex-1">
                      <h4 className="text-white font-semibold mb-1">{warmup.name}</h4>
                      <div className="flex items-center text-blue-400 text-sm">
                        <span>{warmup.duration}</span>
                        <span className="mx-2">|</span>
                        <span>Alongar</span>
                      </div>
                      <div className="flex items-center text-gray-400 text-xs mt-1">
                        <Users className="w-3 h-3 mr-1" />
                        <span>212.3 mil Participantes</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <button className="w-full mt-4 text-blue-400 font-medium flex items-center justify-center">
                <ChevronLeft className="w-4 h-4 mr-1 rotate-90" />
                Ver todos
              </button>
            </div>
          )}

          {/* Suggestions */}
          {dayData.suggestions && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Sugeridos para você</h3>
              <div className="space-y-4">
                {dayData.suggestions.map((suggestion, index) => (
                  <div key={index} className="flex items-center">
                    <img 
                      src={suggestion.image} 
                      alt={suggestion.name}
                      className="w-16 h-16 rounded-xl object-cover mr-4"
                    />
                    <div className="flex-1">
                      <h4 className="text-white font-semibold mb-1">{suggestion.name}</h4>
                      <div className="flex items-center text-blue-400 text-sm">
                        <span>{suggestion.duration}</span>
                        <span className="mx-2">|</span>
                        <span className={getDifficultyColor(suggestion.difficulty)}>
                          {suggestion.difficulty}
                        </span>
                      </div>
                      <div className="flex items-center text-gray-400 text-xs mt-1">
                        <Users className="w-3 h-3 mr-1" />
                        <span>{suggestion.participants} Participantes</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Start Button */}
        <div className="px-6 pb-8">
          <button className="w-full bg-blue-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-blue-600 transition-colors duration-200 active:scale-95">
            Começe
          </button>
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800">
          <div className="flex justify-around py-2">
            <button className="flex flex-col items-center py-2 px-4">
              <Clock className="w-5 h-5 text-gray-400 mb-1" />
              <span className="text-xs text-gray-400">Classic</span>
            </button>
            <button className="flex flex-col items-center py-2 px-4">
              <Target className="w-5 h-5 text-gray-400 mb-1" />
              <span className="text-xs text-gray-400">Workout</span>
            </button>
            <button className="flex flex-col items-center py-2 px-4">
              <Calendar className="w-5 h-5 text-blue-500 mb-1" />
              <span className="text-xs text-blue-500">Personal</span>
            </button>
            <button className="flex flex-col items-center py-2 px-4">
              <Trophy className="w-5 h-5 text-gray-400 mb-1" />
              <span className="text-xs text-gray-400">Daily</span>
            </button>
            <button className="flex flex-col items-center py-2 px-4">
              <User className="w-5 h-5 text-gray-400 mb-1" />
              <span className="text-xs text-gray-400">Me</span>
            </button>
          </div>
        </div>

        {/* Bottom Indicator */}
        <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-white">10:57</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-white rounded-full"></div>
          <div className="w-1 h-1 bg-white rounded-full"></div>
          <div className="w-1 h-1 bg-white rounded-full"></div>
          <span className="ml-2 text-white">4G</span>
          <div className="w-6 h-3 bg-white rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button className="p-2">
            <Settings className="w-6 h-6 text-white" />
          </button>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-2 leading-tight">
          {currentWeek.title}
        </h1>
        <p className="text-gray-400 mb-6">{currentWeek.subtitle}</p>
        
        {/* Week Progress */}
        <div className="flex items-center justify-between mb-2">
          <span className="text-white font-medium">Week {selectedWeek}</span>
          <span className="text-gray-400 text-sm">{currentWeek.completedDays}/{currentWeek.totalDays}</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-2 mb-6">
          <div 
            className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
            style={{ width: `${(currentWeek.completedDays / currentWeek.totalDays) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Week Selector */}
      <div className="px-6 mb-8">
        <div className="flex space-x-3 overflow-x-auto pb-4">
          {weeks.map((week) => (
            <button
              key={week.week}
              onClick={() => setSelectedWeek(week.week)}
              className={`flex-shrink-0 px-4 py-2 rounded-full transition-all duration-200 ${
                selectedWeek === week.week
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              Semana {week.week}
            </button>
          ))}
        </div>
      </div>

      {/* Today Section */}
      <div className="px-6 mb-8">
        <div className="flex items-center mb-6">
          <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
          <h2 className="text-xl font-bold text-white">Today</h2>
        </div>

        {/* Today's Training */}
        <div className="relative bg-gray-900 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-gray-400 text-sm">{currentWeek.days[0].date}</p>
              <h3 className="text-2xl font-bold text-white">Day {currentWeek.days[0].day}</h3>
              <div className="flex items-center space-x-4 mt-2">
                <span className="text-white">{currentWeek.days[0].duration}</span>
                <span className="text-gray-400">|</span>
                <span className="text-white">{currentWeek.days[0].calories}</span>
              </div>
            </div>
            <div className="w-24 h-24 rounded-2xl overflow-hidden">
              <img 
                src={currentWeek.days[0].image} 
                alt="Treino de hoje"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          <button 
            onClick={() => setSelectedDay(1)}
            className="w-full bg-blue-500 text-white py-3 rounded-xl font-bold hover:bg-blue-600 transition-colors"
          >
            Start Now
          </button>
        </div>
      </div>

      {/* Upcoming Section */}
      <div className="px-6 mb-8">
        <h2 className="text-xl font-bold text-white mb-6">Upcoming</h2>
        
        <div className="space-y-4">
          {currentWeek.days.slice(1, 4).map((day, index) => (
            <button
              key={day.day}
              onClick={() => setSelectedDay(day.day)}
              disabled={day.locked}
              className={`w-full bg-gray-900 rounded-2xl p-4 transition-all duration-200 ${
                day.locked ? 'opacity-50' : 'hover:bg-gray-800'
              }`}
            >
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full mr-4 ${
                  day.completed ? 'bg-green-500' : 
                  day.locked ? 'bg-gray-600' : 'bg-gray-500'
                }`}></div>
                
                <div className="flex-1 text-left">
                  <p className="text-gray-400 text-sm">{day.date}</p>
                  <h4 className="text-lg font-bold text-white">Day {day.day}</h4>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-white text-sm">{day.duration}</span>
                    <span className="text-gray-400">|</span>
                    <span className="text-white text-sm">{day.calories}</span>
                  </div>
                </div>
                
                <div className="w-16 h-16 rounded-xl overflow-hidden ml-4">
                  <img 
                    src={day.image} 
                    alt={`Treino do dia ${day.day}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {day.locked && (
                  <div className="absolute right-4">
                    <Lock className="w-5 h-5 text-gray-500" />
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Week Stats */}
      <div className="px-6 mb-8">
        <div className="bg-gray-900 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-white mb-4">Progresso da Semana</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{currentWeek.completedDays}</div>
              <div className="text-gray-400 text-sm">Dias completos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">
                {currentWeek.days.reduce((acc, day) => acc + (day.completed ? parseInt(day.calories) || 0 : 0), 0)}
              </div>
              <div className="text-gray-400 text-sm">Calorias queimadas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">
                {Math.round((currentWeek.completedDays / currentWeek.totalDays) * 100)}%
              </div>
              <div className="text-gray-400 text-sm">Progresso</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800">
        <div className="flex justify-around py-2">
          <button className="flex flex-col items-center py-2 px-4">
            <Clock className="w-5 h-5 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Classic</span>
          </button>
          <button className="flex flex-col items-center py-2 px-4">
            <Target className="w-5 h-5 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Workout</span>
          </button>
          <button className="flex flex-col items-center py-2 px-4">
            <Calendar className="w-5 h-5 text-blue-500 mb-1" />
            <span className="text-xs text-blue-500">Personal</span>
          </button>
          <button className="flex flex-col items-center py-2 px-4">
            <Trophy className="w-5 h-5 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Daily</span>
          </button>
          <button className="flex flex-col items-center py-2 px-4">
            <User className="w-5 h-5 text-gray-400 mb-1" />
            <span className="text-xs text-gray-400">Me</span>
          </button>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-white mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}