import React, { useState } from 'react';
import { ChevronLeft, CreditCard, Truck, Shield, MapPin, Plus, Minus, Trash2, Tag } from 'lucide-react';
import CardPaymentForm, { CardData } from './CardPaymentForm';

interface CheckoutScreenProps {
  cartItems: any[];
  onBack: () => void;
  onUpdateCart: (items: any[]) => void;
}

export default function CheckoutScreen({ cartItems, onBack, onUpdateCart }: CheckoutScreenProps) {
  const [selectedPayment, setSelectedPayment] = useState('pix');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState('');
  const [cardData, setCardData] = useState<CardData | null>(null);
  const [isCardValid, setIsCardValid] = useState(false);
  const [shippingAddress, setShippingAddress] = useState({
    cep: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: ''
  });

  const paymentMethods = [
    { id: 'pix', name: 'PIX', discount: 5, icon: '💳' },
    { id: 'credit', name: 'Cartão de Crédito', discount: 0, icon: '💳' },
    { id: 'debit', name: 'Cartão de Débito', discount: 0, icon: '💳' },
    { id: 'boleto', name: 'Boleto', discount: 0, icon: '📄' }
  ];

  const updateQuantity = (cartId: number, newQuantity: number) => {
    if (newQuantity === 0) {
      removeItem(cartId);
      return;
    }
    
    const updatedItems = cartItems.map(item => 
      item.cartId === cartId ? { ...item, quantity: newQuantity } : item
    );
    onUpdateCart(updatedItems);
  };

  const removeItem = (cartId: number) => {
    const updatedItems = cartItems.filter(item => item.cartId !== cartId);
    onUpdateCart(updatedItems);
  };

  const applyCoupon = () => {
    if (couponCode.toUpperCase() === 'PRIMEIRACOMPRA') {
      setAppliedCoupon(couponCode);
      setCouponCode('');
    }
  };

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const calculateDiscount = () => {
    const subtotal = calculateSubtotal();
    let discount = 0;
    
    // Payment method discount
    const paymentMethod = paymentMethods.find(p => p.id === selectedPayment);
    if (paymentMethod?.discount) {
      discount += subtotal * (paymentMethod.discount / 100);
    }
    
    // Coupon discount
    if (appliedCoupon === 'PRIMEIRACOMPRA') {
      discount += subtotal * 0.1; // 10% off
    }
    
    return discount;
  };

  const calculateShipping = () => {
    return 15.90; // Fixed shipping for demo
  };

  const calculateTotal = () => {
    return calculateSubtotal() - calculateDiscount() + calculateShipping();
  };

  const handleCardDataChange = (data: CardData) => {
    setCardData(data);
    const cardDataWithValidation = data as CardData & { isValid?: boolean };
    setIsCardValid(cardDataWithValidation.isValid || false);
  };

  const canFinishPurchase = () => {
    if (selectedPayment === 'credit' || selectedPayment === 'debit') {
      return isCardValid;
    }
    return true;
  };

  const handleFinishPurchase = () => {
    if (!canFinishPurchase()) {
      alert('Por favor, preencha todos os dados do cartão corretamente.');
      return;
    }

    if (selectedPayment === 'credit' || selectedPayment === 'debit') {
      console.log('Processando pagamento com cartão:', cardData);
    }

    alert('Compra realizada com sucesso! 🎉');
    onUpdateCart([]);
    onBack();
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6">
        <div className="text-center">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingCart className="w-12 h-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Carrinho vazio</h2>
          <p className="text-gray-600 mb-8">Adicione produtos ao carrinho para continuar</p>
          <button
            onClick={onBack}
            className="bg-gray-900 text-white px-8 py-3 rounded-full font-semibold hover:bg-gray-800 transition-colors"
          >
            Continuar Comprando
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 pt-12 text-sm font-medium">
        <span className="text-gray-900">18:11</span>
        <div className="flex items-center space-x-1">
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
          <span className="ml-2 text-gray-800">4G</span>
          <div className="w-6 h-3 bg-gray-800 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-white">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Finalizar Compra</h1>
        <div className="w-10"></div>
      </div>

      <div className="px-6">
        {/* Cart Items */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Seus Produtos</h2>
          <div className="space-y-4">
            {cartItems.map((item) => (
              <div key={item.cartId} className="flex items-center space-x-4 pb-4 border-b border-gray-100 last:border-b-0">
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-sm line-clamp-2 mb-1">
                    {item.name}
                  </h3>
                  <p className="text-gray-600 text-xs mb-2">
                    {item.selectedColor} • Tamanho {item.selectedSize}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-gray-900">
                      R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}
                    </span>
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => updateQuantity(item.cartId, item.quantity - 1)}
                        className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                      >
                        <Minus className="w-4 h-4 text-gray-600" />
                      </button>
                      <span className="font-medium text-gray-900">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.cartId, item.quantity + 1)}
                        className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                      >
                        <Plus className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={() => removeItem(item.cartId)}
                        className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center hover:bg-red-200"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Coupon */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Cupom de Desconto</h3>
          {appliedCoupon ? (
            <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center">
                <Tag className="w-5 h-5 text-green-600 mr-2" />
                <span className="text-green-800 font-medium">{appliedCoupon}</span>
              </div>
              <span className="text-green-600 font-bold">-10%</span>
            </div>
          ) : (
            <div className="flex space-x-3">
              <input
                type="text"
                placeholder="Digite o código do cupom"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
              <button
                onClick={applyCoupon}
                className="bg-gray-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                Aplicar
              </button>
            </div>
          )}
        </div>

        {/* Payment Method */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Forma de Pagamento</h3>
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => setSelectedPayment(method.id)}
                className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                  selectedPayment === method.id
                    ? 'border-gray-900 bg-gray-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">{method.icon}</span>
                    <span className="font-medium text-gray-900">{method.name}</span>
                  </div>
                  {method.discount > 0 && (
                    <span className="text-green-600 font-bold text-sm">
                      -{method.discount}%
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Card Payment Form */}
        {(selectedPayment === 'credit' || selectedPayment === 'debit') && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <CardPaymentForm
              onCardDataChange={handleCardDataChange}
              isValid={isCardValid}
            />
          </div>
        )}

        {/* Order Summary */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo do Pedido</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium text-gray-900">
                R$ {calculateSubtotal().toFixed(2).replace('.', ',')}
              </span>
            </div>
            
            {calculateDiscount() > 0 && (
              <div className="flex justify-between">
                <span className="text-gray-600">Desconto</span>
                <span className="font-medium text-green-600">
                  -R$ {calculateDiscount().toFixed(2).replace('.', ',')}
                </span>
              </div>
            )}
            
            <div className="flex justify-between">
              <span className="text-gray-600">Frete</span>
              <span className="font-medium text-gray-900">
                R$ {calculateShipping().toFixed(2).replace('.', ',')}
              </span>
            </div>
            
            <div className="border-t border-gray-200 pt-3">
              <div className="flex justify-between">
                <span className="text-lg font-semibold text-gray-900">Total</span>
                <span className="text-xl font-bold text-gray-900">
                  R$ {calculateTotal().toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Shipping Address */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Endereço de Entrega</h3>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="CEP"
              value={shippingAddress.cep}
              onChange={(e) => setShippingAddress(prev => ({ ...prev, cep: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
            />
            <input
              type="text"
              placeholder="Rua"
              value={shippingAddress.street}
              onChange={(e) => setShippingAddress(prev => ({ ...prev, street: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Número"
                value={shippingAddress.number}
                onChange={(e) => setShippingAddress(prev => ({ ...prev, number: e.target.value }))}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
              <input
                type="text"
                placeholder="Complemento"
                value={shippingAddress.complement}
                onChange={(e) => setShippingAddress(prev => ({ ...prev, complement: e.target.value }))}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
            </div>
            <input
              type="text"
              placeholder="Bairro"
              value={shippingAddress.neighborhood}
              onChange={(e) => setShippingAddress(prev => ({ ...prev, neighborhood: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Cidade"
                value={shippingAddress.city}
                onChange={(e) => setShippingAddress(prev => ({ ...prev, city: e.target.value }))}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
              <input
                type="text"
                placeholder="Estado"
                value={shippingAddress.state}
                onChange={(e) => setShippingAddress(prev => ({ ...prev, state: e.target.value }))}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
            </div>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-24">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Truck className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-sm font-medium text-gray-900">Entrega Rápida</div>
              <div className="text-xs text-gray-600">Em até 3 dias</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-sm font-medium text-gray-900">Compra Segura</div>
              <div className="text-xs text-gray-600">Dados protegidos</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Shield className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="text-sm font-medium text-gray-900">Garantia</div>
              <div className="text-xs text-gray-600">30 dias</div>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-semibold text-gray-900">Total:</span>
          <span className="text-2xl font-bold text-gray-900">
            R$ {calculateTotal().toFixed(2).replace('.', ',')}
          </span>
        </div>
        
        <button
          onClick={handleFinishPurchase}
          disabled={!canFinishPurchase()}
          className={`w-full py-4 rounded-full font-bold text-lg transition-colors duration-200 active:scale-95 ${
            canFinishPurchase()
              ? 'bg-gray-900 text-white hover:bg-gray-800'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Finalizar Compra
        </button>
        
        <div className="flex items-center justify-center mt-3 space-x-4 text-xs text-gray-500">
          <div className="flex items-center">
            <Shield className="w-4 h-4 mr-1" />
            <span>Compra 100% segura</span>
          </div>
          <div className="flex items-center">
            <Truck className="w-4 h-4 mr-1" />
            <span>Entrega garantida</span>
          </div>
        </div>
      </div>

      {/* Bottom Indicator */}
      <div className="h-1 bg-gray-900 mx-auto mb-2 rounded-full" style={{width: '134px'}}></div>
    </div>
  );
}