import { supabase } from '../lib/supabase';

export interface TrainingProgress {
  id?: string;
  user_id?: string;
  training_type: 'daily' | 'category' | 'challenge28' | 'exercise';
  training_id: string;
  exercise_id?: string;
  current_exercise_index: number;
  total_exercises: number;
  timer_remaining: number;
  is_resting: boolean;
  rest_timer_remaining: number;
  progress_data: {
    categoryId?: string;
    currentSet?: number;
    totalSets?: number;
    exerciseName?: string;
    categoryName?: string;
    [key: string]: any;
  };
  paused_at?: string;
  created_at?: string;
  updated_at?: string;
}

export async function saveTrainingProgress(progress: TrainingProgress): Promise<{ success: boolean; error?: string }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    const existingProgress = await getTrainingProgress(progress.training_type, progress.training_id);

    if (existingProgress) {
      const { error } = await supabase
        .from('training_pause_progress')
        .update({
          exercise_id: progress.exercise_id,
          current_exercise_index: progress.current_exercise_index,
          total_exercises: progress.total_exercises,
          timer_remaining: progress.timer_remaining,
          is_resting: progress.is_resting,
          rest_timer_remaining: progress.rest_timer_remaining,
          progress_data: progress.progress_data,
          paused_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', existingProgress.id);

      if (error) {
        console.error('Error updating training progress:', error);
        return { success: false, error: error.message };
      }
    } else {
      const { error } = await supabase
        .from('training_pause_progress')
        .insert({
          user_id: user.id,
          training_type: progress.training_type,
          training_id: progress.training_id,
          exercise_id: progress.exercise_id,
          current_exercise_index: progress.current_exercise_index,
          total_exercises: progress.total_exercises,
          timer_remaining: progress.timer_remaining,
          is_resting: progress.is_resting,
          rest_timer_remaining: progress.rest_timer_remaining,
          progress_data: progress.progress_data,
          paused_at: new Date().toISOString()
        });

      if (error) {
        console.error('Error saving training progress:', error);
        return { success: false, error: error.message };
      }
    }

    return { success: true };
  } catch (error) {
    console.error('Error in saveTrainingProgress:', error);
    return { success: false, error: String(error) };
  }
}

export async function getTrainingProgress(
  trainingType: string,
  trainingId: string
): Promise<TrainingProgress | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('training_pause_progress')
      .select('*')
      .eq('user_id', user.id)
      .eq('training_type', trainingType)
      .eq('training_id', trainingId)
      .order('paused_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error('Error fetching training progress:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Error in getTrainingProgress:', error);
    return null;
  }
}

export async function deleteTrainingProgress(progressId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('training_pause_progress')
      .delete()
      .eq('id', progressId);

    if (error) {
      console.error('Error deleting training progress:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in deleteTrainingProgress:', error);
    return { success: false, error: String(error) };
  }
}

export async function clearAllUserProgress(): Promise<{ success: boolean; error?: string }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { success: false, error: 'User not authenticated' };

    const { error } = await supabase
      .from('training_pause_progress')
      .delete()
      .eq('user_id', user.id);

    if (error) {
      console.error('Error clearing user progress:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error('Error in clearAllUserProgress:', error);
    return { success: false, error: String(error) };
  }
}

export function formatPausedTime(pausedAt: string): string {
  const now = new Date();
  const paused = new Date(pausedAt);
  const diffInMinutes = Math.floor((now.getTime() - paused.getTime()) / 60000);

  if (diffInMinutes < 1) return 'agora mesmo';
  if (diffInMinutes < 60) return `há ${diffInMinutes} minuto${diffInMinutes > 1 ? 's' : ''}`;

  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `há ${diffInHours} hora${diffInHours > 1 ? 's' : ''}`;

  const diffInDays = Math.floor(diffInHours / 24);
  return `há ${diffInDays} dia${diffInDays > 1 ? 's' : ''}`;
}
