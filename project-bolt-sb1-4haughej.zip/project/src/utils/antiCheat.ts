export interface Challenge {
  id: string;
  gesture: 'thumbs_up' | 'peace_sign' | 'ok_sign' | 'wave' | 'fist' | 'smile' | 'chin' | 'tongue' | 'rock' | 'three';
  timestamp: number;
  expiresAt: number;
  code?: string;
}

export interface MovementData {
  accelerationX: number;
  accelerationY: number;
  accelerationZ: number;
  rotationAlpha: number;
  rotationBeta: number;
  rotationGamma: number;
  timestamp: number;
}

const CHALLENGE_DURATION = 60000; // 60 seconds

export function generateChallenge(): Challenge {
  const gestures: Challenge['gesture'][] = [
    'thumbs_up',
    'peace_sign',
    'ok_sign',
    'wave',
    'fist',
    'smile',
    'chin',
    'tongue',
    'rock',
    'three'
  ];
  const randomGesture = gestures[Math.floor(Math.random() * gestures.length)];
  const now = Date.now();

  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }

  return {
    id: `challenge_${now}_${Math.random().toString(36).substr(2, 9)}`,
    gesture: randomGesture,
    code,
    timestamp: now,
    expiresAt: now + CHALLENGE_DURATION,
  };
}

export function isChallengeExpired(challenge: Challenge): boolean {
  return Date.now() > challenge.expiresAt;
}

export function getGestureLabel(gesture: Challenge['gesture']): string {
  const labels: Record<Challenge['gesture'], string> = {
    thumbs_up: 'Joinha',
    peace_sign: 'Sinal de paz (V)',
    ok_sign: 'Sinal de OK',
    wave: 'Aceno com mão',
    fist: 'Punho fechado',
    smile: 'Sorriso',
    chin: 'Mão no queixo',
    tongue: 'Língua para fora',
    rock: 'Rock (🤘)',
    three: 'Número 3 com dedos'
  };
  return labels[gesture];
}

export function calculatePhash(imageData: string): string {
  // Simplified perceptual hash simulation
  // In production, use a proper perceptual hashing library
  let hash = 0;
  for (let i = 0; i < imageData.length; i++) {
    const char = imageData.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

export function isDuplicatePhoto(phash1: string, phash2: string): boolean {
  // Simple comparison - in production use Hamming distance
  return phash1 === phash2;
}

export function calculateMovementScore(movements: MovementData[]): number {
  if (movements.length === 0) return 0;

  let totalMovement = 0;
  for (let i = 1; i < movements.length; i++) {
    const prev = movements[i - 1];
    const curr = movements[i];

    const accelDelta = Math.sqrt(
      Math.pow(curr.accelerationX - prev.accelerationX, 2) +
      Math.pow(curr.accelerationY - prev.accelerationY, 2) +
      Math.pow(curr.accelerationZ - prev.accelerationZ, 2)
    );

    const rotationDelta = Math.sqrt(
      Math.pow(curr.rotationAlpha - prev.rotationAlpha, 2) +
      Math.pow(curr.rotationBeta - prev.rotationBeta, 2) +
      Math.pow(curr.rotationGamma - prev.rotationGamma, 2)
    );

    totalMovement += accelDelta + rotationDelta;
  }

  // Normalize to 0-100 scale
  const avgMovement = totalMovement / movements.length;
  return Math.min(100, avgMovement * 10);
}

export function calculateRiskScore(
  movementScore: number,
  photoVerified: boolean,
  challengeCompleted: boolean
): number {
  let risk = 0;

  // Low movement suggests static/fake training
  if (movementScore < 20) risk += 40;
  else if (movementScore < 40) risk += 20;

  // No photo verification
  if (!photoVerified) risk += 30;

  // Challenge not completed
  if (!challengeCompleted) risk += 30;

  return Math.min(100, risk);
}

export function getPointsMultiplier(riskScore: number): number {
  // Lower risk = higher multiplier
  if (riskScore < 20) return 1.5; // Bonus for genuine training
  if (riskScore < 40) return 1.2;
  if (riskScore < 60) return 1.0;
  if (riskScore < 80) return 0.8;
  return 0.5; // Heavy penalty for suspicious activity
}

export function validateMovementPattern(movements: MovementData[]): {
  isValid: boolean;
  reason?: string;
} {
  if (movements.length < 10) {
    return {
      isValid: false,
      reason: 'Movimento insuficiente detectado',
    };
  }

  const movementScore = calculateMovementScore(movements);

  if (movementScore < 15) {
    return {
      isValid: false,
      reason: 'Padrão de movimento muito baixo - possível fraude',
    };
  }

  // Check for unnatural patterns (too consistent)
  const accelerations = movements.map(m =>
    Math.sqrt(m.accelerationX ** 2 + m.accelerationY ** 2 + m.accelerationZ ** 2)
  );

  const avgAccel = accelerations.reduce((a, b) => a + b, 0) / accelerations.length;
  const variance = accelerations.reduce((sum, val) =>
    sum + Math.pow(val - avgAccel, 2), 0
  ) / accelerations.length;

  if (variance < 0.1) {
    return {
      isValid: false,
      reason: 'Padrão de movimento não natural detectado',
    };
  }

  return { isValid: true };
}
