export const convertDriveUrlToEmbed = (driveUrl: string): string => {
  if (!driveUrl) return '';

  const fileIdMatch = driveUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);

  if (fileIdMatch && fileIdMatch[1]) {
    const fileId = fileIdMatch[1];
    return `https://drive.google.com/file/d/${fileId}/preview`;
  }

  return driveUrl;
};

export const isValidDriveUrl = (url: string): boolean => {
  return url.includes('drive.google.com') && url.includes('/d/');
};

export const createVideoElementForLoop = (url: string): HTMLVideoElement => {
  const video = document.createElement('video');
  video.src = convertDriveUrlToEmbed(url);
  video.loop = true;
  video.muted = true;
  video.playsInline = true;
  video.autoplay = true;
  return video;
};
