import { supabase } from '../lib/supabase';

export interface VideoUploadProgress {
  status: 'queued' | 'uploading' | 'processing' | 'ready' | 'failed';
  progress: number;
  error?: string;
}

export const PLAYER_POSITIONS = [
  { id: 'gk', label: 'Goleiro', abbr: 'GK' },
  { id: 'rb', label: 'Lateral Direito', abbr: 'LD' },
  { id: 'lb', label: 'Lateral Esquerdo', abbr: 'LE' },
  { id: 'cb', label: 'Zagueiro', abbr: 'ZAG' },
  { id: 'cdm', label: 'Volante', abbr: 'VOL' },
  { id: 'cm', label: 'Meia Central', abbr: 'MC' },
  { id: 'cam', label: 'Meia Atacante', abbr: 'MA' },
  { id: 'rm', label: 'Ponta Direita', abbr: 'PD' },
  { id: 'lm', label: 'Ponta Esquerda', abbr: 'PE' },
  { id: 'st', label: 'Atacante', abbr: 'ATA' },
] as const;

export async function uploadVideo(
  file: File,
  userId: string,
  source: 'gallery' | 'capture',
  onProgress?: (progress: VideoUploadProgress) => void
): Promise<string | null> {
  try {
    onProgress?.({
      status: 'queued',
      progress: 10,
    });

    const validation = validateVideoFile(file);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    const { data: limitCheck } = await supabase.rpc('check_upload_limit', {
      p_user_id: userId
    });

    if (!limitCheck) {
      throw new Error('Limite diário de uploads atingido (máximo 5 por dia)');
    }

    const videoId = crypto.randomUUID();
    const fileExtension = file.name.split('.').pop() || 'mp4';
    const storagePath = `${userId}/${videoId}.${fileExtension}`;

    onProgress?.({
      status: 'uploading',
      progress: 30,
    });

    const { error: uploadError } = await supabase.storage
      .from('player-videos')
      .upload(storagePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      throw uploadError;
    }

    onProgress?.({
      status: 'uploading',
      progress: 60,
    });

    const { data: urlData } = supabase.storage
      .from('player-videos')
      .getPublicUrl(storagePath);

    const videoHash = await generateVideoHash(file);

    const { data: duplicateCheck } = await supabase.rpc('check_duplicate_video', {
      p_user_id: userId,
      p_video_hash: videoHash
    });

    if (duplicateCheck) {
      await supabase.storage.from('player-videos').remove([storagePath]);
      throw new Error('Este vídeo já foi enviado anteriormente');
    }

    const duration = await getVideoDuration(file);

    const { error: insertError } = await supabase
      .from('player_videos')
      .insert({
        id: videoId,
        user_id: userId,
        storage_path: storagePath,
        original_url: urlData.publicUrl,
        hls_url: urlData.publicUrl,
        poster_url: urlData.publicUrl,
        duration_seconds: Math.floor(duration),
        file_size_bytes: file.size,
        video_hash: videoHash,
        status: 'ready',
        upload_source: source
      });

    if (insertError) {
      await supabase.storage.from('player-videos').remove([storagePath]);
      throw insertError;
    }

    await supabase.rpc('increment_upload_count', {
      p_user_id: userId
    });

    await supabase.rpc('award_video_points', {
      p_video_id: videoId
    });

    onProgress?.({
      status: 'ready',
      progress: 100,
    });

    await logTelemetry(userId, 'video_upload_complete', {
      video_id: videoId,
      source: source,
      file_size: file.size,
      duration: duration
    });

    return videoId;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erro ao enviar vídeo';

    onProgress?.({
      status: 'failed',
      progress: 0,
      error: errorMessage
    });

    await logTelemetry(userId, 'video_upload_failed', {
      error: errorMessage,
      source: source
    });

    return null;
  }
}

export async function deleteVideo(videoId: string, userId: string): Promise<boolean> {
  try {
    const { data: video } = await supabase
      .from('player_videos')
      .select('storage_path')
      .eq('id', videoId)
      .eq('user_id', userId)
      .maybeSingle();

    if (!video) {
      throw new Error('Vídeo não encontrado');
    }

    const { data: shouldReverse } = await supabase.rpc('reverse_video_points', {
      p_video_id: videoId
    });

    const { error: updateError } = await supabase
      .from('player_videos')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', videoId)
      .eq('user_id', userId);

    if (updateError) {
      throw updateError;
    }

    if (video.storage_path) {
      await supabase.storage
        .from('player-videos')
        .remove([video.storage_path]);
    }

    await logTelemetry(userId, 'video_deleted', {
      video_id: videoId,
      points_reversed: shouldReverse
    });

    return true;
  } catch (error) {
    console.error('Error deleting video:', error);
    await logTelemetry(userId, 'video_delete_failed', {
      video_id: videoId,
      error: error instanceof Error ? error.message : 'Unknown error'
    });
    return false;
  }
}

export async function logTelemetry(
  userId: string,
  eventType: string,
  eventData?: Record<string, any>
): Promise<void> {
  try {
    await supabase
      .from('video_telemetry')
      .insert({
        user_id: userId,
        event_type: eventType,
        event_data: eventData || {}
      });
  } catch (error) {
    console.error('Failed to log telemetry:', error);
  }
}

export function validateVideoFile(file: File): {
  isValid: boolean;
  error?: string;
} {
  if (!file.type.startsWith('video/')) {
    return {
      isValid: false,
      error: 'Arquivo deve ser um vídeo',
    };
  }

  const maxSize = 100 * 1024 * 1024; // 100MB
  if (file.size > maxSize) {
    return {
      isValid: false,
      error: 'Vídeo muito grande. Máximo 100MB',
    };
  }

  const minSize = 100 * 1024; // 100KB
  if (file.size < minSize) {
    return {
      isValid: false,
      error: 'Vídeo muito pequeno',
    };
  }

  return { isValid: true };
}

export function formatVideoDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatVideoSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function generateVideoHash(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function getVideoDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';

    video.onloadedmetadata = () => {
      window.URL.revokeObjectURL(video.src);
      resolve(video.duration);
    };

    video.onerror = () => {
      reject(new Error('Erro ao ler metadados do vídeo'));
    };

    video.src = URL.createObjectURL(file);
  });
}
