import { useState, useEffect, useRef } from 'react';
import { MovementData } from '../utils/antiCheat';

export function useMotionSensor(isActive: boolean) {
  const [movementData, setMovementData] = useState<MovementData[]>([]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!isActive) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    // Check if DeviceMotionEvent is supported
    if (typeof DeviceMotionEvent === 'undefined') {
      console.warn('DeviceMotionEvent not supported');
      return;
    }

    const handleMotion = (event: DeviceMotionEvent) => {
      if (event.accelerationIncludingGravity) {
        const { x, y, z } = event.accelerationIncludingGravity;

        setMovementData(prev => [
          ...prev,
          {
            timestamp: Date.now(),
            x: x || 0,
            y: y || 0,
            z: z || 0
          }
        ]);
      }
    };

    // Request permission for iOS 13+
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      (DeviceMotionEvent as any).requestPermission()
        .then((response: string) => {
          if (response === 'granted') {
            window.addEventListener('devicemotion', handleMotion);
          }
        })
        .catch(console.error);
    } else {
      // Non-iOS or older iOS
      window.addEventListener('devicemotion', handleMotion);
    }

    return () => {
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [isActive]);

  const resetMovementData = () => {
    setMovementData([]);
  };

  return { movementData, resetMovementData };
}
