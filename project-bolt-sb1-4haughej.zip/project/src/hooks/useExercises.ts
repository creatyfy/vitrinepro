import { useState, useEffect } from 'react';
import {
  Exercise,
  getExercisesByCategory,
  getAllCategories,
  getExerciseVideoUrl
} from '../services/exerciseService';

export const useExercises = (category?: string) => {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchExercises = async () => {
      try {
        setLoading(true);
        setError(null);

        if (category) {
          const data = await getExercisesByCategory(category);
          setExercises(data);
        } else {
          setExercises([]);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error loading exercises');
        console.error('Error fetching exercises:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchExercises();
  }, [category]);

  return { exercises, loading, error };
};

export const useCategories = () => {
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await getAllCategories();
        setCategories(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error loading categories');
        console.error('Error fetching categories:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  return { categories, loading, error };
};

export const useExerciseVideo = (exercise: Exercise | null) => {
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (exercise) {
      setIsLoading(true);
      const url = getExerciseVideoUrl(exercise);
      setVideoUrl(url);
      setIsLoading(false);
    } else {
      setVideoUrl('');
    }
  }, [exercise]);

  return { videoUrl, isLoading };
};
