import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { profileService, ProfileData, PlayerProfileData } from '../services/profileService';

interface QuizData {
  name?: string;
  birthDate?: string;
  gender?: string;
  height?: number;
  weight?: number;
  position?: string;
  city?: string;
  state?: string;
  country?: string;
}

export function useProfile() {
  const [userId, setUserId] = useState<string | null>(null);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [playerProfile, setPlayerProfile] = useState<PlayerProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initializeUser();
  }, []);

  useEffect(() => {
    if (userId) {
      loadProfileData();
    }
  }, [userId]);

  async function initializeUser() {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (user) {
        setUserId(user.id);
      } else {
        const mockUserId = localStorage.getItem('vitrine_mock_user_id');
        if (!mockUserId) {
          const newMockId = crypto.randomUUID();
          localStorage.setItem('vitrine_mock_user_id', newMockId);
          setUserId(newMockId);
        } else {
          setUserId(mockUserId);
        }
      }
    } catch (error) {
      console.error('Error initializing user:', error);
      setError('Failed to initialize user');
      const mockUserId = localStorage.getItem('vitrine_mock_user_id');
      if (!mockUserId) {
        const newMockId = crypto.randomUUID();
        localStorage.setItem('vitrine_mock_user_id', newMockId);
        setUserId(newMockId);
      } else {
        setUserId(mockUserId);
      }
    } finally {
      setLoading(false);
    }
  }

  async function loadProfileData() {
    if (!userId) return;

    try {
      const [profileData, playerData] = await Promise.all([
        profileService.getProfile(userId),
        profileService.getPlayerProfile(userId)
      ]);

      setProfile(profileData);
      setPlayerProfile(playerData);
    } catch (error) {
      console.error('Error loading profile data:', error);
      setError('Failed to load profile');
    }
  }

  async function syncQuizDataToProfile(quizData: QuizData) {
    if (!userId) return false;

    try {
      const success = await profileService.syncQuizDataToProfile(userId, {
        name: quizData.name,
        birth_date: quizData.birthDate,
        gender: quizData.gender,
        height: quizData.height,
        weight: quizData.weight,
        position: quizData.position,
        city: quizData.city,
        state: quizData.state,
        country: quizData.country
      });

      if (success) {
        await loadProfileData();
      }

      return success;
    } catch (error) {
      console.error('Error in syncQuizDataToProfile:', error);
      return false;
    }
  }

  async function completeOnboarding(data: {
    full_name: string;
    phone: string;
    birth_date: string;
    gender: string;
    height: number;
    weight: number;
    user_type: 'athlete' | 'club' | 'agent';
    player_position?: string;
    goals?: string[];
    objective?: string;
    obstacles?: string[];
    training_frequency?: string;
    referral_source?: string;
    referral_code?: string;
  }) {
    if (!userId) return false;

    try {
      const success = await profileService.completeOnboarding(userId, data);

      if (success) {
        await loadProfileData();
      }

      return success;
    } catch (error) {
      console.error('Error completing onboarding:', error);
      return false;
    }
  }

  async function updateProfile(data: Partial<ProfileData>) {
    if (!userId) return false;

    try {
      const success = await profileService.updateProfile(userId, data);

      if (success) {
        await loadProfileData();
      }

      return success;
    } catch (error) {
      console.error('Error updating profile:', error);
      return false;
    }
  }

  return {
    userId,
    profile,
    playerProfile,
    loading,
    error,
    syncQuizDataToProfile,
    completeOnboarding,
    updateProfile,
    refreshProfile: loadProfileData
  };
}
