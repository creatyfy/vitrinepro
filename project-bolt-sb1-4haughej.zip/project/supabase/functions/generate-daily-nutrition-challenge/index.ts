import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface Dish {
  id: string;
  name: string;
  description: string;
  points_full: number;
  points_partial: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const today = new Date().toISOString().split('T')[0];
    
    // Check if challenge already exists for today
    const { data: existingChallenge } = await supabase
      .from('daily_nutrition_challenges')
      .select('*')
      .eq('challenge_date', today)
      .maybeSingle();

    if (existingChallenge) {
      return new Response(
        JSON.stringify({ 
          status: 'exists', 
          challenge: existingChallenge 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get yesterday's dish to avoid repetition
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    const { data: yesterdayChallenge } = await supabase
      .from('daily_nutrition_challenges')
      .select('dish_id')
      .eq('challenge_date', yesterdayStr)
      .maybeSingle();

    // Get all dishes except yesterday's
    const { data: dishes, error: dishesError } = await supabase
      .from('nutrition_dishes')
      .select('*')
      .neq('id', yesterdayChallenge?.dish_id || '00000000-0000-0000-0000-000000000000');

    if (dishesError || !dishes || dishes.length === 0) {
      throw new Error('No dishes available');
    }

    // Select random dish
    const randomDish = dishes[Math.floor(Math.random() * dishes.length)] as Dish;

    // Generate random gesture code (4 chars)
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let gestureCode = '';
    for (let i = 0; i < 4; i++) {
      gestureCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    // Set deadline to end of day
    const deadline = new Date();
    deadline.setHours(23, 59, 59, 999);

    // Create challenge
    const { data: newChallenge, error: challengeError } = await supabase
      .from('daily_nutrition_challenges')
      .insert({
        challenge_date: today,
        dish_id: randomDish.id,
        gesture_code: gestureCode,
        deadline: deadline.toISOString()
      })
      .select()
      .single();

    if (challengeError) {
      throw challengeError;
    }

    return new Response(
      JSON.stringify({
        status: 'created',
        challenge: {
          ...newChallenge,
          dish: randomDish
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error generating challenge:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});