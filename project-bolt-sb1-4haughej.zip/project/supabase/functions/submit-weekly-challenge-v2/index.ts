import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/jpg"];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Sem internet. Verifique sua conexão e tente de novo." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Sem internet. Verifique sua conexão e tente de novo." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const formData = await req.formData();
    const weekId = formData.get("week_id") as string;
    const challengeId = formData.get("challenge_id") as string;
    const photo = formData.get("photo") as File;
    const replaceExisting = formData.get("replace_existing") === "true";

    if (!weekId || !challengeId || !photo) {
      return new Response(
        JSON.stringify({ error: "Dados inválidos. Tente novamente." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (photo.size > MAX_FILE_SIZE) {
      return new Response(
        JSON.stringify({ error: "Foto muito grande. Máximo 5MB." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!ALLOWED_TYPES.includes(photo.type)) {
      return new Response(
        JSON.stringify({ error: "Formato inválido. Use JPEG ou PNG." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: challenge, error: challengeError } = await supabase
      .from("nutrition_weekly_challenges_v2")
      .select("deadline, points_on_submit")
      .eq("id", challengeId)
      .eq("week_id", weekId)
      .maybeSingle();

    if (challengeError || !challenge) {
      return new Response(
        JSON.stringify({ error: "Desafio não encontrado." }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (new Date() > new Date(challenge.deadline)) {
      return new Response(
        JSON.stringify({ error: "Prazo expirado. Aguarde o próximo desafio." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const fileExt = photo.name.split(".").pop() || "jpg";
    const fileName = `${user.id}_${Date.now()}.${fileExt}`;
    const filePath = `nutrition/weekly/${weekId}/${fileName}`;

    const photoBuffer = await photo.arrayBuffer();
    const photoHash = await crypto.subtle.digest("SHA-256", photoBuffer)
      .then(buf => Array.from(new Uint8Array(buf))
      .map(b => b.toString(16).padStart(2, "0"))
      .join(""));

    const { data: isDuplicate } = await supabase
      .rpc("check_duplicate_photo_v2", {
        p_user_id: user.id,
        p_photo_hash: photoHash
      });

    if (isDuplicate && !replaceExisting) {
      return new Response(
        JSON.stringify({ error: "Esta foto já foi usada. Use uma foto nova." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { error: uploadError } = await supabase.storage
      .from("nutrition-photos")
      .upload(filePath, photoBuffer, {
        contentType: photo.type,
        cacheControl: "3600",
        upsert: replaceExisting
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      return new Response(
        JSON.stringify({ error: "Falha no envio da foto. Tentar novamente?" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: { publicUrl } } = supabase.storage
      .from("nutrition-photos")
      .getPublicUrl(filePath);

    const submissionData = {
      user_id: user.id,
      week_id: weekId,
      challenge_id: challengeId,
      photo_url: publicUrl,
      photo_hash: photoHash,
      points_awarded: challenge.points_on_submit,
      metadata: {
        file_size: photo.size,
        file_type: photo.type,
        replaced: replaceExisting
      }
    };

    const { error: insertError } = await supabase
      .from("nutrition_weekly_submissions_v2")
      .upsert(submissionData, {
        onConflict: "user_id,week_id"
      });

    if (insertError) {
      console.error("Insert error:", insertError);
      return new Response(
        JSON.stringify({ error: "Falha no envio da foto. Tentar novamente?" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    await supabase
      .from("athlete_meal_history")
      .insert({
        user_id: user.id,
        meal_type: "desafio_semanal_v2",
        date: new Date().toISOString().split("T")[0],
        points_earned: challenge.points_on_submit,
        quality_score: 90,
        notes: `Desafio Semanal: ${weekId}`
      });

    return new Response(
      JSON.stringify({ 
        awarded_points: challenge.points_on_submit,
        message: `Foto enviada! +${challenge.points_on_submit} pontos.`
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: "Falha no envio da foto. Tentar novamente?" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});