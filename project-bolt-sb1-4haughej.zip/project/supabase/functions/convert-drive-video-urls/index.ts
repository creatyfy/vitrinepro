import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

function convertDriveUrlToEmbed(driveUrl: string): string {
  if (!driveUrl) return '';

  const fileIdMatch = driveUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);

  if (fileIdMatch && fileIdMatch[1]) {
    const fileId = fileIdMatch[1];
    return `https://drive.google.com/file/d/${fileId}/preview`;
  }

  return driveUrl;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: exercises, error: fetchError } = await supabase
      .from('exercises')
      .select('id, video_url, video_embed_url')
      .is('video_embed_url', null);

    if (fetchError) {
      throw new Error(`Error fetching exercises: ${fetchError.message}`);
    }

    if (!exercises || exercises.length === 0) {
      return new Response(
        JSON.stringify({
          success: true,
          message: 'All exercises already have embed URLs',
          updated: 0,
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const updates = [];
    for (const exercise of exercises) {
      const embedUrl = convertDriveUrlToEmbed(exercise.video_url);
      
      const { error: updateError } = await supabase
        .from('exercises')
        .update({ video_embed_url: embedUrl })
        .eq('id', exercise.id);

      if (updateError) {
        console.error(`Error updating exercise ${exercise.id}:`, updateError);
      } else {
        updates.push({
          id: exercise.id,
          original_url: exercise.video_url,
          embed_url: embedUrl,
        });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Successfully updated ${updates.length} exercises`,
        updated: updates.length,
        details: updates,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error in convert-drive-video-urls:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});