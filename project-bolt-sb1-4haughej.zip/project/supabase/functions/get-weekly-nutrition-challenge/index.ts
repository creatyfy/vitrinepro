import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

function getWeekNumber(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
}

function getWeekBounds(date: Date): { start: Date; end: Date } {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const start = new Date(d.setDate(diff));
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const now = new Date();
    const period = getWeekNumber(now);
    const { start, end } = getWeekBounds(now);

    let { data: weeklyChallenge, error: challengeError } = await supabase
      .from('daily_nutrition_challenges')
      .select(`
        *,
        dish:nutrition_dishes(*)
      `)
      .eq('challenge_date', start.toISOString().split('T')[0])
      .maybeSingle();

    if (!weeklyChallenge) {
      const lastWeekStart = new Date(start);
      lastWeekStart.setDate(lastWeekStart.getDate() - 7);

      const { data: lastWeekChallenge } = await supabase
        .from('daily_nutrition_challenges')
        .select('dish_id')
        .eq('challenge_date', lastWeekStart.toISOString().split('T')[0])
        .maybeSingle();

      const { data: dishes, error: dishesError } = await supabase
        .from('nutrition_dishes')
        .select('*')
        .neq('id', lastWeekChallenge?.dish_id || '00000000-0000-0000-0000-000000000000');

      if (dishesError || !dishes || dishes.length === 0) {
        throw new Error('No dishes available');
      }

      const randomDish = dishes[Math.floor(Math.random() * dishes.length)];

      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let gestureCode = '';
      for (let i = 0; i < 4; i++) {
        gestureCode += chars.charAt(Math.floor(Math.random() * chars.length));
      }

      const { data: newChallenge, error: createError } = await supabase
        .from('daily_nutrition_challenges')
        .insert({
          challenge_date: start.toISOString().split('T')[0],
          dish_id: randomDish.id,
          gesture_code: gestureCode,
          deadline: end.toISOString()
        })
        .select(`
          *,
          dish:nutrition_dishes(*)
        `)
        .single();

      if (createError) throw createError;
      weeklyChallenge = newChallenge;
    }

    const { data: submission } = await supabase
      .from('nutrition_submissions')
      .select('*')
      .eq('user_id', user.id)
      .eq('challenge_id', weeklyChallenge.id)
      .maybeSingle();

    const response = {
      period,
      cadence: 'WEEKLY',
      startAt: start.toISOString(),
      endAt: end.toISOString(),
      dish: {
        id: weeklyChallenge.dish.id,
        name: weeklyChallenge.dish.name,
        description: weeklyChallenge.dish.description,
        imageUrl: weeklyChallenge.dish.image_url || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
        pointsFull: weeklyChallenge.dish.points_full,
        pointsPartial: weeklyChallenge.dish.points_partial
      },
      gestureCode: weeklyChallenge.gesture_code,
      challengeId: weeklyChallenge.id,
      user: submission ? {
        submitted: true,
        status: submission.verification_status,
        provisionalPoints: submission.points_awarded,
        photoUrl: submission.photo_url,
        submittedAt: submission.submitted_at
      } : {
        submitted: false,
        status: null,
        provisionalPoints: 0
      }
    };

    return new Response(
      JSON.stringify(response),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { 
        status: error.message === 'Unauthorized' ? 401 : 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});