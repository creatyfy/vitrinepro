import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Não foi possível carregar o desafio. Tente novamente em alguns instantes." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Não foi possível carregar o desafio. Tente novamente em alguns instantes." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const weekId = new Date().toISOString().slice(0, 4) + "-W" + getWeekNumber(new Date());

    await supabase.rpc("create_weekly_challenge_if_needed");

    const { data: challenge, error: challengeError } = await supabase
      .from("nutrition_weekly_challenges_v2")
      .select(`
        id,
        week_id,
        deadline,
        points_on_submit,
        dish:nutrition_weekly_dishes_v2(
          id,
          name,
          image_url,
          recipe_steps,
          prep_time_minutes,
          macros
        )
      `)
      .eq("week_id", weekId)
      .eq("is_active", true)
      .maybeSingle();

    if (challengeError || !challenge) {
      console.error("Challenge error:", challengeError);
      return new Response(
        JSON.stringify({ error: "Não foi possível carregar o desafio. Tente novamente em alguns instantes." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: submission } = await supabase
      .from("nutrition_weekly_submissions_v2")
      .select("*")
      .eq("user_id", user.id)
      .eq("week_id", weekId)
      .maybeSingle();

    const response = {
      week_id: challenge.week_id,
      title: "Prato da Semana",
      dish_name: challenge.dish.name,
      image_url: challenge.dish.image_url,
      recipe_steps: challenge.dish.recipe_steps || [],
      prep_time_minutes: challenge.dish.prep_time_minutes,
      macros: challenge.dish.macros,
      deadline_iso: challenge.deadline,
      points_on_submit: challenge.points_on_submit,
      challenge_id: challenge.id,
      user_submission: submission ? {
        exists: true,
        image_url: submission.photo_url,
        submitted_at: submission.submitted_at,
        points_awarded: submission.points_awarded
      } : {
        exists: false
      }
    };

    return new Response(
      JSON.stringify(response),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: "Não foi possível carregar o desafio. Tente novamente em alguns instantes." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function getWeekNumber(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return weekNo.toString().padStart(2, "0");
}