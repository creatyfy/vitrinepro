/*
  # Sistema Completo de Medalhas Vitrine Pro

  1. Nova Estrutura
    - Tabela `medals` com todas as medalhas disponíveis
    - Tabela `user_medals` para rastrear medalhas dos usuários
    - Triggers automáticos para desbloquear medalhas
    
  2. Medalhas por Categoria
    - **Iniciante** (10 medalhas): primeiros passos na plataforma
    - **Consistência** (10 medalhas): treinos regulares e evolução
    - **Visibilidade** (10 medalhas): engajamento e destaque
    - **Performance** (6 medalhas): excelência esportiva
    - **Progressão** (10 medalhas): ranking e níveis
    - **Carreira** (5 medalhas): marcos profissionais
    - **Social** (5 medalhas): comunidade e networking
    - **Lendárias** (6 medalhas): conquistas raríssimas
    
  3. Sistema de Raridade
    - Comum: medalhas básicas (10-50 pontos)
    - Raro: medalhas intermediárias (100-300 pontos)
    - Épico: grandes conquistas (400-1000 pontos)
    - Lendário: conquistas extremas (1000-15000 pontos)
    
  4. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas para leitura pública e escrita autenticada
    - Auditoria de desbloqueio de medalhas
*/

-- Criar tabela de medalhas disponíveis
CREATE TABLE IF NOT EXISTS medals (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL CHECK (category IN ('iniciante', 'consistencia', 'visibilidade', 'performance', 'progressao', 'carreira', 'social', 'lendaria')),
  rarity text NOT NULL CHECK (rarity IN ('comum', 'raro', 'epico', 'lendario')),
  icon text NOT NULL,
  requirement_type text NOT NULL,
  requirement_target integer NOT NULL,
  requirement_condition text,
  points integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE medals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Medalhas são públicas"
  ON medals FOR SELECT
  TO public
  USING (true);

-- Criar tabela de medalhas dos usuários
CREATE TABLE IF NOT EXISTS user_medals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  medal_id text NOT NULL REFERENCES medals(id) ON DELETE CASCADE,
  unlocked_at timestamptz DEFAULT now(),
  progress integer DEFAULT 0,
  is_unlocked boolean DEFAULT false,
  UNIQUE(user_id, medal_id)
);

ALTER TABLE user_medals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários podem ver suas medalhas"
  ON user_medals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Medalhas são públicas para visualização"
  ON user_medals FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Sistema pode inserir medalhas"
  ON user_medals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Sistema pode atualizar medalhas"
  ON user_medals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Inserir todas as medalhas
INSERT INTO medals (id, name, description, category, rarity, icon, requirement_type, requirement_target, requirement_condition, points) VALUES
  -- INICIANTE
  ('chute_inicial', 'Chute Inicial', 'Primeiro treino concluído', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 1, NULL, 10),
  ('primeira_estrela', 'Primeira Estrela', 'Primeiro vídeo enviado', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'video_count', 1, NULL, 15),
  ('fominha', 'Fominha', '3 treinos concluídos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 3, NULL, 20),
  ('rookie_do_jogo', 'Rookie do Jogo', '5 treinos concluídos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 5, NULL, 30),
  ('deu_primeiro_gas', 'Deu o Primeiro Gás', '10 treinos concluídos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 10, NULL, 50),
  ('faz_o_l', 'Faz o L', '10 vídeos publicados', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'video_count', 10, NULL, 50),
  ('constancia_rei', 'Constância é Rei', '7 dias seguidos de treino', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 7, NULL, 70),
  ('sem_migue', 'Sem Migué', '14 dias seguidos de treino', 'iniciante', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 14, NULL, 100),
  
  -- CONSISTÊNCIA
  ('motorzinho', 'Motorzinho', '30 treinos concluídos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 30, NULL, 150),
  ('faro_de_gol', 'Faro de Gol', '50 treinos concluídos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 50, NULL, 200),
  ('raca_coracao', 'Raça e Coração', '20 dias seguidos de treino', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 20, NULL, 150),
  ('treino_jogo', 'Treino é Jogo', '25 vídeos publicados', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'video_count', 25, NULL, 150),
  ('orgulho_quebrada', 'Orgulho da Quebrada', '30 dias seguidos de treino', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 30, NULL, 250),
  ('ta_voando', 'Tá Voando', '75 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 75, NULL, 300),
  ('artilheiro_treino', 'Artilheiro de Treino', '100 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 100, NULL, 400),
  ('nunca_desista', 'Nunca Desista', 'Voltar após 30 dias parado', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'comeback_30days', 100),
  ('disciplina_tudo', 'Disciplina é Tudo', '60 dias seguidos de treino', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 60, NULL, 500),
  ('tanque_cheio', 'Tanque Cheio', '150 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 150, NULL, 600),
  
  -- VISIBILIDADE
  ('top_semana', 'Top da Semana', 'Aparecer no ranking semanal', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 10, 'weekly', 150),
  ('craque_bairro', 'Craque do Bairro', 'Destaque no ranking regional', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 5, 'regional', 200),
  ('idolo_local', 'Ídolo Local', '50 curtidas nos treinos', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'likes', 50, NULL, 150),
  ('camisa_10', 'Camisa 10', 'Avaliação positiva de empresário', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'agent_review', 300),
  ('olho_olheiro', 'Olho do Olheiro', 'Vídeo avaliado por olheiro', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'scout_review', 350),
  ('inspirando_base', 'Inspirando a Base', '100 curtidas nos treinos', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'likes', 100, NULL, 300),
  ('fazendo_historia', 'Fazendo História', 'Vídeo com 500 visualizações', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 500, NULL, 400),
  ('fenomeno_internet', 'Fenômeno da Internet', 'Vídeo com 1k views', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 1000, NULL, 500),
  ('ta_estourado', 'Tá Estourado', 'Vídeo com 5k views', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 5000, NULL, 1000),
  ('vitrine_nacional', 'Vitrine Nacional', 'Vídeo compartilhado por clube', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'club_share', 800),
  
  -- PERFORMANCE
  ('pe_anjo', 'Pé de Anjo', 'Completar 50 exercícios de finalização', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 50, 'finishing_drills', 200),
  ('velocista', 'Velocista', 'Registrar 20 sprints', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 20, 'sprints', 150),
  ('forca_bruta', 'Força Bruta', 'Completar 50 treinos de força', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 50, 'strength_training', 300),
  ('controle_total', 'Controle Total', '30 treinos de mobilidade', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 30, 'mobility_training', 200),
  ('explosao_maxima', 'Explosão Máxima', '20 treinos de explosão', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 20, 'explosive_training', 180),
  ('mestre_tecnica', 'Mestre da Técnica', 'Completar todos os exercícios técnicos de 1 semana', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'weekly_technical_complete', 250),
  
  -- PROGRESSÃO
  ('novato_promissor', 'Novato Promissor', 'Subir para nível intermediário', 'progressao', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'level_intermediate', 100),
  ('semi_pro', 'Semi Pro', 'Desbloquear nível semi-profissional', 'progressao', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'level_semi_pro', 300),
  ('pro_player', 'Pro Player', 'Desbloquear nível profissional', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'level_pro', 500),
  ('craque_vitrine', 'Craque da Vitrine', 'Chegar ao nível avançado', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'level_advanced', 600),
  ('elite_campo', 'Elite do Campo', 'Atingir o nível máximo', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'level_max', 1000),
  ('balon_ouro', 'Balón de Ouro', 'Liderar ranking geral', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 1, 'global', 1500),
  ('bola_prata', 'Bola de Prata', 'Vice-líder do ranking', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 2, 'global', 1200),
  ('bola_bronze', 'Bola de Bronze', 'Terceiro lugar do ranking', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 3, 'global', 1000),
  ('estrela_temporada', 'Estrela da Temporada', 'Destaque no final do mês', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 1, 'monthly', 800),
  ('revelacao_ano', 'Revelação do Ano', 'Eleito revelação anual', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'yearly_revelation', 2000),
  
  -- CARREIRA
  ('contrato_assinado', 'Contrato Assinado', 'Fechar primeiro contrato oficial', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'first_contract', 1000),
  ('sonho_realizado', 'Sonho Realizado', 'Primeiro teste em clube', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'first_tryout', 800),
  ('clube_vitrine', 'Clube Vitrine', 'Parceria firmada com clube', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'club_partnership', 1500),
  ('estreia_profissional', 'Estreia Profissional', 'Primeiro jogo oficial no profissional', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'pro_debut', 2000),
  ('internacional', 'Internacional', 'Contato com clube estrangeiro', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'international_contact', 1800),
  
  -- SOCIAL
  ('amigos_jogo', 'Amigos do Jogo', 'Ganhar 10 seguidores', 'social', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'followers', 10, NULL, 50),
  ('torcida_organizada', 'Torcida Organizada', 'Ganhar 50 seguidores', 'social', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'followers', 50, NULL, 150),
  ('idolo_massa', 'Ídolo da Massa', 'Ganhar 100 seguidores', 'social', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'followers', 100, NULL, 300),
  ('conexao_vitrine', 'Conexão Vitrine', 'Enviar 10 mensagens pra empresários', 'social', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'agent_messages', 100),
  ('mito_quebrada', 'Mito da Quebrada', '500 seguidores no app', 'social', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'followers', 500, NULL, 1000),
  
  -- LENDÁRIAS
  ('um_ano_raca', 'Um Ano de Raça', '365 treinos no ano', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 365, NULL, 3000),
  ('lenda_campo', 'Lenda do Campo', '500 treinos concluídos', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 500, NULL, 5000),
  ('rei_vitrine', 'Rei da Vitrine', 'Atleta com mais engajamento no ano', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'yearly_engagement_leader', 5000),
  ('fenomeno_global', 'Fenômeno Global', 'Destaque fora do país', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'international_highlight', 4000),
  ('contrato_ouro', 'Contrato de Ouro', 'Assinatura com time de Série A', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'serie_a_contract', 10000),
  ('hall_fama', 'Hall da Fama Vitrine', 'Maior honra do app', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'hall_of_fame', 15000)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  category = EXCLUDED.category,
  rarity = EXCLUDED.rarity,
  icon = EXCLUDED.icon,
  requirement_type = EXCLUDED.requirement_type,
  requirement_target = EXCLUDED.requirement_target,
  requirement_condition = EXCLUDED.requirement_condition,
  points = EXCLUDED.points;

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_user_medals_user_id ON user_medals(user_id);
CREATE INDEX IF NOT EXISTS idx_user_medals_medal_id ON user_medals(medal_id);
CREATE INDEX IF NOT EXISTS idx_user_medals_unlocked ON user_medals(user_id, is_unlocked);
CREATE INDEX IF NOT EXISTS idx_medals_category ON medals(category);
CREATE INDEX IF NOT EXISTS idx_medals_rarity ON medals(rarity);
