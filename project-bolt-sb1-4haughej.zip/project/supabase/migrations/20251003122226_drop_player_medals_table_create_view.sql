/*
  # Converter player_medals de tabela para view

  1. Mudança de Estrutura
    - Remove tabela antiga player_medals (que tinha apenas 7 medalhas hardcoded)
    - Cria view player_medals que mostra todas as 80 medalhas do sistema
    - Une dados de medals (definições) com user_medals (progresso individual)
    
  2. Benefícios
    - Sistema centralizado de medalhas
    - Jogadores veem todas as 80 medalhas
    - Progresso individual rastreado corretamente
*/

-- Drop tabela antiga (isso vai remover os dados antigos, mas está ok pois vamos migrar)
DROP TABLE IF EXISTS player_medals CASCADE;

-- Criar view que une medals com user_medals
CREATE VIEW player_medals AS
SELECT 
  COALESCE(um.id, gen_random_uuid()) as id,
  um.user_id,
  m.category as medal_type,
  m.name as medal_name,
  m.description as medal_description,
  m.icon as medal_icon,
  um.unlocked_at as earned_at,
  COALESCE(um.progress, 0) as progress,
  m.requirement_target as target,
  COALESCE(um.is_unlocked, false) as is_unlocked,
  COALESCE(um.unlocked_at, now()) as created_at,
  m.medal_order,
  m.points,
  m.rarity,
  m.id as medal_id
FROM medals m
LEFT JOIN user_medals um ON m.id = um.medal_id
ORDER BY m.medal_order;
