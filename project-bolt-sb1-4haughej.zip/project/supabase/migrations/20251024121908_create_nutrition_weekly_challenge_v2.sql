/*
  # Desafio Semanal de Nutrição V2 - Sistema Simplificado e Robusto

  ## Resumo
  Refatoração completa do sistema de desafios semanais de nutrição.
  Remove a complexidade anterior e implementa um fluxo simples e confiável.

  ## Mudanças
  
  ### 1. Limpeza (Desativa V1 temporariamente)
  - Mantém tabelas antigas por enquanto para auditoria
  - Cria novas tabelas V2 com estrutura simplificada
  
  ### 2. Novas Tabelas V2
  
  #### nutrition_weekly_dishes_v2
  - Pratos disponíveis para sorteio semanal
  - Campos: id, name, image_url, recipe_steps (jsonb), prep_time_minutes, macros (jsonb)
  
  #### nutrition_weekly_challenges_v2
  - Um desafio por semana (global)
  - Campos: week_id, dish_id, deadline, points_on_submit, is_active
  
  #### nutrition_weekly_submissions_v2
  - Submissões dos usuários
  - Campos: user_id, week_id, photo_url, points_awarded, submitted_at
  - UNIQUE constraint: um envio por usuário por semana (com opção de substituir)
  
  ### 3. Feature Flag
  - Coluna para controlar rollout: feature_flags.nutrition_weekly_challenge_v2
  
  ## Segurança (RLS)
  - Usuários podem ver desafios ativos
  - Usuários podem inserir/atualizar apenas suas próprias submissões
  - Usuários podem ver apenas suas próprias submissões
*/

-- 1. Criar tabela de pratos V2 (simplificada)
CREATE TABLE IF NOT EXISTS nutrition_weekly_dishes_v2 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  image_url text NOT NULL,
  recipe_steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  prep_time_minutes integer DEFAULT 30,
  macros jsonb NOT NULL DEFAULT '{"kcal": 0, "protein": 0, "carbs": 0, "fat": 0}'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_weekly_dishes_v2 ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active dishes v2"
  ON nutrition_weekly_dishes_v2 FOR SELECT
  TO authenticated
  USING (is_active = true);

-- 2. Criar tabela de desafios semanais V2
CREATE TABLE IF NOT EXISTS nutrition_weekly_challenges_v2 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  week_id text NOT NULL UNIQUE,
  dish_id uuid NOT NULL REFERENCES nutrition_weekly_dishes_v2(id) ON DELETE CASCADE,
  deadline timestamptz NOT NULL,
  points_on_submit integer DEFAULT 10,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_weekly_challenges_v2 ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active challenges v2"
  ON nutrition_weekly_challenges_v2 FOR SELECT
  TO authenticated
  USING (is_active = true);

-- 3. Criar tabela de submissões V2
CREATE TABLE IF NOT EXISTS nutrition_weekly_submissions_v2 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  week_id text NOT NULL,
  challenge_id uuid NOT NULL REFERENCES nutrition_weekly_challenges_v2(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  photo_hash text NOT NULL,
  points_awarded integer DEFAULT 0,
  submitted_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb,
  UNIQUE(user_id, week_id)
);

ALTER TABLE nutrition_weekly_submissions_v2 ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own submissions v2"
  ON nutrition_weekly_submissions_v2 FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own submissions v2"
  ON nutrition_weekly_submissions_v2 FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own submissions v2"
  ON nutrition_weekly_submissions_v2 FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- 4. Índices para performance
CREATE INDEX IF NOT EXISTS idx_weekly_dishes_v2_active ON nutrition_weekly_dishes_v2(is_active);
CREATE INDEX IF NOT EXISTS idx_weekly_challenges_v2_week ON nutrition_weekly_challenges_v2(week_id, is_active);
CREATE INDEX IF NOT EXISTS idx_weekly_submissions_v2_user ON nutrition_weekly_submissions_v2(user_id, week_id);
CREATE INDEX IF NOT EXISTS idx_weekly_submissions_v2_challenge ON nutrition_weekly_submissions_v2(challenge_id);
CREATE INDEX IF NOT EXISTS idx_weekly_submissions_v2_hash ON nutrition_weekly_submissions_v2(photo_hash);

-- 5. Inserir pratos iniciais simplificados
INSERT INTO nutrition_weekly_dishes_v2 (name, image_url, recipe_steps, prep_time_minutes, macros) VALUES
(
  'Frango Grelhado com Legumes',
  'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Tempere o frango com sal, pimenta e limão", "Grelhe o frango por 6-8 minutos de cada lado", "Cozinhe os legumes no vapor por 10 minutos", "Tempere os legumes com azeite e ervas", "Monte o prato e sirva quente"]'::jsonb,
  25,
  '{"kcal": 520, "protein": 45, "carbs": 35, "fat": 18}'::jsonb
),
(
  'Salmão com Batata Doce',
  'https://images.pexels.com/photos/1410235/pexels-photo-1410235.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Tempere o salmão com sal e limão", "Asse o salmão a 180°C por 15 minutos", "Cozinhe a batata doce por 20 minutos", "Prepare uma salada verde", "Monte o prato e finalize com azeite"]'::jsonb,
  30,
  '{"kcal": 580, "protein": 38, "carbs": 48, "fat": 22}'::jsonb
),
(
  'Omelete de Claras com Aveia',
  'https://images.pexels.com/photos/566345/pexels-photo-566345.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Separe 4 claras de ovo", "Bata as claras com sal e ervas", "Aqueça uma frigideira antiaderente", "Despeje as claras e cozinhe por 3 minutos", "Sirva com aveia e frutas"]'::jsonb,
  15,
  '{"kcal": 320, "protein": 28, "carbs": 38, "fat": 6}'::jsonb
),
(
  'Bowl de Quinoa com Legumes',
  'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Cozinhe a quinoa conforme embalagem", "Asse os legumes (abobrinha, tomate, pimentão)", "Prepare um molho de iogurte com ervas", "Monte o bowl com quinoa e legumes", "Finalize com o molho e sementes"]'::jsonb,
  35,
  '{"kcal": 480, "protein": 18, "carbs": 62, "fat": 16}'::jsonb
),
(
  'Wrap de Frango com Salada',
  'https://images.pexels.com/photos/1059905/pexels-photo-1059905.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Desfie o frango grelhado", "Lave e pique a salada", "Aqueça a tortilha integral", "Monte o wrap com frango e salada", "Enrole e corte ao meio"]'::jsonb,
  20,
  '{"kcal": 420, "protein": 35, "carbs": 42, "fat": 12}'::jsonb
),
(
  'Peixe Assado com Arroz Integral',
  'https://images.pexels.com/photos/842142/pexels-photo-842142.jpeg?auto=compress&cs=tinysrgb&w=800',
  '["Tempere o peixe com limão e ervas", "Asse a 200°C por 20 minutos", "Cozinhe o arroz integral", "Refogue brócolis no azeite", "Monte o prato e sirva"]'::jsonb,
  40,
  '{"kcal": 550, "protein": 40, "carbs": 58, "fat": 14}'::jsonb
)
ON CONFLICT DO NOTHING;

-- 6. Função para verificar fotos duplicadas V2
CREATE OR REPLACE FUNCTION check_duplicate_photo_v2(
  p_user_id uuid,
  p_photo_hash text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM nutrition_weekly_submissions_v2
    WHERE user_id = p_user_id 
      AND photo_hash = p_photo_hash
      AND submitted_at > NOW() - INTERVAL '30 days'
  );
END;
$$;

-- 7. Função para criar desafio semanal automaticamente
CREATE OR REPLACE FUNCTION create_weekly_challenge_if_needed()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_week_id text;
  v_week_start date;
  v_week_end timestamptz;
  v_random_dish_id uuid;
  v_challenge_exists boolean;
BEGIN
  -- Calcular week_id (formato: 2025-W43)
  v_week_id := TO_CHAR(CURRENT_DATE, 'IYYY') || '-W' || TO_CHAR(CURRENT_DATE, 'IW');
  
  -- Verificar se já existe desafio para esta semana
  SELECT EXISTS(
    SELECT 1 FROM nutrition_weekly_challenges_v2 WHERE week_id = v_week_id
  ) INTO v_challenge_exists;
  
  IF NOT v_challenge_exists THEN
    -- Calcular início e fim da semana (segunda a domingo 23:59:59)
    v_week_start := DATE_TRUNC('week', CURRENT_DATE);
    v_week_end := v_week_start + INTERVAL '6 days 23 hours 59 minutes 59 seconds';
    
    -- Selecionar prato aleatório (evitar o da semana passada se possível)
    SELECT id INTO v_random_dish_id
    FROM nutrition_weekly_dishes_v2
    WHERE is_active = true
      AND id NOT IN (
        SELECT dish_id 
        FROM nutrition_weekly_challenges_v2 
        ORDER BY created_at DESC 
        LIMIT 1
      )
    ORDER BY RANDOM()
    LIMIT 1;
    
    -- Se não encontrou (talvez só existe 1 prato), pegar qualquer um
    IF v_random_dish_id IS NULL THEN
      SELECT id INTO v_random_dish_id
      FROM nutrition_weekly_dishes_v2
      WHERE is_active = true
      ORDER BY RANDOM()
      LIMIT 1;
    END IF;
    
    -- Criar desafio
    IF v_random_dish_id IS NOT NULL THEN
      INSERT INTO nutrition_weekly_challenges_v2 (week_id, dish_id, deadline, points_on_submit)
      VALUES (v_week_id, v_random_dish_id, v_week_end, 10);
    END IF;
  END IF;
END;
$$;

-- 8. Comentários
COMMENT ON TABLE nutrition_weekly_dishes_v2 IS 'V2: Pratos simplificados para desafio semanal';
COMMENT ON TABLE nutrition_weekly_challenges_v2 IS 'V2: Um desafio global por semana';
COMMENT ON TABLE nutrition_weekly_submissions_v2 IS 'V2: Submissões dos usuários (um por semana, substituível)';
