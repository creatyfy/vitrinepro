/*
  # Add Free Agent Field

  1. Purpose
    - Add free_agent boolean field to track if player is available in the market
    - When true, club field should be null

  2. Changes
    - Add free_agent boolean column (default false)
    - Add check constraint to ensure club is null when free_agent is true

  3. Security
    - Maintain existing RLS policies
*/

-- Add free_agent field
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'free_agent'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN free_agent boolean DEFAULT false;
  END IF;
END $$;

-- Create index for free agents query
CREATE INDEX IF NOT EXISTS idx_player_profiles_free_agent 
  ON player_profiles(free_agent) 
  WHERE free_agent = true;

-- Add comment
COMMENT ON COLUMN player_profiles.free_agent IS 'Indicates if player is available in the market (no current club)';
