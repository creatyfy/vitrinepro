/*
  # Atualizar URLs de Vídeo para Formato Embed Automaticamente

  ## Descrição
  Esta migration atualiza automaticamente todas as URLs dos vídeos do Google Drive
  para o formato embed/preview que funciona melhor em iframes.

  ## Mudanças
    - Adiciona função para converter URLs automaticamente
    - Atualiza todas as URLs existentes
    - Cria trigger para converter URLs automaticamente ao inserir/atualizar
*/

-- Função para converter URL do Google Drive para formato embed
CREATE OR REPLACE FUNCTION convert_drive_url_to_embed(drive_url text)
RETURNS text AS $$
DECLARE
  file_id text;
BEGIN
  IF drive_url IS NULL OR drive_url = '' THEN
    RETURN drive_url;
  END IF;

  file_id := substring(drive_url from '/d/([a-zA-Z0-9_-]+)');
  
  IF file_id IS NOT NULL THEN
    RETURN 'https://drive.google.com/file/d/' || file_id || '/preview';
  END IF;
  
  RETURN drive_url;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Atualizar todas as URLs existentes para formato embed
UPDATE exercises
SET video_embed_url = convert_drive_url_to_embed(video_url)
WHERE video_embed_url IS NULL OR video_embed_url = '';

-- Função trigger para converter URL automaticamente
CREATE OR REPLACE FUNCTION auto_convert_video_url()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.video_url IS NOT NULL AND NEW.video_url != '' THEN
    NEW.video_embed_url := convert_drive_url_to_embed(NEW.video_url);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para converter URLs automaticamente ao inserir ou atualizar
DROP TRIGGER IF EXISTS trigger_auto_convert_video_url ON exercises;
CREATE TRIGGER trigger_auto_convert_video_url
  BEFORE INSERT OR UPDATE OF video_url ON exercises
  FOR EACH ROW
  EXECUTE FUNCTION auto_convert_video_url();

-- Comentário para documentação
COMMENT ON FUNCTION convert_drive_url_to_embed(text) IS 
  'Converte URL do Google Drive para formato embed/preview automaticamente';

COMMENT ON FUNCTION auto_convert_video_url() IS 
  'Trigger function para converter URLs de vídeo automaticamente ao inserir/atualizar exercícios';
