-- Criar Tabelas para Funcionalidades do Ranking
-- Notícias do futebol de base, conquistas da comunidade e localização dos atletas

-- Tabela de Notícias
CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  summary text NOT NULL,
  full_content text NOT NULL,
  image_url text,
  category text DEFAULT 'geral' CHECK (category IN ('dica', 'historia', 'metodo', 'projeto', 'geral')),
  is_featured boolean DEFAULT false,
  views_count integer DEFAULT 0,
  author text DEFAULT 'Vitrine Pro',
  published_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read news articles"
  ON news_articles FOR SELECT
  TO public
  USING (published_at <= now());

CREATE POLICY "Only admins can insert news"
  ON news_articles FOR INSERT
  TO authenticated
  WITH CHECK (false);

CREATE POLICY "Only admins can update news"
  ON news_articles FOR UPDATE
  TO authenticated
  USING (false);

CREATE POLICY "Only admins can delete news"
  ON news_articles FOR DELETE
  TO authenticated
  USING (false);

-- Tabela de Conquistas da Comunidade
CREATE TABLE IF NOT EXISTS community_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_type text NOT NULL CHECK (achievement_type IN ('profissional', 'medalhas', 'treinos', 'clube', 'outro')),
  title text NOT NULL,
  description text,
  image_url text,
  location_city text,
  location_state text,
  is_featured boolean DEFAULT false,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE community_achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read community achievements"
  ON community_achievements FOR SELECT
  TO authenticated
  USING (is_featured = true);

CREATE POLICY "Users can insert their own achievements"
  ON community_achievements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own achievements"
  ON community_achievements FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own achievements"
  ON community_achievements FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Tabela de Localização dos Atletas
CREATE TABLE IF NOT EXISTS athlete_locations (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  state text NOT NULL,
  city text NOT NULL,
  latitude decimal(10, 8),
  longitude decimal(11, 8),
  is_active boolean DEFAULT true,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE athlete_locations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read athlete locations"
  ON athlete_locations FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Users can manage their own location"
  ON athlete_locations FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Inserir algumas notícias de exemplo
INSERT INTO news_articles (title, summary, full_content, image_url, category, is_featured) VALUES
('Projeto social revela 3 novos talentos no Nordeste', 'Iniciativa em Pernambuco descobre jovens promessas através de treinos sistemáticos', 'Um projeto social em Recife vem chamando atenção de olheiros profissionais. Nos últimos 3 meses, 3 atletas do projeto foram convidados para testes em clubes da Série A. O segredo? Treinos diários registrados no Vitrine Pro e acompanhamento técnico constante.', 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=800', 'projeto', true),
('5 dicas para melhorar sua velocidade em 30 dias', 'Treinos específicos podem aumentar sua performance rapidamente', 'A velocidade é fundamental no futebol moderno. Veja 5 exercícios comprovados que vão te fazer mais rápido: 1) Tiros de 30m com descanso ativo, 2) Escadas de agilidade, 3) Pliometria, 4) Treino em rampa, 5) Exercícios de coordenação motora. Execute 3x por semana.', 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=800', 'dica', true),
('A história de João: de pelada ao profissional', 'Atleta do interior virou profissional aos 19 anos', 'João Silva começou jogando pelada no interior de Minas Gerais. Aos 17 anos, descobriu o Vitrine Pro e começou a registrar seus treinos diariamente. Dois anos depois, foi contratado por um clube da Série B. "A disciplina e os dados me deram credibilidade", conta.', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=800', 'historia', true),
('Como a periodização pode transformar seu treino', 'Método usado por profissionais agora acessível a todos', 'A periodização é a chave para evolução constante. Em vez de treinar aleatoriamente, organize seu treino em ciclos: 1) Base (resistência), 2) Força, 3) Velocidade, 4) Técnica. Cada ciclo de 4 semanas. O Vitrine Pro te ajuda a organizar isso.', 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=800', 'metodo', true);

-- Inserir algumas conquistas de exemplo
INSERT INTO community_achievements (achievement_type, title, description, location_city, location_state, is_featured) VALUES
('profissional', 'João Silva virou jogador profissional', 'Contratado pelo ABC-RN após destaque no Vitrine Pro', 'Natal', 'RN', true),
('medalhas', 'Pedro Marques completou todas as medalhas de ouro', '365 dias de treino consecutivo e 80 medalhas conquistadas', 'São Paulo', 'SP', true),
('treinos', 'Ana Costa fez 365 treinos seguidos', 'Um ano inteiro sem faltar um dia de treino', 'Curitiba', 'PR', true),
('clube', 'Clube Base F7 revelou 3 atletas', 'Projeto social enviou atletas para avaliação nacional', 'Recife', 'PE', true);
