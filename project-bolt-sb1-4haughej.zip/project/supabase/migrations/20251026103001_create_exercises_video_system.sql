/*
  # Sistema de Vídeos para Exercícios

  ## Descrição
  Este migration cria o sistema completo de gerenciamento de exercícios com vídeos em loop
  para serem exibidos durante a execução dos treinos.

  ## Nova Tabela
    - `exercises`
      - `id` (uuid, primary key) - ID único do exercício
      - `name` (text) - Nome do exercício
      - `category` (text) - Categoria (Equilíbrio, Explosão, Fortalecimento, Peladas)
      - `video_url` (text) - URL do vídeo no Google Drive
      - `video_embed_url` (text) - URL convertida para embed direto
      - `description` (text) - Descrição do exercício
      - `duration` (integer) - Duração em segundos (se aplicável)
      - `sets` (integer) - Número de séries recomendadas
      - `reps` (text) - Repetições ou tempo por série
      - `difficulty` (text) - Nível de dificuldade (iniciante, intermediário, avançado)
      - `created_at` (timestamptz) - Data de criação
      - `updated_at` (timestamptz) - Data de atualização
  
  ## Segurança
    - RLS habilitado
    - Políticas para leitura pública e escrita apenas para usuários autenticados
  
  ## Dados Iniciais
    - Inserção de todos os exercícios da categoria Equilíbrio com seus vídeos
*/

-- Criar tabela de exercícios
CREATE TABLE IF NOT EXISTS exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL DEFAULT 'Equilíbrio',
  video_url text NOT NULL,
  video_embed_url text,
  description text DEFAULT '',
  duration integer DEFAULT 0,
  sets integer DEFAULT 3,
  reps text DEFAULT '10-12',
  difficulty text DEFAULT 'intermediário',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

-- Política para leitura (todos podem ver)
CREATE POLICY "Todos podem visualizar exercícios"
  ON exercises
  FOR SELECT
  TO public
  USING (true);

-- Política para inserção (apenas autenticados)
CREATE POLICY "Usuários autenticados podem criar exercícios"
  ON exercises
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Política para atualização (apenas autenticados)
CREATE POLICY "Usuários autenticados podem atualizar exercícios"
  ON exercises
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Política para exclusão (apenas autenticados)
CREATE POLICY "Usuários autenticados podem deletar exercícios"
  ON exercises
  FOR DELETE
  TO authenticated
  USING (true);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_exercises_category ON exercises(category);
CREATE INDEX IF NOT EXISTS idx_exercises_name ON exercises(name);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_exercises_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_update_exercises_updated_at'
  ) THEN
    CREATE TRIGGER trigger_update_exercises_updated_at
      BEFORE UPDATE ON exercises
      FOR EACH ROW
      EXECUTE FUNCTION update_exercises_updated_at();
  END IF;
END $$;

-- Inserir exercícios de Equilíbrio com URLs do Google Drive
INSERT INTO exercises (name, category, video_url, sets, reps, difficulty) VALUES
('Abdominal dinâmico sobre superfície instável com equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1jNBVyCS3O1S6AwDqhTFd2eApIgzoAVzx/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Abdução unilateral com elástico em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1ftL4rtdvp8oOlP0PcKRX7x8N-7yyKysT/view?usp=drive_link', 3, '12-15 cada lado', 'intermediário'),
('Afundo com equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1Yy0zdApYF4epN1Hl8iz--aE7PW5n2vPE/view?usp=drive_link', 3, '10 cada perna', 'iniciante'),
('Afundo com salto em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1ImOKJ7NiVMj_XBt6SEgKUm-xBQ4Jjpsz/view?usp=drive_link', 4, '8-10 cada perna', 'avançado'),
('Afundo dinâmico em equilíbrio com mãos sobre a cabeça', 'Equilíbrio', 'https://drive.google.com/file/d/1fgR4Z4IE1GovmXiTRwo_gnaWkX8bhYr1/view?usp=drive_link', 3, '10 cada perna', 'intermediário'),
('Agachamento com braços à frente em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1gWF0dQCUdI4iWHKCzfTL4f0R6hwphVEm/view?usp=drive_link', 3, '12-15', 'iniciante'),
('Agachamento com equilíbrio de bastão', 'Equilíbrio', 'https://drive.google.com/file/d/1VL8-_sUOI84F4BY4KDsOGG77Rba5KQlw/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Agachamento em superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1dpbs-RYjtsuvr_safzBqWu-qP9K6Tyi1/view?usp=drive_link', 3, '12-15', 'intermediário'),
('Agachamento isométrico com rotação de tronco', 'Equilíbrio', 'https://drive.google.com/file/d/1ppbFpeXZTqeVLo8X00Hgf4k68Uk0GcBW/view?usp=drive_link', 3, '30-45s', 'intermediário'),
('Agachamento isométrico na parede unilateral', 'Equilíbrio', 'https://drive.google.com/file/d/1ktFX_wq2nwzBI2yGqGJp6VZF9aT37txg/view?usp=drive_link', 3, '30-45s cada perna', 'avançado'),
('Agachamento lateral com braços pra cima', 'Equilíbrio', 'https://drive.google.com/file/d/1FuHOEfO_vwn_wXQ1A1xF-2MXXP_0CWum/view?usp=drive_link', 3, '10-12 cada lado', 'iniciante'),
('Agachamento sobre superfície instável unilateral', 'Equilíbrio', 'https://drive.google.com/file/d/15vvW4Tr9hWCMCOP_xSz3dVxYoddfmUwJ/view?usp=drive_link', 3, '8-10 cada perna', 'avançado'),
('Caminhada com equilíbrio de carga nos pés', 'Equilíbrio', 'https://drive.google.com/file/d/18buobs0F6zOjwqnRtTh-cGFU6nX4Mul7/view?usp=drive_link', 3, '20-30 passos', 'iniciante'),
('Caminhada com equilíbrio de peso', 'Equilíbrio', 'https://drive.google.com/file/d/1_krSgVvD0xgkbbgon2OkAzv_p9Wyzw_P/view?usp=drive_link', 3, '20-30 passos', 'iniciante'),
('Caminhada sobre superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/14JwIG0ClPEJ-HD6rG4nNo4e6C3DD0Xnu/view?usp=drive_link', 3, '20-30 passos', 'intermediário'),
('Circuito com equilíbrio trocando de perna', 'Equilíbrio', 'https://drive.google.com/file/d/1jNOsBWCQCVwZB9CmrR5djYsPKhJRIMd5/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Corrida com salto sobre superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1Cuw9H9jSxKdqb4SnsgtEL4RUB5ZE4As6/view?usp=drive_link', 4, '8-10', 'avançado'),
('Equilíbrio com carga', 'Equilíbrio', 'https://drive.google.com/file/d/1pqFn0JN9ohXaCi7-da4WXaKVykMO7ELa/view?usp=drive_link', 3, '30-45s cada perna', 'iniciante'),
('Equilíbrio com carga acima da cabeça', 'Equilíbrio', 'https://drive.google.com/file/d/1A8A34BDeDxfyRP163AtJ5rg1B5PJL4Gc/view?usp=drive_link', 3, '30-45s cada perna', 'intermediário'),
('Equilíbrio com carga sobre superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1O_-s39kL9u_cCZmSbQlYkJK1_ObB6ibN/view?usp=drive_link', 3, '30-45s cada perna', 'avançado'),
('Equilíbrio com elástico + elevação de perna', 'Equilíbrio', 'https://drive.google.com/file/d/1vLkA8Q071KgVu7GL3Kb8ZI3ccdSc0ONP/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Equilíbrio com elástico nos pés', 'Equilíbrio', 'https://drive.google.com/file/d/1kLEZrcoaPN8qO5VdwTTgqFz5YqiLT5Tl/view?usp=drive_link', 3, '12-15 cada perna', 'intermediário'),
('Equilíbrio com elevação à frente com elástico', 'Equilíbrio', 'https://drive.google.com/file/d/1tb1-JM51kDIOEazL8VZ6QYUAMf-lKJeq/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Equilíbrio com perna à frente e mãos sobre a cabeça', 'Equilíbrio', 'https://drive.google.com/file/d/1L9Rz9MKnLbQpF62uSBvfqpHd8IJjB-h9/view?usp=drive_link', 3, '30-45s cada perna', 'intermediário'),
('Equilíbrio com um pé só com rotação de tronco', 'Equilíbrio', 'https://drive.google.com/file/d/1rjQpxE4aecDnU4aB3usZiAq_LyOLMDtW/view?usp=drive_link', 3, '10-12 cada lado', 'intermediário'),
('Equilíbrio com um pé só com toque à frente', 'Equilíbrio', 'https://drive.google.com/file/d/1fWMIDBPr-gwa-U_w0ljonzhaKdOmTCoE/view?usp=drive_link', 3, '10-12 cada perna', 'iniciante'),
('Equilíbrio com um pé só com toque ao lado', 'Equilíbrio', 'https://drive.google.com/file/d/1mxTjn1-oT__WMKStQHVIdaHgf8BPc9cK/view?usp=drive_link', 3, '10-12 cada perna', 'iniciante'),
('Equilíbrio de peso com uma perna em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1eVgctYlqS9XiSl2OJarw4fw56f8WBvpO/view?usp=drive_link', 3, '30-45s cada perna', 'intermediário'),
('Equilíbrio de um pé só', 'Equilíbrio', 'https://drive.google.com/file/d/1XwTxxcdYkP8ZBjkwk7S3giYm_qcN0X3K/view?usp=drive_link', 3, '45-60s cada perna', 'iniciante'),
('Equilíbrio dinâmico com elástico nos pés', 'Equilíbrio', 'https://drive.google.com/file/d/1P2_TvlOB0qWC5cTJzkgoQzhsfPPa_FEX/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Equilíbrio dinâmico com mãos na cabeça', 'Equilíbrio', 'https://drive.google.com/file/d/18WfEVDTyZkFMnhaqDJzBBQ8okhgj13fE/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Equilíbrio dinâmico com troca de perna', 'Equilíbrio', 'https://drive.google.com/file/d/1mcTtXvpnwL04aluerh4qQBGnx0jQCclM/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Equilíbrio na bola com contração abdominal', 'Equilíbrio', 'https://drive.google.com/file/d/1H6Rb1Qs0xWU6FW9geLkU3-gzdOv781d0/view?usp=drive_link', 3, '12-15', 'avançado'),
('Equilíbrio Esquerdo unilateral pegando bastão no solo', 'Equilíbrio', 'https://drive.google.com/file/d/1WcgB8RijugSEurMn5zRn_3tXfGcgQBIL/view?usp=drive_link', 3, '8-10', 'intermediário'),
('Equilíbrio Direito unilateral pegando objeto do solo', 'Equilíbrio', 'https://drive.google.com/file/d/1xNPB1ZurriswIzYq8eGnwDAJLu0qDbgk/view?usp=drive_link', 3, '8-10', 'intermediário'),
('Equilíbrio unilateral com elástico', 'Equilíbrio', 'https://drive.google.com/file/d/1pYsZSZH6Cg3ZjCEc5l28dVXJjSFeAsxI/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Flexão com equilíbrio unilateral', 'Equilíbrio', 'https://drive.google.com/file/d/1s-16uPQutZiVvMWiJnW034FAfaNP64TN/view?usp=drive_link', 3, '8-10 cada lado', 'avançado'),
('Flexão de perna com bola', 'Equilíbrio', 'https://drive.google.com/file/d/1_c7EvL7v9iKKqzJkk66Jzn8XlnVPrNsr/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Peso morto sem carga com salto', 'Equilíbrio', 'https://drive.google.com/file/d/1_hOOFIFkKO7ub8naZJIN7TJKRCybLx2n/view?usp=drive_link', 4, '8-10', 'intermediário'),
('Polichinelo com uma perna só', 'Equilíbrio', 'https://drive.google.com/file/d/1NYjuEqVAdXU8JApnuD6FpEMlqgJlg5ZG/view?usp=drive_link', 3, '15-20 cada perna', 'intermediário'),
('Ponte de glúteo sobre superfície instável unilateral', 'Equilíbrio', 'https://drive.google.com/file/d/1t8cHj50B20gv4-rHCifcrA7T-AaLW41I/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Ponte de glúteo unilateral sobre superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/14v7XzaNSRdkt-xkFA5q8ldUZU5YvLtfC/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Prancha com equilíbrio sobre superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1TDRTUEQZo8znxBBXMEmTxJRMwLYNgN_J/view?usp=drive_link', 3, '30-45s', 'intermediário'),
('Prancha com perna elevada em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1uWYG-CigyJ1uj8uW71Ckod2W0HjkLxZZ/view?usp=drive_link', 3, '30-45s cada perna', 'intermediário'),
('Prancha com toque nos cotovelos em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/14lO04O_DMLuGBuYOs-AOlThHHYGf3dF2/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Prancha de joelhos dinâmica', 'Equilíbrio', 'https://drive.google.com/file/d/1SPkqL8Q5KpymtwhTeogE_rAROIGinqea/view?usp=drive_link', 3, '30-45s', 'iniciante'),
('Prancha lateral em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1TH2Og-DGEnUw6Vzr85BX2EYWLAFvjv9C/view?usp=drive_link', 3, '30-45s cada lado', 'intermediário'),
('Rotação de tronco com equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1QXJm2TjZdKqmatPc4dWCd5FBkdD0gtDf/view?usp=drive_link', 3, '10-12 cada lado', 'intermediário'),
('Salto 360 unilateral', 'Equilíbrio', 'https://drive.google.com/file/d/1UhOl6Af2euuGI12cTxhRDgNFo82IHjwu/view?usp=drive_link', 4, '6-8 cada perna', 'avançado'),
('Salto com agachamento em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/16vvvxm0g8yqoZgRHmkSYf5M_9onbH_0j/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Salto com estabilização', 'Equilíbrio', 'https://drive.google.com/file/d/1vgrkmS4rF2ZaW6aytZF7TKduVFYN0x_Y/view?usp=drive_link', 4, '8-10', 'intermediário'),
('Salto com uma perna só em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1GVUwrkl6EwmQLa5AZgg6V2tl206XdRHc/view?usp=drive_link', 4, '8-10 cada perna', 'avançado'),
('Salto dinâmico em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/13RLrpqk5SWIHGN8w8JIhxo6c8s_KoCFf/view?usp=drive_link', 4, '10-12', 'intermediário'),
('Salto em superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1fVmem49hp3ampMyVP8IL0ydnUv6poNrU/view?usp=drive_link', 4, '10-12', 'intermediário'),
('Salto lateral com cone em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/1ckhid2-5rvuYXrWWTWqiLKBOacb9GC38/view?usp=drive_link', 4, '10-12 cada lado', 'intermediário'),
('Salto lateral em equilíbrio', 'Equilíbrio', 'https://drive.google.com/file/d/14sF7M7x37mCF1RjiOVPBwCJlbO8RtlR7/view?usp=drive_link', 4, '10-12 cada lado', 'intermediário'),
('Subida com equilíbrio em superfície instável', 'Equilíbrio', 'https://drive.google.com/file/d/1d075Xd1V-ENn6Vop0UEQ_Q9BgQgG0XMx/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Toque à frente com elástico sobre as pernas', 'Equilíbrio', 'https://drive.google.com/file/d/1fl2LHQswHsV0uhNSrZBQ3QWrNC0WEgVX/view?usp=drive_link', 3, '10-12', 'intermediário'),
('Toque à frente com elevação de perna com carga', 'Equilíbrio', 'https://drive.google.com/file/d/1KGtv-mnBK9_bYZEbByZsPU7b1HAxGl2M/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Toque à frente com elevação de pernas dinâmico', 'Equilíbrio', 'https://drive.google.com/file/d/1mKzn2sDJwcKFzLjrStjQAn9hNH7CwpVb/view?usp=drive_link', 3, '10-12 cada perna', 'intermediário'),
('Toque lateral no cone equilibrando a perna', 'Equilíbrio', 'https://drive.google.com/file/d/18bpfoQcuWqlbbU32mZI0ypgSTOYPWlPA/view?usp=drive_link', 3, '10-12 cada lado', 'iniciante'),
('Toque no cone com elevação de perna', 'Equilíbrio', 'https://drive.google.com/file/d/1iEYtrbnhiUBQGfLMoSoWuv6pEWwVFt5v/view?usp=drive_link', 3, '10-12 cada perna', 'iniciante'),
('Toque no cone equilibrando uma perna', 'Equilíbrio', 'https://drive.google.com/file/d/12QHynz-6aPH63Y8majn7EAd09fG7B0O2/view?usp=drive_link', 3, '10-12 cada perna', 'iniciante')
ON CONFLICT DO NOTHING;
