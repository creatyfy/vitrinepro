/*
  # Create Training Pause Progress System

  1. New Tables
    - `training_pause_progress`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `training_type` (text) - Type of training: 'daily', 'category', 'challenge28', 'exercise'
      - `training_id` (text) - ID of the training being performed
      - `exercise_id` (text) - Current exercise ID
      - `current_exercise_index` (integer) - Index of current exercise
      - `total_exercises` (integer) - Total number of exercises in session
      - `timer_remaining` (integer) - Seconds remaining on timer when paused
      - `is_resting` (boolean) - Whether user was in rest period
      - `rest_timer_remaining` (integer) - Seconds remaining on rest timer
      - `progress_data` (jsonb) - Additional progress data (sets completed, etc.)
      - `paused_at` (timestamptz) - When the training was paused
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `training_pause_progress` table
    - Add policy for authenticated users to read their own pause progress
    - Add policy for authenticated users to insert their own pause progress
    - Add policy for authenticated users to update their own pause progress
    - Add policy for authenticated users to delete their own pause progress

  3. Indexes
    - Add index on user_id for faster lookups
    - Add index on paused_at for cleanup queries
*/

CREATE TABLE IF NOT EXISTS training_pause_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  training_type text NOT NULL,
  training_id text NOT NULL,
  exercise_id text,
  current_exercise_index integer NOT NULL DEFAULT 0,
  total_exercises integer NOT NULL DEFAULT 1,
  timer_remaining integer DEFAULT 0,
  is_resting boolean DEFAULT false,
  rest_timer_remaining integer DEFAULT 0,
  progress_data jsonb DEFAULT '{}'::jsonb,
  paused_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

ALTER TABLE training_pause_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own pause progress"
  ON training_pause_progress
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pause progress"
  ON training_pause_progress
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pause progress"
  ON training_pause_progress
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pause progress"
  ON training_pause_progress
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_training_pause_progress_user_id 
  ON training_pause_progress(user_id);

CREATE INDEX IF NOT EXISTS idx_training_pause_progress_paused_at 
  ON training_pause_progress(paused_at);

CREATE INDEX IF NOT EXISTS idx_training_pause_progress_user_training 
  ON training_pause_progress(user_id, training_type, training_id);
