/*
  # Sistema de Treino do Dia

  1. Novas Tabelas
    - `daily_workout_seeds`
      - `id` (uuid, primary key)
      - `date` (date, unique) - Data do treino
      - `seed` (integer) - Semente para geração aleatória
      - `exercise_ids` (text[]) - IDs dos exercícios selecionados
      - `created_at` (timestamptz)
    
    - `workout_completions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `workout_date` (date) - Data do treino realizado
      - `exercise_ids` (text[]) - IDs dos exercícios concluídos
      - `duration_minutes` (integer)
      - `points_earned` (integer)
      - `proof_photo_url` (text) - URL da foto de comprovação
      - `completed_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Users can read their own completions
    - Anyone can read daily seeds (public data)
    - Only authenticated users can insert completions
*/

-- Daily workout seeds table
CREATE TABLE IF NOT EXISTS daily_workout_seeds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE NOT NULL DEFAULT CURRENT_DATE,
  seed integer NOT NULL,
  exercise_ids text[] NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Workout completions table
CREATE TABLE IF NOT EXISTS workout_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workout_date date NOT NULL,
  exercise_ids text[] NOT NULL,
  duration_minutes integer NOT NULL,
  points_earned integer NOT NULL DEFAULT 0,
  proof_photo_url text,
  completed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE daily_workout_seeds ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_completions ENABLE ROW LEVEL SECURITY;

-- Policies for daily_workout_seeds
CREATE POLICY "Anyone can read daily workout seeds"
  ON daily_workout_seeds
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can insert daily seeds"
  ON daily_workout_seeds
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policies for workout_completions
CREATE POLICY "Users can read own workout completions"
  ON workout_completions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own workout completions"
  ON workout_completions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_daily_workout_seeds_date 
  ON daily_workout_seeds(date DESC);

CREATE INDEX IF NOT EXISTS idx_workout_completions_user_date 
  ON workout_completions(user_id, workout_date DESC);

-- Function to get or create today's workout
CREATE OR REPLACE FUNCTION get_or_create_daily_workout()
RETURNS TABLE (
  date date,
  seed integer,
  exercise_ids text[]
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  today_date date := CURRENT_DATE;
  workout_record RECORD;
BEGIN
  SELECT * INTO workout_record
  FROM daily_workout_seeds
  WHERE daily_workout_seeds.date = today_date;
  
  IF NOT FOUND THEN
    INSERT INTO daily_workout_seeds (date, seed, exercise_ids)
    VALUES (
      today_date,
      EXTRACT(EPOCH FROM NOW())::integer,
      ARRAY[]::text[]
    )
    RETURNING * INTO workout_record;
  END IF;
  
  RETURN QUERY
  SELECT workout_record.date, workout_record.seed, workout_record.exercise_ids;
END;
$$;