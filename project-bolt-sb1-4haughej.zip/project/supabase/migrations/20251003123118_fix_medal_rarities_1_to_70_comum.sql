/*
  # Corrigir raridade das medalhas 1-70 para 'comum'

  1. Correção de Raridade
    - Medalhas 1-70: todas devem ser 'comum' (progressão natural)
    - Medalhas 71-80: mantêm 'lendario' (conquistas raras)
    
  2. Justificativa
    - Apenas as últimas 10 medalhas são verdadeiramente raras/lendárias
    - Medalhas de 1-70 são conquistas de progressão natural do atleta
    - Isso motiva o atleta a perseguir as últimas 10 como objetivo final
*/

-- Atualizar medalhas 1-70 para raridade 'comum'
UPDATE medals 
SET rarity = 'comum'
WHERE medal_order >= 1 AND medal_order <= 70;

-- Garantir que medalhas 71-80 são 'lendario'
UPDATE medals 
SET rarity = 'lendario'
WHERE medal_order >= 71 AND medal_order <= 80;
