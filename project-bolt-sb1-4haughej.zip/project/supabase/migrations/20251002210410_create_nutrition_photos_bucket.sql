/*
  # Create Storage Bucket for Nutrition Photos

  1. Storage
    - Create `nutrition-photos` bucket for nutrition challenge submissions
    - Set public access for viewing photos

  2. Security
    - Users can upload photos to their own folders
    - Users can view all nutrition photos
    - Only photo owner can delete their photos
*/

-- Create nutrition-photos bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('nutrition-photos', 'nutrition-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can upload nutrition photos" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can view nutrition photos" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete own nutrition photos" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Policy: Allow authenticated users to upload nutrition photos
CREATE POLICY "Users can upload nutrition photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'nutrition-photos');

-- Policy: Allow public read access to all nutrition photos
CREATE POLICY "Anyone can view nutrition photos"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'nutrition-photos');

-- Policy: Allow users to delete their own nutrition photos
CREATE POLICY "Users can delete own nutrition photos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'nutrition-photos');
