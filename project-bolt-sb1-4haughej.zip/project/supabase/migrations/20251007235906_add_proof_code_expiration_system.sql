/*
  # Add Proof Code Expiration System

  1. Changes to existing tables
    - Add `code_generated_at` column to training_proofs table
    - Add `code_expires_at` column to training_proofs table
    - Add `code_used` boolean column to training_proofs table
    - Add `code_value` text column to store the generated code

  2. Purpose
    - Enable time-based expiration for proof codes (default 5 minutes)
    - Track when codes are generated and used
    - Prevent reuse of old codes
    - Provide better security for training proof validation

  3. Notes
    - Codes expire 5 minutes after generation
    - Only one active code per training session
    - Codes are 4-character alphanumeric strings
*/

-- Add expiration columns to training_proofs table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'code_generated_at'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN code_generated_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'code_expires_at'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN code_expires_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'code_used'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN code_used boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'code_value'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN code_value text;
  END IF;
END $$;

-- Create index for faster queries on active codes
CREATE INDEX IF NOT EXISTS idx_training_proofs_code_expires ON training_proofs(code_expires_at) WHERE code_used = false;

-- Create a function to generate a random 4-character code
CREATE OR REPLACE FUNCTION generate_proof_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- Excluded similar-looking chars
  result text := '';
  i integer;
BEGIN
  FOR i IN 1..4 LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
  END LOOP;
  RETURN result;
END;
$$;

-- Create a table to store active proof codes
CREATE TABLE IF NOT EXISTS active_proof_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  training_session_id uuid NOT NULL,
  code_value text NOT NULL,
  generated_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE active_proof_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own active codes"
  ON active_proof_codes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own active codes"
  ON active_proof_codes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own active codes"
  ON active_proof_codes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_active_proof_codes_user_id ON active_proof_codes(user_id);
CREATE INDEX IF NOT EXISTS idx_active_proof_codes_session ON active_proof_codes(training_session_id);
CREATE INDEX IF NOT EXISTS idx_active_proof_codes_expires ON active_proof_codes(expires_at) WHERE used = false;
