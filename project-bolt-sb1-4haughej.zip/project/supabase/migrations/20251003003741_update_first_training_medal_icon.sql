/*
  # Atualizar Ícone da Medalha "Primeiro Treino"

  1. Alterações
    - Atualiza o ícone da medalha "Primeiro Treino" para usar a imagem individual
    - Remove emojis e usa a medalha dourada com estrela
    
  2. Medalhas Atualizadas
    - Primeiro Treino → Medalha Dourada com Estrela
*/

-- Atualizar ícone da medalha "Primeiro Treino"
UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_36_03.png'
WHERE medal_type = 'first_training';
