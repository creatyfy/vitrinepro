/*
  # Fix Profile for Mock Users

  1. Changes
    - Grant execute permission to anon users for profile functions
    - Allow anon users to insert/update their own profiles
    - Fix RLS policies to work with mock users

  2. Security
    - Still maintain user isolation
    - Users can only access their own data
*/

-- Grant execute permission to anon users (for mock users)
GRANT EXECUTE ON FUNCTION upsert_profile_from_quiz TO anon;
GRANT EXECUTE ON FUNCTION check_upload_limit TO anon;
GRANT EXECUTE ON FUNCTION increment_upload_count TO anon;
GRANT EXECUTE ON FUNCTION check_duplicate_video TO anon;
GRANT EXECUTE ON FUNCTION award_video_points TO anon;
GRANT EXECUTE ON FUNCTION reverse_video_points TO anon;

-- Update RLS policies to allow anon access for mock users
DROP POLICY IF EXISTS "Anyone can view player profiles" ON player_profiles;
CREATE POLICY "Anyone can view player profiles"
  ON player_profiles FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Users can create their own profile" ON player_profiles;
CREATE POLICY "Users can create their own profile"
  ON player_profiles FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Users can update their own profile" ON player_profiles;
CREATE POLICY "Users can update their own profile"
  ON player_profiles FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Update video policies for anon users
DROP POLICY IF EXISTS "Anyone can view non-deleted videos" ON player_videos;
CREATE POLICY "Anyone can view non-deleted videos"
  ON player_videos FOR SELECT
  USING (deleted_at IS NULL);

DROP POLICY IF EXISTS "Users can create their own videos" ON player_videos;
CREATE POLICY "Users can create their own videos"
  ON player_videos FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Users can update their own videos" ON player_videos;
CREATE POLICY "Users can update their own videos"
  ON player_videos FOR UPDATE
  USING (true)
  WITH CHECK (true);

DROP POLICY IF EXISTS "Users can delete their own videos" ON player_videos;
CREATE POLICY "Users can delete their own videos"
  ON player_videos FOR DELETE
  USING (true);

-- Update telemetry policies
DROP POLICY IF EXISTS "Users can view their own telemetry" ON video_telemetry;
CREATE POLICY "Users can view their own telemetry"
  ON video_telemetry FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Users can create their own telemetry" ON video_telemetry;
CREATE POLICY "Users can create their own telemetry"
  ON video_telemetry FOR INSERT
  WITH CHECK (true);

-- Update upload limits policies
DROP POLICY IF EXISTS "Users can view their own upload limits" ON video_upload_limits;
CREATE POLICY "Users can view their own upload limits"
  ON video_upload_limits FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Users can create their own upload limits" ON video_upload_limits;
CREATE POLICY "Users can create their own upload limits"
  ON video_upload_limits FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Users can update their own upload limits" ON video_upload_limits;
CREATE POLICY "Users can update their own upload limits"
  ON video_upload_limits FOR UPDATE
  USING (true)
  WITH CHECK (true);
