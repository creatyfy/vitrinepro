/*
  # Create Daily Training System

  ## Summary
  This migration creates the database structure for the "Treino do Dia" (Daily Training) feature.
  Athletes receive one unique personalized training per day, automatically generated from existing exercises.

  1. New Tables
    - `daily_trainings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `training_date` (date) - The date this training was generated for
      - `exercises` (jsonb) - Array of exercise IDs and metadata for the daily workout
      - `total_exercises` (integer) - Total number of exercises (10-20)
      - `intensity_level` (text) - 'low', 'medium', 'high'
      - `prep_time` (integer) - Seconds of preparation time per exercise
      - `rest_time` (integer) - Seconds of rest time between exercises
      - `status` (text) - 'generated', 'completed', 'expired'
      - `completed_at` (timestamptz) - When the training was completed
      - `proof_submitted` (boolean) - Whether proof photo was submitted
      - `proof_gesture` (text) - The random gesture required for proof
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `daily_trainings` table
    - Add policy for users to read their own daily trainings
    - Add policy for users to update their own daily trainings

  3. Indexes
    - Index on (user_id, training_date) for fast lookups

  4. Important Notes
    - One training per user per day (enforced by unique constraint)
    - Trainings expire at end of day (midnight)
    - Random gesture for anti-cheat verification
    - Intensity affects prep_time and rest_time
*/

-- Create daily_trainings table
CREATE TABLE IF NOT EXISTS daily_trainings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  training_date date NOT NULL DEFAULT CURRENT_DATE,
  exercises jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_exercises integer NOT NULL DEFAULT 15,
  intensity_level text NOT NULL DEFAULT 'medium' CHECK (intensity_level IN ('low', 'medium', 'high')),
  prep_time integer NOT NULL DEFAULT 10,
  rest_time integer NOT NULL DEFAULT 15,
  status text NOT NULL DEFAULT 'generated' CHECK (status IN ('generated', 'in_progress', 'completed', 'expired')),
  completed_at timestamptz,
  proof_submitted boolean DEFAULT false,
  proof_gesture text,
  created_at timestamptz DEFAULT now(),
  
  UNIQUE(user_id, training_date)
);

-- Create index for fast lookups
CREATE INDEX IF NOT EXISTS idx_daily_trainings_user_date 
  ON daily_trainings(user_id, training_date DESC);

-- Enable RLS
ALTER TABLE daily_trainings ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own daily trainings
CREATE POLICY "Users can view own daily trainings"
  ON daily_trainings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy: Users can insert their own daily trainings
CREATE POLICY "Users can create own daily trainings"
  ON daily_trainings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own daily trainings
CREATE POLICY "Users can update own daily trainings"
  ON daily_trainings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Function to generate random gesture for proof
CREATE OR REPLACE FUNCTION generate_proof_gesture()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  gestures text[] := ARRAY[
    'Mão no queixo',
    'Braço cruzado',
    'Polegar para cima',
    'Sinal de joia (👌)',
    'Mão na testa',
    'Punho fechado ao lado da cabeça',
    'Dois dedos em V',
    'Mão espalmada na câmera',
    'Apontando para cima',
    'Mão na cintura'
  ];
BEGIN
  RETURN gestures[floor(random() * array_length(gestures, 1) + 1)];
END;
$$;

-- Function to check if user has completed daily training
CREATE OR REPLACE FUNCTION has_completed_daily_training(p_user_id uuid, p_date date DEFAULT CURRENT_DATE)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM daily_trainings 
    WHERE user_id = p_user_id 
      AND training_date = p_date 
      AND status = 'completed'
  );
END;
$$;

-- Function to get or create today's daily training
CREATE OR REPLACE FUNCTION get_or_create_daily_training(p_user_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_training_id uuid;
  v_today date := CURRENT_DATE;
BEGIN
  -- Try to find existing training for today
  SELECT id INTO v_training_id
  FROM daily_trainings
  WHERE user_id = p_user_id
    AND training_date = v_today
    AND status != 'expired';

  -- If not found, create new training
  IF v_training_id IS NULL THEN
    INSERT INTO daily_trainings (
      user_id,
      training_date,
      proof_gesture
    ) VALUES (
      p_user_id,
      v_today,
      generate_proof_gesture()
    )
    RETURNING id INTO v_training_id;
  END IF;

  RETURN v_training_id;
END;
$$;