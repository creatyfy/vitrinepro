/*
  # Sistema de Medalhas VitrinePro - 80 Medalhas Oficiais

  1. Nova Tabela
    - `medals` - Armazena as 80 medalhas oficiais do app
      - `id` (bigint, primary key)
      - `name` (text) - Nome da medalha
      - `description` (text) - Descrição/conquista
      - `category` (text) - Categoria da medalha
      - `rarity` (text) - Raridade (comum, raro, épico, lendário)
      - `icon_url` (text) - URL da imagem da medalha
      - `requirement_type` (text) - Tipo de requisito
      - `requirement_target` (integer) - Meta do requisito
      - `requirement_condition` (text, nullable) - Condição especial
      - `points` (integer) - Pontos concedidos
      - `display_order` (integer) - Ordem de exibição (1-80)
      - `created_at` (timestamptz)

    - `player_medals` - Relaciona jogadores com medalhas conquistadas
      - `id` (bigint, primary key)
      - `user_id` (uuid, foreign key)
      - `medal_id` (bigint, foreign key)
      - `earned_at` (timestamptz)
      - `progress` (integer) - Progresso atual para medalhas não conquistadas

  2. Segurança
    - RLS habilitado em ambas as tabelas
    - Jogadores podem visualizar todas as medalhas
    - Jogadores podem visualizar apenas suas próprias conquistas
    - Sistema gerencia a concessão de medalhas

  3. Observações
    - As 80 medalhas são inseridas na ordem oficial (1-80)
    - Imagens usam placeholder temporário
    - Imagens reais serão atualizadas posteriormente
*/

-- Cria tabela de medalhas
CREATE TABLE IF NOT EXISTS medals (
  id bigserial PRIMARY KEY,
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  rarity text NOT NULL,
  icon_url text NOT NULL,
  requirement_type text NOT NULL,
  requirement_target integer NOT NULL,
  requirement_condition text,
  points integer NOT NULL DEFAULT 0,
  display_order integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Cria tabela de medalhas dos jogadores
CREATE TABLE IF NOT EXISTS player_medals (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  medal_id bigint NOT NULL REFERENCES medals(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  progress integer DEFAULT 0,
  UNIQUE(user_id, medal_id)
);

-- Habilita RLS
ALTER TABLE medals ENABLE ROW LEVEL SECURITY;
ALTER TABLE player_medals ENABLE ROW LEVEL SECURITY;

-- Políticas para medals (todos podem ver)
CREATE POLICY "Qualquer um pode ver medalhas"
  ON medals FOR SELECT
  TO authenticated
  USING (true);

-- Políticas para player_medals
CREATE POLICY "Jogadores veem suas medalhas"
  ON player_medals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Sistema pode inserir medalhas"
  ON player_medals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Sistema pode atualizar progresso"
  ON player_medals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Cria índices
CREATE INDEX IF NOT EXISTS idx_player_medals_user ON player_medals(user_id);
CREATE INDEX IF NOT EXISTS idx_player_medals_medal ON player_medals(medal_id);
CREATE INDEX IF NOT EXISTS idx_medals_display_order ON medals(display_order);

-- Insere as 80 medalhas oficiais do VitrinePro
INSERT INTO medals (name, description, category, rarity, icon_url, requirement_type, requirement_target, requirement_condition, points, display_order) VALUES
  ('Chute Inicial', 'Primeiro treino concluído', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 1, NULL, 10, 1),
  ('Primeira Estrela', 'Primeiro vídeo enviado', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'video_count', 1, NULL, 15, 2),
  ('Foco Total', 'Primeiro treino em vídeo concluído', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'first_video_training', 20, 3),
  ('Em Campo', '3 dias de treino seguidos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 3, NULL, 25, 4),
  ('Pegando Ritmo', '5 treinos concluídos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 5, NULL, 30, 5),
  ('Constância é Rei', '7 dias de treinos seguidos', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 7, NULL, 40, 6),
  ('Sem Migué', '14 dias seguidos de treino', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 14, NULL, 80, 7),
  ('Primeira Vitória', 'Primeiro treino completo com nota máxima', 'iniciante', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'first_perfect_training', 50, 8),
  ('Motozinho', '30 treinos concluídos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 30, NULL, 100, 9),
  ('Faro de Gol', '50 treinos concluídos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 50, NULL, 150, 10),
  ('Raça e Coração', '20 dias de treinos seguidos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 20, NULL, 120, 11),
  ('Treino é Jogo', '25 vídeos publicados na plataforma', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'video_count', 25, NULL, 130, 12),
  ('Orgulho da Quebrada', '30 dias seguidos de treino', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 30, NULL, 200, 13),
  ('Tá Voando', '75 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 75, NULL, 220, 14),
  ('Artilheiro de Treino', '100 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 100, NULL, 300, 15),
  ('Nunca Desista', '30 dias parado, mas voltou a treinar', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'comeback_30days', 100, 16),
  ('Disciplina é Tudo', '60 dias seguidos de treino', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 60, NULL, 400, 17),
  ('Tanque Cheio', '150 treinos concluídos', 'consistencia', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 150, NULL, 450, 18),
  ('Top da Semana', 'Apareceu no ranking semanal', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 10, 'weekly', 120, 19),
  ('Craque do Bairro', 'Destaque no ranking regional', 'visibilidade', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 5, 'regional', 150, 20),
  ('Ídolo Local', '50 curtidas nos treinos', 'social', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'likes', 50, NULL, 100, 21),
  ('Camisa 10', 'Avaliação positiva de empresário', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'agent_review', 250, 22),
  ('Olho do Olheiro', 'Vídeo avaliado por olheiro', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'scout_review', 280, 23),
  ('Inspirando a Base', '100 curtidas nos treinos', 'social', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'likes', 100, NULL, 200, 24),
  ('Fazendo História', 'Vídeo com 500 visualizações', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 500, NULL, 300, 25),
  ('Fenômeno da Internet', 'Vídeo com 1.000 visualizações', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 1000, NULL, 400, 26),
  ('Tá Estourado', 'Vídeo com 5.000 visualizações', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 5000, NULL, 800, 27),
  ('Vitrine Nacional', 'Vídeo compartilhado por clube', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'club_share', 700, 28),
  ('Desafio Semanal Cumprido', 'Cumpriu todos os treinos de uma semana', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'weekly_challenge_complete', 150, 29),
  ('Showman', 'Vídeo em destaque na aba Top da Semana', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'top_weekly_video', 250, 30),
  ('Desafio de Ferro', 'Concluiu 10 desafios oficiais seguidos', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'consecutive_challenges', 300, 31),
  ('Craque Mundial', 'Vídeo atingiu 10.000 visualizações', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 10000, NULL, 1200, 32),
  ('Lenda Viva', 'Concluiu 365 treinos no total', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 365, NULL, 2000, 33),
  ('Hall da Fama', 'Atingiu 100% das medalhas até Ouro', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'all_gold_medals', 3000, 34),
  ('Elite Vitrine', 'Entrou no Top 10 geral do app', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 10, 'global', 1500, 35),
  ('Mentor Pro', 'Avaliou positivamente 10 atletas diferentes', 'social', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'athlete_evaluations', 400, 36),
  ('Treino Supremo', '500 treinos completos com vídeo publicado', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 500, 'video_trainings', 5000, 37),
  ('Relâmpago Humano', 'Média de velocidade acima de 30 km/h registrada', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'speed_30kmh', 350, 38),
  ('Maestro da Bola', 'Fez 20 vídeos técnicos com nota máxima', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 20, 'perfect_technical_videos', 400, 39),
  ('Retorno Triunfal', 'Voltou de lesão e completou 7 treinos seguidos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'injury_comeback', 180, 40),
  ('Tanque de Guerra', 'Treinou 200 dias consecutivos', 'consistencia', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 200, NULL, 2500, 41),
  ('Frieza de Artilheiro', 'Marcou 10 gols em vídeos de treino', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'training_goals', 200, 42),
  ('Destaque Oficial Vitrine', 'Vídeo repostado pela página oficial', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'official_repost', 1000, 43),
  ('Fenômeno Local', 'Entrou no Top 3 da região', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 3, 'regional', 500, 44),
  ('Desafio Semanal Cumprido', 'Cumpriu todos os treinos da semana com nota máxima', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'weekly_perfect', 350, 45),
  ('Showman', 'Vídeo em destaque na aba Top da Semana', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'featured_weekly', 300, 46),
  ('Desafio de Ferro', 'Concluiu 10 desafios oficiais seguidos', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'iron_challenges', 400, 47),
  ('Craque Mundial', 'Vídeo atingiu 10.000 visualizações', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'views', 10000, NULL, 1300, 48),
  ('Lenda Viva', 'Concluiu 365 treinos no total', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'training_count', 365, NULL, 2200, 49),
  ('Hall da Fama', 'Atingiu 100% das medalhas até Ouro', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'gold_complete', 3500, 50),
  ('Elite Vitrine', 'Entrou no Top 10 geral do app', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 10, 'app_global', 1800, 51),
  ('Mentor Pro', 'Avaliou positivamente 10 atletas diferentes', 'social', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'positive_reviews', 450, 52),
  ('Treino Supremo', '500 treinos completos com vídeo publicado', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 500, 'supreme_videos', 5500, 53),
  ('Relâmpago Humano', 'Média de velocidade acima de 30 km/h registrada', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'lightning_speed', 380, 54),
  ('Maestro da Bola', 'Fez 20 vídeos técnicos com nota máxima', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 20, 'maestro_tech', 420, 55),
  ('Retorno Triunfal', 'Voltou de lesão e completou 7 treinos seguidos', 'consistencia', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'comeback_injury', 200, 56),
  ('Tanque de Guerra', 'Treinou 200 dias consecutivos', 'consistencia', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'streak', 200, NULL, 2800, 57),
  ('Frieza de Artilheiro', 'Marcou 10 gols em vídeos de treino', 'performance', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'goal_scorer', 220, 58),
  ('Destaque Oficial Vitrine', 'Vídeo repostado pela página oficial', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'vitrine_repost', 1100, 59),
  ('Top 1 da Semana', 'Líder absoluto do ranking semanal', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 1, 'weekly_leader', 1000, 60),
  ('Top 1 da Região', 'Líder do ranking regional', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 1, 'regional_leader', 1500, 61),
  ('Top 10 Nacional', 'Entrou entre os 10 melhores do país', 'progressao', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'ranking', 10, 'national', 2000, 62),
  ('Top 1 da Posição', 'Melhor atleta da sua posição', 'progressao', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'position_leader', 800, 63),
  ('Subiu de Divisão', 'Passou de categoria (Bronze → Prata, etc.)', 'progressao', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'division_promotion', 300, 64),
  ('Desafio dos 1000', 'Realizou 1.000 repetições em treino', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1000, 'repetitions', 600, 65),
  ('Desafio do Vitrine', 'Cumpriu desafio oficial mensal', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'monthly_challenge', 500, 66),
  ('Evolução Confirmada', 'IA detectou melhora física/estatística', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'ai_improvement', 400, 67),
  ('Feedback Profissional', 'Recebeu avaliação positiva de olheiro', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'scout_feedback', 350, 68),
  ('Olheiro Confirmado', 'Adicionado à lista de observação de um empresário', 'carreira', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'scout_watchlist', 450, 69),
  ('Contrato Assinado', 'Firmou contrato com clube ou empresa pelo app', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'contract_signed', 3000, 70),
  ('Primeiro Patrocínio', 'Recebeu patrocínio validado', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'sponsorship', 2500, 71),
  ('Treino Verificado', 'Treino autenticado por IA com vídeo legítimo', 'performance', 'comum', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'ai_verified', 50, 72),
  ('Perfil Oficial', 'Conta verificada com documento e vídeo facial', 'social', 'raro', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'verified_profile', 200, 73),
  ('Desafio Relâmpago', 'Venceu desafio de 24 horas', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'flash_challenge', 400, 74),
  ('Top Vídeo da Semana', 'Vídeo mais curtido da semana', 'visibilidade', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'top_video_week', 500, 75),
  ('Top Vídeo do Mês', 'Vídeo mais visualizado do mês', 'visibilidade', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'top_video_month', 1000, 76),
  ('Treino Nota 10', '10 treinos consecutivos com nota máxima', 'performance', 'epico', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 10, 'perfect_streak', 600, 77),
  ('Atleta 5 Estrelas', '5 avaliações máximas de empresários', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 5, 'max_evaluations', 2000, 78),
  ('Camisa Assinada', 'Reconhecimento oficial de um clube profissional', 'carreira', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'club_recognition', 5000, 79),
  ('Imortal do Vitrine', 'Conquistou todas as medalhas e reconhecimento global', 'lendaria', 'lendario', '/ChatGPT Image 3 de out. de 2025, 01_36_03.png', 'special', 1, 'all_medals', 25000, 80);
