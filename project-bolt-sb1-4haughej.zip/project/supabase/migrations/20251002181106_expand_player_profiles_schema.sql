/*
  # Expand Player Profiles Schema

  1. Purpose
    - Add all fields needed for complete profile editing
    - Support 4 tabs: Básico, Físico, Jogo, Sobre
    - Enable privacy controls and social links

  2. Changes to player_profiles
    - Add wingspan_cm (envergadura)
    - Add speed_30m (velocidade 30m)
    - Add vertical_jump_cm (salto vertical)
    - Add endurance_level (resistência)
    - Add injury_history (histórico de lesões)
    - Add dominant_foot (pé dominante)
    - Add current_club (clube atual)
    - Add shirt_number (número da camisa)
    - Add play_style_tags (estilo de jogo - array)
    - Add featured_video_id (vídeo destaque)
    - Add instagram_url, youtube_url, tiktok_url
    - Add commercial_email, commercial_phone
    - Add agent_name, agent_contact
    - Add privacy settings (show_age, show_city, allow_club_messages)
    - Add contact_visibility flags

  3. Security
    - Maintain existing RLS policies
    - All fields optional for gradual migration
*/

-- Add new physical fields
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'wingspan_cm'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN wingspan_cm integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'speed_30m'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN speed_30m numeric(3,2);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'vertical_jump_cm'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN vertical_jump_cm integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'endurance_level'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN endurance_level text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'injury_history'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN injury_history text;
  END IF;
END $$;

-- Add game/playing fields
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'dominant_foot'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN dominant_foot text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'current_club'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN current_club text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'shirt_number'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN shirt_number integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'play_style_tags'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN play_style_tags text[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'featured_video_id'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN featured_video_id text;
  END IF;
END $$;

-- Add social media and contact fields
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'instagram_url'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN instagram_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'youtube_url'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN youtube_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'tiktok_url'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN tiktok_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'commercial_email'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN commercial_email text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'commercial_phone'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN commercial_phone text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'agent_name'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN agent_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'agent_contact'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN agent_contact text;
  END IF;
END $$;

-- Add privacy settings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'show_age_public'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN show_age_public boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'show_city_public'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN show_city_public boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'allow_club_messages'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN allow_club_messages boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'hide_contact_public'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN hide_contact_public boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'hide_agent_public'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN hide_agent_public boolean DEFAULT false;
  END IF;
END $$;

-- Add constraints
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'player_profiles_wingspan_check'
  ) THEN
    ALTER TABLE player_profiles ADD CONSTRAINT player_profiles_wingspan_check 
      CHECK (wingspan_cm IS NULL OR (wingspan_cm >= 120 AND wingspan_cm <= 240));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'player_profiles_speed_check'
  ) THEN
    ALTER TABLE player_profiles ADD CONSTRAINT player_profiles_speed_check 
      CHECK (speed_30m IS NULL OR (speed_30m >= 3.5 AND speed_30m <= 7.0));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'player_profiles_vertical_jump_check'
  ) THEN
    ALTER TABLE player_profiles ADD CONSTRAINT player_profiles_vertical_jump_check 
      CHECK (vertical_jump_cm IS NULL OR (vertical_jump_cm >= 20 AND vertical_jump_cm <= 90));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'player_profiles_shirt_number_check'
  ) THEN
    ALTER TABLE player_profiles ADD CONSTRAINT player_profiles_shirt_number_check 
      CHECK (shirt_number IS NULL OR (shirt_number >= 1 AND shirt_number <= 99));
  END IF;
END $$;

-- Create index for featured videos
CREATE INDEX IF NOT EXISTS idx_player_profiles_featured_video 
  ON player_profiles(featured_video_id) 
  WHERE featured_video_id IS NOT NULL;
