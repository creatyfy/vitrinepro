/*
  # Atualizar função de inicialização de medalhas para 80 medalhas

  1. Alterações
    - Remove função antiga que inseria apenas 7 medalhas
    - Cria nova função que inicializa todas as 80 medalhas da tabela medals
    - Cria registros em user_medals para cada medalha existente
    
  2. Funcionamento
    - Ao chamar a função, ela verifica todas as medalhas cadastradas
    - Para cada medalha, cria um registro em user_medals se não existir
    - Permite que o jogador veja todas as 80 medalhas (bloqueadas ou não)
*/

-- Drop função antiga
DROP FUNCTION IF EXISTS initialize_player_medals(uuid);

-- Criar nova função que inicializa todas as medalhas do sistema
CREATE OR REPLACE FUNCTION initialize_player_medals(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  -- Inserir todas as medalhas do sistema na tabela user_medals do usuário
  INSERT INTO user_medals (user_id, medal_id, progress, is_unlocked)
  SELECT 
    p_user_id,
    m.id,
    0,
    false
  FROM medals m
  WHERE NOT EXISTS (
    SELECT 1 
    FROM user_medals um 
    WHERE um.user_id = p_user_id 
    AND um.medal_id = m.id
  );
END;
$$;
