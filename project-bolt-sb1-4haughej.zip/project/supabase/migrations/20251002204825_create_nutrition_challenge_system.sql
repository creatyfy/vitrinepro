/*
  # Nutrition Challenge System (Prato do Dia)

  1. Purpose
    - Enable daily nutrition challenges for athletes
    - Track photo submissions with anti-fraud measures
    - Award points and medals for participation
    - Create weekly rankings

  2. New Tables
    - `nutrition_dishes` - Pre-defined list of daily dishes
    - `daily_nutrition_challenges` - Daily challenge assignments
    - `nutrition_submissions` - Photo submissions from athletes
    - `nutrition_weekly_rankings` - Weekly leaderboard
    - `nutrition_medals` - Medals earned for streaks

  3. Security
    - Enable RLS on all tables
    - Athletes can only view their own submissions
    - Public can view rankings (anonymized)
*/

-- Nutrition Dishes (pre-defined options)
CREATE TABLE IF NOT EXISTS nutrition_dishes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  image_url text,
  points_full integer DEFAULT 200,
  points_partial integer DEFAULT 50,
  difficulty text DEFAULT 'easy',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_dishes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view dishes"
  ON nutrition_dishes FOR SELECT
  TO authenticated
  USING (true);

-- Daily Nutrition Challenges (one per day, global)
CREATE TABLE IF NOT EXISTS daily_nutrition_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_date date NOT NULL UNIQUE,
  dish_id uuid NOT NULL REFERENCES nutrition_dishes(id),
  gesture_code text NOT NULL,
  deadline timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_nutrition_challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view daily challenges"
  ON daily_nutrition_challenges FOR SELECT
  TO authenticated
  USING (true);

-- Nutrition Submissions (athlete photos)
CREATE TABLE IF NOT EXISTS nutrition_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  challenge_id uuid NOT NULL REFERENCES daily_nutrition_challenges(id),
  photo_url text NOT NULL,
  photo_hash text NOT NULL,
  gesture_code_provided text,
  gesture_correct boolean DEFAULT false,
  points_awarded integer DEFAULT 0,
  verification_status text DEFAULT 'pending',
  submitted_at timestamptz DEFAULT now(),
  verified_at timestamptz,
  metadata jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE nutrition_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own submissions"
  ON nutrition_submissions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own submissions"
  ON nutrition_submissions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Nutrition Weekly Rankings
CREATE TABLE IF NOT EXISTS nutrition_weekly_rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  week_start date NOT NULL,
  week_end date NOT NULL,
  challenges_completed integer DEFAULT 0,
  total_points integer DEFAULT 0,
  rank integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, week_start)
);

ALTER TABLE nutrition_weekly_rankings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own ranking"
  ON nutrition_weekly_rankings FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Public can view all rankings"
  ON nutrition_weekly_rankings FOR SELECT
  TO authenticated
  USING (true);

-- Nutrition Medals
CREATE TABLE IF NOT EXISTS nutrition_medals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  medal_type text NOT NULL,
  streak_days integer NOT NULL,
  earned_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE nutrition_medals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own medals"
  ON nutrition_medals FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_daily_challenges_date 
  ON daily_nutrition_challenges(challenge_date DESC);

CREATE INDEX IF NOT EXISTS idx_submissions_user_challenge 
  ON nutrition_submissions(user_id, challenge_id);

CREATE INDEX IF NOT EXISTS idx_submissions_hash 
  ON nutrition_submissions(photo_hash);

CREATE INDEX IF NOT EXISTS idx_weekly_rankings_week 
  ON nutrition_weekly_rankings(week_start DESC, rank ASC);

CREATE INDEX IF NOT EXISTS idx_medals_user 
  ON nutrition_medals(user_id, earned_at DESC);

-- Insert initial dishes
INSERT INTO nutrition_dishes (name, description, points_full, points_partial, difficulty) VALUES
  ('Banana com Aveia', 'Banana fatiada com aveia em flocos', 200, 50, 'easy'),
  ('Salada de Tomate com Alface', 'Salada simples de tomate e alface fresca', 200, 50, 'easy'),
  ('Iogurte Natural com Frutas', 'Iogurte natural com frutas picadas', 200, 50, 'easy'),
  ('Maçã com Granola', 'Maçã fatiada com granola por cima', 200, 50, 'easy'),
  ('Sanduíche Integral com Frango', 'Sanduíche de pão integral com peito de frango', 200, 50, 'medium'),
  ('Ovo Mexido com Espinafre', 'Ovos mexidos com espinafre refogado', 200, 50, 'medium'),
  ('Batata Doce com Frango Grelhado', 'Batata doce cozida com peito de frango grelhado', 200, 50, 'medium'),
  ('Vitamina de Frutas', 'Vitamina com banana, morango e leite', 200, 50, 'easy'),
  ('Wrap de Atum', 'Wrap integral com atum e salada', 200, 50, 'medium'),
  ('Panqueca de Aveia', 'Panqueca feita com aveia e banana', 200, 50, 'medium')
ON CONFLICT (name) DO NOTHING;

-- Function to check for duplicate photo hashes
CREATE OR REPLACE FUNCTION check_duplicate_photo_hash(
  p_user_id uuid,
  p_photo_hash text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM nutrition_submissions 
    WHERE user_id = p_user_id 
      AND photo_hash = p_photo_hash
      AND verification_status != 'rejected'
  );
END;
$$;

-- Function to get current streak
CREATE OR REPLACE FUNCTION get_nutrition_streak(p_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_streak integer := 0;
  v_current_date date := CURRENT_DATE;
  v_has_submission boolean;
BEGIN
  LOOP
    SELECT EXISTS(
      SELECT 1
      FROM nutrition_submissions ns
      JOIN daily_nutrition_challenges dnc ON ns.challenge_id = dnc.id
      WHERE ns.user_id = p_user_id
        AND dnc.challenge_date = v_current_date
        AND ns.verification_status = 'approved'
    ) INTO v_has_submission;
    
    IF NOT v_has_submission THEN
      EXIT;
    END IF;
    
    v_streak := v_streak + 1;
    v_current_date := v_current_date - INTERVAL '1 day';
  END LOOP;
  
  RETURN v_streak;
END;
$$;

COMMENT ON TABLE nutrition_dishes IS 'Pre-defined list of healthy dishes for daily challenges';
COMMENT ON TABLE daily_nutrition_challenges IS 'One challenge per day, randomized from dishes list';
COMMENT ON TABLE nutrition_submissions IS 'Photo submissions from athletes with anti-fraud validation';
COMMENT ON TABLE nutrition_weekly_rankings IS 'Weekly leaderboard based on completed challenges';
COMMENT ON TABLE nutrition_medals IS 'Medals earned for consecutive day streaks';
