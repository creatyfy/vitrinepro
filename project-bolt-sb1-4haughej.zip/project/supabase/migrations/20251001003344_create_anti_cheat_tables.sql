/*
  # Anti-Cheat System Tables

  1. New Tables
    - `training_proofs`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users if auth enabled)
      - `training_session_id` (uuid)
      - `photo_hash` (text) - perceptual hash of the photo
      - `challenge_code` (text) - random 4-char code
      - `challenge_gesture` (text) - gesture type
      - `movement_score` (integer) - 0-100 based on accelerometer
      - `risk_score` (integer) - 0-100 overall risk score
      - `points_awarded` (integer)
      - `timestamp` (timestamptz)
      - `location_lat` (real, nullable)
      - `location_lng` (real, nullable)
      - `metadata` (jsonb) - additional data
      - `created_at` (timestamptz)
    
    - `user_photo_history`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users if auth enabled)
      - `photo_hash` (text) - for duplicate detection
      - `created_at` (timestamptz)
    
    - `risk_flags`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users if auth enabled)
      - `proof_id` (uuid, references training_proofs)
      - `flag_type` (text) - duplicate_photo, no_movement, expired_challenge, etc.
      - `severity` (text) - low, medium, high
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Training Proofs Table
CREATE TABLE IF NOT EXISTS training_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  training_session_id uuid NOT NULL,
  photo_hash text NOT NULL,
  challenge_code text NOT NULL,
  challenge_gesture text NOT NULL,
  movement_score integer DEFAULT 0 CHECK (movement_score >= 0 AND movement_score <= 100),
  risk_score integer DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  points_awarded integer DEFAULT 0,
  timestamp timestamptz DEFAULT now(),
  location_lat real,
  location_lng real,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE training_proofs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own training proofs"
  ON training_proofs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own training proofs"
  ON training_proofs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- User Photo History Table
CREATE TABLE IF NOT EXISTS user_photo_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  photo_hash text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_photo_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own photo history"
  ON user_photo_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own photo history"
  ON user_photo_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Risk Flags Table
CREATE TABLE IF NOT EXISTS risk_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  proof_id uuid REFERENCES training_proofs(id),
  flag_type text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('low', 'medium', 'high')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE risk_flags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own risk flags"
  ON risk_flags FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_training_proofs_user_id ON training_proofs(user_id);
CREATE INDEX IF NOT EXISTS idx_training_proofs_risk_score ON training_proofs(risk_score);
CREATE INDEX IF NOT EXISTS idx_user_photo_history_user_id ON user_photo_history(user_id);
CREATE INDEX IF NOT EXISTS idx_user_photo_history_hash ON user_photo_history(photo_hash);
CREATE INDEX IF NOT EXISTS idx_risk_flags_user_id ON risk_flags(user_id);
CREATE INDEX IF NOT EXISTS idx_risk_flags_severity ON risk_flags(severity);
