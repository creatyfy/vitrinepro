/*
  # Criar tabela de configurações de privacidade

  1. Nova Tabela: privacy_settings
    - id (uuid, pk)
    - user_id (uuid, fk -> auth.users)
    - is_profile_public (boolean) - perfil público ou privado
    - show_in_rankings (boolean) - participar de rankings
    - message_permission (text) - quem pode enviar mensagens (all, followers, none)
    - allow_scout_messages (boolean) - permitir mensagens de empresários
    - two_factor_enabled (boolean) - 2FA ativado
    - two_factor_method (text) - método 2FA (sms, authenticator, null)
    - account_status (text) - status da conta (active, frozen, deleted)
    - created_at (timestamptz)
    - updated_at (timestamptz)
    
  2. Segurança
    - RLS habilitado
    - Políticas para usuários acessarem apenas seus próprios dados
    - Valores padrão: perfil público, rankings ativos, mensagens abertas
*/

-- Criar tabela de configurações de privacidade
CREATE TABLE IF NOT EXISTS privacy_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  is_profile_public boolean DEFAULT true,
  show_in_rankings boolean DEFAULT true,
  message_permission text DEFAULT 'all' CHECK (message_permission IN ('all', 'followers', 'none')),
  allow_scout_messages boolean DEFAULT true,
  two_factor_enabled boolean DEFAULT false,
  two_factor_method text CHECK (two_factor_method IN ('sms', 'authenticator', null)),
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'frozen', 'deleted')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE privacy_settings ENABLE ROW LEVEL SECURITY;

-- Política: usuários podem ver suas próprias configurações
CREATE POLICY "Users can view own privacy settings"
  ON privacy_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Política: usuários podem inserir suas próprias configurações
CREATE POLICY "Users can insert own privacy settings"
  ON privacy_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Política: usuários podem atualizar suas próprias configurações
CREATE POLICY "Users can update own privacy settings"
  ON privacy_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Criar índice para busca rápida por user_id
CREATE INDEX IF NOT EXISTS idx_privacy_settings_user_id ON privacy_settings(user_id);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_privacy_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE TRIGGER update_privacy_settings_timestamp
  BEFORE UPDATE ON privacy_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_privacy_settings_updated_at();

-- Função para inicializar configurações de privacidade ao criar usuário
CREATE OR REPLACE FUNCTION initialize_privacy_settings(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO privacy_settings (user_id)
  VALUES (p_user_id)
  ON CONFLICT (user_id) DO NOTHING;
END;
$$;
