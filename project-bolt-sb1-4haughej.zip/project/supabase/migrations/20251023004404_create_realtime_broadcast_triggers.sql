/*
  # Triggers de Broadcast em Tempo Real

  1. Funções de Trigger
    - Função para broadcast de mudanças em peneiras
    - Função para broadcast de mudanças em inscrições
    - Função para broadcast de mudanças em ranking/pontos
    - Função para broadcast de novas notificações
    - Função para broadcast de mudanças em estoque de produtos
    - Função para broadcast de mudanças em pedidos
    - Função para broadcast de novas mensagens

  2. Triggers
    - Trigger em peneiras para INSERT, UPDATE, DELETE
    - Trigger em peneira_registrations para atualizar contador
    - Trigger em player_profiles para mudanças de pontos
    - Trigger em real_time_notifications para novas notificações
    - Trigger em marketplace_products para mudanças de estoque
    - Trigger em marketplace_orders para mudanças de status
    - Trigger em chat_messages para novas mensagens

  3. Funções Auxiliares
    - Função para atualizar status de peneira automaticamente
    - Função para atualizar contador de participantes
    - Função para criar notificações automáticas
*/

-- Habilitar extensão Realtime se não estiver habilitada
CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA extensions;

-- Função para broadcast de mudanças em peneiras
CREATE OR REPLACE FUNCTION broadcast_peneira_changes()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM pg_notify(
    'peneiras_channel',
    json_build_object(
      'operation', TG_OP,
      'record', CASE 
        WHEN TG_OP = 'DELETE' THEN row_to_json(OLD)
        ELSE row_to_json(NEW)
      END,
      'old_record', CASE 
        WHEN TG_OP = 'UPDATE' THEN row_to_json(OLD)
        ELSE NULL
      END,
      'timestamp', NOW()
    )::text
  );
  
  RETURN CASE 
    WHEN TG_OP = 'DELETE' THEN OLD
    ELSE NEW
  END;
END;
$$;

-- Trigger para peneiras
DROP TRIGGER IF EXISTS trigger_broadcast_peneira_changes ON peneiras;
CREATE TRIGGER trigger_broadcast_peneira_changes
  AFTER INSERT OR UPDATE OR DELETE ON peneiras
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_peneira_changes();

-- Função para atualizar contador de participantes e status de peneira
CREATE OR REPLACE FUNCTION update_peneira_participants()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
DECLARE
  v_count integer;
  v_max_participants integer;
  v_new_status text;
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    SELECT COUNT(*), p.max_participants
    INTO v_count, v_max_participants
    FROM peneira_registrations pr
    JOIN peneiras p ON p.id = pr.peneira_id
    WHERE pr.peneira_id = NEW.peneira_id
      AND pr.status = 'confirmed'
    GROUP BY p.max_participants;
    
    v_count := COALESCE(v_count, 0);
    
    IF v_count >= v_max_participants * 0.9 THEN
      v_new_status := 'fechando';
    ELSIF v_count >= v_max_participants THEN
      v_new_status := 'encerrada';
    ELSE
      v_new_status := 'aberta';
    END IF;
    
    UPDATE peneiras
    SET current_participants = v_count,
        status = v_new_status,
        updated_at = NOW()
    WHERE id = NEW.peneira_id;
    
  ELSIF TG_OP = 'DELETE' THEN
    SELECT COUNT(*)
    INTO v_count
    FROM peneira_registrations
    WHERE peneira_id = OLD.peneira_id
      AND status = 'confirmed';
    
    UPDATE peneiras
    SET current_participants = v_count,
        updated_at = NOW()
    WHERE id = OLD.peneira_id;
  END IF;
  
  RETURN CASE 
    WHEN TG_OP = 'DELETE' THEN OLD
    ELSE NEW
  END;
END;
$$;

-- Trigger para atualizar participantes de peneira
DROP TRIGGER IF EXISTS trigger_update_peneira_participants ON peneira_registrations;
CREATE TRIGGER trigger_update_peneira_participants
  AFTER INSERT OR UPDATE OR DELETE ON peneira_registrations
  FOR EACH ROW
  EXECUTE FUNCTION update_peneira_participants();

-- Função para broadcast de mudanças em ranking/pontos
CREATE OR REPLACE FUNCTION broadcast_ranking_changes()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF (TG_OP = 'UPDATE' AND OLD.total_points != NEW.total_points) OR TG_OP = 'INSERT' THEN
    PERFORM pg_notify(
      'ranking_channel',
      json_build_object(
        'operation', TG_OP,
        'user_id', NEW.user_id,
        'old_points', CASE WHEN TG_OP = 'UPDATE' THEN OLD.total_points ELSE 0 END,
        'new_points', NEW.total_points,
        'change', NEW.total_points - COALESCE(OLD.total_points, 0),
        'timestamp', NOW()
      )::text
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para mudanças de pontos
DROP TRIGGER IF EXISTS trigger_broadcast_ranking_changes ON player_profiles;
CREATE TRIGGER trigger_broadcast_ranking_changes
  AFTER INSERT OR UPDATE ON player_profiles
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_ranking_changes();

-- Função para broadcast de novas notificações
CREATE OR REPLACE FUNCTION broadcast_notification()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM pg_notify(
      'notifications_' || NEW.user_id::text,
      json_build_object(
        'id', NEW.id,
        'type', NEW.type,
        'title', NEW.title,
        'message', NEW.message,
        'data', NEW.data,
        'priority', NEW.priority,
        'created_at', NEW.created_at
      )::text
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para novas notificações
DROP TRIGGER IF EXISTS trigger_broadcast_notification ON real_time_notifications;
CREATE TRIGGER trigger_broadcast_notification
  AFTER INSERT ON real_time_notifications
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_notification();

-- Função para broadcast de mudanças em estoque de produtos
CREATE OR REPLACE FUNCTION broadcast_product_changes()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF (TG_OP = 'UPDATE' AND OLD.stock_quantity != NEW.stock_quantity) OR TG_OP = 'INSERT' THEN
    PERFORM pg_notify(
      'products_channel',
      json_build_object(
        'operation', TG_OP,
        'product_id', NEW.id,
        'old_stock', CASE WHEN TG_OP = 'UPDATE' THEN OLD.stock_quantity ELSE 0 END,
        'new_stock', NEW.stock_quantity,
        'is_low_stock', NEW.stock_quantity < 10,
        'is_out_of_stock', NEW.stock_quantity = 0,
        'timestamp', NOW()
      )::text
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para mudanças em produtos
DROP TRIGGER IF EXISTS trigger_broadcast_product_changes ON marketplace_products;
CREATE TRIGGER trigger_broadcast_product_changes
  AFTER INSERT OR UPDATE ON marketplace_products
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_product_changes();

-- Função para broadcast de mudanças em pedidos
CREATE OR REPLACE FUNCTION broadcast_order_changes()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND (OLD.order_status != NEW.order_status OR OLD.payment_status != NEW.payment_status)) THEN
    PERFORM pg_notify(
      'orders_' || NEW.user_id::text,
      json_build_object(
        'operation', TG_OP,
        'order_id', NEW.id,
        'order_number', NEW.order_number,
        'old_status', CASE WHEN TG_OP = 'UPDATE' THEN OLD.order_status ELSE NULL END,
        'new_status', NEW.order_status,
        'payment_status', NEW.payment_status,
        'timestamp', NOW()
      )::text
    );
    
    IF TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND OLD.payment_status != NEW.payment_status) THEN
      INSERT INTO real_time_notifications (user_id, type, title, message, data, priority)
      VALUES (
        NEW.user_id,
        'payment',
        CASE 
          WHEN NEW.payment_status = 'paid' THEN 'Pagamento Confirmado'
          WHEN NEW.payment_status = 'failed' THEN 'Falha no Pagamento'
          WHEN NEW.payment_status = 'refunded' THEN 'Reembolso Processado'
          ELSE 'Atualização de Pedido'
        END,
        CASE 
          WHEN NEW.payment_status = 'paid' THEN 'Seu pedido #' || NEW.order_number || ' foi confirmado!'
          WHEN NEW.payment_status = 'failed' THEN 'Houve um problema com o pagamento do pedido #' || NEW.order_number
          WHEN NEW.payment_status = 'refunded' THEN 'O reembolso do pedido #' || NEW.order_number || ' foi processado'
          ELSE 'Status do pedido #' || NEW.order_number || ' atualizado'
        END,
        json_build_object('order_id', NEW.id, 'order_number', NEW.order_number, 'status', NEW.order_status),
        CASE WHEN NEW.payment_status = 'paid' THEN 'high' ELSE 'medium' END
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para mudanças em pedidos
DROP TRIGGER IF EXISTS trigger_broadcast_order_changes ON marketplace_orders;
CREATE TRIGGER trigger_broadcast_order_changes
  AFTER INSERT OR UPDATE ON marketplace_orders
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_order_changes();

-- Função para broadcast de novas mensagens
CREATE OR REPLACE FUNCTION broadcast_message()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM pg_notify(
      'messages_' || NEW.receiver_id::text,
      json_build_object(
        'message_id', NEW.id,
        'sender_id', NEW.sender_id,
        'message', NEW.message,
        'created_at', NEW.created_at
      )::text
    );
    
    INSERT INTO real_time_notifications (user_id, type, title, message, data, priority)
    VALUES (
      NEW.receiver_id,
      'message',
      'Nova Mensagem',
      LEFT(NEW.message, 100),
      json_build_object('message_id', NEW.id, 'sender_id', NEW.sender_id),
      'high'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para novas mensagens
DROP TRIGGER IF EXISTS trigger_broadcast_message ON chat_messages;
CREATE TRIGGER trigger_broadcast_message
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION broadcast_message();

-- Função para criar notificação quando nova peneira é criada
CREATE OR REPLACE FUNCTION notify_new_peneira()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO real_time_notifications (user_id, type, title, message, data, priority)
    SELECT 
      u.id,
      'peneira',
      'Nova Peneira Disponível: ' || NEW.club_name,
      NEW.title || ' em ' || NEW.location_city || ', ' || NEW.location_state,
      json_build_object(
        'peneira_id', NEW.id,
        'club_name', NEW.club_name,
        'event_date', NEW.event_date
      ),
      CASE WHEN NEW.priority = 'alta' THEN 'high' ELSE 'medium' END
    FROM auth.users u
    WHERE EXISTS (
      SELECT 1 FROM player_profiles pp 
      WHERE pp.user_id = u.id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para notificar novas peneiras
DROP TRIGGER IF EXISTS trigger_notify_new_peneira ON peneiras;
CREATE TRIGGER trigger_notify_new_peneira
  AFTER INSERT ON peneiras
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_peneira();
