/*
  # Desafio Diário de Nutrição - Sistema Simplificado

  ## Resumo
  Sistema de desafio nutricional diário onde o atleta recebe um prato do dia,
  visualiza a receita e envia uma foto comprovando que fez a refeição.

  ## Estrutura

  ### 1. Tabela de Pratos Diários
  - `daily_nutrition_dishes`: Biblioteca de pratos saudáveis rotativos
  - Campos: nome, imagem, ingredientes, modo de preparo, pontos

  ### 2. Tabela de Desafios Diários
  - `daily_nutrition_challenges_simple`: Um desafio por dia (global)
  - Reseta automaticamente à meia-noite
  - Expira às 23h59

  ### 3. Tabela de Submissões
  - `daily_nutrition_submissions_simple`: Fotos enviadas pelos atletas
  - Um envio por atleta por dia
  - Pontos creditados apenas se enviado dentro do prazo

  ## Regras
  - Desafio dura 24h (00h00 até 23h59)
  - Uma foto por atleta por dia
  - Pontos apenas para quem enviar no prazo
  - Sistema antitrapassa com verificação de uma foto

  ## Segurança
  - RLS ativado em todas as tabelas
  - Atletas podem ver o desafio do dia
  - Atletas podem enviar apenas suas próprias fotos
*/

-- 1. Tabela de pratos disponíveis
CREATE TABLE IF NOT EXISTS daily_nutrition_dishes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  image_url text NOT NULL,
  ingredients text[] NOT NULL DEFAULT '{}',
  preparation_steps text[] NOT NULL DEFAULT '{}',
  points integer DEFAULT 50,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_nutrition_dishes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active dishes"
  ON daily_nutrition_dishes FOR SELECT
  TO authenticated
  USING (is_active = true);

-- 2. Tabela de desafio diário (um por dia)
CREATE TABLE IF NOT EXISTS daily_nutrition_challenges_simple (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_date date NOT NULL UNIQUE,
  dish_id uuid NOT NULL REFERENCES daily_nutrition_dishes(id) ON DELETE CASCADE,
  starts_at timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  points_reward integer DEFAULT 50,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_nutrition_challenges_simple ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view today's challenge"
  ON daily_nutrition_challenges_simple FOR SELECT
  TO authenticated
  USING (is_active = true AND challenge_date = CURRENT_DATE);

-- 3. Tabela de submissões
CREATE TABLE IF NOT EXISTS daily_nutrition_submissions_simple (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  challenge_id uuid NOT NULL REFERENCES daily_nutrition_challenges_simple(id) ON DELETE CASCADE,
  challenge_date date NOT NULL,
  photo_url text NOT NULL,
  verification_code text NOT NULL,
  points_earned integer DEFAULT 0,
  submitted_at timestamptz DEFAULT now(),
  verified_at timestamptz,
  metadata jsonb DEFAULT '{}'::jsonb,
  UNIQUE(user_id, challenge_date)
);

ALTER TABLE daily_nutrition_submissions_simple ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own submissions"
  ON daily_nutrition_submissions_simple FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own submissions"
  ON daily_nutrition_submissions_simple FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- 4. Índices para performance
CREATE INDEX IF NOT EXISTS idx_daily_challenges_date ON daily_nutrition_challenges_simple(challenge_date, is_active);
CREATE INDEX IF NOT EXISTS idx_daily_submissions_user_date ON daily_nutrition_submissions_simple(user_id, challenge_date);
CREATE INDEX IF NOT EXISTS idx_daily_dishes_active ON daily_nutrition_dishes(is_active);

-- 5. Função para criar desafio diário automaticamente
CREATE OR REPLACE FUNCTION create_daily_nutrition_challenge()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_today date;
  v_challenge_exists boolean;
  v_random_dish_id uuid;
  v_starts_at timestamptz;
  v_expires_at timestamptz;
BEGIN
  v_today := CURRENT_DATE;
  
  -- Verificar se já existe desafio para hoje
  SELECT EXISTS(
    SELECT 1 FROM daily_nutrition_challenges_simple 
    WHERE challenge_date = v_today
  ) INTO v_challenge_exists;
  
  IF NOT v_challenge_exists THEN
    -- Definir horários (00h00 até 23h59)
    v_starts_at := v_today::timestamptz;
    v_expires_at := (v_today + INTERVAL '1 day')::timestamptz - INTERVAL '1 minute';
    
    -- Selecionar prato aleatório (evitar o de ontem se possível)
    SELECT id INTO v_random_dish_id
    FROM daily_nutrition_dishes
    WHERE is_active = true
      AND id NOT IN (
        SELECT dish_id 
        FROM daily_nutrition_challenges_simple 
        WHERE challenge_date = v_today - 1
        LIMIT 1
      )
    ORDER BY RANDOM()
    LIMIT 1;
    
    -- Se não encontrou (só tem 1 prato), pegar qualquer um
    IF v_random_dish_id IS NULL THEN
      SELECT id INTO v_random_dish_id
      FROM daily_nutrition_dishes
      WHERE is_active = true
      ORDER BY RANDOM()
      LIMIT 1;
    END IF;
    
    -- Criar desafio do dia
    IF v_random_dish_id IS NOT NULL THEN
      INSERT INTO daily_nutrition_challenges_simple (
        challenge_date, 
        dish_id, 
        starts_at, 
        expires_at,
        points_reward
      ) VALUES (
        v_today,
        v_random_dish_id,
        v_starts_at,
        v_expires_at,
        50
      );
    END IF;
  END IF;
END;
$$;

-- 6. Inserir pratos iniciais
INSERT INTO daily_nutrition_dishes (name, image_url, ingredients, preparation_steps, points) VALUES
(
  'Salmão Grelhado com Quinoa',
  'https://images.pexels.com/photos/1410235/pexels-photo-1410235.jpeg?auto=compress&cs=tinysrgb&w=800',
  ARRAY[
    '200g de filé de salmão',
    '1 xícara de quinoa',
    'Brócolis a gosto',
    'Azeite extra virgem',
    'Limão',
    'Sal e pimenta'
  ],
  ARRAY[
    'Cozinhe a quinoa em água fervente por 15 minutos',
    'Tempere o salmão com sal, pimenta e limão',
    'Grelhe o salmão por 4 minutos de cada lado',
    'Cozinhe o brócolis no vapor por 5 minutos',
    'Monte o prato e finalize com azeite'
  ],
  50
),
(
  'Frango Grelhado com Batata Doce',
  'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
  ARRAY[
    '200g de peito de frango',
    '1 batata doce média',
    'Salada verde',
    'Azeite',
    'Temperos naturais'
  ],
  ARRAY[
    'Tempere o frango com sal, alho e ervas',
    'Grelhe o frango por 6-8 minutos de cada lado',
    'Asse a batata doce no forno por 30 minutos',
    'Prepare uma salada verde fresca',
    'Sirva tudo junto com um fio de azeite'
  ],
  50
),
(
  'Bowl Vegetariano com Grão de Bico',
  'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=800',
  ARRAY[
    '1 xícara de grão de bico cozido',
    'Quinoa',
    'Abacate',
    'Tomate cereja',
    'Rúcula',
    'Azeite e limão'
  ],
  ARRAY[
    'Cozinhe a quinoa conforme embalagem',
    'Tempere o grão de bico com cominho',
    'Corte o abacate e tomates',
    'Monte o bowl com todos os ingredientes',
    'Finalize com azeite e limão'
  ],
  50
),
(
  'Omelete de Claras com Legumes',
  'https://images.pexels.com/photos/566345/pexels-photo-566345.jpeg?auto=compress&cs=tinysrgb&w=800',
  ARRAY[
    '4 claras de ovo',
    'Tomate',
    'Cebola',
    'Espinafre',
    'Queijo branco light',
    'Azeite'
  ],
  ARRAY[
    'Bata as claras com sal',
    'Refogue os legumes no azeite',
    'Despeje as claras na frigideira',
    'Adicione os legumes e queijo',
    'Dobre ao meio e sirva'
  ],
  50
),
(
  'Peixe Assado com Arroz Integral',
  'https://images.pexels.com/photos/842142/pexels-photo-842142.jpeg?auto=compress&cs=tinysrgb&w=800',
  ARRAY[
    '200g de filé de peixe branco',
    '1 xícara de arroz integral',
    'Legumes variados',
    'Limão',
    'Ervas frescas'
  ],
  ARRAY[
    'Cozinhe o arroz integral por 40 minutos',
    'Tempere o peixe com limão e ervas',
    'Asse o peixe a 180°C por 20 minutos',
    'Prepare legumes no vapor',
    'Monte o prato e sirva quente'
  ],
  50
)
ON CONFLICT DO NOTHING;

-- 7. Criar desafio para hoje (se ainda não existe)
SELECT create_daily_nutrition_challenge();

-- Comentários
COMMENT ON TABLE daily_nutrition_dishes IS 'Biblioteca de pratos saudáveis para desafios diários';
COMMENT ON TABLE daily_nutrition_challenges_simple IS 'Desafio diário de nutrição (um por dia, 24h)';
COMMENT ON TABLE daily_nutrition_submissions_simple IS 'Fotos enviadas pelos atletas no desafio diário';
