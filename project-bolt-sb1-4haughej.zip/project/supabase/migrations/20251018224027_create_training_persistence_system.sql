-- Training Persistence System
--
-- 1. New Tables
--    - training_sessions: Main training session tracking
--    - training_session_exercises: Individual exercise progress within sessions
--    - training_preferences: User preferences for training execution
--
-- 2. Security
--    - RLS enabled on all tables
--    - Users can only access their own data
--
-- 3. Features
--    - Automatic state persistence
--    - Resume capability
--    - Cross-device sync
--    - Analytics ready

-- Training Sessions Table
CREATE TABLE IF NOT EXISTS training_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  training_type text NOT NULL,
  training_id text NOT NULL,
  started_at timestamptz DEFAULT now(),
  last_updated_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  status text DEFAULT 'active',
  total_exercises integer DEFAULT 0,
  completed_exercises integer DEFAULT 0,
  session_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE training_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own training sessions"
  ON training_sessions FOR SELECT
  TO authenticated
  USING (user_id = (SELECT id FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Users can insert own training sessions"
  ON training_sessions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT id FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Users can update own training sessions"
  ON training_sessions FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT id FROM auth.users WHERE id = auth.uid()))
  WITH CHECK (user_id = (SELECT id FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Users can delete own training sessions"
  ON training_sessions FOR DELETE
  TO authenticated
  USING (user_id = (SELECT id FROM auth.users WHERE id = auth.uid()));

-- Training Session Exercises Table
CREATE TABLE IF NOT EXISTS training_session_exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES training_sessions(id) ON DELETE CASCADE,
  exercise_id text NOT NULL,
  exercise_name text NOT NULL,
  exercise_index integer NOT NULL,
  phase text DEFAULT 'prep',
  current_set integer DEFAULT 1,
  total_sets integer DEFAULT 1,
  remaining_time integer DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  exercise_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE training_session_exercises ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own session exercises"
  ON training_session_exercises FOR SELECT
  TO authenticated
  USING (session_id IN (
    SELECT id FROM training_sessions WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can insert own session exercises"
  ON training_session_exercises FOR INSERT
  TO authenticated
  WITH CHECK (session_id IN (
    SELECT id FROM training_sessions WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can update own session exercises"
  ON training_session_exercises FOR UPDATE
  TO authenticated
  USING (session_id IN (
    SELECT id FROM training_sessions WHERE user_id = auth.uid()
  ))
  WITH CHECK (session_id IN (
    SELECT id FROM training_sessions WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can delete own session exercises"
  ON training_session_exercises FOR DELETE
  TO authenticated
  USING (session_id IN (
    SELECT id FROM training_sessions WHERE user_id = auth.uid()
  ));

-- Training Preferences Table
CREATE TABLE IF NOT EXISTS training_preferences (
  user_id uuid PRIMARY KEY,
  music_enabled boolean DEFAULT true,
  fullscreen_enabled boolean DEFAULT false,
  video_quality text DEFAULT '1080p',
  video_speed numeric DEFAULT 1.0,
  haptic_feedback boolean DEFAULT true,
  default_rest_time integer DEFAULT 10,
  default_prep_time integer DEFAULT 10,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE training_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own training preferences"
  ON training_preferences FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own training preferences"
  ON training_preferences FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own training preferences"
  ON training_preferences FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_training_sessions_user_id ON training_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_training_sessions_status ON training_sessions(status);
CREATE INDEX IF NOT EXISTS idx_training_session_exercises_session_id ON training_session_exercises(session_id);
CREATE INDEX IF NOT EXISTS idx_training_session_exercises_phase ON training_session_exercises(phase);