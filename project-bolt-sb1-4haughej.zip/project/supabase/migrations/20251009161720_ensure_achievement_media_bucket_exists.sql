/*
  # Ensure Achievement Media Bucket Exists
  
  1. Create or update the achievement-media bucket
  2. Set proper configuration
  3. Ensure policies are in place
*/

-- Ensure bucket exists with correct settings
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'achievement-media',
  'achievement-media',
  true,
  20971520,
  ARRAY['image/jpeg', 'image/png', 'image/heic', 'image/jpg', 'video/mp4', 'video/quicktime']::text[]
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 20971520,
  allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/heic', 'image/jpg', 'video/mp4', 'video/quicktime']::text[];

-- Ensure policies exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated users can upload achievement media'
  ) THEN
    CREATE POLICY "Authenticated users can upload achievement media"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = 'achievement-media');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated users can view achievement media'
  ) THEN
    CREATE POLICY "Authenticated users can view achievement media"
      ON storage.objects FOR SELECT
      TO authenticated
      USING (bucket_id = 'achievement-media');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated users can delete achievement media'
  ) THEN
    CREATE POLICY "Authenticated users can delete achievement media"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (bucket_id = 'achievement-media');
  END IF;
END $$;