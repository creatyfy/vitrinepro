/*
  # Achievements System - Complete Implementation
  
  1. New Tables
    - `achievement_types`
      - `id` (uuid, primary key)
      - `code` (text, unique) - internal identifier (trophy, goal, tournament, club, other)
      - `label` (text) - display label in Portuguese
      - `default_points` (integer) - base points for this achievement type
      - `icon` (text, optional) - icon identifier
      - `created_at` (timestamptz)
    
    - `achievements`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `type_id` (uuid, foreign key to achievement_types)
      - `title` (text) - title/name of achievement
      - `year` (integer, optional) - year of achievement
      - `club` (text, optional) - club represented
      - `level` (text, optional) - amateur/regional/estadual/nacional/internacional/profissional
      - `description` (text, optional)
      - `goals_count` (integer, optional)
      - `adversary` (text, optional) - for goals
      - `match_date` (date, optional) - for goals
      - `match_minute` (integer, optional) - for goals
      - `match_type` (text, optional) - for goals
      - `tournament_name` (text, optional)
      - `position` (text, optional) - placement in tournament
      - `games_played` (integer, optional)
      - `period_start` (date, optional) - for clubs
      - `period_end` (date, optional) - for clubs
      - `role` (text, optional) - role/position at club
      - `custom_fields` (jsonb, optional) - flexible storage for other types
      - `status` (text) - pending/approved/rejected/draft
      - `submission_id` (uuid, unique) - reference for tracking
      - `provisional_points` (integer) - points credited provisionally
      - `final_points` (integer) - points after approval
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `achievement_media`
      - `id` (uuid, primary key)
      - `achievement_id` (uuid, foreign key to achievements)
      - `user_id` (uuid, foreign key to auth.users)
      - `media_url` (text) - storage URL
      - `media_type` (text) - image/video/document
      - `file_size` (bigint) - file size in bytes
      - `mime_type` (text)
      - `exif_data` (jsonb, optional) - extracted EXIF data
      - `uploaded_at` (timestamptz)
    
    - `achievement_verifications`
      - `id` (uuid, primary key)
      - `achievement_id` (uuid, foreign key to achievements)
      - `reviewer_id` (uuid, optional, foreign key to auth.users)
      - `auto_result` (text, optional) - auto_pass/auto_review/auto_fail
      - `auto_score` (numeric, optional) - 0.0 to 1.0
      - `auto_checks` (jsonb, optional) - detailed auto-check results
      - `manual_result` (text, optional) - approved/rejected/pending
      - `manual_notes` (text, optional)
      - `created_at` (timestamptz)
      - `reviewed_at` (timestamptz, optional)
    
    - `achievement_points_settings`
      - `id` (uuid, primary key)
      - `type_id` (uuid, foreign key to achievement_types)
      - `level` (text) - level qualifier (amateur/regional/etc)
      - `points_value` (integer) - points awarded
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `achievement_appeals`
      - `id` (uuid, primary key)
      - `achievement_id` (uuid, foreign key to achievements)
      - `user_id` (uuid, foreign key to auth.users)
      - `reason` (text)
      - `status` (text) - pending/under_review/resolved
      - `resolution_notes` (text, optional)
      - `resolved_by` (uuid, optional, foreign key to auth.users)
      - `created_at` (timestamptz)
      - `resolved_at` (timestamptz, optional)
    
    - `achievement_audit_log`
      - `id` (uuid, primary key)
      - `achievement_id` (uuid, foreign key to achievements)
      - `user_id` (uuid, foreign key to auth.users)
      - `action` (text) - created/submitted/approved/rejected/appealed
      - `details` (jsonb, optional)
      - `ip_address` (text, optional)
      - `created_at` (timestamptz)
    
    - `achievement_user_limits`
      - `user_id` (uuid, primary key, foreign key to auth.users)
      - `submissions_this_month` (integer, default 0)
      - `last_submission_date` (timestamptz, optional)
      - `total_submissions` (integer, default 0)
      - `approved_count` (integer, default 0)
      - `rejected_count` (integer, default 0)
      - `appeals_count` (integer, default 0)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Storage Buckets
    - Create 'achievement-media' bucket for storing evidence files

  3. Security
    - Enable RLS on all tables
    - Policies for authenticated users to manage their own achievements
    - Policies for admin/reviewers to access verification data
    - Secure media access

  4. Functions
    - Function to reset monthly submission counters
    - Function to calculate auto-verification score
    - Function to process achievement approval/rejection
*/

-- Create achievement_types table
CREATE TABLE IF NOT EXISTS achievement_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  label text NOT NULL,
  default_points integer NOT NULL DEFAULT 0,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type_id uuid REFERENCES achievement_types(id) NOT NULL,
  title text NOT NULL,
  year integer,
  club text,
  level text,
  description text,
  goals_count integer,
  adversary text,
  match_date date,
  match_minute integer,
  match_type text,
  tournament_name text,
  position text,
  games_played integer,
  period_start date,
  period_end date,
  role text,
  custom_fields jsonb,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'approved', 'rejected')),
  submission_id uuid UNIQUE DEFAULT gen_random_uuid(),
  provisional_points integer DEFAULT 0,
  final_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create achievement_media table
CREATE TABLE IF NOT EXISTS achievement_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  media_url text NOT NULL,
  media_type text NOT NULL CHECK (media_type IN ('image', 'video', 'document')),
  file_size bigint,
  mime_type text,
  exif_data jsonb,
  uploaded_at timestamptz DEFAULT now()
);

-- Create achievement_verifications table
CREATE TABLE IF NOT EXISTS achievement_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  reviewer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  auto_result text CHECK (auto_result IN ('auto_pass', 'auto_review', 'auto_fail')),
  auto_score numeric(3,2) CHECK (auto_score >= 0 AND auto_score <= 1),
  auto_checks jsonb,
  manual_result text CHECK (manual_result IN ('approved', 'rejected', 'pending')),
  manual_notes text,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

-- Create achievement_points_settings table
CREATE TABLE IF NOT EXISTS achievement_points_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type_id uuid REFERENCES achievement_types(id) NOT NULL,
  level text NOT NULL,
  points_value integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(type_id, level)
);

-- Create achievement_appeals table
CREATE TABLE IF NOT EXISTS achievement_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'resolved')),
  resolution_notes text,
  resolved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- Create achievement_audit_log table
CREATE TABLE IF NOT EXISTS achievement_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  action text NOT NULL,
  details jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- Create achievement_user_limits table
CREATE TABLE IF NOT EXISTS achievement_user_limits (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  submissions_this_month integer DEFAULT 0,
  last_submission_date timestamptz,
  total_submissions integer DEFAULT 0,
  approved_count integer DEFAULT 0,
  rejected_count integer DEFAULT 0,
  appeals_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default achievement types
INSERT INTO achievement_types (code, label, default_points, icon) VALUES
  ('trophy', 'Título / Troféu', 100, 'trophy'),
  ('goal', 'Gol / Lance', 50, 'target'),
  ('tournament', 'Torneio / Campeonato', 75, 'award'),
  ('club', 'Clube / Período jogado', 30, 'shield'),
  ('other', 'Outro', 20, 'star')
ON CONFLICT (code) DO NOTHING;

-- Insert default points settings
INSERT INTO achievement_points_settings (type_id, level, points_value)
SELECT id, 'amador', 50 FROM achievement_types WHERE code = 'trophy'
UNION ALL
SELECT id, 'regional', 75 FROM achievement_types WHERE code = 'trophy'
UNION ALL
SELECT id, 'estadual', 100 FROM achievement_types WHERE code = 'trophy'
UNION ALL
SELECT id, 'nacional', 150 FROM achievement_types WHERE code = 'trophy'
UNION ALL
SELECT id, 'internacional', 200 FROM achievement_types WHERE code = 'trophy'
UNION ALL
SELECT id, 'profissional', 250 FROM achievement_types WHERE code = 'trophy'
ON CONFLICT (type_id, level) DO NOTHING;

-- Enable RLS
ALTER TABLE achievement_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_points_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_appeals ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievement_user_limits ENABLE ROW LEVEL SECURITY;

-- Policies for achievement_types (public read)
CREATE POLICY "Anyone can view achievement types"
  ON achievement_types FOR SELECT
  TO authenticated
  USING (true);

-- Policies for achievements
CREATE POLICY "Users can view own achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own achievements"
  ON achievements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own draft achievements"
  ON achievements FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'draft')
  WITH CHECK (auth.uid() = user_id);

-- Policies for achievement_media
CREATE POLICY "Users can view own achievement media"
  ON achievement_media FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can upload achievement media"
  ON achievement_media FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own draft achievement media"
  ON achievement_media FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM achievements
      WHERE achievements.id = achievement_media.achievement_id
      AND achievements.status = 'draft'
    )
  );

-- Policies for achievement_verifications (users can view their own)
CREATE POLICY "Users can view verifications of own achievements"
  ON achievement_verifications FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM achievements
      WHERE achievements.id = achievement_verifications.achievement_id
      AND achievements.user_id = auth.uid()
    )
  );

-- Policies for achievement_points_settings (public read)
CREATE POLICY "Anyone can view points settings"
  ON achievement_points_settings FOR SELECT
  TO authenticated
  USING (true);

-- Policies for achievement_appeals
CREATE POLICY "Users can view own appeals"
  ON achievement_appeals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create appeals for own achievements"
  ON achievement_appeals FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM achievements
      WHERE achievements.id = achievement_appeals.achievement_id
      AND achievements.user_id = auth.uid()
    )
  );

-- Policies for achievement_audit_log
CREATE POLICY "Users can view own audit log"
  ON achievement_audit_log FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for achievement_user_limits
CREATE POLICY "Users can view own limits"
  ON achievement_user_limits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "System can manage user limits"
  ON achievement_user_limits FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Function to update achievements timestamp
CREATE OR REPLACE FUNCTION update_achievement_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for achievements
DROP TRIGGER IF EXISTS update_achievements_timestamp ON achievements;
CREATE TRIGGER update_achievements_timestamp
  BEFORE UPDATE ON achievements
  FOR EACH ROW
  EXECUTE FUNCTION update_achievement_timestamp();

-- Function to log achievement actions
CREATE OR REPLACE FUNCTION log_achievement_action()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO achievement_audit_log (achievement_id, user_id, action, details)
  VALUES (
    NEW.id,
    NEW.user_id,
    CASE
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'pending' AND OLD.status = 'draft' THEN 'submitted'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'approved' THEN 'approved'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'rejected' THEN 'rejected'
      ELSE 'updated'
    END,
    jsonb_build_object('old_status', OLD.status, 'new_status', NEW.status)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for achievement audit logging
DROP TRIGGER IF EXISTS log_achievement_actions ON achievements;
CREATE TRIGGER log_achievement_actions
  AFTER INSERT OR UPDATE ON achievements
  FOR EACH ROW
  EXECUTE FUNCTION log_achievement_action();

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_achievements_user_id ON achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_achievements_status ON achievements(status);
CREATE INDEX IF NOT EXISTS idx_achievements_type_id ON achievements(type_id);
CREATE INDEX IF NOT EXISTS idx_achievement_media_achievement_id ON achievement_media(achievement_id);
CREATE INDEX IF NOT EXISTS idx_achievement_verifications_achievement_id ON achievement_verifications(achievement_id);
CREATE INDEX IF NOT EXISTS idx_achievement_appeals_achievement_id ON achievement_appeals(achievement_id);
CREATE INDEX IF NOT EXISTS idx_achievement_audit_log_achievement_id ON achievement_audit_log(achievement_id);