/*
  # Player Profiles and Videos System

  1. New Tables
    - `player_profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text)
      - `birth_date` (date)
      - `age` (computed from birth_date)
      - `city` (text)
      - `state` (text, 2 chars for UF)
      - `country` (text)
      - `gender` (text: male/female/other)
      - `height_cm` (integer, 120-220)
      - `weight_kg` (integer, 40-150)
      - `position_1` (text)
      - `position_2` (text, nullable)
      - `bio` (text, max 240 chars)
      - `avatar_url` (text)
      - `total_points` (integer, default 0)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `player_videos`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `title` (text, nullable)
      - `description` (text, nullable)
      - `duration_seconds` (integer)
      - `file_size_bytes` (bigint)
      - `video_hash` (text, for duplicate detection)
      - `original_url` (text)
      - `hls_url` (text, nullable after processing)
      - `poster_url` (text, nullable)
      - `status` (text: queued/processing/ready/failed)
      - `upload_source` (text: capture/gallery)
      - `created_at` (timestamptz)
      - `processed_at` (timestamptz, nullable)
      - `deleted_at` (timestamptz, nullable, soft delete)
      - `points_awarded` (integer, default 0)
      - `points_reversed` (boolean, default false)

    - `video_upload_limits`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `upload_date` (date)
      - `upload_count` (integer, default 0)
      - `created_at` (timestamptz)

    - `video_telemetry`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `video_id` (uuid, nullable)
      - `event_type` (text)
      - `event_data` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for public read access to profiles and videos

  3. Functions
    - Function to calculate age from birth_date
    - Function to check daily upload limits
    - Function to detect duplicate videos
*/

-- Player Profiles Table
CREATE TABLE IF NOT EXISTS player_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  name text NOT NULL,
  birth_date date,
  city text,
  state text,
  country text DEFAULT 'Brasil',
  gender text CHECK (gender IN ('male', 'female', 'other', 'prefer_not_say')),
  height_cm integer CHECK (height_cm >= 120 AND height_cm <= 220),
  weight_kg integer CHECK (weight_kg >= 40 AND weight_kg <= 150),
  position_1 text,
  position_2 text,
  bio text,
  avatar_url text,
  total_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Player Videos Table
CREATE TABLE IF NOT EXISTS player_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text,
  description text,
  duration_seconds integer,
  file_size_bytes bigint,
  video_hash text,
  original_url text NOT NULL,
  hls_url text,
  poster_url text,
  status text DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'ready', 'failed')),
  upload_source text CHECK (upload_source IN ('capture', 'gallery')),
  created_at timestamptz DEFAULT now(),
  processed_at timestamptz,
  deleted_at timestamptz,
  points_awarded integer DEFAULT 0,
  points_reversed boolean DEFAULT false
);

-- Video Upload Limits Table
CREATE TABLE IF NOT EXISTS video_upload_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  upload_date date DEFAULT CURRENT_DATE NOT NULL,
  upload_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, upload_date)
);

-- Video Telemetry Table
CREATE TABLE IF NOT EXISTS video_telemetry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  video_id uuid REFERENCES player_videos(id) ON DELETE SET NULL,
  event_type text NOT NULL,
  event_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_player_videos_user_id ON player_videos(user_id);
CREATE INDEX IF NOT EXISTS idx_player_videos_status ON player_videos(status);
CREATE INDEX IF NOT EXISTS idx_player_videos_created_at ON player_videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_player_videos_hash ON player_videos(video_hash);
CREATE INDEX IF NOT EXISTS idx_video_limits_user_date ON video_upload_limits(user_id, upload_date);
CREATE INDEX IF NOT EXISTS idx_video_telemetry_user_id ON video_telemetry(user_id);
CREATE INDEX IF NOT EXISTS idx_video_telemetry_created_at ON video_telemetry(created_at DESC);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for player_profiles
DROP TRIGGER IF EXISTS update_player_profiles_updated_at ON player_profiles;
CREATE TRIGGER update_player_profiles_updated_at
  BEFORE UPDATE ON player_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to check daily upload limit (max 5 uploads per day)
CREATE OR REPLACE FUNCTION check_upload_limit(p_user_id uuid)
RETURNS boolean AS $$
DECLARE
  v_count integer;
BEGIN
  SELECT COALESCE(upload_count, 0) INTO v_count
  FROM video_upload_limits
  WHERE user_id = p_user_id AND upload_date = CURRENT_DATE;
  
  RETURN v_count < 5;
END;
$$ LANGUAGE plpgsql;

-- Function to increment upload count
CREATE OR REPLACE FUNCTION increment_upload_count(p_user_id uuid)
RETURNS void AS $$
BEGIN
  INSERT INTO video_upload_limits (user_id, upload_date, upload_count)
  VALUES (p_user_id, CURRENT_DATE, 1)
  ON CONFLICT (user_id, upload_date)
  DO UPDATE SET upload_count = video_upload_limits.upload_count + 1;
END;
$$ LANGUAGE plpgsql;

-- Function to check for duplicate videos
CREATE OR REPLACE FUNCTION check_duplicate_video(p_user_id uuid, p_video_hash text)
RETURNS boolean AS $$
DECLARE
  v_exists boolean;
BEGIN
  SELECT EXISTS(
    SELECT 1 FROM player_videos
    WHERE user_id = p_user_id 
    AND video_hash = p_video_hash
    AND deleted_at IS NULL
    AND status != 'failed'
  ) INTO v_exists;
  
  RETURN v_exists;
END;
$$ LANGUAGE plpgsql;

-- Function to award points for video upload
CREATE OR REPLACE FUNCTION award_video_points(p_video_id uuid)
RETURNS void AS $$
DECLARE
  v_user_id uuid;
  v_points integer := 20;
BEGIN
  SELECT user_id INTO v_user_id FROM player_videos WHERE id = p_video_id;
  
  UPDATE player_videos
  SET points_awarded = v_points
  WHERE id = p_video_id;
  
  UPDATE player_profiles
  SET total_points = total_points + v_points
  WHERE user_id = v_user_id;
END;
$$ LANGUAGE plpgsql;

-- Function to reverse points when video deleted within 24h
CREATE OR REPLACE FUNCTION reverse_video_points(p_video_id uuid)
RETURNS boolean AS $$
DECLARE
  v_video_record RECORD;
  v_should_reverse boolean := false;
BEGIN
  SELECT * INTO v_video_record
  FROM player_videos
  WHERE id = p_video_id;
  
  -- Check if video was created less than 24 hours ago
  IF v_video_record.created_at > (now() - interval '24 hours') 
     AND v_video_record.points_awarded > 0 
     AND NOT v_video_record.points_reversed THEN
    
    -- Reverse points
    UPDATE player_profiles
    SET total_points = total_points - v_video_record.points_awarded
    WHERE user_id = v_video_record.user_id;
    
    UPDATE player_videos
    SET points_reversed = true
    WHERE id = p_video_id;
    
    v_should_reverse := true;
  END IF;
  
  RETURN v_should_reverse;
END;
$$ LANGUAGE plpgsql;

-- Enable Row Level Security
ALTER TABLE player_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE player_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_upload_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_telemetry ENABLE ROW LEVEL SECURITY;

-- Policies for player_profiles
CREATE POLICY "Anyone can view player profiles"
  ON player_profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create their own profile"
  ON player_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
  ON player_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for player_videos
CREATE POLICY "Anyone can view non-deleted videos"
  ON player_videos FOR SELECT
  TO authenticated
  USING (deleted_at IS NULL);

CREATE POLICY "Users can create their own videos"
  ON player_videos FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own videos"
  ON player_videos FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own videos"
  ON player_videos FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for video_upload_limits
CREATE POLICY "Users can view their own upload limits"
  ON video_upload_limits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own upload limits"
  ON video_upload_limits FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own upload limits"
  ON video_upload_limits FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for video_telemetry
CREATE POLICY "Users can view their own telemetry"
  ON video_telemetry FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own telemetry"
  ON video_telemetry FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);