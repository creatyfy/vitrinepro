/*
  # Enhance Daily Training Limitations System

  ## Summary
  This migration enhances the daily training system to ensure athletes can only complete
  one training per day with robust validation and helpful utility functions.

  1. Database Functions
    - `validate_daily_training_completion` - Validates if user can mark training as completed
    - `get_time_until_next_training` - Returns seconds until midnight (next training available)
    - `get_user_training_streak` - Calculates consecutive days of completed trainings
    - `get_recent_training_history` - Returns last 7 days of training history

  2. Trigger
    - `prevent_multiple_completions_trigger` - Prevents marking multiple trainings as completed on same day

  3. Security
    - Additional validation at database level
    - Server-side timestamp verification
    - Audit logging for suspicious activities

  4. Important Notes
    - Uses database server time to prevent timezone manipulation
    - Enforces one completed training per user per day
    - Provides helpful functions for UI features (streak, countdown, history)
*/

-- Function to validate if user can complete training today
CREATE OR REPLACE FUNCTION validate_daily_training_completion(
  p_user_id uuid,
  p_training_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_training_date date;
  v_completed_today integer;
BEGIN
  -- Get the training date for the training being completed
  SELECT training_date INTO v_training_date
  FROM daily_trainings
  WHERE id = p_training_id AND user_id = p_user_id;

  -- Check if user already has a completed training for this date
  SELECT COUNT(*) INTO v_completed_today
  FROM daily_trainings
  WHERE user_id = p_user_id
    AND training_date = v_training_date
    AND status = 'completed'
    AND id != p_training_id;

  -- Return false if already completed training today
  RETURN v_completed_today = 0;
END;
$$;

-- Function to get seconds until next training (midnight)
CREATE OR REPLACE FUNCTION get_time_until_next_training()
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  v_now timestamptz;
  v_midnight timestamptz;
  v_seconds integer;
BEGIN
  v_now := now();
  v_midnight := (CURRENT_DATE + INTERVAL '1 day')::timestamptz;
  v_seconds := EXTRACT(EPOCH FROM (v_midnight - v_now))::integer;

  RETURN v_seconds;
END;
$$;

-- Function to calculate user's training streak
CREATE OR REPLACE FUNCTION get_user_training_streak(p_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  v_streak integer := 0;
  v_check_date date := CURRENT_DATE;
  v_has_training boolean;
BEGIN
  -- Start from today and go backwards
  LOOP
    SELECT EXISTS (
      SELECT 1
      FROM daily_trainings
      WHERE user_id = p_user_id
        AND training_date = v_check_date
        AND status = 'completed'
    ) INTO v_has_training;

    -- If no training found, break the streak
    IF NOT v_has_training THEN
      EXIT;
    END IF;

    -- Increment streak and check previous day
    v_streak := v_streak + 1;
    v_check_date := v_check_date - INTERVAL '1 day';

    -- Safety limit: don't check more than 365 days
    IF v_streak >= 365 THEN
      EXIT;
    END IF;
  END LOOP;

  RETURN v_streak;
END;
$$;

-- Function to get recent training history (last 7 days)
CREATE OR REPLACE FUNCTION get_recent_training_history(p_user_id uuid)
RETURNS TABLE (
  training_date date,
  status text,
  completed_at timestamptz,
  total_exercises integer,
  intensity_level text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT
    dt.training_date,
    dt.status,
    dt.completed_at,
    dt.total_exercises,
    dt.intensity_level
  FROM daily_trainings dt
  WHERE dt.user_id = p_user_id
    AND dt.training_date >= CURRENT_DATE - INTERVAL '6 days'
    AND dt.training_date <= CURRENT_DATE
  ORDER BY dt.training_date DESC;
END;
$$;

-- Trigger function to prevent multiple completions on same day
CREATE OR REPLACE FUNCTION prevent_multiple_daily_completions()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_existing_completion boolean;
BEGIN
  -- Only check when status is being changed to 'completed'
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Check if user already has a completed training for this date
    SELECT EXISTS (
      SELECT 1
      FROM daily_trainings
      WHERE user_id = NEW.user_id
        AND training_date = NEW.training_date
        AND status = 'completed'
        AND id != NEW.id
    ) INTO v_existing_completion;

    -- Raise exception if trying to complete multiple trainings on same day
    IF v_existing_completion THEN
      RAISE EXCEPTION 'User has already completed a training for this date. Only one training per day is allowed.'
        USING HINT = 'Each user can only complete one training per day.';
    END IF;

    -- Set completed_at to server time to prevent manipulation
    NEW.completed_at := now();
  END IF;

  RETURN NEW;
END;
$$;

-- Drop trigger if exists and create new one
DROP TRIGGER IF EXISTS prevent_multiple_completions_trigger ON daily_trainings;

CREATE TRIGGER prevent_multiple_completions_trigger
  BEFORE UPDATE ON daily_trainings
  FOR EACH ROW
  EXECUTE FUNCTION prevent_multiple_daily_completions();

-- Create audit log table for tracking suspicious activities
CREATE TABLE IF NOT EXISTS daily_training_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  training_id uuid NOT NULL,
  action text NOT NULL,
  status_before text,
  status_after text,
  training_date date NOT NULL,
  attempt_timestamp timestamptz DEFAULT now(),
  ip_address text,
  user_agent text,
  blocked boolean DEFAULT false,
  reason text
);

-- Enable RLS on audit log
ALTER TABLE daily_training_audit_log ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own audit logs
CREATE POLICY "Users can view own audit logs"
  ON daily_training_audit_log
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for audit log queries
CREATE INDEX IF NOT EXISTS idx_audit_log_user_date
  ON daily_training_audit_log(user_id, attempt_timestamp DESC);

-- Function to log training completion attempts
CREATE OR REPLACE FUNCTION log_training_completion_attempt(
  p_user_id uuid,
  p_training_id uuid,
  p_training_date date,
  p_status_before text,
  p_status_after text,
  p_blocked boolean DEFAULT false,
  p_reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO daily_training_audit_log (
    user_id,
    training_id,
    action,
    status_before,
    status_after,
    training_date,
    blocked,
    reason
  ) VALUES (
    p_user_id,
    p_training_id,
    'completion_attempt',
    p_status_before,
    p_status_after,
    p_training_date,
    p_blocked,
    p_reason
  );
END;
$$;

-- Update the existing trigger to include audit logging
CREATE OR REPLACE FUNCTION prevent_multiple_daily_completions()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_existing_completion boolean;
BEGIN
  -- Only check when status is being changed to 'completed'
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Check if user already has a completed training for this date
    SELECT EXISTS (
      SELECT 1
      FROM daily_trainings
      WHERE user_id = NEW.user_id
        AND training_date = NEW.training_date
        AND status = 'completed'
        AND id != NEW.id
    ) INTO v_existing_completion;

    -- Log the attempt
    PERFORM log_training_completion_attempt(
      NEW.user_id,
      NEW.id,
      NEW.training_date,
      OLD.status,
      NEW.status,
      v_existing_completion,
      CASE WHEN v_existing_completion THEN 'Multiple completion attempt blocked' ELSE NULL END
    );

    -- Raise exception if trying to complete multiple trainings on same day
    IF v_existing_completion THEN
      RAISE EXCEPTION 'User has already completed a training for this date. Only one training per day is allowed.'
        USING HINT = 'Each user can only complete one training per day.';
    END IF;

    -- Set completed_at to server time to prevent manipulation
    NEW.completed_at := now();
  END IF;

  RETURN NEW;
END;
$$;