/*
  # Sistema de Tempo Real - Tabelas Base

  1. Novas Tabelas
    - `peneiras` (oportunidades de teste em clubes)
      - `id` (uuid, primary key)
      - `club_name` (text)
      - `title` (text)
      - `description` (text)
      - `location_city` (text)
      - `location_state` (text)
      - `location_address` (text)
      - `event_date` (timestamptz)
      - `event_time` (text)
      - `age_range_min` (integer)
      - `age_range_max` (integer)
      - `positions` (text[])
      - `max_participants` (integer)
      - `current_participants` (integer, default 0)
      - `status` (text: aberta/fechando/encerrada)
      - `fee_amount` (decimal)
      - `fee_currency` (text, default 'BRL')
      - `requirements` (text[])
      - `contact_email` (text)
      - `contact_phone` (text)
      - `priority` (text: alta/media/baixa)
      - `is_featured` (boolean)
      - `created_by` (uuid, references auth.users)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `peneira_registrations` (inscrições em peneiras)
      - `id` (uuid, primary key)
      - `peneira_id` (uuid, references peneiras)
      - `user_id` (uuid, references auth.users)
      - `status` (text: pending/confirmed/cancelled)
      - `payment_status` (text: pending/paid/failed/refunded)
      - `payment_id` (text)
      - `registered_at` (timestamptz)
      - `confirmed_at` (timestamptz)

    - `real_time_notifications` (notificações do sistema)
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `type` (text: peneira/ranking/achievement/message/payment)
      - `title` (text)
      - `message` (text)
      - `data` (jsonb)
      - `is_read` (boolean, default false)
      - `priority` (text: high/medium/low)
      - `created_at` (timestamptz)

    - `marketplace_products` (produtos do marketplace)
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `category` (text)
      - `brand` (text)
      - `price` (decimal)
      - `original_price` (decimal)
      - `discount_percent` (integer)
      - `stock_quantity` (integer)
      - `images` (text[])
      - `features` (text[])
      - `colors` (text[])
      - `sizes` (text[])
      - `rating` (decimal)
      - `review_count` (integer)
      - `is_featured` (boolean)
      - `is_available` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `marketplace_orders` (pedidos do marketplace)
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `order_number` (text)
      - `total_amount` (decimal)
      - `payment_method` (text)
      - `payment_status` (text: pending/paid/failed/refunded)
      - `payment_id` (text)
      - `order_status` (text: pending/processing/shipped/delivered/cancelled)
      - `items` (jsonb)
      - `shipping_address` (jsonb)
      - `tracking_code` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `chat_messages` (mensagens entre usuários)
      - `id` (uuid, primary key)
      - `sender_id` (uuid, references auth.users)
      - `receiver_id` (uuid, references auth.users)
      - `message` (text)
      - `is_read` (boolean, default false)
      - `read_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Segurança
    - Habilitar RLS em todas as tabelas
    - Políticas para usuários autenticados gerenciarem seus dados
    - Políticas de leitura pública para peneiras e produtos
    - Políticas restritas para mensagens e notificações

  3. Índices
    - Índices para queries de tempo real
    - Índices compostos para filtragem eficiente
*/

-- Tabela de Peneiras
CREATE TABLE IF NOT EXISTS peneiras (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  club_name text NOT NULL,
  club_logo text,
  title text NOT NULL,
  description text NOT NULL,
  location_city text NOT NULL,
  location_state text NOT NULL,
  location_address text NOT NULL,
  event_date timestamptz NOT NULL,
  event_time text NOT NULL,
  age_range_min integer NOT NULL,
  age_range_max integer NOT NULL,
  positions text[] NOT NULL DEFAULT '{}',
  max_participants integer NOT NULL,
  current_participants integer DEFAULT 0,
  status text DEFAULT 'aberta' CHECK (status IN ('aberta', 'fechando', 'encerrada')),
  fee_amount decimal(10,2) DEFAULT 0,
  fee_currency text DEFAULT 'BRL',
  requirements text[] DEFAULT '{}',
  contact_email text,
  contact_phone text,
  priority text DEFAULT 'media' CHECK (priority IN ('alta', 'media', 'baixa')),
  is_featured boolean DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE peneiras ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view open peneiras"
  ON peneiras FOR SELECT
  TO public
  USING (status != 'encerrada' OR created_at > now() - interval '30 days');

CREATE POLICY "Authenticated users can create peneiras"
  ON peneiras FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Creators can update their peneiras"
  ON peneiras FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

-- Tabela de Inscrições em Peneiras
CREATE TABLE IF NOT EXISTS peneira_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  peneira_id uuid REFERENCES peneiras(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled')),
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_id text,
  registered_at timestamptz DEFAULT now(),
  confirmed_at timestamptz,
  UNIQUE(peneira_id, user_id)
);

ALTER TABLE peneira_registrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their registrations"
  ON peneira_registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can register for peneiras"
  ON peneira_registrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their registrations"
  ON peneira_registrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Tabela de Notificações em Tempo Real
CREATE TABLE IF NOT EXISTS real_time_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('peneira', 'ranking', 'achievement', 'message', 'payment', 'system')),
  title text NOT NULL,
  message text NOT NULL,
  data jsonb DEFAULT '{}'::jsonb,
  is_read boolean DEFAULT false,
  priority text DEFAULT 'medium' CHECK (priority IN ('high', 'medium', 'low')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE real_time_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their notifications"
  ON real_time_notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their notifications"
  ON real_time_notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Tabela de Produtos do Marketplace
CREATE TABLE IF NOT EXISTS marketplace_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  brand text,
  price decimal(10,2) NOT NULL,
  original_price decimal(10,2),
  discount_percent integer DEFAULT 0,
  stock_quantity integer DEFAULT 0,
  images text[] DEFAULT '{}',
  features text[] DEFAULT '{}',
  colors text[] DEFAULT '{}',
  sizes text[] DEFAULT '{}',
  rating decimal(2,1) DEFAULT 0,
  review_count integer DEFAULT 0,
  is_featured boolean DEFAULT false,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE marketplace_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available products"
  ON marketplace_products FOR SELECT
  TO public
  USING (is_available = true);

-- Tabela de Pedidos do Marketplace
CREATE TABLE IF NOT EXISTS marketplace_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  order_number text UNIQUE NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  payment_method text NOT NULL,
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_id text,
  order_status text DEFAULT 'pending' CHECK (order_status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  items jsonb NOT NULL,
  shipping_address jsonb NOT NULL,
  tracking_code text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE marketplace_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their orders"
  ON marketplace_orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create orders"
  ON marketplace_orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Tabela de Mensagens de Chat
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Receivers can mark messages as read"
  ON chat_messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = receiver_id);

-- Índices para Performance
CREATE INDEX IF NOT EXISTS idx_peneiras_status ON peneiras(status);
CREATE INDEX IF NOT EXISTS idx_peneiras_date ON peneiras(event_date);
CREATE INDEX IF NOT EXISTS idx_peneiras_location ON peneiras(location_state, location_city);
CREATE INDEX IF NOT EXISTS idx_peneira_registrations_user ON peneira_registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_peneira_registrations_peneira ON peneira_registrations(peneira_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON real_time_notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_marketplace_products_category ON marketplace_products(category);
CREATE INDEX IF NOT EXISTS idx_marketplace_orders_user ON marketplace_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_sender ON chat_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_receiver ON chat_messages(receiver_id);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_peneiras_updated_at BEFORE UPDATE ON peneiras
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_marketplace_products_updated_at BEFORE UPDATE ON marketplace_products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_marketplace_orders_updated_at BEFORE UPDATE ON marketplace_orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Inserir peneiras de exemplo
INSERT INTO peneiras (club_name, club_logo, title, description, location_city, location_state, location_address, event_date, event_time, age_range_min, age_range_max, positions, max_participants, current_participants, status, fee_amount, requirements, contact_email, priority, is_featured) VALUES
('Santos FC', '⚪', 'Peneira Sub-20 - Categoria de Base', 'O Santos FC está em busca de jovens talentos para integrar as categorias de base do clube.', 'Santos', 'SP', 'Vila Belmiro - Av. Princesa Isabel, 77', '2025-11-15 14:00:00', '14:00', 16, 20, ARRAY['Atacante', 'Meio-campo', 'Lateral'], 100, 67, 'aberta', 0, ARRAY['Documento com foto', 'Atestado médico', 'Chuteira'], 'peneiras@santosfc.com.br', 'alta', true),
('Palmeiras', '🟢', 'Seleção para Academia de Futebol', 'Oportunidade única para integrar a renomada Academia de Futebol do Palmeiras.', 'São Paulo', 'SP', 'Academia de Futebol - Av. Presidente Castelo Branco', '2025-11-20 09:00:00', '09:00', 17, 21, ARRAY['Zagueiro', 'Volante', 'Atacante'], 80, 45, 'aberta', 50, ARRAY['RG', 'CPF', 'Comprovante de residência', 'Atestado médico'], 'captacao@palmeiras.com.br', 'alta', true),
('Corinthians', '⚫', 'Peneira Feminina - Corinthians/Audax', 'Seleção para o time feminino profissional do Sport Club Corinthians Paulista.', 'São Paulo', 'SP', 'CT Dr. Joaquim Grava - Rua São Jorge, 777', '2025-11-18 15:30:00', '15:30', 18, 25, ARRAY['Todas as posições'], 60, 58, 'fechando', 0, ARRAY['Documento com foto', 'Atestado médico', 'Experiência comprovada'], 'futebol.feminino@corinthians.com.br', 'alta', true),
('São Paulo FC', '🔴', 'Captação de Talentos - Cotia', 'O São Paulo FC busca jovens promessas para as categorias de base em Cotia.', 'Cotia', 'SP', 'Centro de Treinamento - Av. Robert Kennedy, 1000', '2025-11-25 08:00:00', '08:00', 15, 19, ARRAY['Goleiro', 'Zagueiro', 'Meio-campo'], 120, 23, 'aberta', 30, ARRAY['RG', 'Atestado médico', 'Autorização dos pais (menores)'], 'base@saopaulofc.net', 'media', false),
('Flamengo', '🔴', 'Peneira Nacional - Ninho do Urubu', 'Peneira nacional do Clube de Regatas do Flamengo para descobrir novos talentos.', 'Rio de Janeiro', 'RJ', 'CT Ninho do Urubu - Estrada Boca do Mato, s/n', '2025-12-01 07:00:00', '07:00', 16, 22, ARRAY['Todas as posições'], 200, 156, 'aberta', 80, ARRAY['Documento com foto', 'Atestado médico', 'Comprovante de vacinação'], 'peneiras@flamengo.com.br', 'alta', true);
