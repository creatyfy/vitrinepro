/*
  # Sistema Completo de Nutrição - Vitrine Pro

  ## Resumo
  Este migration expande o sistema de nutrição existente adicionando:
  - Receitas completas com ingredientes e modo de preparo
  - Planos alimentares personalizados por objetivo
  - Histórico de alimentação do atleta
  - Sistema de recomendações inteligentes
  - Pontuação nutricional e níveis de progresso
  - Modo PRO com recursos exclusivos
  
  ## Novas Tabelas
  
  ### 1. nutrition_recipes (Receitas Completas)
  - `id` (uuid, primary key)
  - `dish_id` (uuid, referência a nutrition_dishes)
  - `ingredients` (jsonb, lista de ingredientes)
  - `preparation_steps` (jsonb, passo a passo)
  - `cooking_time` (integer, minutos)
  - `difficulty` (text, fácil/médio/difícil)
  - `nutritional_info` (jsonb, calorias, proteínas, etc)
  - `tips` (text, dicas extras)
  
  ### 2. nutrition_meal_plans (Planos Alimentares)
  - `id` (uuid, primary key)
  - `name` (text, nome do plano)
  - `goal` (text, ganho_massa/definicao/resistencia)
  - `description` (text, descrição do objetivo)
  - `is_pro` (boolean, se é exclusivo PRO)
  - `daily_calories` (integer, meta calórica)
  - `macros` (jsonb, distribuição de macros)
  
  ### 3. nutrition_meal_plan_items (Itens dos Planos)
  - `id` (uuid, primary key)
  - `meal_plan_id` (uuid, referência a nutrition_meal_plans)
  - `meal_type` (text, cafe/lanche_manha/almoco/lanche_tarde/jantar)
  - `meal_order` (integer, ordem da refeição)
  - `foods` (jsonb, lista de alimentos)
  - `time_range` (text, horário sugerido)
  - `alternatives` (jsonb, substituições possíveis)
  
  ### 4. athlete_meal_history (Histórico de Alimentação)
  - `id` (uuid, primary key)
  - `user_id` (uuid, referência ao atleta)
  - `submission_id` (uuid, referência a nutrition_submissions)
  - `meal_type` (text, tipo de refeição)
  - `date` (date, data da refeição)
  - `points_earned` (integer, pontos ganhos)
  - `quality_score` (integer, nota de 0-100)
  
  ### 5. athlete_nutrition_stats (Estatísticas Nutricionais)
  - `user_id` (uuid, primary key, referência ao atleta)
  - `current_level` (integer, nível nutricional atual)
  - `total_nutrition_points` (integer, pontos totais de nutrição)
  - `current_streak` (integer, dias consecutivos)
  - `longest_streak` (integer, maior sequência)
  - `meals_completed` (integer, refeições completas)
  - `quality_average` (numeric, média de qualidade)
  - `last_updated` (timestamptz, última atualização)
  
  ### 6. nutrition_smart_recommendations (Recomendações Inteligentes)
  - `id` (uuid, primary key)
  - `food_original` (text, alimento original)
  - `food_alternative` (text, alternativa sugerida)
  - `reason` (text, motivo da substituição)
  - `category` (text, categoria do alimento)
  - `is_active` (boolean, se está ativa)
  
  ### 7. nutrition_weekly_challenges (Desafios Semanais)
  - `id` (uuid, primary key)
  - `week_start` (date, início da semana)
  - `week_end` (date, fim da semana)
  - `recipe_id` (uuid, referência a nutrition_recipes)
  - `dish_id` (uuid, referência a nutrition_dishes)
  - `is_active` (boolean, se está ativo)
  - `created_at` (timestamptz)
  
  ## Segurança (RLS)
  - Atletas podem ver apenas seus próprios dados de histórico e estatísticas
  - Planos alimentares são visíveis para todos autenticados
  - Planos PRO só aparecem para usuários com assinatura PRO
  - Recomendações são públicas para todos autenticados
  
  ## Índices
  - Índices em user_id para queries rápidas de histórico
  - Índices em date para filtros temporais
  - Índices em meal_plan_id para busca de itens
  - Índices compostos para otimização de queries complexas
*/

-- 1. Nutrition Recipes (Receitas Completas)
CREATE TABLE IF NOT EXISTS nutrition_recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dish_id uuid REFERENCES nutrition_dishes(id) ON DELETE CASCADE,
  ingredients jsonb NOT NULL DEFAULT '[]'::jsonb,
  preparation_steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  cooking_time integer DEFAULT 30,
  difficulty text DEFAULT 'easy' CHECK (difficulty IN ('easy', 'medium', 'hard')),
  nutritional_info jsonb DEFAULT '{}'::jsonb,
  tips text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_recipes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view recipes"
  ON nutrition_recipes FOR SELECT
  TO authenticated
  USING (true);

-- 2. Nutrition Meal Plans (Planos Alimentares)
CREATE TABLE IF NOT EXISTS nutrition_meal_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  goal text NOT NULL CHECK (goal IN ('ganho_massa', 'definicao', 'resistencia', 'manutencao')),
  description text NOT NULL,
  is_pro boolean DEFAULT false,
  daily_calories integer DEFAULT 2800,
  macros jsonb DEFAULT '{"protein": 140, "carbs": 350, "fats": 80}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_meal_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view free meal plans"
  ON nutrition_meal_plans FOR SELECT
  TO authenticated
  USING (is_pro = false OR is_pro IS NULL);

CREATE POLICY "PRO users can view all meal plans"
  ON nutrition_meal_plans FOR SELECT
  TO authenticated
  USING (true);

-- 3. Nutrition Meal Plan Items (Itens dos Planos)
CREATE TABLE IF NOT EXISTS nutrition_meal_plan_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meal_plan_id uuid NOT NULL REFERENCES nutrition_meal_plans(id) ON DELETE CASCADE,
  meal_type text NOT NULL CHECK (meal_type IN ('cafe_manha', 'lanche_manha', 'almoco', 'lanche_tarde', 'pre_treino', 'pos_treino', 'jantar')),
  meal_order integer NOT NULL,
  foods jsonb NOT NULL DEFAULT '[]'::jsonb,
  time_range text DEFAULT '08:00-10:00',
  alternatives jsonb DEFAULT '[]'::jsonb,
  calories integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_meal_plan_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view meal plan items"
  ON nutrition_meal_plan_items FOR SELECT
  TO authenticated
  USING (true);

-- 4. Athlete Meal History (Histórico de Alimentação)
CREATE TABLE IF NOT EXISTS athlete_meal_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  submission_id uuid REFERENCES nutrition_submissions(id) ON DELETE SET NULL,
  meal_type text,
  date date NOT NULL DEFAULT CURRENT_DATE,
  points_earned integer DEFAULT 0,
  quality_score integer DEFAULT 0 CHECK (quality_score >= 0 AND quality_score <= 100),
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE athlete_meal_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own meal history"
  ON athlete_meal_history FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own meal history"
  ON athlete_meal_history FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- 5. Athlete Nutrition Stats (Estatísticas Nutricionais)
CREATE TABLE IF NOT EXISTS athlete_nutrition_stats (
  user_id uuid PRIMARY KEY,
  current_level integer DEFAULT 1,
  total_nutrition_points integer DEFAULT 0,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  meals_completed integer DEFAULT 0,
  quality_average numeric(5,2) DEFAULT 0.0,
  last_meal_date date,
  last_updated timestamptz DEFAULT now()
);

ALTER TABLE athlete_nutrition_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own nutrition stats"
  ON athlete_nutrition_stats FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own nutrition stats"
  ON athlete_nutrition_stats FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own nutrition stats"
  ON athlete_nutrition_stats FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- 6. Nutrition Smart Recommendations (Recomendações Inteligentes)
CREATE TABLE IF NOT EXISTS nutrition_smart_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  food_original text NOT NULL,
  food_alternative text NOT NULL,
  reason text NOT NULL,
  category text DEFAULT 'geral' CHECK (category IN ('proteina', 'carboidrato', 'gordura', 'fruta', 'vegetal', 'geral')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_smart_recommendations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active recommendations"
  ON nutrition_smart_recommendations FOR SELECT
  TO authenticated
  USING (is_active = true);

-- 7. Nutrition Weekly Challenges (Desafios Semanais)
CREATE TABLE IF NOT EXISTS nutrition_weekly_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  week_start date NOT NULL,
  week_end date NOT NULL,
  recipe_id uuid REFERENCES nutrition_recipes(id) ON DELETE SET NULL,
  dish_id uuid REFERENCES nutrition_dishes(id) ON DELETE CASCADE,
  gesture_code text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(week_start)
);

ALTER TABLE nutrition_weekly_challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view weekly challenges"
  ON nutrition_weekly_challenges FOR SELECT
  TO authenticated
  USING (true);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_recipes_dish_id ON nutrition_recipes(dish_id);
CREATE INDEX IF NOT EXISTS idx_meal_plan_items_plan_id ON nutrition_meal_plan_items(meal_plan_id);
CREATE INDEX IF NOT EXISTS idx_meal_plan_items_meal_type ON nutrition_meal_plan_items(meal_type);
CREATE INDEX IF NOT EXISTS idx_athlete_meal_history_user_date ON athlete_meal_history(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_athlete_meal_history_submission ON athlete_meal_history(submission_id);
CREATE INDEX IF NOT EXISTS idx_nutrition_stats_user ON athlete_nutrition_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_weekly_challenges_active ON nutrition_weekly_challenges(is_active, week_start DESC);
CREATE INDEX IF NOT EXISTS idx_smart_recommendations_active ON nutrition_smart_recommendations(is_active, category);

-- Inserir receitas completas para os pratos existentes
INSERT INTO nutrition_recipes (dish_id, ingredients, preparation_steps, cooking_time, difficulty, nutritional_info, tips)
SELECT 
  id,
  '[
    {"item": "1 banana madura", "quantity": "1 unidade"},
    {"item": "Aveia em flocos", "quantity": "3 colheres de sopa"},
    {"item": "Mel", "quantity": "1 colher de chá (opcional)"},
    {"item": "Canela em pó", "quantity": "A gosto"}
  ]'::jsonb,
  '[
    "Descasque e fatie a banana em rodelas médias",
    "Coloque as fatias de banana em uma tigela",
    "Adicione a aveia em flocos por cima",
    "Polvilhe canela em pó a gosto",
    "Se desejar, adicione mel para adoçar",
    "Misture bem e sirva imediatamente"
  ]'::jsonb,
  5,
  'easy',
  '{"calories": 250, "protein": 6, "carbs": 52, "fats": 3, "fiber": 7}'::jsonb,
  'Dica: Você pode adicionar outras frutas como morango ou blueberry para variar. A banana deve estar bem madura para ficar mais doce naturalmente.'
FROM nutrition_dishes
WHERE name = 'Banana com Aveia'
ON CONFLICT DO NOTHING;

INSERT INTO nutrition_recipes (dish_id, ingredients, preparation_steps, cooking_time, difficulty, nutritional_info, tips)
SELECT 
  id,
  '[
    {"item": "Tomate maduro", "quantity": "2 unidades médias"},
    {"item": "Alface crespa", "quantity": "4 folhas"},
    {"item": "Azeite extra virgem", "quantity": "1 colher de sopa"},
    {"item": "Limão", "quantity": "Suco de meio limão"},
    {"item": "Sal", "quantity": "A gosto"}
  ]'::jsonb,
  '[
    "Lave bem os tomates e a alface em água corrente",
    "Corte os tomates em cubos médios",
    "Rasgue as folhas de alface com as mãos",
    "Coloque tudo em uma saladeira",
    "Regue com azeite e suco de limão",
    "Tempere com sal a gosto e misture delicadamente"
  ]'::jsonb,
  10,
  'easy',
  '{"calories": 120, "protein": 2, "carbs": 8, "fats": 9, "fiber": 3}'::jsonb,
  'Dica: Adicione sementes de chia ou gergelim para aumentar o valor nutricional. Sirva sempre fresca.'
FROM nutrition_dishes
WHERE name = 'Salada de Tomate com Alface'
ON CONFLICT DO NOTHING;

-- Inserir planos alimentares padrão
INSERT INTO nutrition_meal_plans (name, goal, description, is_pro, daily_calories, macros) VALUES
('Ganho de Massa Muscular', 'ganho_massa', 'Plano focado em hipertrofia com alto teor proteico e calórico controlado', false, 3200, '{"protein": 180, "carbs": 400, "fats": 90}'::jsonb),
('Definição Muscular', 'definicao', 'Plano para redução de gordura mantendo massa muscular', false, 2400, '{"protein": 150, "carbs": 250, "fats": 70}'::jsonb),
('Resistência e Performance', 'resistencia', 'Plano com foco em energia sustentada para atletas de alta performance', false, 2900, '{"protein": 130, "carbs": 380, "fats": 75}'::jsonb),
('Manutenção Saudável', 'manutencao', 'Plano balanceado para manter peso e saúde', false, 2600, '{"protein": 140, "carbs": 320, "fats": 80}'::jsonb),
('Profissional - Ganho Extremo', 'ganho_massa', 'Plano avançado com suplementação para atletas profissionais', true, 3800, '{"protein": 220, "carbs": 450, "fats": 100}'::jsonb),
('Profissional - Cutting', 'definicao', 'Plano profissional para definição extrema pré-competição', true, 2000, '{"protein": 180, "carbs": 180, "fats": 50}'::jsonb)
ON CONFLICT DO NOTHING;

-- Inserir itens do plano "Ganho de Massa Muscular"
DO $$
DECLARE
  v_plan_id uuid;
BEGIN
  SELECT id INTO v_plan_id FROM nutrition_meal_plans WHERE name = 'Ganho de Massa Muscular' LIMIT 1;
  
  IF v_plan_id IS NOT NULL THEN
    INSERT INTO nutrition_meal_plan_items (meal_plan_id, meal_type, meal_order, foods, time_range, alternatives, calories) VALUES
    (v_plan_id, 'cafe_manha', 1, '["Aveia 100g", "Banana 2 unidades", "Ovos mexidos 4 unidades", "Pão integral 2 fatias", "Suco de laranja 200ml"]'::jsonb, '06:00-08:00', '["Tapioca", "Batata doce", "Whey protein"]'::jsonb, 650),
    (v_plan_id, 'lanche_manha', 2, '["Iogurte grego 200g", "Granola 50g", "Mel 1 colher", "Castanhas 30g"]'::jsonb, '09:30-10:30', '["Pasta de amendoim", "Frutas secas", "Mix de nuts"]'::jsonb, 450),
    (v_plan_id, 'almoco', 3, '["Arroz integral 150g", "Frango grelhado 200g", "Feijão 100g", "Batata doce 150g", "Salada verde à vontade"]'::jsonb, '12:00-13:30', '["Peixe", "Carne vermelha magra", "Macarrão integral"]'::jsonb, 850),
    (v_plan_id, 'pre_treino', 4, '["Batata doce 200g", "Peito de frango 150g", "Água de coco 300ml"]'::jsonb, '14:30-15:30', '["Tapioca", "Pão integral", "Banana com pasta de amendoim"]'::jsonb, 500),
    (v_plan_id, 'pos_treino', 5, '["Whey protein 30g", "Dextrose 30g", "Água 500ml"]'::jsonb, '17:00-18:00', '["Vitamina de frutas", "Sanduíche natural"]'::jsonb, 250),
    (v_plan_id, 'jantar', 6, '["Salmão grelhado 200g", "Arroz integral 100g", "Brócolis cozido 150g", "Salada colorida à vontade"]'::jsonb, '19:00-20:30', '["Tilápia", "Atum", "Frango"]'::jsonb, 700)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- Inserir recomendações inteligentes
INSERT INTO nutrition_smart_recommendations (food_original, food_alternative, reason, category) VALUES
('Iogurte', 'Leite vegetal', 'Para intolerantes à lactose', 'proteina'),
('Banana', 'Maçã', 'Menor índice glicêmico', 'fruta'),
('Arroz branco', 'Arroz integral', 'Maior teor de fibras', 'carboidrato'),
('Frango', 'Peixe', 'Menor teor de gordura', 'proteina'),
('Pão branco', 'Pão integral', 'Melhor digestão e mais nutrientes', 'carboidrato'),
('Açúcar', 'Mel', 'Adoçante natural com minerais', 'geral'),
('Leite integral', 'Leite desnatado', 'Menos calorias e gorduras', 'proteina'),
('Batata frita', 'Batata doce', 'Carboidrato de baixo índice glicêmico', 'carboidrato'),
('Refrigerante', 'Água de coco', 'Hidratação natural sem açúcar', 'geral'),
('Manteiga', 'Abacate', 'Gordura saudável', 'gordura')
ON CONFLICT DO NOTHING;

-- Função para atualizar estatísticas nutricionais automaticamente
CREATE OR REPLACE FUNCTION update_athlete_nutrition_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_new_streak integer := 0;
  v_last_meal_date date;
  v_quality_avg numeric(5,2);
BEGIN
  -- Inserir ou buscar estatísticas do atleta
  INSERT INTO athlete_nutrition_stats (user_id, total_nutrition_points, meals_completed)
  VALUES (NEW.user_id, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;
  
  -- Buscar data da última refeição
  SELECT last_meal_date INTO v_last_meal_date
  FROM athlete_nutrition_stats
  WHERE user_id = NEW.user_id;
  
  -- Calcular streak
  IF v_last_meal_date IS NULL THEN
    v_new_streak := 1;
  ELSIF NEW.date = v_last_meal_date + INTERVAL '1 day' THEN
    SELECT current_streak + 1 INTO v_new_streak
    FROM athlete_nutrition_stats
    WHERE user_id = NEW.user_id;
  ELSIF NEW.date = v_last_meal_date THEN
    SELECT current_streak INTO v_new_streak
    FROM athlete_nutrition_stats
    WHERE user_id = NEW.user_id;
  ELSE
    v_new_streak := 1;
  END IF;
  
  -- Calcular média de qualidade
  SELECT AVG(quality_score)::numeric(5,2) INTO v_quality_avg
  FROM athlete_meal_history
  WHERE user_id = NEW.user_id;
  
  -- Atualizar estatísticas
  UPDATE athlete_nutrition_stats
  SET
    total_nutrition_points = total_nutrition_points + NEW.points_earned,
    current_streak = v_new_streak,
    longest_streak = GREATEST(longest_streak, v_new_streak),
    meals_completed = meals_completed + 1,
    quality_average = COALESCE(v_quality_avg, 0),
    last_meal_date = NEW.date,
    last_updated = now(),
    current_level = FLOOR((total_nutrition_points + NEW.points_earned) / 1000.0) + 1
  WHERE user_id = NEW.user_id;
  
  RETURN NEW;
END;
$$;

-- Trigger para atualizar estatísticas automaticamente
DROP TRIGGER IF EXISTS trigger_update_nutrition_stats ON athlete_meal_history;
CREATE TRIGGER trigger_update_nutrition_stats
  AFTER INSERT ON athlete_meal_history
  FOR EACH ROW
  EXECUTE FUNCTION update_athlete_nutrition_stats();

-- Comentários nas tabelas
COMMENT ON TABLE nutrition_recipes IS 'Receitas completas com ingredientes e modo de preparo detalhado';
COMMENT ON TABLE nutrition_meal_plans IS 'Planos alimentares personalizados por objetivo do atleta';
COMMENT ON TABLE nutrition_meal_plan_items IS 'Itens individuais dos planos alimentares por refeição';
COMMENT ON TABLE athlete_meal_history IS 'Histórico completo de alimentação do atleta';
COMMENT ON TABLE athlete_nutrition_stats IS 'Estatísticas e níveis nutricionais do atleta';
COMMENT ON TABLE nutrition_smart_recommendations IS 'Sistema de recomendações inteligentes de substituição de alimentos';
COMMENT ON TABLE nutrition_weekly_challenges IS 'Desafios nutricionais semanais com receitas específicas';
