/*
  # Sync Quiz Data to Player Profiles

  1. Updates
    - Add quiz_completed flag to player_profiles
    - Add function to sync Quiz data from app state to profile
    - Ensure profile can be pre-filled without losing Quiz data

  2. Changes
    - Make more fields nullable (not all required at once)
    - Add default values for better UX
    - Add updated_at trigger already exists

  3. Notes
    - This migration is idempotent (safe to run multiple times)
    - Existing data is preserved
    - No data loss occurs
*/

-- Add quiz_completed flag if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'quiz_completed'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN quiz_completed boolean DEFAULT false;
  END IF;
END $$;

-- Add secondary_position if position_2 doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'player_profiles' AND column_name = 'position_2'
  ) THEN
    ALTER TABLE player_profiles ADD COLUMN position_2 text;
  END IF;
END $$;

-- Make fields more flexible (nullable where appropriate)
ALTER TABLE player_profiles
  ALTER COLUMN name DROP NOT NULL,
  ALTER COLUMN birth_date DROP NOT NULL,
  ALTER COLUMN city DROP NOT NULL,
  ALTER COLUMN state DROP NOT NULL;

-- Function to merge Quiz data into profile (upsert with smart defaults)
CREATE OR REPLACE FUNCTION upsert_profile_from_quiz(
  p_user_id uuid,
  p_name text DEFAULT NULL,
  p_birth_date date DEFAULT NULL,
  p_gender text DEFAULT NULL,
  p_height_cm integer DEFAULT NULL,
  p_weight_kg integer DEFAULT NULL,
  p_position text DEFAULT NULL,
  p_city text DEFAULT NULL,
  p_state text DEFAULT NULL,
  p_country text DEFAULT 'Brasil'
)
RETURNS player_profiles AS $$
DECLARE
  v_profile player_profiles;
BEGIN
  INSERT INTO player_profiles (
    user_id,
    name,
    birth_date,
    gender,
    height_cm,
    weight_kg,
    position_1,
    city,
    state,
    country,
    quiz_completed
  )
  VALUES (
    p_user_id,
    p_name,
    p_birth_date,
    p_gender,
    p_height_cm,
    p_weight_kg,
    p_position,
    p_city,
    p_state,
    COALESCE(p_country, 'Brasil'),
    true
  )
  ON CONFLICT (user_id) DO UPDATE SET
    name = COALESCE(EXCLUDED.name, player_profiles.name),
    birth_date = COALESCE(EXCLUDED.birth_date, player_profiles.birth_date),
    gender = COALESCE(EXCLUDED.gender, player_profiles.gender),
    height_cm = COALESCE(EXCLUDED.height_cm, player_profiles.height_cm),
    weight_kg = COALESCE(EXCLUDED.weight_kg, player_profiles.weight_kg),
    position_1 = COALESCE(EXCLUDED.position_1, player_profiles.position_1),
    city = COALESCE(EXCLUDED.city, player_profiles.city),
    state = COALESCE(EXCLUDED.state, player_profiles.state),
    country = COALESCE(EXCLUDED.country, player_profiles.country),
    quiz_completed = true,
    updated_at = now()
  RETURNING * INTO v_profile;
  
  RETURN v_profile;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION upsert_profile_from_quiz TO authenticated;
