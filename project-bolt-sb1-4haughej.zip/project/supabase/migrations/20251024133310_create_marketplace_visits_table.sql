/*
  # Create Marketplace Visits Tracking Table

  1. New Tables
    - `marketplace_visits`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `visited_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `marketplace_visits` table
    - Add policy for authenticated users to insert their own visits
    - Add policy for authenticated users to view their own visit history

  3. Purpose
    - Track when users access the external marketplace (FutFanatics)
    - Provide analytics on marketplace engagement
    - Help understand user behavior and marketplace effectiveness
*/

-- Create marketplace_visits table
CREATE TABLE IF NOT EXISTS marketplace_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  visited_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE marketplace_visits ENABLE ROW LEVEL SECURITY;

-- Policy: Users can insert their own marketplace visits
CREATE POLICY "Users can track own marketplace visits"
  ON marketplace_visits
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policy: Users can view their own marketplace visit history
CREATE POLICY "Users can view own marketplace visit history"
  ON marketplace_visits
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for faster queries by user_id
CREATE INDEX IF NOT EXISTS idx_marketplace_visits_user_id ON marketplace_visits(user_id);

-- Create index for faster queries by visited_at
CREATE INDEX IF NOT EXISTS idx_marketplace_visits_visited_at ON marketplace_visits(visited_at DESC);
