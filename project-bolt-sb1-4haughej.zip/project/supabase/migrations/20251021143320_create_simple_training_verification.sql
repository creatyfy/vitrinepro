/*
  # Sistema Simplificado de Verificação de Treino

  1. Nova Tabela
    - `training_verifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `training_session_id` (uuid)
      - `photo_submitted` (boolean) - se o usuário enviou foto
      - `points_awarded` (integer) - pontos ganhos (100 ou 50)
      - `created_at` (timestamptz)

  2. Segurança
    - Enable RLS na tabela
    - Políticas para usuários autenticados gerenciarem seus próprios dados

  3. Notas
    - Sistema simplificado: apenas verifica se foto foi enviada
    - Com foto = 100 pontos
    - Sem foto (pular) = 50 pontos
*/

-- Criar tabela de verificações de treino
CREATE TABLE IF NOT EXISTS training_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  training_session_id uuid NOT NULL,
  photo_submitted boolean DEFAULT false NOT NULL,
  points_awarded integer DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Ativar RLS
ALTER TABLE training_verifications ENABLE ROW LEVEL SECURITY;

-- Política: usuários podem ver suas próprias verificações
CREATE POLICY "Users can view own verifications"
  ON training_verifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Política: usuários podem inserir suas próprias verificações
CREATE POLICY "Users can insert own verifications"
  ON training_verifications FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_training_verifications_user_id ON training_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_training_verifications_session_id ON training_verifications(training_session_id);
CREATE INDEX IF NOT EXISTS idx_training_verifications_created_at ON training_verifications(created_at DESC);
