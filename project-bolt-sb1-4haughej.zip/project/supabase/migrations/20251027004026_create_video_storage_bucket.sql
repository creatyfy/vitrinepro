/*
  # Create Video Storage Bucket and Policies

  1. Storage Bucket
    - Create "player-videos" bucket for storing video files
    - Set to private (not public)
    - Configure max file size and allowed MIME types

  2. Storage Policies
    - Allow authenticated users to upload videos to their own folder
    - Allow authenticated users to read all non-deleted videos
    - Allow users to delete their own videos
    - Folder structure: {user_id}/{video_id}.{extension}

  3. Security
    - Enforce file size limits (max 100MB)
    - Only allow video MIME types (mp4, quicktime, webm)
    - Prevent unauthorized access through RLS
*/

-- Create the player-videos storage bucket if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'player-videos'
  ) THEN
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
      'player-videos',
      'player-videos',
      false,
      104857600,
      ARRAY['video/mp4', 'video/quicktime', 'video/webm', 'video/x-m4v']
    );
  END IF;
END $$;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can upload their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Users can view all videos" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own videos" ON storage.objects;

-- Policy: Users can upload videos to their own folder
CREATE POLICY "Users can upload their own videos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'player-videos' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- Policy: Authenticated users can view all videos (we'll control visibility via deleted_at in player_videos table)
CREATE POLICY "Users can view all videos"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'player-videos');

-- Policy: Users can update metadata of their own videos
CREATE POLICY "Users can update their own videos"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'player-videos' AND
    (storage.foldername(name))[1] = auth.uid()::text
  )
  WITH CHECK (
    bucket_id = 'player-videos' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- Policy: Users can delete their own videos
CREATE POLICY "Users can delete their own videos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'player-videos' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- Add storage_path column to player_videos table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'player_videos' 
    AND column_name = 'storage_path'
  ) THEN
    ALTER TABLE player_videos ADD COLUMN storage_path text;
  END IF;
END $$;

-- Create index on storage_path for faster lookups
CREATE INDEX IF NOT EXISTS idx_player_videos_storage_path ON player_videos(storage_path);
