/*
  # Update Proof Status System

  1. Updates to training_proofs table
    - Add status column (pending, approved, rejected, manual_review)
    - Add provisional_points column
    - Add final_points column
    - Add verification_completed_at timestamp
    - Add rejection_reason text
    - Add resubmission_count integer
    - Add auto_checks jsonb for detailed validation results
    - Add confidence_scores jsonb
    
  2. New Functions
    - Function to auto-verify proofs
    - Function to handle point adjustments

  3. Security
    - Update RLS policies
*/

-- Add new columns to training_proofs
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'status'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'manual_review'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'provisional_points'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN provisional_points integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'final_points'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN final_points integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'verification_completed_at'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN verification_completed_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'rejection_reason'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN rejection_reason text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'resubmission_count'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN resubmission_count integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'auto_checks'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN auto_checks jsonb DEFAULT '{}'::jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'confidence_scores'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN confidence_scores jsonb DEFAULT '{}'::jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'training_proofs' AND column_name = 'photo_url'
  ) THEN
    ALTER TABLE training_proofs ADD COLUMN photo_url text;
  END IF;
END $$;

-- Create audit log table for proof status changes
CREATE TABLE IF NOT EXISTS proof_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proof_id uuid REFERENCES training_proofs(id) NOT NULL,
  user_id uuid,
  action text NOT NULL,
  old_status text,
  new_status text,
  points_change integer,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE proof_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own proof audit logs"
  ON proof_audit_log FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create notification queue table
CREATE TABLE IF NOT EXISTS proof_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  proof_id uuid REFERENCES training_proofs(id),
  notification_type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  deep_link text,
  read boolean DEFAULT false,
  sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE proof_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON proof_notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON proof_notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create config table for thresholds
CREATE TABLE IF NOT EXISTS anti_cheat_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key text UNIQUE NOT NULL,
  config_value jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

-- Insert default config values
INSERT INTO anti_cheat_config (config_key, config_value)
VALUES 
  ('points_with_proof', '100'::jsonb),
  ('points_min', '5'::jsonb),
  ('threshold_approve', '0.80'::jsonb),
  ('threshold_manual', '0.50'::jsonb),
  ('threshold_reject', '0.30'::jsonb),
  ('auto_verify_timeout_seconds', '30'::jsonb),
  ('max_resubmissions_per_24h', '3'::jsonb)
ON CONFLICT (config_key) DO NOTHING;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_training_proofs_status ON training_proofs(status);
CREATE INDEX IF NOT EXISTS idx_proof_audit_log_proof_id ON proof_audit_log(proof_id);
CREATE INDEX IF NOT EXISTS idx_proof_notifications_user_id ON proof_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_proof_notifications_read ON proof_notifications(read);
