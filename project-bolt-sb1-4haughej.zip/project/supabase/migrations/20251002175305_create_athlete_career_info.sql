/*
  # Create Athlete Career Information Table

  1. Purpose
    - Store athlete career history (clubs, achievements, stats)
    - Support professional profile showcase
    - Enable career timeline display

  2. New Tables
    - `athlete_career`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `club_name` (text) - Name of club/team
      - `club_logo_url` (text) - Logo image URL
      - `position` (text) - Position played
      - `start_date` (date) - When started
      - `end_date` (date) - When ended (null if current)
      - `is_current` (boolean) - Currently playing here
      - `games_played` (integer) - Number of games
      - `goals_scored` (integer) - Goals scored
      - `assists` (integer) - Assists made
      - `achievements` (text[]) - Array of achievements
      - `is_professional` (boolean) - Professional or amateur
      - `display_order` (integer) - Sort order
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  3. Security
    - Enable RLS
    - Allow public read access
    - Allow authenticated users to manage their own data
*/

-- Create athlete career table
CREATE TABLE IF NOT EXISTS athlete_career (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  club_name text NOT NULL,
  club_logo_url text,
  position text,
  start_date date,
  end_date date,
  is_current boolean DEFAULT false,
  games_played integer DEFAULT 0,
  goals_scored integer DEFAULT 0,
  assists integer DEFAULT 0,
  achievements text[] DEFAULT '{}',
  is_professional boolean DEFAULT false,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_athlete_career_user_id ON athlete_career(user_id);
CREATE INDEX IF NOT EXISTS idx_athlete_career_is_current ON athlete_career(is_current);

-- Enable RLS
ALTER TABLE athlete_career ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Anyone can view athlete career"
  ON athlete_career FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can insert own career"
  ON athlete_career FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own career"
  ON athlete_career FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own career"
  ON athlete_career FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_athlete_career_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update updated_at
CREATE TRIGGER athlete_career_updated_at
  BEFORE UPDATE ON athlete_career
  FOR EACH ROW
  EXECUTE FUNCTION update_athlete_career_updated_at();
