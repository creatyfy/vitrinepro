/*
  # Corrigir Constraint de Telemetria

  1. Alterações
    - Remove a constraint de chave estrangeira para auth.users em video_telemetry
    - Permite que telemetria seja registrada mesmo sem usuário autenticado
    - Mantém o campo user_id para tracking futuro
    
  2. Notas
    - Isso resolve o erro 23503 quando não há usuários cadastrados
    - A telemetria continuará funcionando normalmente
*/

-- Remove a constraint de FK para auth.users
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'video_telemetry_user_id_fkey' 
    AND table_name = 'video_telemetry'
  ) THEN
    ALTER TABLE video_telemetry 
    DROP CONSTRAINT video_telemetry_user_id_fkey;
  END IF;
END $$;
