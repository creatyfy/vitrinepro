/*
  # Atualizar Ícones de Medalhas com Imagens Reais

  1. Alterações
    - Atualiza os ícones emoji das medalhas para URLs de imagens reais
    - Mapeia cada tipo de conquista para uma imagem específica de troféu ou medalha
    
  2. Medalhas Atualizadas
    - Primeira Semana → Medalha de Ouro com Jogador
    - Consistência 30 dias → Medalha de Ouro da Copa do Mundo
    - Destaque da Semana → Taça Dourada
    - Proposta de Clube → Troféu Champions League
    - Primeiro Treino → Medalha de Bronze Euro
    - Sequência de 7 → Medalha de Prata Champions
    - Duas Semanas → Medalha de Ouro Euro
    - Mestre dos Vídeos → Taça da Copa do Mundo
    - 1000 Pontos → Taça Libertadores
    - Top 10 → Troféu Premier League
*/

-- Atualizar ícones das medalhas com URLs das imagens reais
UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_39.png?medal=3'
WHERE medal_type = 'first_week' AND medal_icon LIKE '%🏆%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_39.png?medal=1'
WHERE medal_type = 'consistency_30' AND medal_icon LIKE '%🏆%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_43.png?trophy=4'
WHERE medal_type = 'week_highlight' AND medal_icon LIKE '%🏆%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_43.png?trophy=1'
WHERE medal_type = 'club_offer' AND medal_icon LIKE '%🏆%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_39.png?medal=4'
WHERE medal_type = 'first_training' AND medal_icon LIKE '%🏅%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_39.png?medal=2'
WHERE medal_type = 'streak_7' AND medal_icon LIKE '%🏅%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_39.png?medal=5'
WHERE medal_type = 'streak_14' AND medal_icon LIKE '%🔥%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_43.png?trophy=2'
WHERE medal_type = 'video_master' AND medal_icon LIKE '%🎥%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_43.png?trophy=3'
WHERE medal_type = 'points_1000' AND medal_icon LIKE '%⭐%';

UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_20_43.png?trophy=6'
WHERE medal_type = 'top_10' AND medal_icon LIKE '%👑%';
