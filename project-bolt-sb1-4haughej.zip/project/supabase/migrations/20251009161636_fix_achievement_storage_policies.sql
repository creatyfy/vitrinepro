/*
  # Fix Achievement Media Storage Policies
  
  1. Drop existing policies
  2. Create simpler, more permissive policies for testing
  3. Ensure users can upload and view their own media
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can upload their own achievement media" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own achievement media" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own draft achievement media" ON storage.objects;

-- Create new simplified policies
CREATE POLICY "Authenticated users can upload achievement media"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'achievement-media');

CREATE POLICY "Authenticated users can view achievement media"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'achievement-media');

CREATE POLICY "Authenticated users can delete achievement media"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'achievement-media');