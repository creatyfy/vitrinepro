/*
  # Atualizar Todas as Medalhas para Medalha Dourada

  1. Alterações
    - Atualiza todas as medalhas e troféus para usar a medalha dourada com estrela
    - Garante que todas as conquistas usem a mesma imagem que funciona
    
  2. Conquistas Atualizadas
    - Todas as medalhas → Medalha Dourada com Estrela
    - Todos os troféus → Medalha Dourada com Estrela
*/

-- Atualizar todas as medalhas existentes
UPDATE player_medals
SET medal_icon = '/ChatGPT Image 3 de out. de 2025, 01_36_03.png'
WHERE medal_icon IS NOT NULL;
