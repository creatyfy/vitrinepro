/*
  # Privacy and Security Tables Migration

  ## Overview
  Creates comprehensive privacy and security management system for Vitrine Pro application.

  ## New Tables

  ### 1. `user_privacy_settings`
  Stores all privacy preferences for each user:
  - `user_id` (uuid, FK to auth.users) - User identifier
  - `profile_visibility` (text) - "public", "connections_only", "private"
  - `video_visibility` (text) - Who can view videos
  - `show_training_history` (boolean) - Display training history
  - `show_statistics` (boolean) - Display performance stats
  - `show_location` (boolean) - Show location info
  - `show_age` (boolean) - Display age
  - `show_height_weight` (boolean) - Display physical metrics
  - `allow_club_messages` (boolean) - Receive messages from clubs
  - `allow_agent_messages` (boolean) - Receive messages from agents
  - `allow_athlete_messages` (boolean) - Receive messages from other athletes
  - `show_online_status` (boolean) - Show when user is online
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `blocked_users`
  Manages blocked users (clubs, agents, athletes):
  - `id` (uuid, PK) - Unique identifier
  - `blocker_id` (uuid, FK to auth.users) - User who blocked
  - `blocked_id` (uuid, FK to auth.users) - User who was blocked
  - `blocked_type` (text) - "club", "agent", "athlete"
  - `reason` (text) - Optional reason for blocking
  - `created_at` (timestamptz) - When block was created

  ### 3. `login_history`
  Tracks user login activity:
  - `id` (uuid, PK) - Unique identifier
  - `user_id` (uuid, FK to auth.users) - User identifier
  - `login_timestamp` (timestamptz) - When login occurred
  - `device_type` (text) - "mobile", "tablet", "desktop", "unknown"
  - `device_name` (text) - Device model/name
  - `browser` (text) - Browser used
  - `ip_address` (text) - IP address (encrypted)
  - `location_city` (text) - Approximate city
  - `location_country` (text) - Country
  - `is_suspicious` (boolean) - Flagged as suspicious
  - `session_id` (text) - Session identifier

  ### 4. `data_access_log`
  Logs when and who accessed user data:
  - `id` (uuid, PK) - Unique identifier
  - `user_id` (uuid, FK to auth.users) - User whose data was accessed
  - `accessor_id` (uuid, FK to auth.users) - Who accessed the data
  - `accessor_type` (text) - "club", "agent", "athlete", "system"
  - `data_type` (text) - What was accessed (profile, videos, stats, etc.)
  - `access_timestamp` (timestamptz) - When access occurred
  - `ip_address` (text) - IP address of accessor

  ### 5. `notification_preferences`
  Granular control over notifications:
  - `user_id` (uuid, FK to auth.users) - User identifier
  - `training_reminders` (boolean) - Training notifications
  - `peneira_alerts` (boolean) - Peneira/tryout notifications
  - `message_notifications` (boolean) - New message alerts
  - `achievement_notifications` (boolean) - Achievement unlocked alerts
  - `club_interest_notifications` (boolean) - Club interest notifications
  - `agent_interest_notifications` (boolean) - Agent interest notifications
  - `marketing_emails` (boolean) - Marketing communications
  - `newsletter` (boolean) - Newsletter subscription
  - `do_not_disturb_start` (time) - DND start time
  - `do_not_disturb_end` (time) - DND end time
  - `notification_frequency` (text) - "realtime", "daily", "weekly"
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 6. `two_factor_auth`
  Manages 2FA settings:
  - `user_id` (uuid, FK to auth.users) - User identifier
  - `is_enabled` (boolean) - 2FA enabled status
  - `method` (text) - "sms", "app", "email"
  - `phone_number` (text) - Phone for SMS (encrypted)
  - `backup_codes` (text[]) - Emergency backup codes (encrypted)
  - `created_at` (timestamptz) - When 2FA was enabled
  - `updated_at` (timestamptz) - Last update timestamp

  ## Security
  - Enable RLS on all tables
  - Users can only read/write their own data
  - Data access logs are append-only (no delete/update)
  - Login history is read-only for users
  - Sensitive data fields use encryption where appropriate

  ## Important Notes
  - All tables use `IF NOT EXISTS` to prevent errors
  - Default privacy settings are set to secure (private by default)
  - Timestamps use `now()` for automatic population
  - Foreign keys ensure referential integrity
*/

-- 1. User Privacy Settings Table
CREATE TABLE IF NOT EXISTS user_privacy_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_visibility text NOT NULL DEFAULT 'connections_only' CHECK (profile_visibility IN ('public', 'connections_only', 'private')),
  video_visibility text NOT NULL DEFAULT 'connections_only' CHECK (video_visibility IN ('public', 'connections_only', 'private')),
  show_training_history boolean DEFAULT true,
  show_statistics boolean DEFAULT true,
  show_location boolean DEFAULT false,
  show_age boolean DEFAULT true,
  show_height_weight boolean DEFAULT true,
  allow_club_messages boolean DEFAULT true,
  allow_agent_messages boolean DEFAULT true,
  allow_athlete_messages boolean DEFAULT true,
  show_online_status boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_privacy_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own privacy settings"
  ON user_privacy_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own privacy settings"
  ON user_privacy_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own privacy settings"
  ON user_privacy_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 2. Blocked Users Table
CREATE TABLE IF NOT EXISTS blocked_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_type text NOT NULL CHECK (blocked_type IN ('club', 'agent', 'athlete', 'other')),
  reason text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(blocker_id, blocked_id)
);

ALTER TABLE blocked_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own blocked list"
  ON blocked_users FOR SELECT
  TO authenticated
  USING (auth.uid() = blocker_id);

CREATE POLICY "Users can insert blocks"
  ON blocked_users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = blocker_id);

CREATE POLICY "Users can delete own blocks"
  ON blocked_users FOR DELETE
  TO authenticated
  USING (auth.uid() = blocker_id);

-- 3. Login History Table
CREATE TABLE IF NOT EXISTS login_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  login_timestamp timestamptz DEFAULT now(),
  device_type text DEFAULT 'unknown' CHECK (device_type IN ('mobile', 'tablet', 'desktop', 'unknown')),
  device_name text,
  browser text,
  ip_address text,
  location_city text,
  location_country text,
  is_suspicious boolean DEFAULT false,
  session_id text
);

ALTER TABLE login_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own login history"
  ON login_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 4. Data Access Log Table
CREATE TABLE IF NOT EXISTS data_access_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  accessor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  accessor_type text NOT NULL CHECK (accessor_type IN ('club', 'agent', 'athlete', 'system')),
  data_type text NOT NULL,
  access_timestamp timestamptz DEFAULT now(),
  ip_address text
);

ALTER TABLE data_access_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view who accessed their data"
  ON data_access_log FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 5. Notification Preferences Table
CREATE TABLE IF NOT EXISTS notification_preferences (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  training_reminders boolean DEFAULT true,
  peneira_alerts boolean DEFAULT true,
  message_notifications boolean DEFAULT true,
  achievement_notifications boolean DEFAULT true,
  club_interest_notifications boolean DEFAULT true,
  agent_interest_notifications boolean DEFAULT true,
  marketing_emails boolean DEFAULT false,
  newsletter boolean DEFAULT false,
  do_not_disturb_start time,
  do_not_disturb_end time,
  notification_frequency text DEFAULT 'realtime' CHECK (notification_frequency IN ('realtime', 'daily', 'weekly')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notification preferences"
  ON notification_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notification preferences"
  ON notification_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own notification preferences"
  ON notification_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 6. Two-Factor Authentication Table
CREATE TABLE IF NOT EXISTS two_factor_auth (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  is_enabled boolean DEFAULT false,
  method text CHECK (method IN ('sms', 'app', 'email')),
  phone_number text,
  backup_codes text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE two_factor_auth ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own 2FA settings"
  ON two_factor_auth FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own 2FA settings"
  ON two_factor_auth FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own 2FA settings"
  ON two_factor_auth FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_blocked_users_blocker ON blocked_users(blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocked_users_blocked ON blocked_users(blocked_id);
CREATE INDEX IF NOT EXISTS idx_login_history_user ON login_history(user_id, login_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_data_access_log_user ON data_access_log(user_id, access_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_data_access_log_accessor ON data_access_log(accessor_id);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for automatic timestamp updates
DROP TRIGGER IF EXISTS update_user_privacy_settings_updated_at ON user_privacy_settings;
CREATE TRIGGER update_user_privacy_settings_updated_at
  BEFORE UPDATE ON user_privacy_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_notification_preferences_updated_at ON notification_preferences;
CREATE TRIGGER update_notification_preferences_updated_at
  BEFORE UPDATE ON notification_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_two_factor_auth_updated_at ON two_factor_auth;
CREATE TRIGGER update_two_factor_auth_updated_at
  BEFORE UPDATE ON two_factor_auth
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();