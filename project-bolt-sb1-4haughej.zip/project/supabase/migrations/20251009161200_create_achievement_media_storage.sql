/*
  # Create Storage for Achievement Media
  
  1. Storage Bucket
    - Create 'achievement-media' bucket
    - Public access for verified media
    - Size limits and file type restrictions
  
  2. Security
    - RLS policies for upload/download
    - Only authenticated users can upload
    - Users can only access their own uploads during draft
    - Approved achievements become publicly viewable
*/

-- Create storage bucket for achievement media
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'achievement-media',
  'achievement-media',
  true,
  20971520,
  ARRAY['image/jpeg', 'image/png', 'image/heic', 'video/mp4']::text[]
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for achievement-media bucket
CREATE POLICY "Users can upload their own achievement media"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'achievement-media' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can view their own achievement media"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'achievement-media' AND
    (
      auth.uid()::text = (storage.foldername(name))[1] OR
      EXISTS (
        SELECT 1 FROM achievements
        WHERE achievements.id::text = (storage.foldername(name))[1]
        AND achievements.status = 'approved'
      )
    )
  );

CREATE POLICY "Users can delete their own draft achievement media"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'achievement-media' AND
    auth.uid()::text = (storage.foldername(name))[1] AND
    EXISTS (
      SELECT 1 FROM achievements
      WHERE achievements.id::text = (storage.foldername(name))[1]
      AND achievements.status = 'draft'
    )
  );